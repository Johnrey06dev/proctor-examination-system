#!/usr/bin/env python3
"""
tests/mysql_to_sqlite.py
Converts database/proctor_system.sql (MySQL) into a SQLite database so the PHP
logic can be tested on machines that have no MySQL server (developer tooling only).
Usage: python3 tests/mysql_to_sqlite.py database/proctor_system.sql out.sqlite
"""
import re, sys, sqlite3

src, out = sys.argv[1], sys.argv[2]
sql = open(src, encoding='utf-8').read()
sql = re.sub(r'--[^\n]*', '', sql)

# split statements
stmts = [s.strip() for s in sql.split(';\n') if s.strip()]
conn = sqlite3.connect(out)
conn.execute('PRAGMA foreign_keys=OFF')
for s in stmts:
    s = s.rstrip(';')
    u = s.upper()
    if u.startswith(('CREATE DATABASE', 'USE ', 'SET ')):
        continue
    if u.startswith('CREATE TABLE'):
        s = re.sub(r'\)\s*ENGINE=.*$', ')', s, flags=re.S)
        lines = s.split('\n')
        new = []
        for ln in lines:
            t = ln.strip()
            if re.match(r'^(PRIMARY KEY|KEY )', t):
                continue
            m = re.match(r'^UNIQUE KEY \w+ (\(.*?\)),?$', t)
            if m:
                ln = '  UNIQUE ' + m.group(1) + (',' if t.endswith(',') else '')
            ln = re.sub(r'ENUM\([^)]*\)', 'TEXT', ln)
            ln = re.sub(r'\bINT UNSIGNED NOT NULL AUTO_INCREMENT', '@@PK@@', ln)
            ln = re.sub(r'\b(TINYINT|INT)( UNSIGNED)?(\(\d+\))?', 'INTEGER', ln)
            ln = ln.replace('@@PK@@', 'INTEGER PRIMARY KEY AUTOINCREMENT')
            ln = re.sub(r'DECIMAL\(\d+,\d+\)', 'REAL', ln)
            ln = re.sub(r'VARCHAR\(\d+\)', 'TEXT', ln)
            new.append(ln)
        s = '\n'.join(new)
        # remove trailing commas before ')'
        s = re.sub(r',\s*\)\s*$', '\n)', s)
        s = re.sub(r',(\s*\n\s*)\)', r'\1)', s)
    if u.startswith('ALTER TABLE'):
        s = re.sub(r'ENUM\([^)]*\)', 'TEXT', s)
        s = re.sub(r'\b(TINYINT|INT)( UNSIGNED)?(\(\d+\))?', 'INTEGER', s)
        s = re.sub(r'VARCHAR\(\d+\)', 'TEXT', s)
        s = re.sub(r'\s+AFTER \w+', '', s)
    # date functions
    s = re.sub(r"DATE_ADD\(CURDATE\(\), INTERVAL (-?\d+) DAY\)", r"date('now','\1 days')", s)
    s = re.sub(r"DATE_ADD\(NOW\(\), INTERVAL (-?\d+) DAY\)", r"datetime('now','\1 days')", s)
    s = s.replace('NOW()', "datetime('now')")
    try:
        conn.execute(s)
    except Exception as ex:
        print('FAILED:', ex, '\n', s[:400]); sys.exit(1)
conn.commit(); conn.execute('PRAGMA foreign_keys=ON')
print('SQLite test database created:', out)
