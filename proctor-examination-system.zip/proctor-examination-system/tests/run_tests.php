<?php
/**
 * tests/run_tests.php – automated scenario tests for the algorithms.
 *
 * Run from the project folder (XAMPP shell or Command Prompt):
 *     C:\xampp\php\php.exe tests\run_tests.php
 *
 * Every test runs inside ONE database transaction that is ROLLED BACK at the end,
 * so your real data is not changed. Requires the sample data from proctor_system.sql.
 */
if (PHP_SAPI !== 'cli') { exit('Run this file from the command line.'); }

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/ui.php';
require_once __DIR__ . '/../backend/ProctorScheduler.php';
require_once __DIR__ . '/../backend/PaperTracker.php';
require_once __DIR__ . '/../includes/ratelimit.php';
require_once __DIR__ . '/../includes/sections.php';
require_once __DIR__ . '/../includes/year.php';
require_once __DIR__ . '/../includes/autoschedule.php';
require_once __DIR__ . '/../includes/otp.php';
require_once __DIR__ . '/../includes/challenge.php';
require_once __DIR__ . '/../backend/Mailer.php';

$pdo = db();
$pass = 0; $fail = 0;
function check(string $name, bool $cond, string $detail = ''): void
{
    global $pass, $fail;
    if ($cond) { $pass++; echo "  [PASS] $name\n"; }
    else { $fail++; echo "  [FAIL] $name" . ($detail ? "  -> $detail" : '') . "\n"; }
}
function mk_exam(PDO $pdo, string $code, string $date, string $start, string $end, int $req, int $dept = 1): int
{
    $pdo->prepare("INSERT INTO examinations (exam_code,name,exam_type,subject_id,department_id,room_id,exam_date,start_time,end_time,required_proctors,paper_sets,status,created_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)")
        ->execute([$code, "Test $code", 'Quiz', 1, $dept, 1, $date, $start, $end, $req, 10, 'Scheduled', now()]);
    return (int) $pdo->lastInsertId();
}
function exam_id(PDO $pdo, string $code): int
{
    $st = $pdo->prepare('SELECT id FROM examinations WHERE exam_code = ?'); $st->execute([$code]);
    return (int) $st->fetchColumn();
}
function codes(array $rows): array { return array_map(fn($r) => (int) $r['teacher_id'], $rows); }

if (!isset($_SESSION)) $_SESSION = [];
$pdo->beginTransaction();
$s = new ProctorScheduler($pdo);
$ADMIN = 1;

echo "\n== 1. Valid teacher assignment ==\n";
$ex5 = exam_id($pdo, 'EX-0005');
$r = $s->generate($ex5, $ADMIN);
check('2 proctors generated for EX-0005', $r['assigned'] === 2 && count($r['selected']) === 2);
check('assignments saved as Pending Review', (int) $pdo->query("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id=$ex5 AND status='Pending Review'")->fetchColumn() === 2);
check('never above required number', $s->activeCount($ex5) === 2);
check('explanation produced for every teacher', count($r['explanations']) === 12);
$again = $s->generate($ex5, $ADMIN);
check('second run does not add proctors (already staffed)', $again['assigned'] === 0 && $s->activeCount($ex5) === 2);

echo "\n== 2. Unavailable / inactive teachers ==\n";
$ex3 = exam_id($pdo, 'EX-0003');
$ev = $s->evaluate($ex3);
$exIds = codes($ev['excluded']);
check('T-010 (status Unavailable) excluded', in_array(10, $exIds, true));
check('T-011 (blocked 12:00-16:00 on exam day) excluded', in_array(11, $exIds, true));
check('T-012 (inactive account) excluded', in_array(12, $exIds, true));
$h = array_column($ev['excluded'], 'reasons', 'teacher_id');
check('reasons mention H1 / H2', str_contains(implode(' ', $h[12]), 'H1') && str_contains(implode(' ', $h[10]), 'H2') && str_contains(implode(' ', $h[11]), 'H2'));

echo "\n== 3. Overlapping examination schedule ==\n";
$ex2 = exam_id($pdo, 'EX-0002');          // 09:30-11:30, overlaps EX-0001 (09:00-11:00)
$ev = $s->evaluate($ex2);
$h = array_column($ev['excluded'], 'reasons', 'teacher_id');
check('T-001 and T-002 (already on EX-0001) excluded with H3', isset($h[1], $h[2]) && str_contains(implode(' ', $h[1]), 'H3') && str_contains(implode(' ', $h[2]), 'H3'));
check('overlapping teachers never selected', !array_intersect([1, 2], codes($ev['eligible'])));

echo "\n== 4. Duplicate proctor assignment ==\n";
$d1 = (string) $pdo->query("SELECT exam_date FROM examinations WHERE exam_code='EX-0001'")->fetchColumn();
$dupDate = date('Y-m-d', strtotime($d1 . ' +40 days'));
$xd = mk_exam($pdo, 'TX-DUP', $dupDate, '08:00:00', '10:00:00', 3);
$m1 = $s->manualAssign($xd, 3, 'Confirmed', $ADMIN);
$m2 = $s->manualAssign($xd, 3, 'Confirmed', $ADMIN);
check('first manual assignment accepted', $m1['ok']);
check('same teacher twice rejected (H4)', !$m2['ok'] && str_contains(implode(' ', $m2['errors']), 'H4'));

echo "\n== 5. Insufficient available teachers ==\n";
$xi = mk_exam($pdo, 'TX-BIG', date('Y-m-d', strtotime($d1 . ' +41 days')), '08:00:00', '10:00:00', 20);
$r = $s->generate($xi, $ADMIN);
check('warning displayed', !empty($r['warnings']) && !$r['ok']);
check('only eligible teachers assigned (10 of 12), none forced', $r['assigned'] === 10 && $s->activeCount($xi) === 10, 'assigned=' . $r['assigned']);
check('inactive and unavailable teachers not forced', !array_intersect([10, 12], array_map('intval', $pdo->query("SELECT teacher_id FROM proctor_assignments WHERE examination_id=$xi")->fetchAll(PDO::FETCH_COLUMN))));

echo "\n== 6. Fair workload distribution (load balancing) ==\n";
$base = strtotime($d1 . ' +50 days');
$okCutoff = true; $firstEx = null;
for ($i = 0; $i < 6; $i++) {
    $id = mk_exam($pdo, 'TX-F' . $i, date('Y-m-d', $base + $i * 86400), '09:00:00', '11:00:00', 2);
    $r = $s->generate($id, $ADMIN);
    $sel = array_column($r['selected'], 'score');
    $rest = array_column(array_filter($r['eligible'], fn($e) => !in_array($e['teacher_id'], array_column($r['selected'], 'teacher_id'), true)), 'score');
    if ($sel && $rest && max($sel) > min($rest)) $okCutoff = false;
}
check('selected teachers always have the lowest workload scores', $okCutoff);
$rk = $s->workloadRanking();
$elig = array_filter($rk, fn($t) => $t['account_status'] === 'active' && $t['availability_status'] === 'Available');
$vals = array_column($elig, 'workload');
check('workload spread among eligible teachers is small (max-min <= 3)', (max($vals) - min($vals)) <= 3, 'spread=' . (max($vals) - min($vals)));

echo "\n== 7. Manual assignment validation ==\n";
$xm = mk_exam($pdo, 'TX-MAN', date('Y-m-d', strtotime($d1 . ' +60 days')), '13:00:00', '15:00:00', 2);
check('inactive teacher rejected (H1)', str_contains(implode(' ', $s->manualAssign($xm, 12, 'Confirmed', $ADMIN)['errors']), 'H1'));
check('unavailable teacher rejected (H2)', str_contains(implode(' ', $s->manualAssign($xm, 10, 'Confirmed', $ADMIN)['errors']), 'H2'));
$ex1 = exam_id($pdo, 'EX-0001');
$e2 = $s->manualAssign($ex2, 1, 'Confirmed', $ADMIN);
check('overlap rejected (H3) in manual mode', !$e2['ok'] && str_contains(implode(' ', $e2['errors']), 'H3'));
$ok = $s->manualAssign($xm, 5, 'Confirmed', $ADMIN);
check('valid manual assignment accepted', $ok['ok']);
$s->manualAssign($xm, 6, 'Confirmed', $ADMIN);
$over = $s->manualAssign($xm, 7, 'Confirmed', $ADMIN);
check('third proctor on a 2-proctor exam rejected (H5)', !$over['ok'] && str_contains(implode(' ', $over['errors']), 'H5'));

echo "\n== 8. Replace / approve / reject ==\n";
$ap = $s->approveExam($ex5, $ADMIN);
check('pending assignments approved -> Confirmed', $ap['approved'] === 2 && (int) $pdo->query("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id=$ex5 AND status='Confirmed'")->fetchColumn() === 2);
$aid = (int) $pdo->query("SELECT id FROM proctor_assignments WHERE examination_id=$xm AND teacher_id=5")->fetchColumn();
$rep = $s->replaceAssignment($aid, 12, $ADMIN);
check('replace with ineligible teacher refused, original kept', !$rep['ok'] && (string) $pdo->query("SELECT status FROM proctor_assignments WHERE id=$aid")->fetchColumn() === 'Confirmed');
$rep = $s->replaceAssignment($aid, 8, $ADMIN);
check('replace with eligible teacher works', $rep['ok'] && (string) $pdo->query("SELECT status FROM proctor_assignments WHERE id=$aid")->fetchColumn() === 'Cancelled');
$ex4 = exam_id($pdo, 'EX-0004');
$re = $s->regenerate($ex4, $ADMIN);
$newIds = array_map('intval', $pdo->query("SELECT teacher_id FROM proctor_assignments WHERE examination_id=$ex4 AND status='Pending Review'")->fetchAll(PDO::FETCH_COLUMN));
check('regenerate proposes different teachers than the rejected ones', $re['assigned'] === 2 && !array_intersect([6, 7], $newIds), implode(',', $newIds));

echo "\n== 9. Paper release, receipt, return ==\n";
$pt = new PaperTracker($pdo);
$ex6 = exam_id($pdo, 'EX-0006');
$s->generate($ex6, $ADMIN); $s->approveExam($ex6, $ADMIN);
$pid = (int) $pdo->query("SELECT id FROM paper_distribution WHERE examination_id=$ex6 AND status='Pending'")->fetchColumn();
check('transaction created automatically when proctors were approved (Pending)', $pid > 0);
$proctor = (int) $pdo->query("SELECT teacher_id FROM proctor_assignments WHERE examination_id=$ex6 AND status='Confirmed' ORDER BY id LIMIT 1")->fetchColumn();
$other = (int) $pdo->query("SELECT teacher_id FROM proctor_assignments WHERE examination_id=$ex6 AND status='Confirmed' ORDER BY id DESC LIMIT 1")->fetchColumn();
$bad = $pt->release($pid, $proctor, $ADMIN, '');
check('cannot release before papers are ready', !$bad['ok']);
check('papers: Pending -> Preparing', $pt->startPreparing($pid, $ADMIN)['ok']);
check('papers marked ready', $pt->markReady($pid, $ADMIN, '')['ok']);
check('cannot release to a teacher who is not an assigned proctor', !$pt->release($pid, 12, $ADMIN, '')['ok']);
check('released to confirmed proctor', $pt->release($pid, $proctor, $ADMIN, '')['ok']);
check('another teacher cannot confirm receipt', $other !== $proctor ? !$pt->confirmReceipt($pid, $other, 0)['ok'] : true);
check('proctor confirms receipt', $pt->confirmReceipt($pid, $proctor, 0)['ok']);
check('cannot complete before return', !$pt->complete($pid, $ADMIN, '')['ok']);
check('return recorded', $pt->recordReturn($pid, $ADMIN, 'all sets back')['ok']);
check('verified -> Completed', $pt->complete($pid, $ADMIN, '')['ok']);
check('status history kept (7 changes)', (int) $pdo->query("SELECT COUNT(*) FROM paper_tracking_history WHERE distribution_id=$pid")->fetchColumn() === 7);

echo "\n== 10. Teacher limits, decline + auto-reassign, rate limit ==\n";
$sc = new ProctorScheduler($pdo);
$e1 = mk_exam($pdo, 'EX-V2A', '2099-03-02', '08:00:00', '10:00:00', 2);
$e2 = mk_exam($pdo, 'EX-V2B', '2099-03-03', '08:00:00', '10:00:00', 1);
$r1 = $sc->generate($e1, $ADMIN);
$first = (int) $pdo->query("SELECT teacher_id FROM proctor_assignments WHERE examination_id=$e1 AND status<>'Cancelled' ORDER BY id LIMIT 1")->fetchColumn();
check('auto-assign filled 2 proctors', $r1['assigned'] === 2);
// teacher cap: teacher with max_assignments = current load can take no more
$pdo->prepare('UPDATE teachers SET max_assignments = 0 WHERE id = ?')->execute([$first]);
$pdo->prepare('UPDATE teachers SET max_assignments = (SELECT COUNT(*) FROM proctor_assignments WHERE teacher_id = ? AND status <> \'Cancelled\') WHERE id = ?')->execute([$first, $first]);
$ev = $sc->evaluate($e2);
check('H7: teacher at own limit is not eligible', !in_array($first, codes($ev['eligible']), true));
$pdo->prepare('UPDATE teachers SET max_assignments = NULL WHERE id = ?')->execute([$first]);
// decline
$aid = (int) $pdo->query("SELECT id FROM proctor_assignments WHERE examination_id=$e1 AND teacher_id=$first AND status<>'Cancelled'")->fetchColumn();
check('decline needs a reason', !$sc->decline($aid, $first, '')['ok']);
check('other teacher cannot decline it', !$sc->decline($aid, $first + 1000, 'x y z')['ok']);
check('teacher declines own assignment', $sc->decline($aid, $first, 'Medical appointment')['ok']);
check('pending decline counted', ProctorScheduler::pendingDeclines($pdo) >= 1);
$re = $sc->reassignDeclined($e1, $ADMIN);
check('auto-reassign finds a replacement', $re['assigned'] === 1);
check('decliner is not picked again', !(int) $pdo->query("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id=$e1 AND teacher_id=$first AND status<>'Cancelled'")->fetchColumn());
check('decline marked resolved when staffed', !(int) $pdo->query("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id=$e1 AND declined_at IS NOT NULL AND decline_resolved=0")->fetchColumn());
$ge = $sc->generateAll($ADMIN, '2099-03-03', '2099-03-03');
check('date-range auto-assign only touches that day', count($ge) === 1 && (int) $ge[0]['exam']['id'] === $e2);
for ($i = 0; $i < 6; $i++) $w = rl_hit('test:key', 5, 60, 120);
check('rate limit blocks once the limit is exceeded', $w > 0 && rl_blocked('test:key') > 0);
rl_clear('test:key');
check('cooldown cleared', rl_blocked('test:key') === 0);

echo "\n== 11. Account deletion ==\n";
$pdo->prepare("INSERT INTO users (email,password_hash,full_name,role,status,created_at) VALUES ('del@x.test','x','Del Me','teacher','active',?)")->execute([now()]);
$duid = (int) $pdo->lastInsertId();
$pdo->prepare("INSERT INTO teachers (user_id,teacher_no,department_id,created_at) VALUES (?,?,1,?)")->execute([$duid, 'T-DEL', now()]);
check('cannot delete own account', delete_user_account($ADMIN, $ADMIN) !== null);
check('teacher account deleted', delete_user_account($duid, $ADMIN) === null);
check('teacher profile removed too', !(int) $pdo->query("SELECT COUNT(*) FROM teachers WHERE teacher_no='T-DEL'")->fetchColumn());
$pdo->prepare("INSERT INTO users (email,password_hash,full_name,role,status,created_at) VALUES ('sch@x.test','x','Sched','coordinator','active',?)")->execute([now()]);
check('scheduler role can be stored', (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role='coordinator'")->fetchColumn() === 1);

echo "\n== 12. Teacher accept, clear unanswered, run settings override ==\n";
$sc2 = new ProctorScheduler($pdo, ['max_exams_per_day' => '1']);
$e3 = mk_exam($pdo, 'EX-V2C', '2099-04-01', '08:00:00', '10:00:00', 1);
$e4 = mk_exam($pdo, 'EX-V2D', '2099-04-01', '11:00:00', '12:00:00', 1);
$sc2->generate($e3, $ADMIN); $sc2->generate($e4, $ADMIN);
$t3 = (int) $pdo->query("SELECT teacher_id FROM proctor_assignments WHERE examination_id=$e3 AND status<>'Cancelled'")->fetchColumn();
$t4 = (int) $pdo->query("SELECT teacher_id FROM proctor_assignments WHERE examination_id=$e4 AND status<>'Cancelled'")->fetchColumn();
check('override max 1 exam/day: two exams same day go to different teachers', $t3 && $t4 && $t3 !== $t4);
$aid3 = (int) $pdo->query("SELECT id FROM proctor_assignments WHERE examination_id=$e3 AND status<>'Cancelled'")->fetchColumn();
check('other teacher cannot accept it', !$sc2->acceptByTeacher($aid3, $t3 + 999)['ok']);
check('teacher accepts own proposal', $sc2->acceptByTeacher($aid3, $t3)['ok']);
check('accepted becomes Confirmed', $pdo->query("SELECT status FROM proctor_assignments WHERE id=$aid3")->fetchColumn() === 'Confirmed');
$n = $sc2->clearUnanswered($ADMIN, '2099-04-01', '2099-04-01');
check('clear removes only unanswered (1), keeps accepted', $n === 1 && $pdo->query("SELECT status FROM proctor_assignments WHERE id=$aid3")->fetchColumn() === 'Confirmed');

echo "\n== 13. Automatic paper tracking (students + 5 extra copies) ==\n";
$pdo->prepare("INSERT INTO exam_sections (examination_id, section_name, subject_id, examinees, sort_order) VALUES (?,?,?,?,1)")->execute([$e3, 'BSIT 1A', 1, 32]);
check('teacher acceptance already created the paper transaction', (int) $pdo->query("SELECT COUNT(*) FROM paper_distribution WHERE examination_id=$e3")->fetchColumn() === 1);
PaperTracker::sync($pdo, $e3, $ADMIN);
$pp = $pdo->query("SELECT status, paper_sets FROM paper_distribution WHERE examination_id=$e3")->fetch();
check('accepted proctor -> paper transaction created (Pending)', $pp && $pp['status'] === 'Pending');
check('copies = 32 students + 5 extra = 37', $pp && (int) $pp['paper_sets'] === 37);
$pdo->prepare("UPDATE exam_sections SET examinees = 40 WHERE examination_id = ?")->execute([$e3]);
PaperTracker::sync($pdo, $e3, $ADMIN);
check('copies follow the students while Pending (45)', (int) $pdo->query("SELECT paper_sets FROM paper_distribution WHERE examination_id=$e3")->fetchColumn() === 45);
check('pending exam (no accepted proctor) has no paper transaction', !(int) $pdo->query("SELECT COUNT(*) FROM paper_distribution WHERE examination_id=$e4")->fetchColumn());
$sc2->cancelAssignment($aid3, $ADMIN);
check('proctor removed -> automatic paper transaction removed', !(int) $pdo->query("SELECT COUNT(*) FROM paper_distribution WHERE examination_id=$e3")->fetchColumn());
$a5 = $sc2->manualAssign($e3, $t3, 'Confirmed', $ADMIN);
check('manual confirmed assignment creates the paper transaction', $a5['ok'] && (int) $pdo->query("SELECT COUNT(*) FROM paper_distribution WHERE examination_id=$e3")->fetchColumn() === 1);

echo "\n== 14. Weekly availability (Mon-Sat days and hours) ==\n";
$wd = mk_exam($pdo, 'EX-WK1', '2099-06-02', '08:00:00', '10:00:00', 1);   // 2099-06-02 is a Tuesday
$pdo->exec("DELETE FROM teacher_weekly_availability");
$ev = (new ProctorScheduler($pdo))->evaluate($wd);
check('nobody is eligible when no teacher set availability', count($ev['eligible']) === 0);
$tz = (int) $pdo->query("SELECT id FROM teachers ORDER BY id LIMIT 1")->fetchColumn();
$pdo->prepare("INSERT INTO teacher_weekly_availability (teacher_id, weekday, start_time, end_time) VALUES (?,?,?,?)")->execute([$tz, 2, '07:00:00', '12:00:00']);
$ev = (new ProctorScheduler($pdo))->evaluate($wd);
check('teacher free Tuesday 7-12 is eligible for Tue 8-10', in_array($tz, array_map('intval', array_column($ev['eligible'], 'teacher_id')), true));
$pdo->exec("UPDATE teacher_weekly_availability SET end_time = '09:00:00'");
$ev = (new ProctorScheduler($pdo))->evaluate($wd);
check('window that ends before the exam ends -> not eligible', !in_array($tz, array_map('intval', array_column($ev['eligible'], 'teacher_id')), true));
$pdo->exec("UPDATE teacher_weekly_availability SET weekday = 3, end_time = '12:00:00'");
$ev = (new ProctorScheduler($pdo))->evaluate($wd);
check('free only on Wednesday -> not eligible on Tuesday', !in_array($tz, array_map('intval', array_column($ev['eligible'], 'teacher_id')), true));

echo "\n== 15. Section rules (capacity, max sections, overlap, same subject) ==\n";
$pdo->exec("INSERT INTO rooms (name, building, seat_rows, seat_cols, capacity, max_sections, status, created_at) VALUES ('T-ROOM', NULL, 6, 10, 60, 1, 'Available', '2099-01-01 00:00:00')");
$rx = (int) $pdo->query("SELECT id FROM rooms WHERE name = 'T-ROOM'")->fetchColumn();
check('Sunday refused', (bool) array_filter(section_rule_errors('S-A', 30, 1, $rx, '2099-06-07', '08:00:00', '09:00:00'), fn($m) => strpos($m, 'Sunday') !== false));
check('more students than capacity refused', (bool) array_filter(section_rule_errors('S-A', 61, 1, $rx, '2099-06-02', '08:00:00', '09:00:00'), fn($m) => strpos($m, 'capacity') !== false));
check('valid section accepted', !section_rule_errors('S-A', 60, 1, $rx, '2099-06-02', '13:00:00', '14:00:00'));
$xa = mk_exam($pdo, 'EX-SEC1', '2099-06-03', '08:00:00', '10:00:00', 1);
$pdo->exec("UPDATE examinations SET room_id = $rx WHERE id = $xa");
$pdo->prepare("INSERT INTO exam_sections (examination_id, section_name, subject_id, examinees, sort_order) VALUES (?,?,?,?,1)")->execute([$xa, 'S-A', 1, 30]);
check('same section overlapping in time refused', (bool) array_filter(section_rule_errors('s-a', 30, 2, 2, '2099-06-03', '09:00:00', '11:00:00'), fn($m) => strpos($m, 'already has an exam') !== false));
check('same section same subject refused', (bool) array_filter(section_rule_errors('S-A', 30, 1, 2, '2099-06-04', '09:00:00', '11:00:00'), fn($m) => strpos($m, 'already takes') !== false));
check('OTHER section, same subject, same time is allowed', !section_rule_errors('S-B', 30, 1, 2, '2099-06-03', '08:00:00', '10:00:00'));
check('room with max 1 section is full for a 2nd section', (bool) array_filter(section_rule_errors('S-B', 30, 1, $rx, '2099-06-03', '13:00:00', '15:00:00'), fn($m) => strpos($m, 'allows only') !== false));
check('the same section may still add another subject to that room', !section_rule_errors('S-A', 30, 2, $rx, '2099-06-03', '13:00:00', '15:00:00'));

echo "\n== 16. E-mail challenge codes (registration / change e-mail) ==\n";
$_SESSION['chal']['t'] = ['hash' => password_hash('123456', PASSWORD_DEFAULT), 'exp' => time() + 600, 'tries' => 0, 'sent' => time(), 'email' => 'a@gmail.com', 'payload' => ['x' => 1]];
check('wrong code refused', !chal_verify('t', '000000')['ok']);
$r = chal_verify('t', '123 456');
check('right code accepted once with payload', $r['ok'] && $r['payload']['x'] === 1 && $r['email'] === 'a@gmail.com');
check('code cannot be reused', !chal_verify('t', '123456')['ok']);
$_SESSION['chal']['t2'] = ['hash' => password_hash('111111', PASSWORD_DEFAULT), 'exp' => time() - 1, 'tries' => 0, 'sent' => time(), 'email' => 'a@gmail.com', 'payload' => []];
check('expired code refused', !chal_verify('t2', '111111')['ok']);
check('per-user OTP: user flag counts only when SMTP verified', !user_needs_otp(['otp_enabled' => 1]) || (get_settings()['smtp_verified'] ?? '0') === '1');

echo "\n== 17. Year module, section form and required proctors ==\n";
$pdo->exec("DELETE FROM teacher_weekly_availability");
foreach ($pdo->query("SELECT id FROM teachers")->fetchAll(PDO::FETCH_COLUMN) as $tid_) for ($d_ = 1; $d_ <= 6; $d_++) $pdo->prepare("INSERT INTO teacher_weekly_availability (teacher_id, weekday, start_time, end_time) VALUES (?,?,?,?)")->execute([$tid_, $d_, '06:00:00', '20:00:00']);
$pdo->prepare("INSERT INTO year_configs (department_id, year_level, created_at) VALUES (1, 4, ?)")->execute([now()]);
$yc = (int) $pdo->lastInsertId();
$dupYear = false; try { $pdo->prepare("INSERT INTO year_configs (department_id, year_level, created_at) VALUES (1, 4, ?)")->execute([now()]); } catch (PDOException $e) { $dupYear = true; }
check('same department + year level cannot be added twice', $dupYear);
$names = ['Programming 1', 'Mathematics', 'Database Management', 'Computer Fundamentals', 'Introduction to Computing'];
$ys = [];
foreach ($names as $i => $nm) { $pdo->prepare("INSERT INTO year_subjects (year_config_id, semester, name, sort_order) VALUES (?,1,?,?)")->execute([$yc, $nm, $i]); $ys[] = (int) $pdo->lastInsertId(); }
$pdo->prepare("INSERT INTO year_subjects (year_config_id, semester, name, sort_order) VALUES (?,2,'Programming 2',1)")->execute([$yc]);
$ys2 = (int) $pdo->lastInsertId();
check('subjects of department + year + semester are retrieved from the Year module', count(year_subjects_for(1, 4, 1)) === 5 && count(year_subjects_for(1, 4, 2)) === 1);
$sid1 = ensure_subject($pdo, $ys[0]);
check('a Year subject gets (and reuses) its subjects-table row', $sid1 > 0 && ensure_subject($pdo, $ys[0]) === $sid1);
$pdo->exec("INSERT INTO rooms (name, building, seat_rows, seat_cols, capacity, max_sections, status, created_at) VALUES ('TST-60', NULL, 6, 10, 60, NULL, 'Available', '" . now() . "')");
$room60 = fetch_one("SELECT * FROM rooms WHERE name = 'TST-60'");
$sc17 = new ProctorScheduler($pdo);
$mkIn = function (array $pick, int $students = 60, int $secId = 0, string $name = 'BSCS 4A', int $sem = 1) use ($yc) {
    $in = ['section_id' => $secId, 'name' => $name, 'department_id' => 1, 'year_level' => 4, 'semester' => $sem, 'students' => $students, 'subj' => []];
    foreach ($pick as $k => $ysId) $in['subj'][$ysId] = ['on' => 1, 'id' => 0, 'date' => '2099-07-' . sprintf('%02d', 6 + ($k % 5)), 'start' => '08:00', 'end' => '10:00'];
    return $in;
};
$pdo->prepare("INSERT INTO class_sections (name, department_id, year_config_id, semester, students, created_at) VALUES ('BSCS 4A', 1, ?, 1, 60, ?)")->execute([$yc, now()]);
$regId = (int) $pdo->lastInsertId();
$dupSec = false; try { $pdo->prepare("INSERT INTO class_sections (name, department_id, year_config_id, semester, students, created_at) VALUES ('BSCS 4A', 1, ?, 1, 40, ?)")->execute([$yc, now()]); } catch (PDOException $e) { $dupSec = true; }
$pdo->prepare("INSERT INTO class_sections (name, department_id, year_config_id, semester, students, created_at) VALUES ('BSCS 4A', 1, ?, 2, 48, ?)")->execute([$yc, now()]);
check('a section name is unique per semester only (the same name may exist in another semester)', $dupSec && (int) $pdo->query("SELECT COUNT(*) FROM class_sections WHERE name = 'BSCS 4A'")->fetchColumn() === 2);
check('year plan lists the sections and subjects of a semester for the scheduler', year_plan(1, 4, 1)['slots'] === 5 && count(year_plan(1, 4, 1)['sections']) === 1 && count(year_plan(1, 4, 2)['sections']) === 1);
$r17 = section_save($pdo, $sc17, $room60, ['section_id' => $regId] + $mkIn($ys), $ADMIN);
check('section with 5 subjects saved without errors', !$r17['errors'] && $r17['made'] === 5, implode('; ', $r17['errors']));
$secId = $r17['section_id'];
check('the registered section was used (no guessing, same id)', $secId === $regId);
check('year plan shows 5 of 5 exams scheduled', year_plan(1, 4, 1)['scheduled'] === 5);
check('required proctors = number of subjects (5)', section_requirements($secId)['proctors'] === 5);
check('every subject exam needs exactly ONE proctor', (int) $pdo->query("SELECT COUNT(*) FROM examinations e JOIN exam_sections x ON x.examination_id = e.id WHERE x.section_id = $secId AND e.required_proctors = 1")->fetchColumn() === 5);
check('no paper record before any proctor accepts', !(int) $pdo->query("SELECT COUNT(*) FROM paper_distribution p JOIN exam_sections x ON x.examination_id = p.examination_id WHERE x.section_id = $secId")->fetchColumn());
$bad = section_save($pdo, $sc17, $room60, ['year_level' => 3] + $mkIn([$ys[0]]), $ADMIN);
check('year level that is not registered for the department is refused', (bool) $bad['errors']);
$bad = section_save($pdo, $sc17, $room60, $mkIn([$ys2], 60, 0, 'BSCS 4B'), $ADMIN);
check('subject of the other semester is refused', (bool) $bad['errors']);
$bad = section_save($pdo, $sc17, $room60, $mkIn([$ys[0]], 90, 0, 'BSCS 4C'), $ADMIN);
check('more students than the room capacity is refused', (bool) $bad['errors']);
$in = $mkIn($ys, 60, $secId); $in['subj'][$ys[4]]['id'] = (int) $pdo->query("SELECT e.id FROM examinations e JOIN exam_sections x ON x.examination_id = e.id WHERE x.section_id = $secId AND x.year_subject_id = {$ys[4]}")->fetchColumn();
unset($in['subj'][$ys[4]]);
$rm = section_save($pdo, $sc17, $room60, $in, $ADMIN);
check('un-ticking a subject removes it and lowers the required proctors to 4', !$rm['errors'] && $rm['removed'] === 1 && section_requirements($secId)['proctors'] === 4, implode('; ', $rm['errors']));
$rd = section_save($pdo, $sc17, $room60, $mkIn($ys, 60, $secId), $ADMIN);
check('ticking it again adds it back (5 proctors)', !$rd['errors'] && section_requirements($secId)['proctors'] === 5, implode('; ', $rd['errors']));
$exOf = fn(int $ysId) => (int) $pdo->query("SELECT e.id FROM examinations e JOIN exam_sections x ON x.examination_id = e.id WHERE x.section_id = $secId AND x.year_subject_id = $ysId")->fetchColumn();
$eProg = $exOf($ys[0]); $eMath = $exOf($ys[1]);
check('duplicate section + subject rows are blocked by the database', (function () use ($pdo, $eProg, $secId, $ys, $sid1) { try { $pdo->prepare("INSERT INTO exam_sections (examination_id, section_name, subject_id, examinees, sort_order, section_id, year_subject_id) VALUES (?,?,?,?,1,?,?)")->execute([$eProg, 'BSCS 4A', $sid1, 60, $secId, $ys[0]]); return false; } catch (PDOException $e) { return true; } })());

// older section (typed before the Year module) can be edited: its exam joins the ticked Year subject instead of being duplicated
$sidL = ensure_subject($pdo, $ys[1]);
$pdo->exec("INSERT INTO rooms (name, building, seat_rows, seat_cols, capacity, max_sections, status, created_at) VALUES ('TST-OLD', NULL, 5, 10, 50, NULL, 'Available', '" . now() . "')");
$roomOld = fetch_one("SELECT * FROM rooms WHERE name = 'TST-OLD'");
$eOld = mk_exam($pdo, 'EX-OLD1', '2099-07-13', '08:00:00', '10:00:00', 1);
$pdo->prepare("UPDATE examinations SET room_id = ?, subject_id = ? WHERE id = ?")->execute([$roomOld['id'], $sidL, $eOld]);
$pdo->prepare("INSERT INTO exam_sections (examination_id, section_name, subject_id, examinees, sort_order) VALUES (?,?,?,?,1)")->execute([$eOld, 'OLD 1A', $sidL, 30]);
$rl = section_save($pdo, $sc17, $roomOld, ['section_id' => 0, 'name' => 'OLD 1A', 'department_id' => 1, 'year_level' => 4, 'semester' => 1, 'students' => 35, 'subj' => [$ys[1] => ['on' => 1, 'id' => $eOld, 'date' => '2099-07-13', 'start' => '08:00', 'end' => '10:00']]], $ADMIN);
check('editing an older section links its existing exam (no duplicate, students updated)', !$rl['errors'] && $rl['made'] === 0 && (int) $pdo->query("SELECT COUNT(*) FROM exam_sections WHERE LOWER(section_name) = 'old 1a'")->fetchColumn() === 1
    && (int) $pdo->query("SELECT examinees FROM exam_sections WHERE examination_id = $eOld")->fetchColumn() === 35, implode('; ', $rl['errors']));

echo "\n== 18. Papers per subject (accept -> own record, +5 copies) ==\n";
$t17 = (int) $pdo->query("SELECT id FROM teachers ORDER BY id LIMIT 1")->fetchColumn(); $t18 = (int) $pdo->query("SELECT id FROM teachers ORDER BY id LIMIT 1 OFFSET 1")->fetchColumn();
$a1 = $sc17->manualAssign($eProg, $t17, 'Pending Review', $ADMIN);
check('proposal not yet accepted -> no paper record', $a1['ok'] && !(int) $pdo->query("SELECT COUNT(*) FROM paper_distribution WHERE examination_id = $eProg")->fetchColumn());
$aid = (int) $pdo->query("SELECT id FROM proctor_assignments WHERE examination_id = $eProg AND status <> 'Cancelled'")->fetchColumn();
$sc17->acceptByTeacher($aid, $t17);
$sc17->acceptByTeacher($aid, $t17);
$pr = $pdo->query("SELECT id, status, paper_sets FROM paper_distribution WHERE examination_id = $eProg")->fetchAll();
check('accepting (even twice) creates exactly ONE record for Programming 1, status Pending', count($pr) === 1 && $pr[0]['status'] === 'Pending');
check('Programming 1 papers = 60 students + 5 = 65', count($pr) === 1 && (int) $pr[0]['paper_sets'] === 65);
check('the other 4 subjects have no paper record', (int) $pdo->query("SELECT COUNT(*) FROM paper_distribution p JOIN exam_sections x ON x.examination_id = p.examination_id WHERE x.section_id = $secId")->fetchColumn() === 1);
$sc17->manualAssign($eMath, $t18, 'Confirmed', $ADMIN);
check('accepting Mathematics adds its OWN record (65)', (int) $pdo->query("SELECT COUNT(*) FROM paper_distribution p JOIN exam_sections x ON x.examination_id = p.examination_id WHERE x.section_id = $secId")->fetchColumn() === 2
    && (int) $pdo->query("SELECT paper_sets FROM paper_distribution WHERE examination_id = $eMath")->fetchColumn() === 65);
$cannot = section_save($pdo, $sc17, $room60, $mkIn([$ys[1], $ys[2], $ys[3], $ys[4]], 60, $secId), $ADMIN);
check('a subject with a proctor cannot be un-ticked (nothing is deleted)', (bool) $cannot['errors'] && (int) $pdo->query("SELECT COUNT(*) FROM examinations WHERE id = $eProg")->fetchColumn() === 1);
$edErr = section_update($pdo, $secId, 'BSCS 4A', 50, $ADMIN);
$ed = section_save($pdo, $sc17, $room60, $mkIn($ys, 50, $secId), $ADMIN); $ed['errors'] = array_merge($edErr, $ed['errors']);
check('changing the section\'s students in the Year module updates its exams, keeps assignments, and papers become 55', !$ed['errors'] && (int) $pdo->query("SELECT paper_sets FROM paper_distribution WHERE examination_id = $eProg")->fetchColumn() === 55
    && (int) $pdo->query("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id = $eProg AND status = 'Confirmed'")->fetchColumn() === 1, implode('; ', $ed['errors']));
$pidBefore = (int) $pdo->query("SELECT id FROM paper_distribution WHERE examination_id = $eProg")->fetchColumn();
$rep = $sc17->replaceAssignment($aid, (int) $pdo->query("SELECT id FROM teachers ORDER BY id LIMIT 1 OFFSET 2")->fetchColumn(), $ADMIN);
check('replacing the proctor keeps the SAME paper record (no duplicate)', $rep['ok'] && (int) $pdo->query("SELECT COUNT(*) FROM paper_distribution WHERE examination_id = $eProg")->fetchColumn() === 1
    && (int) $pdo->query("SELECT id FROM paper_distribution WHERE examination_id = $eProg")->fetchColumn() === $pidBefore, implode('; ', $rep['errors'] ?? []));
$newA = (int) $pdo->query("SELECT id FROM proctor_assignments WHERE examination_id = $eProg AND status <> 'Cancelled'")->fetchColumn();
$ren = section_update($pdo, $secId, 'BSCS 4A-1', 50, $ADMIN);
check('renaming a section renames all of its exams', !$ren && (int) $pdo->query("SELECT COUNT(*) FROM exam_sections WHERE section_id = $secId AND section_name = 'BSCS 4A-1'")->fetchColumn() === 5);
check('too many students for the room is refused when editing the section', (bool) section_update($pdo, $secId, 'BSCS 4A-1', 61, $ADMIN));
section_update($pdo, $secId, 'BSCS 4A', 50, $ADMIN);
$sc17->cancelAssignment($newA, $ADMIN);
check('nobody assigned any more and still Pending -> record removed', !(int) $pdo->query("SELECT COUNT(*) FROM paper_distribution WHERE examination_id = $eProg")->fetchColumn());
$pm = $pdo->query("SELECT id FROM paper_distribution WHERE examination_id = $eMath")->fetchColumn();
$ptt = new PaperTracker($pdo);
check('admin moves Pending -> Preparing -> Ready -> Released', $ptt->advance((int) $pm, 'Preparing', $ADMIN)['ok'] && $ptt->advance((int) $pm, 'Ready for Release', $ADMIN)['ok'] && $ptt->advance((int) $pm, 'Released', $ADMIN)['ok']);
$amath = (int) $pdo->query("SELECT id FROM proctor_assignments WHERE examination_id = $eMath AND status = 'Confirmed'")->fetchColumn();
$sc17->cancelAssignment($amath, $ADMIN);
check('a record already released is kept when its proctor is removed', (int) $pdo->query("SELECT COUNT(*) FROM paper_distribution WHERE examination_id = $eMath")->fetchColumn() === 1);

echo "\n== 19. Fair proctor pairing ==\n";
$tt = $pdo->query("SELECT id, department_id FROM teachers ORDER BY teacher_no LIMIT 3")->fetchAll();
[$X, $Y, $Z] = [(int) $tt[0]['id'], (int) $tt[1]['id'], (int) $tt[2]['id']];
$fd = '2099-09-07'; $wdn = (int) date('N', strtotime($fd));
$pdo->exec("DELETE FROM teacher_weekly_availability");
$ins = $pdo->prepare("INSERT INTO teacher_weekly_availability (teacher_id, weekday, start_time, end_time) VALUES (?,?,?,?)");
$ins->execute([$X, $wdn, '08:00:00', '12:00:00']); $ins->execute([$Y, $wdn, '08:00:00', '09:00:00']);
$fa = mk_exam($pdo, 'EX-FA', $fd, '08:00:00', '09:00:00', 1); $fb = mk_exam($pdo, 'EX-FB', $fd, '08:30:00', '09:30:00', 1);
$gres = (new ProctorScheduler($pdo))->generateAll($ADMIN, $fd, $fd);
$got = fn(int $e) => (int) $pdo->query("SELECT teacher_id FROM proctor_assignments WHERE examination_id = $e AND status <> 'Cancelled'")->fetchColumn();
check('scarce slot first: B only X can do, so A goes to Y (both staffed, no overlap)', $got($fb) === $X && $got($fa) === $Y);
check('only available proctors were used (Z, free nowhere, got nothing)', !(int) $pdo->query("SELECT COUNT(*) FROM proctor_assignments WHERE teacher_id = $Z AND examination_id IN ($fa,$fb)")->fetchColumn());
// no free proctor: reported, never forced
$fc = mk_exam($pdo, 'EX-FC', $fd, '08:00:00', '09:00:00', 1);
$g3 = (new ProctorScheduler($pdo))->generate($fc, $ADMIN);
check('not enough proctors -> left unassigned with a reason, nothing forced', $g3['assigned'] === 0 && !$g3['ok'] && $g3['warnings'] && $g3['excluded'] && !(int) $pdo->query("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id = $fc AND status <> 'Cancelled'")->fetchColumn());
// fewer subjects first, then fewer hours; any department
$pdo->exec("DELETE FROM teacher_weekly_availability"); $pdo->exec("DELETE FROM proctor_assignments WHERE examination_id IN ($fa,$fb,$fc)");
foreach ([$X, $Y, $Z] as $tw) $ins->execute([$tw, $wdn, '06:00:00', '20:00:00']);
$pdo->exec("UPDATE system_settings SET setting_value = 'exclude_same' WHERE setting_key = 'dept_rule'");
$h1 = mk_exam($pdo, 'EX-H1', '2099-09-14', '08:00:00', '09:00:00', 1); $h2 = mk_exam($pdo, 'EX-H2', '2099-09-14', '13:00:00', '16:00:00', 1);
foreach ([[$X, $h1], [$Y, $h2]] as [$tw, $ew]) $pdo->prepare("INSERT INTO proctor_assignments (examination_id, teacher_id, status, assignment_type, created_at) VALUES (?,?,'Confirmed','Manual',?)")->execute([$ew, $tw, now()]);
$h3 = mk_exam($pdo, 'EX-H3', '2099-09-21', '08:00:00', '09:00:00', 1);
check('departments do not restrict pairing (same department allowed)', (new ProctorScheduler($pdo))->evaluate($h3)['eligible'] !== [] && in_array((int) $pdo->query("SELECT department_id FROM examinations WHERE id = $h3")->fetchColumn(), array_map('intval', array_column($tt, 'department_id')), true));
$ev = (new ProctorScheduler($pdo))->evaluate($h3);
$order = array_map('intval', array_column($ev['eligible'], 'teacher_id'));
$idx = fn($t) => array_search($t, $order, true);
check('proctor with no subject (Z) is paired before those who already have one', $idx($Z) !== false && $idx($Z) < $idx($X) && $idx($Z) < $idx($Y));
check('with equal subjects, the one with fewer exam hours (X: 1h) comes before Y (3h)', $idx($X) < $idx($Y));

echo "\n== 20. Optional auto-accept for Auto-Assign ==\n";
$pdo->exec("DELETE FROM teacher_weekly_availability");
foreach ($pdo->query("SELECT id FROM teachers")->fetchAll(PDO::FETCH_COLUMN) as $tw) for ($d_ = 1; $d_ <= 6; $d_++) $pdo->prepare("INSERT INTO teacher_weekly_availability (teacher_id, weekday, start_time, end_time) VALUES (?,?,?,?)")->execute([$tw, $d_, '06:00:00', '20:00:00']);
$pdo->prepare("INSERT INTO class_sections (name, department_id, year_config_id, semester, students, created_at) VALUES ('AUTO 1A', 1, ?, 1, 42, ?)")->execute([$yc, now()]);
$autoSec = (int) $pdo->lastInsertId();
$inAuto = ['section_id' => $autoSec] + $mkIn([$ys[0], $ys[1]]);
foreach ($inAuto['subj'] as &$sj_) { $sj_['start'] = '13:00'; $sj_['end'] = '15:00'; } unset($sj_);
$ra = section_save($pdo, $sc17, $room60, $inAuto, $ADMIN);
$exAuto = array_map('intval', $pdo->query("SELECT examination_id FROM exam_sections WHERE section_id = $autoSec")->fetchAll(PDO::FETCH_COLUMN));
$inList = implode(',', $exAuto);
(new ProctorScheduler($pdo))->generateAll($ADMIN, '2099-07-01', '2099-07-31');
check('auto-accept OFF: assignments wait for the proctor (Pending Review), no paper record yet', !$ra['errors'] && (int) $pdo->query("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id IN ($inList) AND status = 'Pending Review'")->fetchColumn() === 2
    && !(int) $pdo->query("SELECT COUNT(*) FROM paper_distribution WHERE examination_id IN ($inList)")->fetchColumn());
$pdo->exec("DELETE FROM proctor_assignments WHERE examination_id IN ($inList)");
(new ProctorScheduler($pdo))->setAutoAccept(true)->generateAll($ADMIN, '2099-07-01', '2099-07-31');
check('auto-accept ON: assignments are Confirmed right away', (int) $pdo->query("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id IN ($inList) AND status = 'Confirmed'")->fetchColumn() === 2);
check('auto-accept ON: each subject gets its own paper record, 42 students + 5 = 47, Pending', (int) $pdo->query("SELECT COUNT(*) FROM paper_distribution WHERE examination_id IN ($inList) AND status = 'Pending' AND paper_sets = 47")->fetchColumn() === 2);

echo "\n== 21. Public schedule board, edit \/ delete, completed paper delete ==\n";
$pb = schedule_board(['past' => false]);
$names21 = []; foreach ($pb['years'] as $yy) foreach ($yy['sections'] as $ss) $names21[] = $ss['name'];
check('public board groups the registered section under its year level (Fourth Year)', isset($pb['years'][4]) && in_array('AUTO 1A', $names21, true));
$pubJson = json_encode($pb);
check('public board never contains proctor data', !preg_match('/teacher|proctor_name|assigned_by/i', $pubJson));
$exPub = (int) $pdo->query("SELECT examination_id FROM exam_sections WHERE section_id = $autoSec ORDER BY examination_id LIMIT 1")->fetchColumn();
$pdo->prepare("UPDATE examinations SET is_public = 0 WHERE id = ?")->execute([$exPub]);
$cnt = function () use ($autoSec) { $n = 0; foreach (schedule_board([])['years'] as $yy) foreach ($yy['sections'] as $ss) if ($ss['name'] === 'AUTO 1A') $n += count($ss['exams']); return $n; };
$adminHas = false; foreach (schedule_board([], true)['years'] as $yy) foreach ($yy['sections'] as $ss) foreach ($ss['exams'] as $xx) if ((int) $xx['id'] === $exPub) $adminHas = true;
check('a hidden exam is not shown publicly (but still in the admin board)', $cnt() === 1 && $adminHas);
$pdo->prepare("UPDATE examinations SET is_public = 1 WHERE id = ?")->execute([$exPub]);
$scE = new ProctorScheduler($pdo);
$err = exam_reschedule($pdo, $scE, $exPub, (int) $room60['id'], '2099-07-20', '15:00', '17:00');
check('admin can move an exam (date, time) from the posted schedule', !$err && $pdo->query("SELECT exam_date FROM examinations WHERE id = $exPub")->fetchColumn() === '2099-07-20', implode('; ', $err));
$other = (int) $pdo->query("SELECT e.id FROM examinations e JOIN exam_sections x ON x.examination_id = e.id WHERE x.section_id = $autoSec AND e.id <> $exPub")->fetchColumn();
$err = exam_reschedule($pdo, $scE, $exPub, (int) $room60['id'], (string) $pdo->query("SELECT exam_date FROM examinations WHERE id = $other")->fetchColumn(), '13:30', '14:30');
check('moving onto the same section\'s other exam time is refused', (bool) $err);
$err = exam_reschedule($pdo, $scE, $exPub, (int) $room60['id'], '2020-01-01', '08:00', '09:00');
check('moving to a past date is refused', (bool) $err);
purge_exam($pdo, $exPub);
check('admin can delete a posted exam (with its assignment and paper)', !(int) $pdo->query("SELECT COUNT(*) FROM examinations WHERE id = $exPub")->fetchColumn() && !(int) $pdo->query("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id = $exPub")->fetchColumn());
// completed paper can be deleted, others cannot
$ptd = new PaperTracker($pdo);
$pOpen = (int) $pdo->query("SELECT id FROM paper_distribution WHERE status = 'Pending' LIMIT 1")->fetchColumn();
check('a record that is not Completed cannot be deleted', $pOpen && !$ptd->deleteCompleted($pOpen, $ADMIN)['ok']);
$pDone = (int) $pdo->query("SELECT id FROM paper_distribution WHERE status = 'Completed' LIMIT 1")->fetchColumn();
check('a Completed record can be deleted', $pDone && $ptd->deleteCompleted($pDone, $ADMIN)['ok'] && !(int) $pdo->query("SELECT COUNT(*) FROM paper_distribution WHERE id = $pDone")->fetchColumn());

echo "\n== 22. Auto-Assign semester filter ==\n";
$exSem = (int) $pdo->query("SELECT x.examination_id FROM exam_sections x JOIN examinations e ON e.id = x.examination_id WHERE x.section_id = $autoSec AND e.status = 'Scheduled' AND e.exam_date >= '" . date('Y-m-d') . "' ORDER BY x.examination_id LIMIT 1")->fetchColumn();
$semOf = (int) $pdo->query("SELECT semester FROM class_sections WHERE id = $autoSec")->fetchColumn();
$wrong = $semOf === 1 ? 2 : 1;
$pdo->prepare("UPDATE proctor_assignments SET status = 'Cancelled' WHERE examination_id = ?")->execute([$exSem]);
$ids = fn($rs) => array_map(fn($r) => (int) $r['exam']['id'], $rs);
$schedS = new ProctorScheduler($pdo);
$rWrong = $schedS->generateAll($ADMIN, null, null, null, $wrong);
check('other semester selected: this section\'s exam is NOT touched', $exSem && !in_array($exSem, $ids($rWrong), true));
$rRight = $schedS->generateAll($ADMIN, null, null, null, $semOf);
check('its own semester selected: the exam IS planned', in_array($exSem, $ids($rRight), true));
$pdo->prepare("UPDATE proctor_assignments SET status = 'Pending Review' WHERE examination_id = ? AND status = 'Cancelled'")->execute([$exSem]);
check('clearUnanswered respects the semester filter', $schedS->clearUnanswered($ADMIN, null, null, null, $wrong) >= 0 && (int) $pdo->query("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id = $exSem AND status = 'Pending Review'")->fetchColumn() >= 0);

echo "\n== 23. Auto-Schedule (Year sections x subjects -> exams) ==\n";
$cfg = fetch_one('SELECT year_config_id, semester FROM class_sections WHERE id = ?', [$autoSec]);
$pdo->prepare('INSERT INTO class_sections (name, department_id, year_config_id, semester, students, created_at) SELECT ?, department_id, year_config_id, semester, 20, ? FROM class_sections WHERE id = ?')->execute(['SCHED 9Z', now(), $autoSec]);
$schSec = (int) $pdo->lastInsertId();
$nSubj = (int) $pdo->query("SELECT COUNT(*) FROM year_subjects WHERE year_config_id = {$cfg['year_config_id']} AND semester = {$cfg['semester']}")->fetchColumn();
$optS = ['sem' => (int) $cfg['semester'], 'dept' => 0, 'year' => 0, 'from' => '2099-08-03', 'to' => '2099-08-14', 'slots' => auto_slots("08:00-10:00\n10:30-12:30\n13:30-15:30"), 'perday' => 2];
check('time slot text is parsed (bad lines ignored)', count(auto_slots("08:00-10:00\nxx\n10:00-09:00\n13:00-15:00")) === 2);
$plan = auto_schedule_plan($pdo, $optS);
$mine = $plan['plans'][$schSec]['items'] ?? [];
check('every subject of the new section is placed', $nSubj > 0 && count($mine) === $nSubj && !array_filter($plan['unplaced'], fn($u) => str_contains($u[0], 'SCHED 9Z')));
$perDayCnt = array_count_values(array_column($mine, 'date'));
check('never more than the per-day limit for a section', max($perDayCnt) <= 2);
$clash = false; foreach ($mine as $i => $a) foreach ($mine as $j => $b) if ($i < $j && $a['date'] === $b['date'] && $a['start'] < $b['end'] && $a['end'] > $b['start']) $clash = true;
check('no two exams of a section overlap', !$clash);
check('no Sunday is used', !array_filter($mine, fn($i) => date('N', strtotime($i['date'])) == 7));
$optWrong = $optS; $optWrong['sem'] = (int) $cfg['semester'] === 1 ? 2 : 1;
$pw = auto_schedule_plan($pdo, $optWrong);
check('other semester selected: the section is not scheduled', !isset($pw['plans'][$schSec]));
$before = (int) $pdo->query('SELECT COUNT(*) FROM examinations')->fetchColumn();
$pr = auto_schedule_run($pdo, $schedS, $plan, $ADMIN, false);
check('preview saves nothing', !$pr['errors'] && (int) $pdo->query('SELECT COUNT(*) FROM examinations')->fetchColumn() === $before, implode('; ', $pr['errors']));
$ap = auto_schedule_run($pdo, $schedS, $plan, $ADMIN, true);
$cntNew = (int) $pdo->query("SELECT COUNT(*) FROM exam_sections x JOIN examinations e ON e.id = x.examination_id WHERE x.section_id = $schSec AND e.status = 'Scheduled'")->fetchColumn();
check('apply creates the exams through section_save', !$ap['errors'] && $cntNew === $nSubj, implode('; ', $ap['errors']));
$plan2 = auto_schedule_plan($pdo, $optS);
check('running again does not duplicate (nothing left to schedule for it)', !isset($plan2['plans'][$schSec]));
check('every new exam needs exactly 1 proctor', (int) $pdo->query("SELECT COUNT(*) FROM examinations e JOIN exam_sections x ON x.examination_id = e.id WHERE x.section_id = $schSec AND e.required_proctors = 1")->fetchColumn() === $nSubj);

echo "\n== 24. Auto-Assign by year level ==\n";
$lvl = (int) $pdo->query("SELECT y.year_level FROM class_sections c JOIN year_configs y ON y.id = c.year_config_id WHERE c.id = $autoSec")->fetchColumn();
$wl = $lvl === 1 ? 2 : 1;
$pdo->prepare("UPDATE proctor_assignments SET status = 'Cancelled' WHERE examination_id = ?")->execute([$exSem]);
check('other year level selected: the exam is NOT touched', !in_array($exSem, $ids($schedS->generateAll($ADMIN, null, null, null, $semOf, $wl)), true));
check('its own year level selected: the exam IS planned', in_array($exSem, $ids($schedS->generateAll($ADMIN, null, null, null, $semOf, $lvl)), true));

echo "\n== 25. Elementary / Junior High / Senior High / College ==\n";
check('Grade 1-10 have no semester, Grade 11-12 and College do', !level_has_sem(101) && !level_has_sem(110) && level_has_sem(111) && level_has_sem(112) && level_has_sem(1) && level_has_sem(4));
check('levels are listed Grade 1.. then College in order', level_rank(101) < level_rank(112) && level_rank(112) < level_rank(1));
save_school_levels($pdo, ['elementary', 'junior', 'senior', 'college']);
$cnt = fn($code) => (int) $pdo->query("SELECT COUNT(*) FROM year_configs y JOIN departments d ON d.id = y.department_id WHERE d.code = '$code'")->fetchColumn();
check('Elementary gets Grade 1-6 cards automatically', $cnt('ELEM') === 6);
check('Junior High gets Grade 7-10 cards automatically', $cnt('JHS') === 4);
check('Senior High gets Grade 11-12 cards automatically', $cnt('SHS') === 2);
save_school_levels($pdo, ['elementary', 'junior', 'senior', 'college']);
check('saving again does not duplicate the cards', $cnt('ELEM') === 6 && $cnt('JHS') === 4 && $cnt('SHS') === 2);
check('the selector offers every enabled level', count(year_level_options()) === 16);
$g3 = (int) $pdo->query("SELECT y.id FROM year_configs y JOIN departments d ON d.id = y.department_id WHERE d.code = 'ELEM' AND y.year_level = 103")->fetchColumn();
$g3d = (int) $pdo->query("SELECT department_id FROM year_configs WHERE id = $g3")->fetchColumn();
foreach (['Math', 'Science', 'English'] as $i => $sn) { $pdo->prepare('INSERT INTO year_subjects (year_config_id, semester, name, sort_order) VALUES (?,?,?,?)')->execute([$g3, 0, $sn, $i + 1]); }
$pdo->prepare('INSERT INTO class_sections (name, department_id, year_config_id, semester, students, created_at) VALUES (?,?,?,?,?,?)')->execute(['Grade 3 - Rose', $g3d, $g3, 0, 25, now()]);
$g3sec = (int) $pdo->lastInsertId();
$o3 = ['sem' => 0, 'dept' => 0, 'year' => 103, 'from' => '2099-09-07', 'to' => '2099-09-18', 'slots' => auto_slots("08:00-09:00\n09:30-10:30"), 'perday' => 2];
$p3 = auto_schedule_plan($pdo, $o3);
check('a Grade 3 section is scheduled with NO semester (3 subjects)', count($p3['plans'][$g3sec]['items'] ?? []) === 3);
check('only the chosen year level is scheduled', count($p3['plans']) === 1);
$r3 = auto_schedule_run($pdo, $schedS, $p3, $ADMIN, true);
check('Grade 3 exams are created', !$r3['errors'] && $r3['made'] === 3, implode('; ', $r3['errors']));
$ids3 = array_map('intval', $pdo->query("SELECT x.examination_id FROM exam_sections x WHERE x.section_id = $g3sec")->fetchAll(PDO::FETCH_COLUMN));
$ra = $schedS->generateAll($ADMIN, null, null, null, null, 103);
$planned = array_map(fn($r) => (int) $r['exam']['id'], $ra);
check('Auto-Assign by Grade 3 (no semester) plans exactly those exams', $ids3 && !array_diff($ids3, $planned) && !array_diff($planned, $ids3));
$e = section_save($pdo, $schedS, $room60, ['section_id' => $g3sec, 'subj' => []], $ADMIN);
check('a section with no subject ticked is refused', (bool) $e['errors']);
$bd = schedule_board(['past' => false]); $keys = array_keys($bd['years']);
check('public board lists Grade 3 before College', in_array(103, $keys, true) && array_search(103, $keys) < array_search(4, $keys) && $bd['years'][103]['label'] === 'Grade 3');
check('Grade 3 section shows no semester label', reset($bd['years'][103]['sections'])['semester'] === '');

$pdo->rollBack();
echo "\n----------------------------------------\n";
echo "Passed: $pass   Failed: $fail   (database changes rolled back)\n";
exit($fail ? 1 : 0);
