<?php
require_once __DIR__ . '/includes/bootstrap.php';
$user = require_login();
$pdo = db();

if (require_post_csrf()) {
    $action = input_str('action', 20);
    if ($action === 'read_all') {
        $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?')->execute([$user['id']]);
        flash('success', 'All notifications marked as read.');
    } elseif ($action === 'read') {
        // only the owner can modify the notification
        $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?')->execute([input_int('id'), $user['id']]);
    }
    redirect('notifications.php');
}

// Opening a link marks it as read, then redirects to the target page.
if (isset($_GET['go'])) {
    $st = $pdo->prepare('SELECT link FROM notifications WHERE id = ? AND user_id = ?');
    $st->execute([(int) $_GET['go'], $user['id']]);
    $link = $st->fetchColumn();
    $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?')->execute([(int) $_GET['go'], $user['id']]);
    redirect($link ? ltrim((string) $link, '/') : 'notifications.php');
}

$st = $pdo->prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 100');
$st->execute([$user['id']]);
$notes = $st->fetchAll();

$icons = ['assignment_new' => 'person-plus', 'assignment_confirmed' => 'check2-circle', 'schedule_update' => 'calendar-event',
          'paper_release' => 'box-arrow-right', 'paper_receipt' => 'inbox', 'paper_return' => 'arrow-return-left'];

$pageTitle = 'Notifications';
$activeNav = 'notifications';
require __DIR__ . '/includes/header.php';
?>
<div class="card-panel">
  <div class="panel-head">
    <h5>Your notifications</h5>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="read_all">
      <button class="btn btn-sm btn-outline-navy" type="submit"><i class="bi bi-check2-all me-1"></i>Mark all as read</button></form>
  </div>
  <?php if (!$notes): ?>
    <?= empty_state('bell-slash', 'No notifications yet', 'You will be notified about assignments, schedule changes and paper movements.') ?>
  <?php else: ?>
    <div class="list-group list-group-flush">
      <?php foreach ($notes as $n): ?>
        <a class="list-group-item list-group-item-action d-flex gap-3 align-items-start <?= $n['is_read'] ? '' : 'bg-light' ?>"
           href="<?= e(url('notifications.php?go=' . (int) $n['id'])) ?>">
          <span class="stat-icon" style="width:38px;height:38px;font-size:1.05rem"><i class="bi bi-<?= e($icons[$n['type']] ?? 'info-circle') ?>"></i></span>
          <span class="flex-grow-1">
            <span class="d-block fw-semibold"><?= e($n['title']) ?> <?php if (!$n['is_read']): ?><span class="badge bg-primary ms-1">New</span><?php endif; ?></span>
            <span class="d-block text-muted small"><?= e($n['message']) ?></span>
          </span>
          <small class="text-muted text-nowrap"><?= e(fmt_dt($n['created_at'])) ?></small>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
