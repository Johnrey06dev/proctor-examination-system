# Stage 1 – Architecture, Workflow and Database Relationships

## Layers
Browser (HTML5, Bootstrap 5, JS, Chart.js) → PHP pages (`admin/`, `teacher/`) → backend classes (`backend/`) → PDO → MySQL.
Every page starts with `includes/bootstrap.php` (config, DB, helpers, session) and an RBAC guard: `require_role('admin')` or `require_role('teacher')`.
Each POST is protected by a CSRF token; output is escaped with `e()`; SQL uses prepared statements.

## User workflow
1. Admin creates departments, subjects, rooms, teachers and examinations (required proctors, paper sets).
2. Admin runs **Generate assignments** → `ProctorScheduler::generate()` filters teachers by HARD constraints, ranks the rest by workload (load balancing), saves the winners as *Pending Review* and stores an explanation.
3. Admin reviews, approves (→ *Confirmed*), replaces, rejects/regenerates, or assigns manually (same validation).
4. Admin records paper **preparation → release** to a Confirmed proctor (`PaperTracker`).
5. Teacher confirms **receipt** (only for papers released to them).
6. Admin records **return**, then verifies → *Completed*. Exam is marked completed → proctors become *Completed* (feeds workload history).
7. Reports (HTML / CSV / PDF / print), notifications and activity logs follow every step.

## Algorithm summary (`backend/ProctorScheduler.php`)
HARD (exclude): H1 active account · H2 available (status + blocked slots) · H3 no overlap / minimum gap · H4 not already on the exam · H5 never above required · H6 eligibility (exam Scheduled, daily limit, optional exclude-same-department).
SOFT (rank): score = workload in period (+ optional department penalty). Order: lowest score → least recently assigned → teacher number. Same `hardViolations()` function is used by automatic, manual, replace and approve.

## Database relationships
```
departments 1─∞ subjects        departments 1─∞ teachers        users 1─1 teachers
subjects 1─∞ examinations       departments 1─∞ examinations    rooms 1─∞ examinations
examinations 1─∞ proctor_assignments ∞─1 teachers  (UNIQUE examination_id + teacher_id)
teachers 1─∞ teacher_availability
examinations 1─1 paper_distribution ∞─1 teachers (proctor) ; paper_distribution 1─∞ paper_tracking_history
examinations 1─∞ assignment_runs   users 1─∞ notifications   users 1─∞ activity_logs   system_settings (key/value)
```
Foreign keys: RESTRICT where records must not disappear (department→teachers/subjects/exams), CASCADE for children (availability, history, notifications), SET NULL for audit references (created_by, recorded_by).

## Transactions
`generate`, `generateAll`, `regenerate`, `replaceAssignment`, `completeExam`, `cancelExam`, teacher creation, and every paper status change run inside a database transaction (rolled back on error). Paper updates also use `UPDATE … WHERE status = old` so a double click cannot advance a transaction twice.

## Known limitations (honest list)
* Tested with automated scenario tests and an HTTP smoke test on a SQLite stand-in of the schema (no MySQL server was available in the build environment). The SQL targets MySQL/MariaDB (XAMPP); please run `tests/run_tests.php` and the manual scenarios on your XAMPP to confirm.
* PDF export is a built-in simple table writer (Latin text, A4 landscape). For fancier PDFs use the Print view → "Save as PDF".
* Bootstrap/Chart.js/icons load from a CDN (internet needed in the browser).
* Greedy algorithm (exam by exam, chronological). It is explainable and consistent but does not guarantee a global optimum across many exams.
* No email/SMS; notifications are in-system only. No QR scanning (as requested).
