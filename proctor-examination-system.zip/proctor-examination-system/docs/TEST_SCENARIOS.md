# Test Scenarios

Automated: `C:\xampp\php\php.exe tests\run_tests.php` (runs in a transaction and rolls back; sample data required). Result when I ran it: **38 passed, 0 failed** (SQLite stand-in – please re-run on your XAMPP).

Manual (login as admin unless stated). Sample data: T-001/T-002 are on EX-0001; EX-0002 overlaps EX-0001; T-010 availability *Unavailable*; T-011 blocked during EX-0003; T-012 inactive.

| # | Scenario | Steps | Expected |
|---|---|---|---|
| 1 | Valid teacher assignment | Examinations → EX-0005 → *Generate assignments* | 2 proctors, status Pending Review, explanation table; counts never exceed required |
| 2 | Unavailable teacher | Generate for EX-0003 | T-010 (H2 status), T-011 (H2 blocked time), T-012 (H1 inactive) listed as Excluded with reasons |
| 3 | Overlapping schedule | Open EX-0002 → Generate | T-001, T-002 excluded (H3 overlap with EX-0001) |
| 4 | Duplicate proctor | EX-0001 → Manual assignment → pick T-001 | Refused: H4 duplicate (and H5 capacity) |
| 5 | Insufficient teachers | Create exam needing 20 proctors → Generate | Warning; only the eligible teachers are assigned; nobody forced |
| 6 | Fair distribution | Proctor Assignments → *Generate all*; open Workload Balance | Selected teachers have the lowest scores; chart/ranking shows small spread |
| 7 | Manual validation | Manual-assign T-012, T-010, an overlapping teacher | Each rejected with its constraint code; a valid teacher is accepted |
| 8 | Approve / replace / reject | Approve pending, replace a proctor, *Reject & regenerate* | Statuses change; regenerate proposes different teachers; teachers get notifications |
| 9 | Paper release | Paper Tracking → New transaction → *Mark prepared* → *Release* to a Confirmed proctor | Status Released; teacher notified; release to a non-assigned teacher is refused |
| 10 | Proctor receipt | Log in as the proctor (teacher01 for EX-0001) → Exam Papers → *Confirm receipt* | Status Received; admin notified. Another teacher cannot confirm (error) |
| 11 | Paper return | Admin → transaction → *Record paper return* → *Verify & complete* | Returned → Completed; every step in Transaction history |
| 12 | Unauthorized access | As teacher open `/admin/dashboard.php`; logged out open any page; POST without token | 403 page; redirect to login; 419 error; each logged |
| 13 | Validation | Create exam with end time before start; duplicate teacher email/ID; duplicate subject code | Clear error messages, nothing saved |
| 14 | Reports | Reports → filter by date/department → CSV, PDF, Print | Files download / print view opens with the same rows |

## V2 scenarios (tests/run_tests.php section 10)
Teacher own limit (H7), decline needs reason / only owner, decline → Reassignment Center, auto-reassign never re-picks the decliner, date-range auto-assign, rate-limit block + cooldown clear. Manually verified: OTP e-mail + code entry (fake SMTP), wrong code rejected, 6th wrong login → cooldown.
