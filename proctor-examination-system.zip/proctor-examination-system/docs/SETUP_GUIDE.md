# XAMPP Setup & Local Deployment Guide (Windows)

Proctor Assignment and Examination Paper Distribution System
URL when finished: **http://localhost/EXAMINATION/**

---------------------------------------------------------------------
## A. Install XAMPP

1. Go to **https://www.apachefriends.org** and download **XAMPP for Windows** (choose a build with **PHP 8.1 or newer**).
2. Run the installer. If Windows shows a User Account Control or antivirus warning, click **Yes / Allow**.
3. On **Select Components** keep ticked: **Apache, MySQL, PHP, phpMyAdmin**. (Others such as Tomcat/Mercury/FileZilla are not needed.)
4. **Installation folder:** keep the default `C:\xampp`. Do not install inside "Program Files" (Windows permissions cause problems).
5. Click Next until it finishes. Tick **Start the Control Panel** and click Finish.
6. In the **XAMPP Control Panel** click **Start** next to **Apache** and **Start** next to **MySQL**. Both names turn green and show port numbers (Apache 80, 443; MySQL 3306).
7. Open a browser and visit **http://localhost/** – you should see the XAMPP dashboard.
8. Visit **http://localhost/phpmyadmin/** – the phpMyAdmin screen should open.

### Troubleshooting the installation
| Problem | Cause | What to do |
|---|---|---|
| Apache will not start, log says *Port 80 in use* / *Port 443 in use* | Skype, IIS, VMware, another web server uses the port | Control Panel → **Netstat** button shows who uses the port. Close that program (safest). Or change Apache's port: **Config → httpd.conf**, change `Listen 80` to `Listen 8080` and `ServerName localhost:80` to `:8080`; for 443 edit `httpd-ssl.conf` (`Listen 443` → `4433`). Consequence: your URL becomes `http://localhost:8080/...`, and you must set the same port nowhere else (only the browser URL changes). |
| MySQL will not start, *Port 3306 in use* | Another MySQL/MariaDB service is running | Open Windows **Services**, stop the other "MySQL" service. Or change MySQL's port in **Config → my.ini** (`port=3307` in both `[client]` and `[mysqld]`) **and** set `DB_PORT` to `3307` in `config/database.php` and `$cfg['Servers'][$i]['port']` in `C:\xampp\phpMyAdmin\config.inc.php`. |
| MySQL starts then stops ("shutdown unexpectedly") | Corrupted InnoDB files after a power cut / force-close | Always stop MySQL with the **Stop** button. First read the log (**Logs → mysql_error.log**). Do **not** delete files in `C:\xampp\mysql\data` blindly: that folder IS your database. If you must repair, copy the whole `C:\xampp\mysql\data` folder somewhere safe first, then follow the official "xampp mysql recovery" steps (replace the `backup` folder contents into a copy of `data`, keeping your own database folders). |
| Apache won't start, no port message | Syntax error in a config you edited, or missing VC++ runtime | Control Panel → Apache **Logs → error.log**; undo your last config change. Install the *Microsoft Visual C++ Redistributable* if XAMPP warns about it. |
| phpMyAdmin: *#2002 Cannot connect* | MySQL is not running or is on another port | Start MySQL. If you changed its port, update `config.inc.php` as above. |
| phpMyAdmin: *#1045 Access denied* | A password was set for `root` | Put the same password in `C:\xampp\phpMyAdmin\config.inc.php` (`$cfg['Servers'][$i]['password']`) and in `config/database.php`. |

---------------------------------------------------------------------
## B. Put the project in the right folder

1. Open `C:\xampp\htdocs\` (this is Apache's web root – everything inside is published).
2. Copy the **entire `proctor-examination-system` folder** here so that this file exists:
   `C:\xampp\htdocs\proctor-examination-system\index.php`
3. Folder structure and what goes where:

```
proctor-examination-system/
├── index.php                 entry point → redirects to login or dashboard
├── login.php  logout.php     authentication pages
├── profile.php               profile + change password (both roles)
├── notifications.php         in-system notifications (both roles)
├── admin/                    ADMIN pages only (role admin enforced in PHP)
│   ├── dashboard.php teachers.php teacher_view.php departments.php subjects.php rooms.php
│   ├── exams.php exam_view.php assignments.php workload.php
│   ├── papers.php paper_view.php reports.php logs.php users.php settings.php
│   └── _assignment_actions.php   shared POST handler (not a page)
├── teacher/                  TEACHER pages only
│   └── dashboard.php assignments.php papers.php history.php availability.php
├── auth/                     (reserved – authentication logic lives in includes/auth.php)
├── config/
│   ├── config.php            app name, BASE_URL, timezone, session timeout
│   └── database.php          PDO connection  ← MySQL user/password/port go here
├── includes/                 bootstrap.php, auth.php, functions.php, ui.php,
│                             header.php / footer.php (layout), 403.php
├── backend/                  ProctorScheduler.php  (constraint scheduling + load balancing)
│                             PaperTracker.php      (paper workflow)
│                             ReportBuilder.php, SimplePDF.php
├── assets/ css/ js/ images/  app.css, app.js
├── reports/  uploads/        (reserved; reports are generated on demand)
├── database/proctor_system.sql   full schema + sample data
├── tests/run_tests.php       automated scenario tests
└── docs/                     this guide, architecture, test scenarios
```
`config`, `includes`, `backend`, `database`, `tests`, `docs` contain a `.htaccess` that blocks direct browser access.

---------------------------------------------------------------------
## C. Create the database in phpMyAdmin

1. Open **http://localhost/phpmyadmin/**.
2. Click **New** (left sidebar).
3. **Database name:** `proctor_examination_system`
4. **Collation:** choose `utf8mb4_unicode_ci`. Click **Create**.
5. Click the new database name in the left list so it is selected.
6. Open the **Import** tab → **Choose File** → select
   `C:\xampp\htdocs\proctor-examination-system\database\proctor_system.sql` → keep format **SQL** → scroll down → **Import**.
7. You should see a green "Import has been successfully finished".
8. Verify: left sidebar shows **14 tables**: `activity_logs, assignment_runs, departments, examinations, notifications, paper_distribution, paper_tracking_history, proctor_assignments, rooms, subjects, system_settings, teacher_availability, teachers, users`.
9. Verify relationships: click `proctor_assignments` → **Structure** → **Relation view** (foreign keys to `examinations`, `teachers`, `users`). Or open the database → **Designer** to see the diagram.
10. Sample data (13 users, 12 teachers, 9 exams, assignments, paper transactions) is inserted by the same file. Dates are relative to the day you import, so there are always upcoming exams.

> Importing the file a second time does **not** wipe data (no DROP statements); it just reports duplicate-key errors. To start over, in phpMyAdmin select the database → **Operations → Drop the database**, then repeat steps 2-7.

---------------------------------------------------------------------
## D. Database connection

File: `C:\xampp\htdocs\proctor-examination-system\config\database.php`

```php
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'proctor_examination_system');
define('DB_USER', 'root');
define('DB_PASS', '');        // empty on a default XAMPP install
```
If your MySQL user/password/port differ, edit only these five lines. The credentials stay on the server – they are never sent to the browser or JavaScript. The connection uses PDO with prepared statements (`db()` function).

---------------------------------------------------------------------
## E. Run the system

1. XAMPP Control Panel: **Start Apache** and **Start MySQL**.
2. Browser: **http://localhost/EXAMINATION/** (redirects to the login page).
3. Development accounts (passwords are stored as bcrypt hashes made with PHP `password_hash()`):

| Role | Email | Password |
|---|---|---|
| Admin | `admin@proctor.local` | `Admin@12345` |
| Teacher | `teacher01@proctor.local` … `teacher11@proctor.local` | `Teacher@12345` |
| Teacher (inactive, for testing) | `teacher12@proctor.local` | cannot log in |

4. **Change passwords after first login:** top-right name → *Profile & password*. Admin can reset any password at *User Accounts*. Set `APP_DEBUG` to `false` in `config/config.php` to hide the development-account box on the login page.
5. Test each module (see `docs/TEST_SCENARIOS.md`). Quick tour as admin: Dashboard → Teachers → Examinations (table/calendar) → **Proctor Assignments → Generate all** → review explanation → **Approve** → Paper Tracking → Reports.
6. Teacher view: log out, log in as `teacher01@proctor.local` → Dashboard → Exam Papers → **Confirm receipt**.
7. **Logout** with the sidebar *Logout* button (this destroys the session). Never just close the tab on a shared computer.

Need Bootstrap, icons and Chart.js? They load from the jsDelivr CDN, so the **browser needs internet access**. (To work fully offline, download those files into `assets/` and change the links in `includes/header.php`, `includes/footer.php` and `login.php`.)

---------------------------------------------------------------------
## F. Troubleshooting (exact places to look)

| Symptom | File / place | Fix |
|---|---|---|
| "Database connection failed" page | `config/database.php` | MySQL running? Credentials/port correct? The page tells you which case. |
| *Access denied for user 'root'* | `config/database.php` line `DB_PASS` | Use the real MySQL root password. |
| *Unknown database* | phpMyAdmin | Create `proctor_examination_system` (Section C). The name must match `DB_NAME`. |
| *Table ... doesn't exist* | phpMyAdmin → database | The SQL import failed or ran on the wrong database. Select the right database, re-import. |
| White page / *Parse error* / *syntax error, unexpected ...* | The file and line number printed on screen (APP_DEBUG is true) | Fix the typo on that line (missing `;`, bracket or quote). Also check `C:\xampp\apache\logs\error.log`. |
| *Undefined variable / array key* warning | File and line printed | Usually a changed variable name; make sure the variable is set before that line. |
| 404 Not Found | Browser URL | Folder must be exactly `htdocs\proctor-examination-system`; URL `http://localhost/EXAMINATION/`. If you rename the folder change `BASE_URL` in `config/config.php`. |
| Page has no styling / charts missing | Browser DevTools (F12) → Network | CSS 404 → `BASE_URL` wrong. CDN blocked → check internet access. |
| Redirects back to login in a loop | Browser cookies / `session.save_path` | Allow cookies; check that `C:\xampp\tmp` exists and is writable; `SESSION_TIMEOUT` is 30 minutes of inactivity. |
| *Security check failed* (419) | The form page was open too long, or cookies blocked | Reload the page and submit again. |
| *403 Access denied* | Teacher opened an admin page (or vice-versa) | Expected – role-based access control. |
| `php` not recognised in Command Prompt | PATH | Use the full path `C:\xampp\php\php.exe`. |

---------------------------------------------------------------------
## G. Local development, backup and restore

**What is what**
* **Project folder (`htdocs\proctor-examination-system`)** – the PHP/CSS/JS source code. Apache serves it.
* **Apache** – the web server that runs the PHP files when a browser asks for them.
* **MySQL** – the database engine that stores the actual records (users, exams, assignments…). Files live in `C:\xampp\mysql\data`.
* **phpMyAdmin** – only a web *tool* (a PHP application) to look at and manage MySQL. Replacing project files never touches your data.

**Back up the database:** phpMyAdmin → select `proctor_examination_system` → **Export** → *Quick* → format *SQL* → **Export**. Save the `.sql` file somewhere safe (date it).
**Restore:** create an empty database with the same name → **Import** → choose your backup file.
**Back up the project:** close editors, copy the whole `proctor-examination-system` folder (or zip it) to another drive/cloud. Before major changes, copy it to `proctor-examination-system_backup_YYYYMMDD` **outside** `htdocs` (a copy inside `htdocs` is also published).
**Restart safely:** Control Panel → **Stop** Apache and MySQL (wait until they turn off) → Start again. Never kill the XAMPP window while MySQL is running.
**Update the code without losing records:** copy the new PHP/CSS/JS files over the old ones – do **not** re-import the SQL file. Data stays in MySQL. If a new version needs new tables, run only the new `CREATE TABLE` statements in phpMyAdmin → SQL tab.

---------------------------------------------------------------------
## H. Final checklist

- [ ] XAMPP installed in `C:\xampp`
- [ ] Apache running (green)  - [ ] MySQL running (green)
- [ ] http://localhost/phpmyadmin/ opens
- [ ] Project is at `C:\xampp\htdocs\proctor-examination-system\`
- [ ] Database imported – 14 tables visible
- [ ] http://localhost/EXAMINATION/ shows the login page (DB connection OK)
- [ ] Admin login works; teacher login works
- [ ] Teacher cannot open `/admin/dashboard.php` (403); anonymous visitor is sent to login
- [ ] Proctor Assignments → Generate all produces results with explanations
- [ ] Workload Balance page shows ranking + chart
- [ ] Paper Tracking: prepare → release → (teacher) receive → return → complete
- [ ] Reports open; CSV and PDF download
- [ ] `C:\xampp\php\php.exe tests\run_tests.php` (run in the project folder) → all tests pass
- [ ] Database backup exported


---
# V2 UPDATE – Room layout, Auto-assign, Reassignment Center, Security & OTP

## A. Update your existing database (ONE time)
1. Open phpMyAdmin → select your database (e.g. `proctor_system`) → **Import** → choose `database/migration_v2.sql` → Go.
   (Fresh install instead? Import the new `database/proctor_system.sql` into an empty database.)
2. Replace the project files in `C:\xampp\htdocs\proctor-examination-system` with the new ones.

## B. New features
- **Rooms** – each room is a rows × columns seat grid; building is optional; capacity = rows × columns.
- **Room layout** (Examinations → open exam → *Room layout*) – add sections, subject and number of examinees per section, choose blocks/interleaved seating, see the classroom preview, print the seat plan. Saving notifies the assigned proctors.
- **Auto-assign** (Proctor Assignments) – by date range or all; follows exam date/time, availability, teacher limits, workload balance.
- **Teacher limits** (My Availability) – teacher sets max exams for the period and per day; auto-assign never exceeds them.
- **Decline** (My Assignments) – teacher declines with a reason → **Reassignment Center** (admin) → Auto-assign again; decliners are never re-picked for that exam.
- **Notifications** now contain date, time, room, building and sections.
- **Security** – 5 failed logins/15 min per account → 5 min cooldown; 20 per IP/10 min → 10 min; 300 requests/min/IP. Admin → *Security & OTP* can unblock.

## C. Gmail OTP setup
1. Google Account → Security → turn on **2-Step Verification**.
2. Google Account → Security → **App passwords** → create one (16 characters).
3. Edit `config/mail.php`: `MAIL_USERNAME` = your Gmail, `MAIL_PASSWORD` = the app password, `MAIL_FROM_EMAIL` = same Gmail.
4. Admin → *Security & OTP* → **Send test e-mail** → when it succeeds, **Enable OTP**.
5. Each user's e-mail (Users page → pencil icon) is where their code is sent. OTP: 6 digits, 5 minutes, 60 s resend cooldown, 5 tries per code.

**Locked out?** In phpMyAdmin run: `UPDATE system_settings SET setting_value='0' WHERE setting_key='otp_enabled';` and to clear blocks: `DELETE FROM rate_limits;`

---
# V2.3 – Roles, deletion
- **Roles:** Administrator (everything), **Scheduler / Coordinator** (arranges exams, rooms, sections, proctor assignments, reassignment, papers, reports – but NOT user accounts, security/OTP, algorithm settings, activity logs), Teacher/Proctor. Create staff accounts at *User Accounts → New staff account* and pick the role.
- **Proctor role per exam:** Head Proctor / Proctor / Assistant Proctor – set in *Rooms → Manage room → Proctors*; the teacher sees it on My Assignments.
- **Delete:** Rooms (also deletes the exams scheduled there – asks first), Teachers and User Accounts (permanent; removes their availability and assignments; you cannot delete yourself or the last administrator).
- Existing database? Import `database/migration_v2.sql` once (it now also adds the role and proctor-role columns). Fresh install: import `proctor_system.sql`.

---
# V2.4 – Inspired by the ProctorPlan prototype
- **Rooms:** *Add rooms* (bulk: how many, prefix, start number, rows × columns), room cards show sections / proctors / "kulang". *Manage room*: schedule an exam in the room, sections + number of examinees, seat plan, proctors (Auto-assign, add, role, remove).
- **Auto-Assign page** (menu → Auto-Assign): 1) choose department, dates, gap, max per day, mode (fill empty slots / re-plan unanswered); 2) "Who is free for each exam?"; 3) **Preview** (nothing saved) with workload before/after; **Apply** saves as Pending and notifies. "Remove all unanswered assignments" is also there.
- **Teacher:** *Accept* / *Accept all* / *Decline* on My Assignments; **Open Exams** (exams in the teacher's department that still need proctors – *Take this exam*, same conflict checks).
- Not ported from the prototype (yet): time in/out attendance, custom roles & permission builder, announcements/messages, exam records history, school type/terms.

## Folder name / URL
The folder can have any name. Example: rename it to `EXAMINATION` in `C:\xampp\htdocs\` and open `http://localhost/EXAMINATION/login.php` (the address is detected automatically; no editing needed). The database name stays `proctor_examination_system`.

---
# V3 – ProctorPlan look & Rooms (green + yellow)
- New theme (green + yellow, **Light/Dark** button on the top bar), sidebar rail (icons only, widens on hover; phone = Menu button), split login page.
- **Rooms** work like the prototype: grid of room tiles (Sections / Exams / Proctors, "Needs proctors" / "All staffed"), search + filter, **Add rooms** (bulk), **Open** → classroom layout (door, board, proctor desk, seats coloured for the chosen exam), Sections and exams, **Edit room schedule** (sections → students → subjects with date, time, proctors needed), **Assign proctor** (only teachers free that day AND time; teacher must accept), **Auto-assign**, **Remove**, **Delete room**.
- Page not styled / old design? Press **Ctrl + F5**.

---

## V3.1 – Features copied from the ProctorPlan prototype

New pages (all linked in the sidebar):

| Page | Who | What |
|---|---|---|
| Exam Day (`teacher/today.php`) | Teacher | Server clock, **Time in** (opens N minutes before the exam, N is set in Attendance) and **Time out**. Works only on the exam day. |
| Attendance (`admin/attendance.php`) | Staff / permission | Who timed in/out per exam day, Reset, **Testing mode** (admin) to try Time in on any day. |
| Announcements | Staff / permission | General announcement or exam reminder to all, a department, or selected teachers; shows how many read it. |
| Messages | Everyone | Teacher → admin/scheduler (quick messages like "I can't make this schedule"), replies, inbox. |
| Roles & Access (`admin/roles.php`) | Admin only | Create custom roles with checkboxes (rooms, auto-assign, papers, attendance, announcements, records, logs...). Give a role (+ extra permissions) to any teacher account. A teacher with permissions sees a **Manage** menu. |
| Exam Records | Staff / permission | Completed exams by section with proctors' time in/out and the paper timeline. |

**Database:** these need new tables/columns. On a fresh install import `database/proctor_system.sql` (drop the old `proctor_examination_system` DB first). On an existing v2 DB run `database/migration_v2.sql` once.

Not copied from the prototype: school types / academic terms.

---

## V3.2 – Rooms: add section by section, automatic paper tracking

- **Room → Add section**: one section at a time. Pick/type the section (known sections auto-fill the number of students), then add every subject it takes, each with its own date, time and proctors needed. **Edit section** / **remove section** buttons are on each section card.
- Same subject, day or time is allowed for **different** sections. The **same section** cannot have two overlapping exams (even in another room) and cannot take the same subject twice.
- **Paper tracking is automatic**: as soon as a proctor *accepts* (or the admin approves/confirms) an exam, its paper transaction is created with status *Preparing* (pending): copies = students + 5 extra. If no accepted proctor is left and papers were not prepared yet, it is removed again. The manual "New paper transaction" button was removed.

---

## V4 – Capacity rooms, weekly availability, Gmail registration, OTP and QR login

**You must re-import** `database/proctor_system.sql` (drop the old `proctor_examination_system` DB first, then phpMyAdmin → Import). It adds: `rooms.max_sections`, `teacher_weekly_availability`, `users.otp_enabled / qr_hash`, and new settings.

**Rooms** – only a *capacity* (e.g. 60) and an optional *max sections*. A section cannot have more students than the capacity. The seat picture is drawn from the capacity.

**Exam Schedule panel** – pick the room from the created rooms, then type the **section** and **students** (auto-filled for a known section). Copies = students + 5 extra, created automatically when a proctor accepts.

**Teacher availability** – My Availability is a weekly plan: Monday–Saturday + hours (several ranges per day). Auto-assign and manual assignment only use a teacher when the exam's day and whole time fit inside those hours. A teacher who set nothing is not assigned. Sunday exams are refused.

**Register with Gmail** – login page → "Create an account with Gmail". A 6-digit code is e-mailed; the account is created only after the code is typed. By default the admin must approve new accounts (User Accounts → "Waiting for your approval"). Turn registration/approval on or off in Security & OTP.

**Set up the sender Gmail (needed for codes)** – open `config/mail.php`, put the sender Gmail in `MAIL_USERNAME` and its 16-letter Google *App Password* in `MAIL_PASSWORD` (steps are in that file). Then Admin → Security & OTP → "Send test e-mail to me".

**Change the admin's e-mail to yours** – log in as admin → My Profile → "Change my login e-mail": type your Gmail + current password; a code is sent to the new address; type it to confirm. (If mail is not set up yet: Admin → User Accounts → pencil next to the e-mail.) Then in My Profile turn on **"Ask for an e-mailed code when I sign in"**. Everybody can turn this on for his own account; or Security & OTP → "Require OTP for EVERYONE".

**QR login** – My Profile → "My QR login" → Create (asks your password). The QR is shown once: save/print it. Scan it with the phone camera, or press **Sign in with QR** on the login page (uses the device camera). Whoever has the QR can open that account, so keep it private; "Make a new QR" or "Turn off" cancels the old one. For phones, set the address in Security & OTP (e.g. `http://192.168.1.10/EXAMINATION`, your PC's Wi-Fi IP from `ipconfig`) because phones cannot open `localhost`.

**Gmail setup is now inside the system** (no file editing): log in as admin → *Security & OTP* → type the sender Gmail and its 16-letter App Password → Save → *Send test e-mail to me*. Needs 2-Step Verification on that Gmail, then https://myaccount.google.com/apppasswords. Your normal Gmail password does not work. Registration and OTP only work after the test e-mail succeeds.

---

## V5 – Separate name fields, gender greeting, profile picture

- Register, My Profile and Teachers use **First name, Middle name, Surname, Suffix, Gender**. The full name is built automatically (e.g. *Juan D. Cruz Jr.*).
- The dashboard greets by time and gender: *Good Morning, Sir Juan!* / *Good Afternoon, Ma'am Ana!*. Old accounts without gender see a reminder to complete their profile.
- **Profile picture**: My Profile → upload JPG/PNG/GIF/WEBP (max 3 MB). It is cropped square, re-encoded (metadata removed) and saved in `uploads/avatars/`. The picture shows in the top bar and in the Teachers list. The `uploads` folder has an `.htaccess` that blocks scripts.
- Needs new columns: re-import `database/proctor_system.sql` (or run the V5 part of `migration_v2.sql`).

---

## V5.1 – (i) help icons

Long explanations are now a small **(i)** icon next to the label or title. Put the mouse on it (or tap it on a phone) to read the explanation, so the pages take less space. Short notes such as "0 = no limit" stay visible. Developers: add `data-info` to any text block to turn it into an (i) icon, or `data-keep` to keep a hint visible.

## V6 – Year module, section form, per-subject papers, fair pairing

**Upgrade an existing database:** in phpMyAdmin open the `proctor_system` database, go to *SQL*, and run only the block at the bottom of `database/migration_v2.sql` that starts with `-- ===== V6`. (A fresh install of `proctor_system.sql` already has everything.)

**New tables:** `year_configs` (department + year level), `year_subjects` (semester + subject name), `class_sections` (registered sections). `exam_sections` got `section_id` and `year_subject_id`, and `paper_distribution.status` got a new first value `Pending`. Nothing else was removed.

**Year Levels panel** (replaces Subjects): Add year level (department from the Departments module + First..Fourth Year, no duplicates) -> add / rename / remove subject names under First and Second Semester. Counts are automatic. "Find subjects" shows what the scheduler will use for a department + year + semester.

**Rooms -> Add / Edit section:** Section name, Department, Year level, Semester, Number of students, then tick the subjects (loaded from the Year module) and give each its date and time. Required proctors = number of subjects (one proctor per subject). Un-ticking a subject removes its exam only when no proctor and no paper record exist; otherwise it tells you what to remove first. Renaming a section or changing its students updates all of its exams and paper copies; schedules and assignments are never deleted by an edit.

**Exam Papers:** one record per subject + section, created as `Pending` when its proctor accepts (students + 5 extra copies). A replaced proctor keeps the same record; a record is removed only when it is still Pending and nobody is assigned any more. Admin buttons: Start preparing -> Mark ready -> Release. ("Ready" is stored as `Ready for Release`.)

**Auto-Assign (fair pairing):** every proctor free on that day/time (any department) is evaluated for every subject; the hardest-to-staff subjects are filled first; the pick is the proctor with the fewest assigned subjects, then the fewest exam hours. The preview shows date/time, subject + section, proctor, department, proctor's available time, subjects and hours so far, the subjects that could not be assigned with the reasons, and a workload summary of ALL proctors (including those who got nothing). Nothing is saved until you press *Apply*.

**Test it:** (1) Year Levels -> add Fourth Year for a department and 5 subjects in First Semester. (2) Rooms -> pick a room -> Add section -> BSCS 4A, 60 students, tick the 5 subjects, set dates. The card says "5 proctors needed". (3) Auto-Assign -> Preview -> Apply. (4) Teachers accept; each accepted subject appears in Exam Papers with 65 copies. (5) `C:\xampp\php\php.exe tests\run_tests.php` (114 checks).

## V6.1 – Sections per semester (Year module)

Each semester of a year level now has its own **Sections** (name + number of students) next to its subjects, because a student's section changes every semester. The same name may exist in another semester (BSCS 4A in 1st sem with 35 students, BSCS 4A in 2nd sem with 28).

- **Year Levels panel:** under the subjects of each semester, add / rename / delete sections and change their students. Changing a section's name or students updates all of its exams and paper copies. A section with scheduled exams cannot be deleted. The small `3/5` beside a section shows how many of its subjects are already scheduled.
- **Rooms > Add section:** choose Department, Year level and Semester, then pick the Section from the registered list (its students are filled in). Tick the subjects and give each its date and time. Nothing is typed or guessed. In Edit, the section is fixed; only its subjects and dates change.
- **Exam Schedule:** the section field suggests the registered sections and fills in their students.
- **For the Auto Scheduler:** `year_plan(department, year, semester)` returns the sections x subjects of that semester and how many exams are already scheduled.

**If you already ran the V6 block before this update**, run this once in phpMyAdmin (SQL tab):
`ALTER TABLE class_sections DROP INDEX uq_class_section_name, ADD UNIQUE KEY uq_class_section (year_config_id, semester, name);`
(A fresh install of `proctor_system.sql` already has it.)

## V6.2 – Optional auto-accept in Auto-Assign

On the Auto-Assign page there is an **Auto-accept** switch (off by default). When it is on, the proctors picked by Auto-Assign are saved as *Confirmed* right away instead of *Pending Review*, the proctor is notified, and each subject's paper record is created at once (Pending, students of the registered section + 5 extra copies). The preview shows a green note when it is on. When it is off, nothing changes: proctors accept or decline themselves.

The number of students always comes from the section registered in the Year module (the students typed when the section was added), so the paper copies follow it.

## V7 – Public exam schedule, Posted Schedule panel, delete completed papers

**Upgrade an existing database:** run the block `-- ===== V7` at the bottom of `database/migration_v2.sql` in phpMyAdmin (adds `examinations.is_public` and the `public_schedule` setting).

**Public home page (`http://localhost/EXAMINATION/`, no login):** shows the posted exam schedule by **Year level -> Section**: each section card shows its *first exam* (date, time, room) and the list of its subjects with date, time and room. Filters: search (section / subject / room), department, year level, include past exams. Proctors are never shown. A signed-in user who opens the home page is sent to his/her dashboard (the public page is still at `index.php?public=1`).

**Admin > Posted Schedule:** the same list for the administrator. For every exam: **Edit** (date, time, room; the room, the section and every assigned proctor are checked again and the proctors are notified), **Hide / Show** on the public page, **Delete** (with its assignment, attendance and paper record). The **Stop posting / Post schedule** button turns the whole public schedule off or on.

**Exam Papers:** a record whose status is **Completed** now has a trash button to delete it. Other records cannot be deleted. (A paper record is only created automatically for exams that are today or later.)

## V7.1 – Semester selector sa Auto-Assign
Sa **Auto-Assign** may **Semester** button na (All / First Semester / Second Semester). Kapag First ang pinili, mga exam lang ng First Semester sections ang ime-match sa proctors (pati ang "Remove unanswered" at ang listahan ng "who is free"), kaya hindi nahahalo ang First at Second sem. Ang "All" ay kasama lahat, pati old exams na walang registered section. Walang bagong SQL na kailangan.

## V8 – Auto-Schedule (gumagawa ng exams mula sa Year module)
**Auto-Assign → "Auto-Schedule"** (o `admin/auto_schedule.php`). Piliin ang **First / Second Semester**, optional na Department at Year level, unang at huling araw, mga time slot (isang linya bawat slot, hal. `08:00-10:00`) at max exams ng section kada araw. I-click ang **Preview**, tapos **Create these exams**.
- Kinukuha nito ang bawat registered section (may students) at ang mga subject ng semester na iyon; nilalagyan ng petsa, oras at room ang bawat subject. Hindi nahahalo ang First at Second sem.
- Bawal: Linggo, lumipas na petsa, dalawang exam ng section sa magkaparehong oras, room na may exam na sa slot, room na hindi kasya ang students o puno na ang "max sections". Rooms na **Available** lang ang gagamitin.
- All-or-nothing: kung may error, walang masasave. Hindi dinodoble ang subject na may exam na.
- Pagkatapos: gamitin ang **Auto-Assign** (piliin ang parehong semester) para mabigyan ng proctor ang bawat subject. Walang bagong SQL.

## V8.1 – Isang Year level lang kada takbo
Sa **Auto-Assign** at **Auto-Schedule**, kailangan nang pumili ng **Year level** (kasama ang Semester). Isang year level lang ang prinoseso bawat takbo para maliit at malinaw ang trabaho; ulitin para sa susunod na year. Ang mga lumang exam na walang registered section ay hindi kasama dito.

## V9 – Para sa buong school sa Pilipinas (Elementary hanggang College)
**Year Levels** ay naka-grid cards na ngayon, may **Open** button bawat card.
- **School levels** (sa taas ng Year Levels page): tick ang Elementary (Grade 1–6), Junior High (Grade 7–10), Senior High (Grade 11–12), College (First–Fourth Year). Pag nag-Save, **awtomatikong nagagawa** ang department (ELEM / JHS / SHS) at lahat ng grade cards nila. Sa College, gumawa ng department at "Add year level" (may "All First–Fourth Year" na option).
- **Semester:** wala ang Elementary at Junior High (Whole school year). Meron ang Senior High at College (First/Second).
- **Auto-Schedule at Auto-Assign:** pumili ng **Year level** (Grade o College). Lalabas lang ang **Semester** button kung Senior High o College; sa Grade 1–10 hindi na hinihingi.
- Ang Rooms (Add section), Posted Schedule at public schedule ay sumusunod din: Grade 1–12 muna, tapos College; walang semester label sa Grade 1–10.
- Migration (kung may luma ka nang database): patakbuhin ang V9 block sa dulo ng `database/migration_v2.sql` (isang setting lang; walang binago sa tables).
