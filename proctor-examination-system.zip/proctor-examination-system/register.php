<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (is_logged_in()) redirect(home_for_role($_SESSION['user']['role']));
$S = get_settings(true);
$open = ($S['registration_open'] ?? '1') !== '0';
$approval = ($S['registration_approval'] ?? '1') === '1';
$depts = dept_list();
$mailOn = mail_ready();   // without working e-mail: no code step, the account always waits for the administrator
function create_teacher_account(string $email, array $p, bool $approval): void
{
    $pdo = db();
    $pdo->beginTransaction();
    $pdo->prepare("INSERT INTO users (email, password_hash, full_name, first_name, middle_name, last_name, suffix, gender, role, status, contact_number, created_at) VALUES (?,?,?,?,?,?,?,?,'teacher',?,?,?)")
        ->execute([$email, $p['hash'], $p['name'], $p['first'], $p['middle'] ?: null, $p['last'], $p['suffix'] ?: null, $p['gender'], $approval ? 'inactive' : 'active', $p['contact'] ?: null, now()]);
    $uid = (int) $pdo->lastInsertId();
    $pdo->prepare('INSERT INTO teachers (user_id, teacher_no, department_id, availability_status, created_at) VALUES (?,?,?,?,?)')
        ->execute([$uid, next_code('teachers', 'teacher_no', 'T-', 3), $p['dept'], 'Available', now()]);
    log_activity('registered', 'user', $uid, null, null, 'Self-registered with ' . $email, $uid);
    $pdo->commit();
    notify_admins('New teacher registered', $p['name'] . ' (' . $email . ') registered' . ($approval ? ' and waits for your approval.' : '.'), 'registration', 'admin/users.php');
}
$errors = []; $v = ['first' => '', 'middle' => '', 'last' => '', 'suffix' => '', 'gender' => '', 'email' => '', 'dept' => 0, 'contact' => ''];

if ($open && require_post_csrf()) {
    $a = input_str('action', 10);
    if ($a === 'cancel') { chal_clear('reg'); redirect('register.php'); }
    if ($a === 'resend' && ($c = chal_pending('reg'))) {
        $r = chal_start('reg', $c['email'], 'registration', $c['payload']);
        $r['ok'] ? flash('success', 'A new code was sent to ' . mask_email($c['email']) . '.') : flash('danger', $r['error']);
        redirect('register.php');
    }
    if ($a === 'send') {
        [$np, $nerr] = name_parts_from_post();
        $v = ['first' => $np['first'], 'middle' => $np['middle'], 'last' => $np['last'], 'suffix' => $np['suffix'], 'gender' => $np['gender'], 'email' => strtolower(input_str('email', 150)), 'dept' => input_int('department_id'), 'contact' => input_str('contact_number', 40)];
        $pw = (string) ($_POST['password'] ?? ''); $cf = (string) ($_POST['confirm'] ?? '');
        foreach ($nerr as $ne) $errors[] = $ne;
        if (!filter_var($v['email'], FILTER_VALIDATE_EMAIL) || !preg_match('/@gmail\.com$/', $v['email'])) $errors[] = 'Use your Gmail address (ends with @gmail.com).';
        elseif (fetch_value('SELECT COUNT(*) FROM users WHERE email = ?', [$v['email']])) $errors[] = 'This e-mail is already registered. Try signing in.';
        if (!fetch_value('SELECT COUNT(*) FROM departments WHERE id = ?', [$v['dept']])) $errors[] = 'Choose your department.';
        if ($err = password_rules_error($pw)) $errors[] = $err;
        elseif ($pw !== $cf) $errors[] = 'Password and confirmation do not match.';
        if (!$errors && !$mailOn) {
            create_teacher_account($v['email'], ['name' => $np['full'], 'first' => $np['first'], 'middle' => $np['middle'], 'last' => $np['last'], 'suffix' => $np['suffix'], 'gender' => $np['gender'], 'dept' => $v['dept'], 'contact' => $v['contact'], 'hash' => password_hash($pw, PASSWORD_DEFAULT)], true);
            flash('success', 'Account request sent. You can sign in after the administrator approves it.');
            redirect('login.php');
        }
        if (!$errors) {
            $r = chal_start('reg', $v['email'], 'registration', ['name' => $np['full'], 'first' => $np['first'], 'middle' => $np['middle'], 'last' => $np['last'], 'suffix' => $np['suffix'], 'gender' => $np['gender'], 'dept' => $v['dept'], 'contact' => $v['contact'], 'hash' => password_hash($pw, PASSWORD_DEFAULT)]);
            if ($r['ok']) { flash('success', 'We sent a 6-digit code to ' . mask_email($v['email']) . '.'); redirect('register.php'); }
            $errors[] = $r['error'];
        }
    }
    if ($a === 'verify') {
        $r = chal_verify('reg', (string) ($_POST['code'] ?? ''));
        if (!$r['ok']) $errors[] = $r['error'];
        else {
            $p = $r['payload'];
            if (fetch_value('SELECT COUNT(*) FROM users WHERE email = ?', [$r['email']])) { flash('danger', 'This e-mail is already registered.'); redirect('login.php'); }
            create_teacher_account($r['email'], $p, $approval);
            send_account_mail($r['email'], 'Welcome to ProctorSys', 'Hi ' . $p['name'] . ', your e-mail is confirmed.' . ($approval ? ' The administrator will approve your account soon. We will e-mail you again when you can sign in.' : ' You can sign in now.'));
            flash('success', $approval ? 'E-mail verified. Your account will be activated once the administrator approves it.' : 'E-mail verified. You can sign in now.');
            redirect('login.php');
        }
    }
}
$pending = chal_pending('reg');
auth_head('Register', 'Create your account', 'Register with your Gmail. The administrator approves your account.');
if ($open && !$mailOn): ?><div class="alert alert-info" data-info>Fill in the form. The administrator will approve your account, then you can sign in.</div><?php endif;
if (!$open): ?><div class="alert alert-warning">Self-registration is closed. Ask the administrator for an account.</div>
<?php else:
foreach ($errors as $er): ?><div class="alert alert-danger"><?= e($er) ?></div><?php endforeach;
if ($pending): ?>
  <p>Enter the 6-digit code sent to <b><?= e(mask_email($pending['email'])) ?></b>. It expires in 10 minutes.</p>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="verify">
    <input class="form-control form-control-lg text-center mb-3" name="code" inputmode="numeric" maxlength="6" autocomplete="one-time-code" placeholder="000000" style="letter-spacing:8px" autofocus required>
    <button class="btn btn-navy w-100 py-2">Verify and create account</button></form>
  <form method="post" class="d-flex justify-content-between mt-2"><?= csrf_field() ?><button class="btn btn-link p-0" name="action" value="resend">Send a new code</button><button class="btn btn-link text-danger p-0" name="action" value="cancel">Cancel</button></form>
<?php else: ?>
  <form method="post" novalidate><?= csrf_field() ?><input type="hidden" name="action" value="send">
    <div class="row g-2 mb-3">
      <div class="col-md-6"><label class="form-label">First name *</label><input class="form-control" name="first_name" value="<?= e($v['first']) ?>" maxlength="60" required></div>
      <div class="col-md-6"><label class="form-label">Middle name <span class="text-muted">(optional)</span></label><input class="form-control" name="middle_name" value="<?= e($v['middle']) ?>" maxlength="60"></div>
      <div class="col-md-6"><label class="form-label">Surname *</label><input class="form-control" name="last_name" value="<?= e($v['last']) ?>" maxlength="60" required></div>
      <div class="col-md-3"><label class="form-label">Suffix</label><select class="form-select" name="suffix"><option value="">None</option><?php foreach (NAME_SUFFIXES as $sf): ?><option <?= $v['suffix'] === $sf ? 'selected' : '' ?>><?= e($sf) ?></option><?php endforeach; ?></select></div>
      <div class="col-md-3"><label class="form-label">Gender *</label><select class="form-select" name="gender" required><option value="">Select</option><option <?= $v['gender'] === 'Male' ? 'selected' : '' ?>>Male</option><option <?= $v['gender'] === 'Female' ? 'selected' : '' ?>>Female</option></select></div>
    </div>
    <div class="mb-3"><label class="form-label">Gmail address</label><input class="form-control" type="email" name="email" value="<?= e($v['email']) ?>" placeholder="yourname@gmail.com" required></div>
    <div class="mb-3"><label class="form-label">Department</label><select class="form-select" name="department_id" required><?= options_html($depts, 'id', fn($d) => $d['code'] . ' – ' . $d['name'], $v['dept'] ?: null, 'Select department') ?></select></div>
    <div class="mb-3"><label class="form-label">Contact number <span class="text-muted">(optional)</span></label><input class="form-control" name="contact_number" value="<?= e($v['contact']) ?>" maxlength="40"></div>
    <div class="row g-2 mb-3"><div class="col"><label class="form-label" id="pwLabel">Password</label><input class="form-control" type="password" name="password" required></div><div class="col"><label class="form-label">Confirm</label><input class="form-control" type="password" name="confirm" required></div></div>
    <div class="hint mb-3" data-info data-info-for="pwLabel">At least 8 characters with letters and numbers.<?= ($approval || !$mailOn) ? ' The administrator must approve your account before you can sign in.' : '' ?></div>
    <button class="btn btn-navy w-100 py-2" data-loading="Please wait..."><?= $mailOn ? 'Send me the code' : 'Request my account' ?></button></form>
<?php endif; endif; ?>
<p class="mt-4 mb-0 small">Already have an account? <a href="<?= e(url('login.php')) ?>">Sign in</a></p>
<?php auth_foot(); ?>
