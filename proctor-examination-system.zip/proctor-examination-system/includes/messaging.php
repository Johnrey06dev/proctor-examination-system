<?php
/** Shared helpers for announcements and direct messages. */

/** user ids that receive an announcement */
function announcement_recipients(array $a): array
{
    if ($a['audience'] === 'department') return array_column(fetch_all("SELECT u.id FROM users u JOIN teachers t ON t.user_id = u.id WHERE u.status = 'active' AND t.department_id = ?", [(int) $a['department_id']]), 'id');
    if ($a['audience'] === 'teachers') {
        $ids = array_filter(array_map('intval', explode(',', (string) $a['target_ids'])));
        if (!$ids) return [];
        $in = implode(',', array_fill(0, count($ids), '?'));
        return array_column(fetch_all("SELECT id FROM users WHERE status = 'active' AND id IN ($in)", array_values($ids)), 'id');
    }
    return array_column(fetch_all("SELECT id FROM users WHERE status = 'active' AND role = 'teacher'"), 'id');
}

function announcement_visible_to(array $a, int $uid): bool
{
    return in_array($uid, array_map('intval', announcement_recipients($a)), true);
}

function send_message(int $from, int $to, string $subject, string $body, ?int $examId = null): void
{
    db()->prepare('INSERT INTO messages (from_user, to_user, subject, body, examination_id, is_read, created_at) VALUES (?,?,?,?,?,0,?)')
        ->execute([$from, $to, $subject, $body, $examId, now()]);
    notify($to, 'New message: ' . $subject, mb_substr($body, 0, 120), 'message', is_staff_id($to) ? 'admin/messages.php' : 'teacher/messages.php');
}

function is_staff_id(int $uid): bool
{
    return (bool) fetch_value("SELECT COUNT(*) FROM users WHERE id = ? AND role IN ('admin','coordinator')", [$uid]);
}

/** staff + teachers holding announcements/rooms permissions who can receive teacher messages */
function message_targets(): array
{
    return fetch_all("SELECT id, full_name, role FROM users WHERE status = 'active' AND role IN ('admin','coordinator') ORDER BY role, full_name");
}
