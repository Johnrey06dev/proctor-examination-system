<?php
/**
 * AUTO-SCHEDULE: turns the Year module (sections x subjects of ONE semester) into real exams.
 * Hard rules: one semester at a time, no Sundays, no past dates, a room holds one exam per time slot, a section sits one exam per
 * slot and at most N exams per day, room capacity >= students, and the room's "max sections" limit. Every exam is then saved
 * through section_save(), so the same validations as the Rooms page apply. Each subject gets one proctor slot (Auto-Assign fills it).
 */

/** "08:00-10:00" lines/commas -> [['08:00','10:00'], ...] (invalid pieces are ignored) */
function auto_slots(string $txt): array
{
    $out = [];
    foreach (preg_split('/[\n,;]+/', $txt) as $p) {
        if (!preg_match('/^\s*(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})\s*$/', $p, $m)) continue;
        $s = sprintf('%02d:%02d', $m[1], $m[2]); $e = sprintf('%02d:%02d', $m[3], $m[4]);
        if ($m[1] > 23 || $m[3] > 23 || $m[2] > 59 || $m[4] > 59 || $s >= $e) continue;
        $out[$s . '-' . $e] = [$s, $e];
    }
    return array_values($out);
}

function auto_overlap(array $list, string $s, string $e): bool
{
    foreach ($list as [$a, $b]) if ($a < $e && $b > $s) return true;
    return false;
}

/**
 * @param array $o sem(1|2), dept, year, from, to, slots[[s,e]], perday
 * @return array{plans:array,unplaced:array,days:int}
 */
function auto_schedule_plan(PDO $pdo, array $o): array
{
    $sem = (int) $o['sem']; $perDay = max(1, (int) ($o['perday'] ?? 2)); $slots = $o['slots'];
    $from = max($o['from'], date('Y-m-d')); $to = $o['to'];
    $days = [];
    for ($d = strtotime($from), $n = 0; $d <= strtotime($to) && $n < 120; $d = strtotime('+1 day', $d), $n++) if (date('N', $d) != 7) $days[] = date('Y-m-d', $d);
    $res = ['plans' => [], 'unplaced' => [], 'days' => count($days)];
    if (!$days || !$slots) return $res;

    $roomBusy = []; $secBusy = []; $secCount = [];
    foreach (fetch_all("SELECT e.room_id, e.exam_date, e.start_time, e.end_time, x.section_id, x.section_name FROM examinations e LEFT JOIN exam_sections x ON x.examination_id = e.id WHERE e.status <> 'Cancelled' AND e.exam_date BETWEEN ? AND ?", [$days[0], end($days)]) as $r) {
        $s = substr($r['start_time'], 0, 5); $e = substr($r['end_time'], 0, 5);
        $roomBusy[$r['room_id'] . '|' . $r['exam_date']][] = [$s, $e];
        if ($r['section_name'] !== null) { $secBusy[mb_strtolower($r['section_name']) . '|' . $r['exam_date']][] = [$s, $e]; }
    }
    $rooms = fetch_all("SELECT * FROM rooms WHERE status = 'Available' ORDER BY capacity, name");
    $roomSecs = [];   // room id => set of section names already using it (for max_sections)
    foreach (fetch_all("SELECT e.room_id, LOWER(x.section_name) AS n FROM examinations e JOIN exam_sections x ON x.examination_id = e.id WHERE e.status = 'Scheduled'") as $r) $roomSecs[$r['room_id']][$r['n']] = true;

    $sql = 'SELECT c.*, y.department_id AS dept, y.year_level AS lvl, d.code AS dcode FROM class_sections c JOIN year_configs y ON y.id = c.year_config_id JOIN departments d ON d.id = y.department_id WHERE c.semester = ?';
    $par = [$sem];
    if (!empty($o['dept'])) { $sql .= ' AND y.department_id = ?'; $par[] = (int) $o['dept']; }
    if (!empty($o['year'])) { $sql .= ' AND y.year_level = ?'; $par[] = (int) $o['year']; }
    foreach (fetch_all($sql . ' ORDER BY d.code, y.year_level, c.name', $par) as $sec) {
        $label = $sec['dcode'] . ' ' . (YEAR_LEVELS[(int) $sec['lvl']] ?? '') . ' – ' . $sec['name'];
        $have = fetch_all("SELECT x.year_subject_id, e.room_id, e.exam_date, e.start_time, e.end_time FROM exam_sections x JOIN examinations e ON e.id = x.examination_id WHERE x.section_id = ? AND e.status = 'Scheduled'", [$sec['id']]);
        $haveYs = array_filter(array_map(fn($h) => (int) $h['year_subject_id'], $have));
        $todo = array_filter(fetch_all('SELECT * FROM year_subjects WHERE year_config_id = ? AND semester = ? ORDER BY sort_order, id', [$sec['year_config_id'], $sem]), fn($y) => !in_array((int) $y['id'], $haveYs, true));
        if (!$todo) continue;
        $students = (int) $sec['students'];
        if ($students < 1) { $res['unplaced'][] = [$label, 'No students registered for this section (set it in Year Levels).']; continue; }
        $key = mb_strtolower($sec['name']);

        $cands = $have ? array_values(array_filter($rooms, fn($r) => (int) $r['id'] === (int) $have[0]['room_id'])) : array_values(array_filter($rooms, function ($r) use ($students, $roomSecs, $key) {
            if ($students > (int) $r['capacity']) return false;
            return $r['max_sections'] === null || isset($roomSecs[$r['id']][$key]) || count($roomSecs[$r['id']] ?? []) < (int) $r['max_sections'];
        }));
        if (!$cands) { $res['unplaced'][] = [$label, $have ? 'Its room is not Available.' : 'No Available room fits ' . $students . ' students (capacity / max sections).']; continue; }

        $best = null;
        foreach ($cands as $room) {
            $rb = $roomBusy; $sb = $secBusy; $items = []; $miss = [];
            foreach ($todo as $ys) {
                $placed = false;
                foreach ($days as $d) {
                    $cnt = count($sb[$key . '|' . $d] ?? []);
                    if ($cnt >= $perDay) continue;
                    foreach ($slots as [$s, $e]) {
                        if (auto_overlap($rb[$room['id'] . '|' . $d] ?? [], $s, $e) || auto_overlap($sb[$key . '|' . $d] ?? [], $s, $e)) continue;
                        $rb[$room['id'] . '|' . $d][] = [$s, $e]; $sb[$key . '|' . $d][] = [$s, $e];
                        $items[] = ['ys' => (int) $ys['id'], 'name' => $ys['name'], 'date' => $d, 'start' => $s, 'end' => $e];
                        $placed = true; break 2;
                    }
                }
                if (!$placed) $miss[] = $ys['name'];
            }
            if ($best === null || count($miss) < count($best['miss'])) $best = ['room' => $room, 'items' => $items, 'miss' => $miss, 'rb' => $rb, 'sb' => $sb];
            if (!$miss) break;
        }
        $roomBusy = $best['rb']; $secBusy = $best['sb'];
        $roomSecs[$best['room']['id']][$key] = true;
        foreach ($best['miss'] as $m) $res['unplaced'][] = [$label . ' / ' . $m, 'No free room + time slot left in the date range. Add dates, slots or rooms.'];
        if ($best['items']) $res['plans'][(int) $sec['id']] = ['label' => $label, 'room' => $best['room'], 'items' => $best['items'], 'have' => $have, 'students' => $students];
    }
    return $res;
}

/** Saves the plan through section_save(). All-or-nothing; $commit=false rolls everything back (preview). */
function auto_schedule_run(PDO $pdo, ProctorScheduler $sched, array $plan, int $userId, bool $commit): array
{
    $errors = []; $made = 0;
    $nested = $pdo->inTransaction();   // inside another transaction (tests): use a savepoint instead
    if ($nested) $pdo->exec('SAVEPOINT auto_sched'); else $pdo->beginTransaction();
    try {
        foreach ($plan['plans'] as $secId => $p) {
            $subj = [];
            foreach (fetch_all("SELECT x.year_subject_id AS ys, e.id, e.exam_date, e.start_time, e.end_time FROM exam_sections x JOIN examinations e ON e.id = x.examination_id WHERE x.section_id = ? AND e.status = 'Scheduled' AND e.room_id = ? AND x.year_subject_id IS NOT NULL", [$secId, $p['room']['id']]) as $h)
                $subj[(int) $h['ys']] = ['on' => 1, 'id' => (int) $h['id'], 'date' => $h['exam_date'], 'start' => substr($h['start_time'], 0, 5), 'end' => substr($h['end_time'], 0, 5)];   // keep what already exists
            foreach ($p['items'] as $it) $subj[$it['ys']] = ['on' => 1, 'date' => $it['date'], 'start' => $it['start'], 'end' => $it['end']];
            $r = section_save($pdo, $sched, $p['room'], ['section_id' => $secId, 'subj' => $subj], $userId);
            foreach ($r['errors'] as $er) $errors[] = $er;
            $made += $r['made'];
        }
        $undo = $errors || !$commit;
        if ($nested) $pdo->exec($undo ? 'ROLLBACK TO SAVEPOINT auto_sched' : 'RELEASE SAVEPOINT auto_sched');
        elseif ($undo) $pdo->rollBack(); else $pdo->commit();
    } catch (Throwable $e) {
        if ($nested) $pdo->exec('ROLLBACK TO SAVEPOINT auto_sched'); elseif ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
    return ['errors' => $errors, 'made' => $errors ? 0 : $made];
}
