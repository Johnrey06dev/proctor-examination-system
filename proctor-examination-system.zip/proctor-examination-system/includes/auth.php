<?php
/**
 * includes/auth.php
 * Session handling, login/logout and role-based access control (RBAC).
 */

function start_secure_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_name('PESSESSID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => !empty($_SERVER['HTTPS']),
    ]);
    session_start();
}

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function is_logged_in(): bool
{
    return !empty($_SESSION['user']['id']);
}

function home_for_role(?string $role): string
{
    return in_array($role, ['admin', 'coordinator'], true) ? 'admin/dashboard.php' : ($role === 'teacher' ? 'teacher/dashboard.php' : 'login.php');
}

/** Redirects to login when there is no valid, active, non-expired session. */
function require_login(): array
{
    if (!is_logged_in()) {
        flash('warning', 'Please log in to continue.');
        redirect('login.php');
    }
    $now = time();
    if (isset($_SESSION['last_activity']) && ($now - $_SESSION['last_activity']) > SESSION_TIMEOUT) {
        logout_user(false);
        start_secure_session();
        flash('warning', 'Your session expired due to inactivity. Please log in again.');
        redirect('login.php');
    }
    $_SESSION['last_activity'] = $now;

    // The account may have been deactivated or deleted while logged in.
    $st = db()->prepare('SELECT status, role FROM users WHERE id = ?');
    $st->execute([$_SESSION['user']['id']]);
    $row = $st->fetch();
    if (!$row || $row['status'] !== 'active') {
        logout_user(false);
        start_secure_session();
        flash('danger', 'Your account is no longer active.');
        redirect('login.php');
    }
    return $_SESSION['user'];
}

/** Shows the 403 page (and logs it) and stops. */
function deny_access(array $user): void
{
    try {
        log_activity('unauthorized_access', 'security', null, null, null,
            $user['email'] . ' (' . $user['role'] . ') tried to open ' . ($_SERVER['REQUEST_URI'] ?? ''));
    } catch (Throwable $e) { /* never block the 403 page */ }
    http_response_code(403);
    $pageTitle = 'Access denied';
    $activeNav = '';
    require ROOT_PATH . '/includes/403.php';
    exit;
}

/** Backend RBAC guard. Wrong role => 403 page and a log entry. ('staff' = admin or scheduler) */
function require_role(string $role): array
{
    $user = require_login();
    $ok = $role === 'staff' ? in_array($user['role'], ['admin', 'coordinator'], true) : $user['role'] === $role;
    if (!$ok) deny_access($user);
    return $user;
}

/* ---------- detailed permissions: "module.action" ---------- */

const PERM_CATALOG = [
    'Departments'   => ['departments.view' => 'View', 'departments.edit' => 'Add / delete'],
    'Year & Subjects' => ['subjects.view' => 'View', 'subjects.edit' => 'Add / edit / delete'],
    'Rooms'         => ['rooms.view' => 'View', 'rooms.add' => 'Add rooms', 'rooms.edit' => 'Edit schedule', 'rooms.assign' => 'Assign proctors', 'rooms.delete' => 'Delete'],
    'Exam Schedule' => ['exams.view' => 'View'],
    'Auto-Assign'   => ['autoassign.view' => 'View / preview', 'autoassign.apply' => 'Apply'],
    'Exam Papers'   => ['papers.view' => 'View', 'papers.manage' => 'Prepare / release / mark done'],
    'Attendance'    => ['attendance.view' => 'View', 'attendance.reset' => 'Reset'],
    'Announcements' => ['announcements.view' => 'View', 'announcements.send' => 'Send'],
    'Exam Records'  => ['records.view' => 'View'],
    'Activity Log'  => ['activity.view' => 'View'],
];

function all_perms(): array
{
    $o = [];
    foreach (PERM_CATALOG as $g) foreach ($g as $k => $_) $o[] = $k;
    return $o;
}

function is_staff(): bool
{
    return in_array($_SESSION['user']['role'] ?? '', ['admin', 'coordinator'], true);
}

/** Permissions of the logged-in user (admin / scheduler = everything; a teacher = his access role + extras). */
function user_perms(): array
{
    static $cache = [];
    $u = $_SESSION['user'] ?? null;
    if (!$u) return [];
    if (isset($cache[$u['id']])) return $cache[$u['id']];
    if ($u['role'] === 'admin' || $u['role'] === 'coordinator') return $cache[$u['id']] = all_perms();
    $row = fetch_one('SELECT u.extra_perms, r.perms FROM users u LEFT JOIN access_roles r ON r.id = u.access_role_id WHERE u.id = ?', [$u['id']]);
    $list = array_filter(array_map('trim', explode(',', ($row['perms'] ?? '') . ',' . ($row['extra_perms'] ?? ''))));
    return $cache[$u['id']] = array_values(array_intersect(array_unique($list), all_perms()));
}

function user_can(string $perm): bool
{
    return in_array($perm, user_perms(), true);
}

/** Page guard by permission (a teacher who was given the permission may open it). */
function require_perm(string $perm): array
{
    $user = require_login();
    if (!user_can($perm)) deny_access($user);
    return $user;
}

/** Guard for the POST part of a page: reading is allowed, changing needs the permission. */
function require_perm_for_post(string $perm): void
{
    if (is_post() && !user_can($perm)) deny_access(require_login());
}

function load_login_user(string $where, $param): ?array
{
    $st = db()->prepare('SELECT u.*, t.id AS teacher_id, t.department_id
                         FROM users u LEFT JOIN teachers t ON t.user_id = u.id WHERE ' . $where);
    $st->execute([$param]);
    return $st->fetch() ?: null;
}

/** Final step of a login (after password and, if enabled, OTP). */
function complete_login(array $u): void
{
    session_regenerate_id(true);
    unset($_SESSION['otp_pending'], $_SESSION['csrf']);
    $_SESSION['user'] = [
        'id'            => (int) $u['id'],
        'name'          => $u['full_name'],
        'email'         => $u['email'],
        'role'          => $u['role'],
        'teacher_id'    => $u['teacher_id'] ? (int) $u['teacher_id'] : null,
        'department_id' => $u['department_id'] ? (int) $u['department_id'] : null,
    ];
    $_SESSION['last_activity'] = time();
    db()->prepare('UPDATE users SET last_login_at = ? WHERE id = ?')->execute([now(), $u['id']]);
    log_activity('login', 'user', (int) $u['id'], null, null, 'User logged in', (int) $u['id']);
}

/**
 * Verifies credentials with rate limiting + cooldown.
 * @return array [bool ok, ?string error, bool needsOtp, int waitSeconds]
 */
function attempt_login(string $email, string $password): array
{
    $ip = client_ip();
    $acctKey = 'login:acct:' . strtolower($email);
    $ipKey = 'login:ip:' . $ip;

    // blocked accounts / IPs are refused BEFORE the password is even checked
    foreach ([$acctKey, $ipKey] as $k) {
        if ($w = rl_blocked($k)) {
            return [false, 'Too many failed login attempts. Cooldown active – try again in ' . fmt_wait($w) . ' minutes.', false, $w];
        }
    }

    $u = load_login_user('u.email = ?', $email);
    if (!$u || !password_verify($password, $u['password_hash'])) {
        $w = max(rl_hit($acctKey, 5, 900, 300), rl_hit($ipKey, 20, 600, 600));   // 5 fails/15 min per account; 20 per 10 min per IP
        log_activity('login_failed', 'security', null, null, null, 'Failed login for ' . $email, null);
        if ($w) return [false, 'Too many failed login attempts. Cooldown active – try again in ' . fmt_wait($w) . ' minutes.', false, $w];
        return [false, 'Invalid email or password.', false, 0];
    }
    if ($u['status'] !== 'active') {
        return [false, 'This account is not active yet. If you just registered, wait for the administrator to approve it.', false, 0];
    }
    rl_clear($acctKey);

    if (password_needs_rehash($u['password_hash'], PASSWORD_DEFAULT)) {
        db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($password, PASSWORD_DEFAULT), $u['id']]);
    }

    if (user_needs_otp($u)) {
        $r = otp_issue($u);
        if (!$r['ok']) return [false, $r['error'], false, 0];
        session_regenerate_id(true);
        $_SESSION['otp_pending'] = ['uid' => (int) $u['id'], 'exp' => time() + 900, 'email' => mask_email($u['email'])];
        log_activity('otp_sent', 'security', (int) $u['id'], null, null, 'OTP e-mailed', (int) $u['id']);
        return [true, null, true, 0];
    }
    complete_login($u);
    return [true, null, false, 0];
}

function logout_user(bool $log = true): void
{
    if ($log && is_logged_in()) {
        log_activity('logout', 'user', (int) $_SESSION['user']['id'], null, null, 'User logged out');
    }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'] ?? '', $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/** Teacher id of the logged-in teacher (backend ownership checks use this). */
function my_teacher_id(): int
{
    return (int) ($_SESSION['user']['teacher_id'] ?? 0);
}
