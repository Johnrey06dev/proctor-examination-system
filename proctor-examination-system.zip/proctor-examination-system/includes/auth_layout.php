<?php
/** Shared page frame for the pages shown before login (register, QR scan...). */
function auth_head(string $title, string $heading, string $sub): void
{
    ?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> · <?= e(APP_SHORT) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Merriweather:wght@700;900&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<script>try{var t=localStorage.getItem('pps_theme');if(t)document.documentElement.setAttribute('data-theme',t)}catch(e){}</script>
<link href="<?= e(url('assets/css/app.css') . '?v=' . filemtime(ROOT_PATH . '/assets/css/app.css')) ?>" rel="stylesheet">
<link href="<?= e(url('assets/css/theme.css') . '?v=' . filemtime(ROOT_PATH . '/assets/css/theme.css')) ?>" rel="stylesheet">
</head>
<body>
<div class="login-page">
  <section class="login-art">
    <div class="logo"><i class="bi bi-mortarboard-fill"></i></div>
    <h1>Proctor Assignment &amp; Examination Paper Distribution</h1>
    <p>Rooms, sections, proctors and exam papers in one place.</p>
  </section>
  <section class="login-form-wrap">
    <div class="login-box">
      <h2><?= e($heading) ?></h2><p class="text-muted mb-4"><?= e($sub) ?></p>
      <?php foreach (flash_pull() as $f): ?><div class="alert alert-<?= e($f['type']) ?>"><?= e($f['msg']) ?></div><?php endforeach;
}

function auth_foot(): void
{
    ?>    </div>
  </section>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
}
