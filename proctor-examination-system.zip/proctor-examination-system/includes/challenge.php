<?php
/**
 * includes/challenge.php – e-mailed 6-digit codes that are NOT tied to a login
 * (registration with Gmail, changing the account e-mail). The state lives in the PHP session:
 * the code is stored hashed, expires in 10 minutes, 5 wrong tries, 60 s resend cooldown.
 */
const CHAL_TTL = 600;

function mail_ready(): bool
{
    return (get_settings()['smtp_verified'] ?? '0') === '1' && Mailer::configured();
}

/** @return array{ok:bool,error?:string} */
function chal_start(string $key, string $email, string $purpose, array $payload = []): array
{
    if (!mail_ready()) return ['ok' => false, 'error' => 'E-mail sending is not set up yet. The administrator must save the sender Gmail + App Password and press "Send test e-mail" in Security & OTP.'];
    $old = $_SESSION['chal'][$key] ?? null;
    if ($old && time() - $old['sent'] < 60) return ['ok' => false, 'error' => 'Please wait ' . (60 - (time() - $old['sent'])) . ' seconds before requesting a new code.'];
    if ($w = rl_hit('chal:send:' . strtolower($email), 5, 3600, 3600)) return ['ok' => false, 'error' => 'Too many codes sent to this e-mail. Try again in ' . fmt_wait($w) . ' minutes.'];
    if ($w = rl_hit('chal:ip:' . client_ip(), 15, 3600, 3600)) return ['ok' => false, 'error' => 'Too many requests from this device. Try again later.'];
    $code = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    try {
        Mailer::send($email, 'Your ProctorSys code', "Your ProctorSys code for $purpose is: $code\n\nIt expires in 10 minutes. If you did not ask for it, ignore this e-mail.",
            Mailer::html('Your code', '<p>Your code for <b>' . e($purpose) . '</b>:</p><p style="font-size:32px;letter-spacing:8px;font-weight:700;color:#0b2545;margin:10px 0">' . $code . '</p><p style="color:#6b7a90">Expires in 10 minutes. If you did not ask for it, ignore this e-mail.</p>'));
    } catch (Throwable $e) {
        return ['ok' => false, 'error' => 'Could not send the e-mail: ' . $e->getMessage()];
    }
    $_SESSION['chal'][$key] = ['hash' => password_hash($code, PASSWORD_DEFAULT), 'exp' => time() + CHAL_TTL, 'tries' => 0, 'sent' => time(), 'email' => $email, 'payload' => $payload];
    return ['ok' => true];
}

function chal_pending(string $key): ?array
{
    $c = $_SESSION['chal'][$key] ?? null;
    return $c && $c['exp'] > time() ? $c : null;
}

/** @return array{ok:bool,error?:string,payload?:array,email?:string} */
function chal_verify(string $key, string $code): array
{
    $c = chal_pending($key);
    if (!$c) return ['ok' => false, 'error' => 'The code expired. Start again.'];
    if ($w = rl_blocked('chal:verify:' . client_ip())) return ['ok' => false, 'error' => 'Too many wrong codes. Try again in ' . fmt_wait($w) . ' minutes.'];
    if ($c['tries'] >= 5) { unset($_SESSION['chal'][$key]); return ['ok' => false, 'error' => 'Too many wrong attempts. Start again.']; }
    $_SESSION['chal'][$key]['tries']++;
    $code = preg_replace('/\D/', '', $code);
    if (strlen($code) !== 6 || !password_verify($code, $c['hash'])) {
        rl_hit('chal:verify:' . client_ip(), 10, 900, 900);
        return ['ok' => false, 'error' => 'Incorrect code.'];
    }
    unset($_SESSION['chal'][$key]);
    return ['ok' => true, 'payload' => $c['payload'], 'email' => $c['email']];
}

function chal_clear(string $key): void { unset($_SESSION['chal'][$key]); }

/** Link of the login page that people can open (phones need the public address set in Security). */
function login_link(): string
{
    $b = rtrim(get_settings()['public_base_url'] ?? '', '/') ?: ((!empty($_SERVER['HTTPS']) ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost') . rtrim(BASE_URL, '/'));
    return $b . '/login.php';
}

/** Short e-mail to a user (welcome / approved). Never breaks the page when mail is not set up. */
function send_account_mail(string $to, string $subject, string $message): void
{
    if (!mail_ready()) return;
    try {
        Mailer::send($to, $subject, $message . "\n\nSign in: " . login_link(), Mailer::html($subject, '<p>' . nl2br(e($message)) . '</p><p><a href="' . e(login_link()) . '">Open the login page</a></p>'));
    } catch (Throwable $e) { /* ignore */ }
}
