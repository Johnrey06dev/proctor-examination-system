<?php
/**
 * includes/header.php  – shared layout (top part).
 * Set before including:  $pageTitle (string), $activeNav (string), optional $useCharts (bool)
 */
$user  = current_user();
$__role = $user['role'] ?? 'guest';
$pageTitle = $pageTitle ?? 'Dashboard';
$activeNav = $activeNav ?? '';
$__unread = $user ? unread_notifications($user['id']) : 0;

$__unreadMsg = 0;
try { $__unreadMsg = (int) fetch_value('SELECT COUNT(*) FROM messages WHERE to_user = ? AND is_read = 0', [$user['id'] ?? 0]); } catch (Throwable $e) { }
// every page an administrator / scheduler / delegated teacher can open: [key, href, icon, label, permission]
$__manage = [
    ['departments', 'admin/departments.php', 'building', 'Departments', 'departments.view'],
    ['years', 'admin/years.php', 'mortarboard', 'Year Levels', 'subjects.view'],
    ['rooms', 'admin/rooms.php', 'door-open', 'Rooms', 'rooms.view'],
    ['exams', 'admin/exams.php', 'calendar-event', 'Exam Schedule', 'exams.view'],
    ['board', 'admin/schedule_board.php', 'megaphone', 'Posted Schedule', 'exams.view'],
    ['autoassign', 'admin/auto_assign.php', 'magic', 'Auto-Assign', 'autoassign.view'],
    ['papers', 'admin/papers.php', 'file-earmark-text', 'Exam Papers', 'papers.view'],
    ['attendance', 'admin/attendance.php', 'clipboard-check', 'Attendance', 'attendance.view'],
    ['announcements', 'admin/announcements.php', 'megaphone', 'Announcements', 'announcements.view'],
    ['records', 'admin/records.php', 'archive', 'Exam Records', 'records.view'],
    ['logs', 'admin/logs.php', 'clock-history', 'Activity Log', 'activity.view'],
];
if ($__role === 'admin' || $__role === 'coordinator') {
    $__nav = [
        'Overview' => [['dashboard', 'admin/dashboard.php', 'speedometer2', 'Dashboard'], ['messages', 'admin/messages.php', 'chat-dots', 'Messages']],
        'People' => [
            ['teachers', 'admin/teachers.php', 'people', 'Teachers'],
            ['workload', 'admin/workload.php', 'bar-chart-line', 'Workload Balance'],
        ],
        'Examinations' => array_map(fn($x) => array_slice($x, 0, 4), array_values(array_filter($__manage, fn($x) => in_array($x[0], ['departments', 'years', 'rooms', 'exams', 'board', 'autoassign', 'papers'], true)))),
        'Proctors' => [
            ['assignments', 'admin/assignments.php', 'person-check', 'Proctor Assignments'],
            ['declined', 'admin/declined.php', 'arrow-repeat', 'Reassignment Center'],
            ['attendance', 'admin/attendance.php', 'clipboard-check', 'Attendance'],
        ],
        'System' => [
            ['announcements', 'admin/announcements.php', 'megaphone', 'Announcements'],
            ['records', 'admin/records.php', 'archive', 'Exam Records'],
            ['reports', 'admin/reports.php', 'printer', 'Reports'],
            ['logs', 'admin/logs.php', 'clock-history', 'Activity Log'],
            ['roles', 'admin/roles.php', 'person-gear', 'Roles &amp; Access'],
            ['users', 'admin/users.php', 'shield-lock', 'User Accounts'],
            ['settings', 'admin/settings.php', 'sliders', 'Algorithm Settings'],
            ['security', 'admin/security.php', 'shield-check', 'Security &amp; OTP'],
        ],
    ];
    if ($__role === 'coordinator') {
        foreach (['logs', 'users', 'settings', 'security', 'roles'] as $__k) foreach ($__nav as $__g => $__list) $__nav[$__g] = array_values(array_filter($__list, fn($x) => $x[0] !== $__k));
    }
} else {
    $__nav = [
        'My Workspace' => [
            ['dashboard', 'teacher/dashboard.php', 'speedometer2', 'Dashboard'],
            ['today', 'teacher/today.php', 'alarm', 'Exam Day'],
            ['assignments', 'teacher/assignments.php', 'person-check', 'My Assignments'],
            ['openexams', 'teacher/open_exams.php', 'door-open', 'Open Exams'],
            ['papers', 'teacher/papers.php', 'file-earmark-text', 'Exam Papers'],
            ['history', 'teacher/history.php', 'clock-history', 'History'],
            ['availability', 'teacher/availability.php', 'calendar-x', 'My Availability'],
            ['messages', 'teacher/messages.php', 'chat-dots', 'Messages'],
        ],
    ];
    $__mine = array_values(array_filter($__manage, fn($x) => user_can($x[4])));
    if ($__mine) $__nav['Manage'] = array_map(fn($x) => array_slice($x, 0, 4), $__mine);
}
foreach ($__nav as $__g => $__list) { if (!$__list) unset($__nav[$__g]); }
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?> · <?= e(APP_SHORT) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Merriweather:wght@700;900&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<script>try{var t=localStorage.getItem('pps_theme');if(t)document.documentElement.setAttribute('data-theme',t)}catch(e){}</script>
<link href="<?= e(url('assets/css/app.css') . '?v=' . filemtime(ROOT_PATH . '/assets/css/app.css')) ?>" rel="stylesheet">
<link href="<?= e(url('assets/css/theme.css') . '?v=' . filemtime(ROOT_PATH . '/assets/css/theme.css')) ?>" rel="stylesheet">
</head>
<body>
<div class="app-shell">
  <aside class="sidebar" id="sidebar">
    <a class="brand" href="<?= e(url(home_for_role($__role))) ?>">
      <span class="brand-mark"><i class="bi bi-mortarboard-fill"></i></span>
      <span class="brand-text"><strong><?= e(APP_SHORT) ?></strong><small><?= $__role === 'admin' ? 'Administrator' : ($__role === 'coordinator' ? 'Scheduler' : 'Teacher / Proctor') ?></small></span>
    </a>
    <nav class="side-nav">
      <?php foreach ($__nav as $__group => $__items): ?>
        <div class="nav-group"><?= e($__group) ?></div>
        <?php foreach ($__items as [$__key, $__href, $__icon, $__label]): ?>
          <a class="nav-item-link <?= $activeNav === $__key ? 'active' : '' ?>" href="<?= e(url($__href)) ?>">
            <i class="bi bi-<?= e($__icon) ?>"></i><span><?= $__label === 'Security &amp; OTP' ? $__label : e($__label) ?></span><?php if ($__key === 'messages' && $__unreadMsg): ?><span class="badge bg-danger ms-auto"><?= (int) $__unreadMsg ?></span><?php endif; ?><?php if ($__key === 'declined' && ($__dc = ProctorScheduler::pendingDeclines(db()))): ?><span class="badge bg-warning text-dark ms-auto"><?= (int) $__dc ?></span><?php endif; ?>
          </a>
        <?php endforeach; ?>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-foot">
      <a class="nav-item-link <?= $activeNav === 'notifications' ? 'active' : '' ?>" href="<?= e(url('notifications.php')) ?>"><i class="bi bi-bell"></i><span>Notifications</span><?php if ($__unread): ?><span class="badge bg-danger ms-auto"><?= (int) $__unread ?></span><?php endif; ?></a>
      <a class="nav-item-link <?= $activeNav === 'profile' ? 'active' : '' ?>" href="<?= e(url('profile.php')) ?>"><i class="bi bi-person-gear"></i><span>My Profile</span></a>
      <a class="nav-item-link" href="<?= e(url('logout.php')) ?>" data-confirm="Log out of your account?"><i class="bi bi-box-arrow-left"></i><span>Logout</span></a>
    </div>
  </aside>
  <div class="sidebar-backdrop" id="sidebarBackdrop"></div>

  <div class="main">
    <header class="topbar">
      <button class="btn btn-light btn-sm d-lg-none" id="sidebarToggle" type="button" aria-label="Menu"><i class="bi bi-list fs-5"></i></button>
      <h1 class="page-title"><?= e($pageTitle) ?></h1>
      <div class="ms-auto d-flex align-items-center gap-3">
        <button class="theme-btn" type="button" id="themeBtn" title="Light / Dark"><i class="bi bi-moon-stars"></i></button>
        <a class="top-bell" href="<?= e(url('notifications.php')) ?>" title="Notifications">
          <i class="bi bi-bell"></i><?php if ($__unread): ?><span class="dot"><?= (int) $__unread ?></span><?php endif; ?>
        </a>
        <div class="dropdown">
          <a class="user-chip dropdown-toggle" href="#" data-bs-toggle="dropdown">
            <?= avatar_html(me_row() ?: ['full_name' => $user['name'] ?? '?']) ?>
            <span class="d-none d-md-inline"><?= e($user['name'] ?? '') ?></span>
          </a>
          <ul class="dropdown-menu dropdown-menu-end shadow-sm">
            <li class="dropdown-header"><?= e($user['email'] ?? '') ?></li>
            <li><a class="dropdown-item" href="<?= e(url('profile.php')) ?>"><i class="bi bi-person me-2"></i>Profile &amp; password</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="<?= e(url('logout.php')) ?>" data-confirm="Log out of your account?"><i class="bi bi-box-arrow-left me-2"></i>Logout</a></li>
          </ul>
        </div>
      </div>
    </header>
    <main class="content">
      <?php if (empty(me_row()['gender']) && basename($_SERVER['SCRIPT_NAME']) !== 'profile.php'): ?><div class="alert alert-warning py-2"><i class="bi bi-person-badge me-1"></i>Complete your profile (first name, surname, gender and picture) so the greeting is correct. <a class="fw-semibold" href="<?= e(url('profile.php')) ?>">Open My Profile</a></div><?php endif; ?>
      <?php foreach (flash_pull() as $__flash): ?>
        <div class="alert alert-<?= e($__flash['type']) ?> alert-dismissible fade show" role="alert">
          <?= e($__flash['msg']) ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      <?php endforeach; ?>
