<?php
/**
 * includes/bootstrap.php
 * Include this ONE file at the top of every page. It loads configuration,
 * the database, helpers, authentication and starts a secure session.
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/ui.php';
require_once __DIR__ . '/ratelimit.php';
require_once __DIR__ . '/otp.php';
require_once __DIR__ . '/challenge.php';
require_once __DIR__ . '/auth_layout.php';
require_once __DIR__ . '/messaging.php';
require_once __DIR__ . '/sections.php';
require_once __DIR__ . '/year.php';
require_once __DIR__ . '/autoschedule.php';
require_once __DIR__ . '/../config/mail.php';
require_once __DIR__ . '/../backend/Mailer.php';
require_once __DIR__ . '/../backend/Attendance.php';
require_once __DIR__ . '/../backend/ProctorScheduler.php';
require_once __DIR__ . '/../backend/PaperTracker.php';

header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

start_secure_session();
throttle_requests();
