<?php
/**
 * includes/ratelimit.php – database-backed rate limiting with cooldown ("blocked_until").
 * Table: rate_limits (rl_key, hits, window_start, blocked_until).
 */

/** Seconds the key is still blocked (0 = free to go). */
function rl_blocked(string $key): int
{
    $st = db()->prepare('SELECT blocked_until FROM rate_limits WHERE rl_key = ?');
    $st->execute([mb_substr($key, 0, 150)]);
    $until = (int) $st->fetchColumn();
    return $until > time() ? $until - time() : 0;
}

/**
 * Register one hit. When more than $max hits happen inside $window seconds the key
 * is blocked for $block seconds. Returns the seconds the key is blocked (0 = allowed).
 */
function rl_hit(string $key, int $max, int $window, int $block): int
{
    $key = mb_substr($key, 0, 150);
    $now = time();
    $pdo = db();
    $st = $pdo->prepare('SELECT hits, window_start, blocked_until FROM rate_limits WHERE rl_key = ?');
    $st->execute([$key]);
    $r = $st->fetch();

    if (!$r) {
        try {
            $pdo->prepare('INSERT INTO rate_limits (rl_key, hits, window_start, blocked_until) VALUES (?,?,?,0)')->execute([$key, 1, $now]);
        } catch (PDOException $e) { /* parallel request created it – ignore */ }
        return 0;
    }
    if ((int) $r['blocked_until'] > $now) {
        return (int) $r['blocked_until'] - $now;
    }
    if ($now - (int) $r['window_start'] > $window) {            // window expired -> start again
        $pdo->prepare('UPDATE rate_limits SET hits = 1, window_start = ?, blocked_until = 0 WHERE rl_key = ?')->execute([$now, $key]);
        return 0;
    }
    $hits = (int) $r['hits'] + 1;
    if ($hits > $max) {
        $pdo->prepare('UPDATE rate_limits SET hits = ?, blocked_until = ? WHERE rl_key = ?')->execute([$hits, $now + $block, $key]);
        return $block;
    }
    $pdo->prepare('UPDATE rate_limits SET hits = ? WHERE rl_key = ?')->execute([$hits, $key]);
    return 0;
}

function rl_clear(string $key): void
{
    db()->prepare('DELETE FROM rate_limits WHERE rl_key = ?')->execute([mb_substr($key, 0, 150)]);
}

/** Human friendly "m:ss". */
function fmt_wait(int $sec): string
{
    return floor($sec / 60) . ':' . str_pad((string) ($sec % 60), 2, '0', STR_PAD_LEFT);
}

/** Global request throttle: stops one IP from flooding the server. */
function throttle_requests(): void
{
    try {
        $ip = client_ip();
        $wait = rl_hit('req:' . $ip, 300, 60, 60);     // 300 requests / minute / IP
        if ($wait > 0) {
            http_response_code(429);
            header('Retry-After: ' . $wait);
            exit('<!doctype html><meta charset="utf-8"><body style="font-family:Segoe UI,Arial;padding:40px;background:#f4f6f9"><div style="max-width:520px;margin:auto;background:#fff;padding:24px;border-left:5px solid #b26a00;border-radius:6px"><h2 style="color:#0b2545;margin-top:0">Too many requests</h2><p>You are sending requests too quickly. Please wait ' . (int) $wait . ' seconds and try again.</p></div></body>');
        }
    } catch (Throwable $e) {
        // table missing (migration not run yet) – never block the site because of this
    }
}
