<?php
/** Year module helpers: Department + Year Level + Semester -> registered subjects (used by Sections, Exam Schedule and Auto-Assign). */

/** School levels. College keeps its old keys 1-4; Grade n is stored as 100 + n. Elementary / Junior High have NO semester (stored as 0). */
const YEAR_LEVELS = [101 => 'Grade 1', 102 => 'Grade 2', 103 => 'Grade 3', 104 => 'Grade 4', 105 => 'Grade 5', 106 => 'Grade 6',
    107 => 'Grade 7', 108 => 'Grade 8', 109 => 'Grade 9', 110 => 'Grade 10', 111 => 'Grade 11', 112 => 'Grade 12',
    1 => 'First Year', 2 => 'Second Year', 3 => 'Third Year', 4 => 'Fourth Year'];
const SEMESTERS = [1 => 'First Semester', 2 => 'Second Semester'];
const SCHOOL_STAGES = [
    'elementary' => ['label' => 'Elementary', 'range' => 'Grade 1 – 6', 'levels' => [101, 102, 103, 104, 105, 106], 'sem' => false, 'code' => 'ELEM', 'dept' => 'Elementary Department', 'icon' => 'emoji-smile'],
    'junior' => ['label' => 'Junior High School', 'range' => 'Grade 7 – 10', 'levels' => [107, 108, 109, 110], 'sem' => false, 'code' => 'JHS', 'dept' => 'Junior High School Department', 'icon' => 'backpack'],
    'senior' => ['label' => 'Senior High School', 'range' => 'Grade 11 – 12', 'levels' => [111, 112], 'sem' => true, 'code' => 'SHS', 'dept' => 'Senior High School Department', 'icon' => 'journal-bookmark'],
    'college' => ['label' => 'College', 'range' => 'First – Fourth Year', 'levels' => [1, 2, 3, 4], 'sem' => true, 'code' => null, 'dept' => null, 'icon' => 'mortarboard'],
];

function level_stage(int $lvl): string
{
    foreach (SCHOOL_STAGES as $k => $st) if (in_array($lvl, $st['levels'], true)) return $k;
    return 'college';
}
/** Senior High and College have First / Second semester; Elementary and Junior High do not. */
function level_has_sem(int $lvl): bool { return SCHOOL_STAGES[level_stage($lvl)]['sem']; }
/** The semesters a level can have: [1,2] or [0 => whole school year]. */
function sem_list(int $lvl): array { return level_has_sem($lvl) ? SEMESTERS : [0 => 'Whole school year']; }
function sem_label(int $sem): string { return SEMESTERS[$sem] ?? ''; }
function level_rank(int $lvl): int { return $lvl >= 100 ? $lvl - 100 : $lvl + 20; }

/** The school levels this school uses (Settings -> School levels). Levels that already have year records are always included. */
function enabled_stages(): array
{
    $raw = (string) (get_settings()['school_levels'] ?? '');
    $on = array_values(array_filter(array_map('trim', explode(',', $raw)), fn($k) => isset(SCHOOL_STAGES[$k])));
    foreach (fetch_all('SELECT DISTINCT year_level FROM year_configs') as $r) $on[] = level_stage((int) $r['year_level']);
    $on = array_values(array_unique($on));
    if (!$on) $on = ['college'];
    return array_values(array_filter(array_keys(SCHOOL_STAGES), fn($k) => in_array($k, $on, true)));
}
/** level key => label, only for the levels the school uses, in school order. */
function year_level_options(): array
{
    $out = [];
    foreach (enabled_stages() as $st) foreach (SCHOOL_STAGES[$st]['levels'] as $l) $out[$l] = YEAR_LEVELS[$l];
    return $out;
}
/** Makes the Elementary / Junior High / Senior High department and all its grade cards (College is made per department). */
function ensure_stage(PDO $pdo, string $stage): int
{
    $st = SCHOOL_STAGES[$stage] ?? null;
    if (!$st || !$st['code']) return 0;
    $dept = (int) fetch_value('SELECT id FROM departments WHERE code = ?', [$st['code']]);
    if (!$dept) { $pdo->prepare('INSERT INTO departments (code, name, description, created_at) VALUES (?,?,?,?)')->execute([$st['code'], $st['dept'], $st['range'], now()]); $dept = (int) $pdo->lastInsertId(); }
    $made = 0;
    foreach ($st['levels'] as $l) if (!fetch_value('SELECT COUNT(*) FROM year_configs WHERE department_id = ? AND year_level = ?', [$dept, $l])) { $pdo->prepare('INSERT INTO year_configs (department_id, year_level, created_at) VALUES (?,?,?)')->execute([$dept, $l, now()]); $made++; }
    return $made;
}
function save_school_levels(PDO $pdo, array $stages): void
{
    $stages = array_values(array_filter($stages, fn($k) => isset(SCHOOL_STAGES[$k])));
    foreach ($stages as $k) ensure_stage($pdo, $k);
    $pdo->prepare('DELETE FROM system_settings WHERE setting_key = ?')->execute(['school_levels']);
    $pdo->prepare('INSERT INTO system_settings (setting_key, setting_value, description) VALUES (?,?,?)')->execute(['school_levels', implode(',', $stages), 'School levels this school uses (elementary, junior, senior, college)']);
    get_settings(true);
}

/** Every year configuration with its subjects: for the Year page, the section form and the scheduler. */
function year_catalog(): array
{
    $out = [];
    foreach (fetch_all('SELECT y.id, y.department_id, y.year_level, d.code AS dept_code, d.name AS dept_name FROM year_configs y JOIN departments d ON d.id = y.department_id ORDER BY d.code, y.year_level') as $y) {
        $out[(int) $y['id']] = ['id' => (int) $y['id'], 'dept' => (int) $y['department_id'], 'dept_code' => $y['dept_code'], 'dept_name' => $y['dept_name'],
            'year' => (int) $y['year_level'], 'label' => YEAR_LEVELS[(int) $y['year_level']] ?? ('Year ' . $y['year_level']), 'stage' => level_stage((int) $y['year_level']), 'has_sem' => level_has_sem((int) $y['year_level']), 'subjects' => [0 => [], 1 => [], 2 => []], 'sections' => [0 => [], 1 => [], 2 => []]];
    }
    foreach (fetch_all('SELECT id, year_config_id, semester, name FROM year_subjects ORDER BY sort_order, id') as $s) {
        if (isset($out[(int) $s['year_config_id']])) $out[(int) $s['year_config_id']]['subjects'][(int) $s['semester']][] = ['id' => (int) $s['id'], 'name' => $s['name']];
    }
    foreach (fetch_all('SELECT id, year_config_id, semester, name, students FROM class_sections ORDER BY name') as $s) {
        if (isset($out[(int) $s['year_config_id']])) $out[(int) $s['year_config_id']]['sections'][(int) $s['semester']][] = ['id' => (int) $s['id'], 'name' => $s['name'], 'students' => (int) $s['students']];
    }
    uasort($out, fn($a, $b) => [level_rank($a['year']), $a['dept_code']] <=> [level_rank($b['year']), $b['dept_code']]);
    return $out;
}

/** The subjects registered for a department + year level + semester (for the Auto Scheduler). */
function year_subjects_for(int $dept, int $year, int $semester): array
{
    return fetch_all('SELECT s.id, s.name, s.year_config_id FROM year_subjects s JOIN year_configs y ON y.id = s.year_config_id WHERE y.department_id = ? AND y.year_level = ? AND s.semester = ? ORDER BY s.sort_order, s.id', [$dept, $year, $semester]);
}

/** Makes sure the Year subject has a row in `subjects` (which the exam tables reference) and returns its id. */
function ensure_subject(PDO $pdo, int $ysId): int
{
    $ys = fetch_one('SELECT s.*, y.department_id FROM year_subjects s JOIN year_configs y ON y.id = s.year_config_id WHERE s.id = ?', [$ysId]);
    if (!$ys) throw new RuntimeException('Subject not found in the Year module.');
    if ($ys['subject_id'] && fetch_value('SELECT COUNT(*) FROM subjects WHERE id = ?', [$ys['subject_id']])) return (int) $ys['subject_id'];
    $sid = (int) fetch_value('SELECT id FROM subjects WHERE department_id = ? AND LOWER(name) = LOWER(?) ORDER BY id LIMIT 1', [$ys['department_id'], $ys['name']]);
    if (!$sid) {
        $words = preg_split('/[^A-Za-z0-9]+/', $ys['name'], -1, PREG_SPLIT_NO_EMPTY);
        $base = strtoupper(implode('', array_map(fn($w) => $w[0], $words)));
        if (strlen($base) < 3) $base = strtoupper(substr(preg_replace('/[^A-Za-z0-9]/', '', $ys['name']), 0, 4));
        $base = substr($base ?: 'SUBJ', 0, 8); $code = $base; $n = 1;
        while (fetch_value('SELECT COUNT(*) FROM subjects WHERE code = ?', [$code])) { $n++; $code = $base . $n; }
        $pdo->prepare('INSERT INTO subjects (code, name, department_id, created_at) VALUES (?,?,?,?)')->execute([$code, $ys['name'], $ys['department_id'], now()]);
        $sid = (int) $pdo->lastInsertId();
    }
    $pdo->prepare('UPDATE year_subjects SET subject_id = ? WHERE id = ?')->execute([$sid, $ysId]);
    return $sid;
}

/** Everything the scheduler needs for one department + year + semester: its sections and subjects, and which section x subject exams already exist. */
function year_plan(int $dept, int $year, int $semester): array
{
    $yc = fetch_one('SELECT id FROM year_configs WHERE department_id = ? AND year_level = ?', [$dept, $year]);
    if (!$yc) return ['sections' => [], 'subjects' => [], 'slots' => 0, 'scheduled' => 0];
    $subjects = fetch_all('SELECT id, name FROM year_subjects WHERE year_config_id = ? AND semester = ? ORDER BY sort_order, id', [$yc['id'], $semester]);
    $sections = fetch_all('SELECT id, name, students FROM class_sections WHERE year_config_id = ? AND semester = ? ORDER BY name', [$yc['id'], $semester]);
    $done = 0;
    foreach ($sections as &$s) {
        $s['scheduled'] = (int) fetch_value("SELECT COUNT(*) FROM exam_sections x JOIN examinations e ON e.id = x.examination_id WHERE x.section_id = ? AND e.status <> 'Cancelled' AND x.year_subject_id IN (SELECT id FROM year_subjects WHERE year_config_id = ? AND semester = ?)", [$s['id'], $yc['id'], $semester]);
        $done += $s['scheduled'];
    }
    unset($s);
    return ['sections' => $sections, 'subjects' => $subjects, 'slots' => count($sections) * count($subjects), 'scheduled' => $done];
}
