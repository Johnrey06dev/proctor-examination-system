<?php
/** Rules for placing a section in an exam (used by the Exam Schedule panel; the room panel applies the same rules). */

function known_sections(): array
{
    $k = [];
    foreach (fetch_all('SELECT name, students FROM class_sections ORDER BY id') as $r) $k[mb_strtolower($r['name'])] = ['name' => $r['name'], 'students' => (int) $r['students']];   // registered in the Year module
    foreach (fetch_all('SELECT section_name, examinees FROM exam_sections ORDER BY id') as $r) $k[mb_strtolower($r['section_name'])] = $k[mb_strtolower($r['section_name'])] ?? ['name' => $r['section_name'], 'students' => (int) $r['examinees']];
    return $k;
}

/** @return string[] error messages (empty = OK) */
function section_rule_errors(string $section, int $students, int $subjectId, int $roomId, string $date, string $start, string $end, int $examId = 0): array
{
    $e = [];
    $room = fetch_one('SELECT * FROM rooms WHERE id = ?', [$roomId]);
    if (!$room) return ['Select a room.'];
    if (date('N', strtotime($date)) == 7) $e[] = 'Sunday is not a class day. Choose Monday to Saturday.';
    if ($students > (int) $room['capacity']) $e[] = $students . ' students are more than the capacity (' . $room['capacity'] . ') of ' . $room['name'] . '.';
    if ($room['max_sections'] !== null) {
        $has = fetch_value("SELECT COUNT(*) FROM examinations e JOIN exam_sections s ON s.examination_id = e.id WHERE e.room_id = ? AND e.status = 'Scheduled' AND LOWER(s.section_name) = LOWER(?) AND e.id <> ?", [$roomId, $section, $examId]);
        $n = (int) fetch_value("SELECT COUNT(DISTINCT LOWER(s.section_name)) FROM examinations e JOIN exam_sections s ON s.examination_id = e.id WHERE e.room_id = ? AND e.status = 'Scheduled' AND e.id <> ?", [$roomId, $examId]);
        if (!$has && $n >= (int) $room['max_sections']) $e[] = $room['name'] . ' allows only ' . $room['max_sections'] . ' section(s) and it is full. Choose another room.';
    }
    if ($c = fetch_one("SELECT e.exam_code, r.name AS rn FROM examinations e JOIN exam_sections s ON s.examination_id = e.id JOIN rooms r ON r.id = e.room_id WHERE LOWER(s.section_name) = LOWER(?) AND e.status = 'Scheduled' AND e.id <> ? AND e.exam_date = ? AND e.start_time < ? AND e.end_time > ?", [$section, $examId, $date, $end, $start]))
        $e[] = 'Section ' . $section . ' already has an exam at that time (' . $c['exam_code'] . ' in ' . $c['rn'] . ').';
    if ($c = fetch_one("SELECT e.exam_code, e.exam_date FROM examinations e JOIN exam_sections s ON s.examination_id = e.id WHERE LOWER(s.section_name) = LOWER(?) AND e.status = 'Scheduled' AND e.id <> ? AND e.subject_id = ?", [$section, $examId, $subjectId]))
        $e[] = 'Section ' . $section . ' already takes this subject (' . $c['exam_code'] . ', ' . $c['exam_date'] . ').';
    return $e;
}

/** Deletes one exam together with everything that hangs on it. */
function purge_exam(PDO $pdo, int $x): void
{
    $pdo->prepare('DELETE FROM paper_tracking_history WHERE distribution_id IN (SELECT id FROM paper_distribution WHERE examination_id = ?)')->execute([$x]);
    $pdo->prepare('UPDATE messages SET examination_id = NULL WHERE examination_id = ?')->execute([$x]);
    foreach (['attendance', 'paper_distribution', 'proctor_assignments', 'assignment_runs', 'exam_sections'] as $tb) $pdo->prepare("DELETE FROM $tb WHERE examination_id = ?")->execute([$x]);
    $pdo->prepare('DELETE FROM examinations WHERE id = ?')->execute([$x]);
}

/**
 * Adds or edits ONE section in ONE room together with the exams of its selected subjects (all in the caller's transaction).
 * Each selected subject = one exam = exactly ONE proctor, so the required proctors of a section = its number of subjects.
 * Never deletes an exam that already has a proctor or a paper record; it reports an error instead.
 *
 * @param array $in section_id, name, department_id, year_level, semester, students, subj[yearSubjectId] => [on, id, date, start, end]
 * @return array{errors:string[],warnings:string[],made:int,upd:int,removed:int,section_id:int}
 */
function section_save(PDO $pdo, ProctorScheduler $sched, array $room, array $in, int $userId): array
{
    $r = ['errors' => [], 'warnings' => [], 'made' => 0, 'upd' => 0, 'removed' => 0, 'section_id' => 0];
    $rid = (int) $room['id'];
    $secId = (int) ($in['section_id'] ?? 0);
    $reg = $secId ? fetch_one('SELECT c.*, y.department_id AS dept, y.year_level AS lvl FROM class_sections c JOIN year_configs y ON y.id = c.year_config_id WHERE c.id = ?', [$secId]) : null;
    if ($secId && !$reg) { $r['errors'][] = 'That section is not registered in the Year module.'; return $r; }
    if ($reg) {   // a registered section decides its own name, department, year, semester and students
        $name = $reg['name']; $dept = (int) $reg['dept']; $yr = (int) $reg['lvl']; $sem = (int) $reg['semester']; $stud = (int) $reg['students'];
    } else {
        $name = trim(preg_replace('/\s+/', ' ', mb_substr((string) ($in['name'] ?? ''), 0, 60)));
        $dept = (int) ($in['department_id'] ?? 0); $yr = (int) ($in['year_level'] ?? 0); $sem = (int) ($in['semester'] ?? 0); $stud = (int) ($in['students'] ?? 0);
    }
    if ($name === '') { $r['errors'][] = 'Choose the section.'; return $r; }
    $yc = fetch_one('SELECT * FROM year_configs WHERE department_id = ? AND year_level = ?', [$dept, $yr]);
    if (!$yc) { $r['errors'][] = $name . ': choose a Department and Year Level that are registered in the Year module.'; return $r; }
    if (!isset(sem_list($yr)[$sem])) { $r['errors'][] = $name . ': choose the semester.'; return $r; }
    if ($stud < 1) { $r['errors'][] = $name . ': enter the number of students.'; return $r; }
    if ($stud > (int) $room['capacity']) { $r['errors'][] = $name . ': ' . $stud . ' students are more than the ' . $room['capacity'] . ' seats (capacity) of ' . $room['name'] . '.'; return $r; }

    // the subjects the administrator ticked: they must really belong to this department / year / semester
    $sel = [];
    foreach ((array) ($in['subj'] ?? []) as $ysId => $d) {
        if (empty($d['on'])) continue;
        $ys = fetch_one('SELECT * FROM year_subjects WHERE id = ? AND year_config_id = ? AND semester = ?', [(int) $ysId, $yc['id'], $sem]);
        if (!$ys) { $r['errors'][] = $name . ': a selected subject is not registered for ' . (YEAR_LEVELS[$yr] ?? '') . (sem_label($sem) ? ' / ' . sem_label($sem) : '') . '.'; continue; }
        $sel[(int) $ysId] = ['ys' => $ys, 'eid' => (int) ($d['id'] ?? 0), 'date' => (string) ($d['date'] ?? ''), 'start' => norm_time((string) ($d['start'] ?? '')), 'end' => norm_time((string) ($d['end'] ?? ''))];
    }
    if (!$sel && !$r['errors']) $r['errors'][] = $name . ': select at least one subject.';
    if ($r['errors']) return $r;

    // the section record (reuse a registered section of the same name)
    $sec = $reg ?: fetch_one('SELECT * FROM class_sections WHERE year_config_id = ? AND semester = ? AND LOWER(name) = LOWER(?)', [$yc['id'], $sem, $name]);
    $cfgChanged = $sec && ((int) $sec['year_config_id'] !== (int) $yc['id'] || (int) $sec['semester'] !== $sem);
    if ($sec) {
        $secId = (int) $sec['id'];
        $pdo->prepare('UPDATE class_sections SET name=?, department_id=?, year_config_id=?, semester=?, students=? WHERE id=?')->execute([$name, $dept, $yc['id'], $sem, $stud, $secId]);
    } else {
        $pdo->prepare('INSERT INTO class_sections (name, department_id, year_config_id, semester, students, created_at) VALUES (?,?,?,?,?,?)')->execute([$name, $dept, $yc['id'], $sem, $stud, now()]);
        $secId = (int) $pdo->lastInsertId();
    }
    $r['section_id'] = $secId;
    // older exams typed in by name only join the registered section
    $pdo->prepare('UPDATE exam_sections SET section_id = ? WHERE section_id IS NULL AND LOWER(section_name) = LOWER(?)')->execute([$secId, $name]);
    $pdo->prepare('UPDATE exam_sections SET section_name = ?, examinees = ? WHERE section_id = ?')->execute([$name, $stud, $secId]);
    // a cancelled exam must not block the subject from being scheduled again
    $pdo->prepare("UPDATE exam_sections SET year_subject_id = NULL WHERE section_id = ? AND examination_id IN (SELECT id FROM examinations WHERE status = 'Cancelled')")->execute([$secId]);

    // an older exam of this section that uses the same subject becomes the exam of the ticked Year subject (no duplicate)
    foreach ($sel as $ysId => $s) {
        $pdo->prepare('UPDATE exam_sections SET year_subject_id = ? WHERE section_id = ? AND year_subject_id IS NULL AND subject_id = ?')->execute([$ysId, $secId, ensure_subject($pdo, $ysId)]);
    }
    $mine = fetch_all('SELECT x.id AS xid, x.year_subject_id, x.examination_id, e.room_id, e.status, e.exam_code, r.name AS room_name, c.capacity
        FROM exam_sections x JOIN examinations e ON e.id = x.examination_id JOIN rooms r ON r.id = e.room_id JOIN rooms c ON c.id = e.room_id WHERE x.section_id = ?', [$secId]);
    $bySubject = [];
    foreach ($mine as $m) if ($m['year_subject_id']) $bySubject[(int) $m['year_subject_id']] = $m;

    foreach ($mine as $m) {   // exams in other rooms must still fit the new student count and the new year / semester
        if ((int) $m['room_id'] !== $rid && $stud > (int) $m['capacity']) $r['errors'][] = $name . ': ' . $stud . ' students do not fit ' . $m['room_name'] . ' (' . $m['capacity'] . ' seats), where it already has ' . $m['exam_code'] . '.';
        if ((int) $m['room_id'] !== $rid && $m['year_subject_id'] && !isset($sel[(int) $m['year_subject_id']]) && $cfgChanged && $m['status'] === 'Scheduled') $r['errors'][] = $name . ': ' . $m['exam_code'] . ' in ' . $m['room_name'] . ' is for the old year / semester. Remove it there first.';
    }

    // subjects un-ticked in THIS room: remove their exam only when nobody is assigned and no paper record exists
    foreach ($mine as $m) {
        if ((int) $m['room_id'] !== $rid || !$m['year_subject_id'] || isset($sel[(int) $m['year_subject_id']]) || $m['status'] !== 'Scheduled') continue;
        $eid = (int) $m['examination_id'];
        if ($sched->activeCount($eid) > 0) { $r['errors'][] = $m['exam_code'] . ' cannot be removed: a proctor is assigned. Remove the proctor first.'; continue; }
        if (fetch_value('SELECT COUNT(*) FROM paper_distribution WHERE examination_id = ?', [$eid])) { $r['errors'][] = $m['exam_code'] . ' cannot be removed: it already has an exam paper record.'; continue; }
        purge_exam($pdo, $eid); $r['removed']++;
        unset($bySubject[(int) $m['year_subject_id']]);
    }

    $touched = [];
    foreach ($sel as $ysId => $s) {
        $ys = $s['ys']; $lab = $name . ' / ' . $ys['name']; $dt = $s['date']; $st_ = $s['start']; $en_ = $s['end'];
        if (!valid_date($dt)) { $r['errors'][] = $lab . ': enter the exam date.'; continue; }
        if (!$st_ || !$en_ || $st_ >= $en_) { $r['errors'][] = $lab . ': the end time must be later than the start time.'; continue; }
        $sid = ensure_subject($pdo, $ysId);
        $old = $bySubject[$ysId] ?? null;
        if ($old && (int) $old['room_id'] !== $rid) { $r['errors'][] = $lab . ' is already scheduled in ' . $old['room_name'] . ' (' . $old['exam_code'] . ').'; continue; }
        $eid = $old ? (int) $old['examination_id'] : 0;
        $oe = $eid ? fetch_one('SELECT * FROM examinations WHERE id = ?', [$eid]) : null;
        if (!$oe && $dt < date('Y-m-d')) { $r['errors'][] = $lab . ': the date cannot be in the past.'; continue; }
        if ($oe && $oe['status'] !== 'Scheduled') continue;
        if (fetch_one("SELECT exam_code FROM examinations WHERE room_id = ? AND exam_date = ? AND status <> 'Cancelled' AND id <> ? AND start_time < ? AND end_time > ?", [$rid, $dt, $eid, $en_, $st_])) { $r['errors'][] = $lab . ': the room is already used at that time.'; continue; }
        if ($errs = section_rule_errors($name, $stud, $sid, $rid, $dt, $st_, $en_, $eid)) { foreach ($errs as $er) $r['errors'][] = $lab . ': ' . $er; continue; }
        if ($oe) {
            $changed = $oe['exam_date'] !== $dt || substr($oe['start_time'], 0, 5) !== substr($st_, 0, 5) || substr($oe['end_time'], 0, 5) !== substr($en_, 0, 5);
            if ($changed) { $new = $oe; $new['exam_date'] = $dt; $new['start_time'] = $st_; $new['end_time'] = $en_; if ($bad = $sched->rescheduleConflicts($new)) { $r['errors'][] = $lab . ': cannot move – ' . $bad[0]; continue; } }
            $pdo->prepare('UPDATE examinations SET subject_id=?, department_id=?, exam_date=?, start_time=?, end_time=?, name=? WHERE id=?')->execute([$sid, $dept, $dt, $st_, $en_, $ys['name'], $eid]);
            $pdo->prepare('UPDATE exam_sections SET subject_id = ?, year_subject_id = ? WHERE examination_id = ?')->execute([$sid, $ysId, $eid]);
            $r['upd']++;
        } else {
            $code = next_code('examinations', 'exam_code', 'EX-');
            $pdo->prepare('INSERT INTO examinations (exam_code, name, exam_type, subject_id, department_id, room_id, exam_date, start_time, end_time, required_proctors, paper_sets, status, created_by, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
                ->execute([$code, $ys['name'], 'Midterm', $sid, $dept, $rid, $dt, $st_, $en_, 1, $stud + PaperTracker::EXTRA_COPIES, 'Scheduled', $userId, now()]);
            $eid = (int) $pdo->lastInsertId();
            $pdo->prepare('INSERT INTO exam_sections (examination_id, section_name, subject_id, examinees, sort_order, section_id, year_subject_id) VALUES (?,?,?,?,1,?,?)')->execute([$eid, $name, $sid, $stud, $secId, $ysId]);
            $r['made']++;
        }
        $touched[] = $eid;
    }
    if ($r['errors']) return $r;

    // exactly ONE proctor per subject: keep every exam of the section in step with its student count and paper copies
    foreach (fetch_all("SELECT e.id FROM examinations e JOIN exam_sections x ON x.examination_id = e.id WHERE x.section_id = ? AND e.status = 'Scheduled'", [$secId]) as $e) {
        $eid = (int) $e['id'];
        if ($sched->activeCount($eid) <= 1) $pdo->prepare('UPDATE examinations SET required_proctors = 1 WHERE id = ?')->execute([$eid]);
        else $r['warnings'][] = 'Exam ' . fetch_value('SELECT exam_code FROM examinations WHERE id = ?', [$eid]) . ' has more than one proctor. A subject needs exactly one; remove the extra proctor.';
        PaperTracker::sync($pdo, $eid, $userId);
    }
    return $r;
}

/** Subjects of a section and the proctors it needs: one proctor per subject. */
function section_requirements(int $sectionId): array
{
    $n = (int) fetch_value("SELECT COUNT(*) FROM exam_sections x JOIN examinations e ON e.id = x.examination_id WHERE x.section_id = ? AND e.status = 'Scheduled'", [$sectionId]);
    return ['subjects' => $n, 'proctors' => $n];
}

/** Links an exam typed in the Exam Schedule panel to the registered section and to its Year-module subject (when they exist). */
function section_link(string $sectionName, int $subjectId): array
{
    $sec = fetch_one('SELECT c.id, c.year_config_id, c.semester FROM class_sections c WHERE LOWER(c.name) = LOWER(?)
        ORDER BY (SELECT COUNT(*) FROM year_subjects y WHERE y.year_config_id = c.year_config_id AND y.semester = c.semester AND y.subject_id = ?) DESC, c.id DESC LIMIT 1', [$sectionName, $subjectId]);
    if (!$sec) return [null, null];
    $ys = fetch_value('SELECT id FROM year_subjects WHERE subject_id = ? AND year_config_id = ? AND semester = ?', [$subjectId, $sec['year_config_id'], $sec['semester']]);
    return [(int) $sec['id'], $ys ? (int) $ys : null];
}

/** Renames a registered section and / or changes its students: every exam and paper record of the section follows. Returns error messages. */
function section_update(PDO $pdo, int $id, string $name, int $students, int $userId = 0): array
{
    $sec = fetch_one('SELECT * FROM class_sections WHERE id = ?', [$id]);
    $name = trim(preg_replace('/\s+/', ' ', mb_substr($name, 0, 60)));
    if (!$sec) return ['Section not found.'];
    if ($name === '') return ['Enter the section name.'];
    if ($students < 1) return ['Enter the number of students.'];
    if (fetch_value('SELECT COUNT(*) FROM class_sections WHERE year_config_id = ? AND semester = ? AND LOWER(name) = LOWER(?) AND id <> ?', [$sec['year_config_id'], $sec['semester'], $name, $id])) return ['This semester already has a section named ' . $name . '.'];
    foreach (fetch_all("SELECT DISTINCT r.name, r.capacity FROM exam_sections x JOIN examinations e ON e.id = x.examination_id JOIN rooms r ON r.id = e.room_id WHERE x.section_id = ? AND e.status = 'Scheduled'", [$id]) as $r) {
        if ($students > (int) $r['capacity']) return [$students . ' students do not fit ' . $r['name'] . ' (' . $r['capacity'] . ' seats), where this section already has an exam.'];
    }
    $pdo->prepare('UPDATE class_sections SET name = ?, students = ? WHERE id = ?')->execute([$name, $students, $id]);
    $pdo->prepare('UPDATE exam_sections SET section_name = ?, examinees = ? WHERE section_id = ?')->execute([$name, $students, $id]);
    foreach (fetch_all('SELECT DISTINCT examination_id FROM exam_sections WHERE section_id = ?', [$id]) as $e) PaperTracker::sync($pdo, (int) $e['examination_id'], $userId);
    return [];
}

/**
 * Exams for the schedule board, grouped Year level -> Section. Used by the public home page (no proctor names) and by the admin panel.
 * @return array{years: array, total: int}
 */
function schedule_board(array $f = [], bool $admin = false): array
{
    $where = ["e.status = 'Scheduled'"]; $par = [];
    if (!$admin) $where[] = 'e.is_public = 1';
    if (empty($f['past'])) { $where[] = 'e.exam_date >= ?'; $par[] = date('Y-m-d'); }
    if (!empty($f['dept'])) { $where[] = 'e.department_id = ?'; $par[] = (int) $f['dept']; }
    if (!empty($f['year'])) { $where[] = ((int) $f['year'] === 9) ? 'y.year_level IS NULL' : 'y.year_level = ?'; if ((int) $f['year'] !== 9) $par[] = (int) $f['year']; }
    if (($q = trim((string) ($f['q'] ?? ''))) !== '') { $where[] = '(x.section_name LIKE ? OR b.name LIKE ? OR r.name LIKE ?)'; array_push($par, "%$q%", "%$q%", "%$q%"); }
    $rows = fetch_all("SELECT e.id, e.exam_code, e.exam_date, e.start_time, e.end_time, e.is_public, e.room_id, r.name AS room, r.building, b.name AS subject, d.code AS dept,
            x.section_name AS section, x.examinees AS students, x.section_id, y.year_level, c.semester
        FROM examinations e JOIN exam_sections x ON x.examination_id = e.id JOIN subjects b ON b.id = e.subject_id JOIN rooms r ON r.id = e.room_id JOIN departments d ON d.id = e.department_id
        LEFT JOIN class_sections c ON c.id = x.section_id LEFT JOIN year_configs y ON y.id = c.year_config_id
        WHERE " . implode(' AND ', $where) . ' ORDER BY COALESCE(y.year_level, 9), x.section_name, e.exam_date, e.start_time, e.id', $par);
    $years = [];
    foreach ($rows as $r) {
        $yl = $r['year_level'] ? (int) $r['year_level'] : 9;
        $key = mb_strtolower($r['section']) . '|' . (int) $r['section_id'];
        $years[$yl]['label'] = $yl === 9 ? 'Other sections' : (YEAR_LEVELS[$yl] ?? 'Year ' . $yl);
        $years[$yl]['sections'][$key] ??= ['name' => $r['section'], 'dept' => $r['dept'], 'semester' => $r['semester'] ? (SEMESTERS[(int) $r['semester']] ?? '') : '', 'students' => (int) $r['students'], 'exams' => []];
        $years[$yl]['sections'][$key]['exams'][] = $r;
    }
    uksort($years, fn($a, $b) => ($a === 9 ? 999 : level_rank($a)) <=> ($b === 9 ? 999 : level_rank($b)));   // Grades first, then College, then Other
    return ['years' => $years, 'total' => count($rows)];
}

/** Moves one exam to another room / date / time with every check (room, section, proctors). Returns error messages. */
function exam_reschedule(PDO $pdo, ProctorScheduler $sched, int $examId, int $roomId, string $date, string $start, string $end): array
{
    $e = fetch_one("SELECT e.*, x.section_name, x.examinees FROM examinations e LEFT JOIN exam_sections x ON x.examination_id = e.id WHERE e.id = ?", [$examId]);
    if (!$e) return ['Examination not found.'];
    if ($e['status'] !== 'Scheduled') return ['Only a scheduled examination can be edited.'];
    $room = fetch_one('SELECT * FROM rooms WHERE id = ?', [$roomId]);
    $start = norm_time($start); $end = norm_time($end);
    if (!$room) return ['Choose a room.'];
    if (!valid_date($date)) return ['Enter the exam date.'];
    if (!$start || !$end || $start >= $end) return ['The end time must be later than the start time.'];
    $moved = $e['exam_date'] !== $date || substr($e['start_time'], 0, 5) !== substr($start, 0, 5) || substr($e['end_time'], 0, 5) !== substr($end, 0, 5);
    if ($moved && $date < date('Y-m-d')) return ['The date cannot be in the past.'];
    if ((int) $e['examinees'] > (int) $room['capacity']) return [$e['examinees'] . ' students do not fit ' . $room['name'] . ' (' . $room['capacity'] . ' seats).'];
    if (fetch_one("SELECT exam_code FROM examinations WHERE room_id = ? AND exam_date = ? AND status <> 'Cancelled' AND id <> ? AND start_time < ? AND end_time > ?", [$roomId, $date, $examId, $end, $start])) return [$room['name'] . ' is already used at that time.'];
    if ($e['section_name'] && ($errs = section_rule_errors($e['section_name'], (int) $e['examinees'], (int) $e['subject_id'], $roomId, $date, $start, $end, $examId))) return $errs;
    if ($moved) {
        $new = $e; $new['exam_date'] = $date; $new['start_time'] = $start; $new['end_time'] = $end; $new['room_id'] = $roomId;
        if ($bad = $sched->rescheduleConflicts($new)) return ['Cannot move: ' . $bad[0]];
    }
    $pdo->prepare('UPDATE examinations SET room_id = ?, exam_date = ?, start_time = ?, end_time = ? WHERE id = ?')->execute([$roomId, $date, $start, $end, $examId]);
    if ($moved || (int) $e['room_id'] !== $roomId) {
        foreach (fetch_all("SELECT teacher_id FROM proctor_assignments WHERE examination_id = ? AND status IN ('Pending Review','Confirmed')", [$examId]) as $a) {
            if ($uid = teacher_user_id((int) $a['teacher_id'])) notify($uid, 'Exam schedule changed', $e['exam_code'] . ' (' . $e['name'] . ') is now ' . fmt_date($date) . ', ' . time_range($start, $end) . ', ' . $room['name'] . '.', 'schedule_update', 'teacher/assignments.php');
        }
    }
    return [];
}
