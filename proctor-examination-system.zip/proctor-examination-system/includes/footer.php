    </main>
    <footer class="app-footer">
      <?= e(APP_NAME) ?> &middot; Thesis project &middot; <?= date('Y') ?>
    </footer>
  </div>
</div>

<!-- Global confirmation dialog (used by data-confirm attributes) -->
<div class="modal fade" id="confirmModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title"><i class="bi bi-question-circle me-2"></i>Please confirm</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body" id="confirmText">Are you sure?</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-navy" id="confirmOk">Yes, continue</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php if (!empty($useCharts)): ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<?php endif; ?>
<script src="<?= e(url('assets/js/app.js') . '?v=' . filemtime(ROOT_PATH . '/assets/js/app.js')) ?>"></script>
<?= $extraScripts ?? '' ?>
</body>
</html>
