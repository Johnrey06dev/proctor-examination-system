<?php
/** includes/403.php – shown when a logged-in user opens a page of another role. */
require ROOT_PATH . '/includes/header.php';
?>
<div class="card-panel text-center py-5">
  <i class="bi bi-shield-exclamation display-3 text-danger"></i>
  <h3 class="mt-3">403 – Access denied</h3>
  <p class="text-muted">Your account does not have permission to open this page.<br>This attempt was recorded in the activity log.</p>
  <a class="btn btn-navy" href="<?= e(url(home_for_role($_SESSION['user']['role'] ?? null))) ?>">Back to my dashboard</a>
</div>
<?php require ROOT_PATH . '/includes/footer.php';
