<?php
/**
 * includes/functions.php
 * Reusable helpers: escaping, URLs, flash messages, CSRF, formatting,
 * badges, settings, notifications and activity logging.
 */

/* ---------- output / url ---------- */

function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function url(string $path = ''): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

function redirect(string $path): void
{
    $target = preg_match('#^https?://#', $path) ? $path : url($path);
    header('Location: ' . $target);
    exit;
}

function client_ip(): string
{
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

/* ---------- flash messages ---------- */

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $message];
}

function flash_pull(): array
{
    $items = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $items;
}

/* ---------- CSRF ---------- */

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

/** Stops the request when a POST arrives without a valid CSRF token. */
function csrf_verify(): void
{
    $sent = $_POST['csrf_token'] ?? '';
    if (!is_string($sent) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $sent)) {
        http_response_code(419);
        exit('Security check failed (invalid or expired form token). Go back, refresh the page and try again.');
    }
}

function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
}

/** Call at the top of every POST handler. */
function require_post_csrf(): bool
{
    if (!is_post()) {
        return false;
    }
    csrf_verify();
    return true;
}

/* ---------- input ---------- */

function input_str(string $key, int $max = 255, ?array $src = null): string
{
    $src = $src ?? $_POST;
    $v = isset($src[$key]) && is_string($src[$key]) ? trim($src[$key]) : '';
    return mb_substr($v, 0, $max);
}

function input_int(string $key, ?array $src = null): int
{
    $src = $src ?? $_POST;
    return isset($src[$key]) ? (int) $src[$key] : 0;
}

function valid_date(string $d): bool
{
    $dt = DateTime::createFromFormat('Y-m-d', $d);
    return $dt && $dt->format('Y-m-d') === $d;
}

/** Normalises "HH:MM" or "HH:MM:SS" to "HH:MM:SS"; returns null if invalid. */
function norm_time(string $t): ?string
{
    if (!preg_match('/^([01]\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?$/', $t, $m)) {
        return null;
    }
    return sprintf('%s:%s:%s', $m[1], $m[2], $m[3] ?? '00');
}

function time_to_min(string $t): int
{
    $p = explode(':', $t);
    return ((int) $p[0]) * 60 + (int) ($p[1] ?? 0);
}

/* ---------- formatting ---------- */

function now(): string
{
    return date('Y-m-d H:i:s');
}

function fmt_date(?string $d): string
{
    return $d ? date('M d, Y', strtotime($d)) : '—';
}

function fmt_time(?string $t): string
{
    return $t ? date('g:i A', strtotime($t)) : '—';
}

function fmt_dt(?string $dt): string
{
    return $dt ? date('M d, Y g:i A', strtotime($dt)) : '—';
}

function time_range(?string $s, ?string $e): string
{
    return fmt_time($s) . ' – ' . fmt_time($e);
}

/** Colour-coded status badge (see assets/css/app.css .s-*). */
function status_badge(?string $status): string
{
    if ($status === null || $status === '') {
        return '<span class="badge-status s-none">—</span>';
    }
    $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $status));
    return '<span class="badge-status s-' . e($slug) . '">' . e($status) . '</span>';
}

function empty_state(string $icon, string $title, string $text = ''): string
{
    return '<div class="empty-state"><i class="bi bi-' . e($icon) . '"></i><h6>' . e($title) . '</h6>'
        . ($text !== '' ? '<p>' . e($text) . '</p>' : '') . '</div>';
}

/* ---------- settings ---------- */

function get_settings(bool $refresh = false): array
{
    static $cache = null;
    if ($cache === null || $refresh) {
        $cache = [];
        foreach (db()->query('SELECT setting_key, setting_value FROM system_settings') as $r) {
            $cache[$r['setting_key']] = $r['setting_value'];
        }
        $cache += [
            'max_exams_per_day' => '3', 'min_gap_minutes' => '0', 'dept_rule' => 'none',
            'dept_weight' => '0.5', 'period_start' => '', 'period_end' => '',
            'examinees_per_proctor' => '30', 'attendance_open_minutes' => '60', 'testing_mode' => '0', 'otp_enabled' => '0', 'smtp_verified' => '0', 'email_notifications' => '0',
            'public_schedule' => '1', 'registration_open' => '1', 'registration_approval' => '1', 'qr_login_enabled' => '1', 'public_base_url' => '',
        ];
    }
    return $cache;
}

/* ---------- activity log + notifications ---------- */

function log_activity(string $action, ?string $entityType = null, ?int $entityId = null,
                      ?string $old = null, ?string $new = null, ?string $description = null, ?int $userId = null): void
{
    $uid = $userId ?? ($_SESSION['user']['id'] ?? null);
    $st = db()->prepare('INSERT INTO activity_logs (user_id, action, entity_type, entity_id, old_value, new_value, description, ip_address, created_at)
                         VALUES (?,?,?,?,?,?,?,?,?)');
    $st->execute([$uid, $action, $entityType, $entityId, $old, $new, $description, client_ip(), now()]);
}

function notify(int $userId, string $title, string $message, string $type = 'info', ?string $link = null): void
{
    $st = db()->prepare('INSERT INTO notifications (user_id, title, message, type, link, is_read, created_at) VALUES (?,?,?,?,?,0,?)');
    $st->execute([$userId, $title, mb_substr($message, 0, 500), $type, $link, now()]);
    // optional e-mail copy (Security page -> "E-mail notifications"); never breaks the main action
    try {
        $s = get_settings();
        if (($s['email_notifications'] ?? '0') === '1' && ($s['smtp_verified'] ?? '0') === '1' && Mailer::configured()) {
            $to = fetch_value('SELECT email FROM users WHERE id = ?', [$userId]);
            if ($to) Mailer::send($to, $title, $message, Mailer::html($title, nl2br(e($message))));
        }
    } catch (Throwable $e) { /* ignore */ }
}

function notify_admins(string $title, string $message, string $type = 'info', ?string $link = null): void
{
    foreach (db()->query("SELECT id FROM users WHERE role IN ('admin','coordinator') AND status='active'")->fetchAll() as $a) {
        notify((int) $a['id'], $title, $message, $type, $link);
    }
}

function teacher_user_id(int $teacherId): ?int
{
    $st = db()->prepare('SELECT user_id FROM teachers WHERE id = ?');
    $st->execute([$teacherId]);
    $v = $st->fetchColumn();
    return $v ? (int) $v : null;
}

function unread_notifications(int $userId): int
{
    $st = db()->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
    $st->execute([$userId]);
    return (int) $st->fetchColumn();
}

/* ---------- misc ---------- */

function password_rules_error(string $pw): ?string
{
    if (strlen($pw) < 8) return 'Password must be at least 8 characters.';
    if (!preg_match('/[A-Za-z]/', $pw) || !preg_match('/\d/', $pw)) return 'Password must contain letters and numbers.';
    return null;
}

/** Next sequential code like EX-0010. */
function next_code(string $table, string $column, string $prefix, int $pad = 4): string
{
    $max = 0;
    $st = db()->prepare("SELECT $column FROM $table WHERE $column LIKE ?");
    $st->execute([$prefix . '%']);
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $code) {
        $n = (int) substr($code, strlen($prefix));
        if ($n > $max) $max = $n;
    }
    return $prefix . str_pad((string) ($max + 1), $pad, '0', STR_PAD_LEFT);
}

/** Permanently deletes a user account (and the teacher profile + history that belongs to it). Returns an error text or null. */
function delete_user_account(int $id, int $actorId): ?string
{
    $pdo = db();
    $u = fetch_one('SELECT * FROM users WHERE id = ?', [$id]);
    if (!$u) return 'Account not found.';
    if ($id === $actorId) return 'You cannot delete your own account.';
    if ($u['role'] === 'admin' && (int) fetch_value("SELECT COUNT(*) FROM users WHERE role='admin' AND status='active' AND id <> ?", [$id]) < 1) return 'You cannot delete the last administrator.';
    $own = !$pdo->inTransaction();
    if ($own) $pdo->beginTransaction();
    try {
        $t = fetch_one('SELECT id FROM teachers WHERE user_id = ?', [$id]);
        if ($t) {
            $tid = (int) $t['id'];
            $pdo->prepare('UPDATE paper_distribution SET proctor_teacher_id = NULL WHERE proctor_teacher_id = ?')->execute([$tid]);
            $pdo->prepare('DELETE FROM proctor_assignments WHERE teacher_id = ?')->execute([$tid]);
            $pdo->prepare('DELETE FROM teacher_availability WHERE teacher_id = ?')->execute([$tid]);
            $pdo->prepare('DELETE FROM attendance WHERE teacher_id = ?')->execute([$tid]);
            $pdo->prepare('DELETE FROM teachers WHERE id = ?')->execute([$tid]);
        }
        foreach (['notifications', 'otp_codes', 'announcement_reads'] as $tb) { try { $pdo->prepare("DELETE FROM $tb WHERE user_id = ?")->execute([$id]); } catch (Throwable $e) {} }
        foreach (['from_user', 'to_user'] as $c) { try { $pdo->prepare("DELETE FROM messages WHERE $c = ?")->execute([$id]); } catch (Throwable $e) {} }
        try { $pdo->prepare('UPDATE announcements SET created_by = NULL WHERE created_by = ?')->execute([$id]); } catch (Throwable $e) {}
        $pdo->prepare('UPDATE activity_logs SET user_id = NULL WHERE user_id = ?')->execute([$id]);
        $pdo->prepare('DELETE FROM users WHERE id = ?')->execute([$id]);
        log_activity('user_deleted', 'user', $id, null, null, 'Account ' . $u['email'] . ' (' . $u['role'] . ') deleted');
        if ($own) $pdo->commit();
    } catch (Throwable $e) { if ($own) $pdo->rollBack(); return 'Could not delete: ' . (APP_DEBUG ? $e->getMessage() : 'the account is still in use.'); }
    return null;
}


/* ---------- names, greeting, profile photo ---------- */
const NAME_SUFFIXES = ['Jr.', 'Sr.', 'II', 'III', 'IV', 'V'];

/** "Juan D. Cruz Jr." from the separate parts */
function compose_name(string $first, string $middle, string $last, string $suffix = ''): string
{
    $mi = trim($middle) !== '' ? mb_strtoupper(mb_substr(trim($middle), 0, 1)) . '.' : '';
    return trim(preg_replace('/\s+/', ' ', trim($first) . ' ' . $mi . ' ' . trim($last) . ' ' . trim($suffix)));
}

/** Reads first_name, middle_name, last_name, suffix, gender from $_POST. @return array{0:array,1:string[]} [parts, errors] */
function name_parts_from_post(): array
{
    $p = ['first' => input_str('first_name', 60), 'middle' => input_str('middle_name', 60), 'last' => input_str('last_name', 60), 'suffix' => input_str('suffix', 10), 'gender' => input_str('gender', 10)];
    $e = [];
    if (mb_strlen($p['first']) < 2) $e[] = 'Enter the first name.';
    if (mb_strlen($p['last']) < 2) $e[] = 'Enter the surname.';
    if (!in_array($p['suffix'], NAME_SUFFIXES, true)) $p['suffix'] = '';
    if (!in_array($p['gender'], ['Male', 'Female'], true)) $e[] = 'Choose the gender (it is used in the greeting: Sir / Ma\'am).';
    $p['full'] = compose_name($p['first'], $p['middle'], $p['last'], $p['suffix']);
    return [$p, $e];
}

/** Full row of the logged-in user (cached per request) */
function me_row(): array
{
    static $row = null;
    if ($row === null) $row = fetch_one('SELECT * FROM users WHERE id = ?', [(int) ($_SESSION['user']['id'] ?? 0)]) ?: [];
    return $row;
}

/** "Good Morning, Sir Juan!" (Sir for male, Ma'am for female, none if not set) */
function greeting(?array $u = null): string
{
    $u = $u ?: me_row();
    $h = (int) date('G');
    $g = $h < 12 ? 'Good Morning' : ($h < 18 ? 'Good Afternoon' : 'Good Evening');
    $first = trim((string) ($u['first_name'] ?? '')) ?: (explode(' ', trim((string) ($u['full_name'] ?? '')))[0] ?? '');
    $title = ($u['gender'] ?? '') === 'Male' ? 'Sir ' : (($u['gender'] ?? '') === 'Female' ? "Ma'am " : '');
    return $g . ', ' . $title . $first . '!';
}

function avatar_url(?string $photo): ?string
{
    return $photo ? url('uploads/avatars/' . rawurlencode($photo)) : null;
}

/** HTML of a round avatar: photo or initials */
function avatar_html(array $u, string $cls = 'avatar'): string
{
    $src = avatar_url($u['photo'] ?? null);
    if ($src) return '<span class="' . $cls . '"><img src="' . e($src) . '" alt=""></span>';
    return '<span class="' . $cls . '">' . e(strtoupper(mb_substr($u['first_name'] ?? '' ?: ($u['full_name'] ?? '?'), 0, 1))) . '</span>';
}

/** Saves an uploaded profile photo (square JPEG 400px, metadata removed). @return string|null error message */
function save_avatar(int $uid, array $f): ?string
{
    if (($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return 'Choose a picture first.';
    if ($f['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) return 'The upload failed. Try a smaller picture.';
    if ($f['size'] > 3 * 1024 * 1024) return 'The picture is too big (max 3 MB).';
    $info = @getimagesize($f['tmp_name']);
    if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_GIF, IMAGETYPE_WEBP], true)) return 'Only JPG, PNG, GIF or WEBP pictures are allowed.';
    $dir = ROOT_PATH . '/uploads/avatars';
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) return 'The uploads folder cannot be created.';
    $name = 'u' . $uid . '_' . bin2hex(random_bytes(6)) . '.jpg';
    if (function_exists('imagecreatefromstring')) {
        $src = @imagecreatefromstring((string) file_get_contents($f['tmp_name']));
        if (!$src) return 'That picture could not be read.';
        $w = imagesx($src); $h = imagesy($src); $side = min($w, $h);
        $dst = imagecreatetruecolor(400, 400);
        imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
        imagecopyresampled($dst, $src, 0, 0, (int) (($w - $side) / 2), (int) (($h - $side) / 2), 400, 400, $side, $side);
        $ok = imagejpeg($dst, $dir . '/' . $name, 85);
        imagedestroy($src); imagedestroy($dst);
        if (!$ok) return 'The picture could not be saved.';
    } else {
        if ($info[2] !== IMAGETYPE_JPEG) return 'Please upload a JPG picture (the server cannot convert other types).';
        if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) return 'The picture could not be saved.';
    }
    $old = fetch_value('SELECT photo FROM users WHERE id = ?', [$uid]);
    db()->prepare('UPDATE users SET photo = ? WHERE id = ?')->execute([$name, $uid]);
    if ($old && preg_match('/^[A-Za-z0-9_.-]+$/', $old)) @unlink($dir . '/' . $old);
    return null;
}

function remove_avatar(int $uid): void
{
    $old = fetch_value('SELECT photo FROM users WHERE id = ?', [$uid]);
    if ($old && preg_match('/^[A-Za-z0-9_.-]+$/', $old)) @unlink(ROOT_PATH . '/uploads/avatars/' . $old);
    db()->prepare('UPDATE users SET photo = NULL WHERE id = ?')->execute([$uid]);
}
