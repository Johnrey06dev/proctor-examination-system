<?php
/**
 * includes/ui.php – small UI helpers shared by the pages.
 */

/** <option> list. $rows = array of rows, $val/$label = column names (label may be a callable). */
function options_html(array $rows, string $val, $label, $selected = null, ?string $placeholder = null): string
{
    $h = $placeholder !== null ? '<option value="">' . e($placeholder) . '</option>' : '';
    foreach ($rows as $r) {
        $text = is_callable($label) ? $label($r) : $r[$label];
        $sel = ((string) $selected !== '' && (string) $selected === (string) $r[$val]) ? ' selected' : '';
        $h .= '<option value="' . e($r[$val]) . '"' . $sel . '>' . e($text) . '</option>';
    }
    return $h;
}

function fetch_all(string $sql, array $params = []): array
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

function fetch_one(string $sql, array $params = []): ?array
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetch() ?: null;
}

function fetch_value(string $sql, array $params = [])
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchColumn();
}

function dept_list(): array { return fetch_all('SELECT id, code, name FROM departments ORDER BY code'); }
function subject_list(): array { return fetch_all('SELECT id, code, name, department_id FROM subjects ORDER BY code'); }
function room_list(): array { return fetch_all('SELECT id, name, building, capacity, status FROM rooms ORDER BY name'); }
function teacher_list(): array
{
    return fetch_all('SELECT t.id, t.teacher_no, u.full_name FROM teachers t JOIN users u ON u.id = t.user_id ORDER BY u.full_name');
}

/** True when a PDOException is a duplicate-key / unique violation (MySQL 23000 / SQLite 19). */
function is_duplicate_error(PDOException $e): bool
{
    return $e->getCode() === '23000' && (stripos($e->getMessage(), 'duplicate') !== false || stripos($e->getMessage(), 'unique') !== false);
}

/** Build a query string while keeping current filters. */
function qs(array $override = []): string
{
    $q = array_merge($_GET, $override);
    foreach ($q as $k => $v) { if ($v === '' || $v === null) unset($q[$k]); }
    return $q ? '?' . http_build_query($q) : '';
}

/** Classroom-like seat grid (empty) for a room card. */
function room_grid_html(int $rows, int $cols, int $max = 10): string
{
    $rows = max(1, min($rows, $max)); $cols = max(1, min($cols, $max + 2));
    $h = '<div class="mini-room" style="--c:' . $cols . '">';
    for ($i = 0; $i < $rows * $cols; $i++) $h .= '<i></i>';
    return $h . '</div>';
}
