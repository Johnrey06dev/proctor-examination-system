<?php
/**
 * includes/otp.php – e-mailed one-time passwords (OTP) for login.
 * Codes: 6 digits, stored hashed, expire in 5 minutes, max 5 wrong tries,
 * resend cooldown 60 s, max 5 e-mails per hour per user.
 */
const OTP_TTL_SECONDS = 300;
const OTP_RESEND_COOLDOWN = 60;
const OTP_MAX_ATTEMPTS = 5;

function otp_enabled(): bool
{
    $s = get_settings();
    return ($s['otp_enabled'] ?? '0') === '1' && ($s['smtp_verified'] ?? '0') === '1';
}

/** Does THIS user have to enter an e-mailed code? (global switch OR his own switch, and e-mail must work) */
function user_needs_otp(array $u): bool
{
    $s = get_settings();
    if (($s['smtp_verified'] ?? '0') !== '1') return false;
    return ($s['otp_enabled'] ?? '0') === '1' || !empty($u['otp_enabled']);
}

function mask_email(string $email): string
{
    [$u, $d] = array_pad(explode('@', $email, 2), 2, '');
    return mb_substr($u, 0, 2) . str_repeat('*', max(2, mb_strlen($u) - 2)) . '@' . $d;
}

/** Seconds until another code may be requested (0 = now). */
function otp_cooldown_left(int $userId): int
{
    $st = db()->prepare('SELECT created_at FROM otp_codes WHERE user_id = ? ORDER BY id DESC LIMIT 1');
    $st->execute([$userId]);
    $last = $st->fetchColumn();
    if (!$last) return 0;
    $left = OTP_RESEND_COOLDOWN - (time() - strtotime((string) $last));
    return $left > 0 ? $left : 0;
}

/** Creates and e-mails a new code. @return array{ok:bool,error?:string} */
function otp_issue(array $user): array
{
    $uid = (int) $user['id'];
    if ($left = otp_cooldown_left($uid)) {
        return ['ok' => false, 'error' => 'Please wait ' . $left . ' seconds before requesting a new code.'];
    }
    if ($wait = rl_hit('otp:send:' . $uid, 5, 3600, 3600)) {
        return ['ok' => false, 'error' => 'Too many codes requested. Try again in ' . fmt_wait($wait) . ' minutes.'];
    }
    $code = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $pdo = db();
    $pdo->prepare('DELETE FROM otp_codes WHERE user_id = ? AND used_at IS NULL')->execute([$uid]);
    $pdo->prepare('INSERT INTO otp_codes (user_id, code_hash, expires_at, attempts, created_at) VALUES (?,?,?,0,?)')
        ->execute([$uid, password_hash($code, PASSWORD_DEFAULT), date('Y-m-d H:i:s', time() + OTP_TTL_SECONDS), now()]);
    $id = (int) $pdo->lastInsertId();
    try {
        $text = "Your ProctorSys verification code is: $code\n\nIt expires in 5 minutes. If you did not try to log in, ignore this e-mail and change your password.";
        $html = Mailer::html('Your verification code', '<p>Use this code to finish signing in:</p><p style="font-size:32px;letter-spacing:8px;font-weight:700;color:#0b2545;margin:10px 0">' . $code . '</p><p style="color:#6b7a90">Expires in 5 minutes. If this was not you, ignore this e-mail and change your password.</p>');
        Mailer::send($user['email'], 'Your ProctorSys login code', $text, $html);
    } catch (Throwable $e) {
        $pdo->prepare('DELETE FROM otp_codes WHERE id = ?')->execute([$id]);
        return ['ok' => false, 'error' => 'Could not send the code: ' . $e->getMessage()];
    }
    return ['ok' => true];
}

/** @return array{ok:bool,error?:string} */
function otp_verify(int $userId, string $code): array
{
    if ($wait = rl_blocked('otp:verify:' . $userId)) {
        return ['ok' => false, 'error' => 'Too many wrong codes. Try again in ' . fmt_wait($wait) . ' minutes.'];
    }
    $code = preg_replace('/\D/', '', $code);
    $st = db()->prepare('SELECT * FROM otp_codes WHERE user_id = ? AND used_at IS NULL ORDER BY id DESC LIMIT 1');
    $st->execute([$userId]);
    $row = $st->fetch();
    if (!$row || strtotime($row['expires_at']) < time()) {
        return ['ok' => false, 'error' => 'The code expired. Request a new one.'];
    }
    if ((int) $row['attempts'] >= OTP_MAX_ATTEMPTS) {
        return ['ok' => false, 'error' => 'Too many wrong attempts for this code. Request a new one.'];
    }
    db()->prepare('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?')->execute([$row['id']]);
    if (strlen($code) !== 6 || !password_verify($code, $row['code_hash'])) {
        rl_hit('otp:verify:' . $userId, 10, 900, 900);            // 10 wrong codes / 15 min -> 15 min block
        return ['ok' => false, 'error' => 'Incorrect code. ' . max(0, OTP_MAX_ATTEMPTS - (int) $row['attempts'] - 1) . ' attempt(s) left for this code.'];
    }
    db()->prepare('UPDATE otp_codes SET used_at = ? WHERE id = ?')->execute([now(), $row['id']]);
    rl_clear('otp:verify:' . $userId);
    return ['ok' => true];
}
