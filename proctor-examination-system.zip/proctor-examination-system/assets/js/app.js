/* assets/js/app.js – sidebar, confirmation dialogs, loading buttons, small helpers */
(function () {
  'use strict';

  // ----- responsive sidebar -----
  var sidebar = document.getElementById('sidebar');
  var backdrop = document.getElementById('sidebarBackdrop');
  var toggle = document.getElementById('sidebarToggle');
  function setSidebar(open) {
    if (!sidebar) return;
    sidebar.classList.toggle('open', open);
    if (backdrop) backdrop.classList.toggle('show', open);
  }
  if (toggle) toggle.addEventListener('click', function () { setSidebar(!sidebar.classList.contains('open')); });
  if (backdrop) backdrop.addEventListener('click', function () { setSidebar(false); });

  // ----- confirmation dialog for [data-confirm] on forms, buttons and links -----
  var modalEl = document.getElementById('confirmModal');
  var modal = modalEl && window.bootstrap ? new bootstrap.Modal(modalEl) : null;
  var pending = null;

  function askConfirm(message, onOk) {
    if (!modal) { if (window.confirm(message)) onOk(); return; }
    document.getElementById('confirmText').textContent = message;
    pending = onOk;
    modal.show();
  }
  var okBtn = document.getElementById('confirmOk');
  if (okBtn) okBtn.addEventListener('click', function () {
    if (modal) modal.hide();
    if (pending) { var fn = pending; pending = null; fn(); }
  });

  document.addEventListener('click', function (ev) {
    var el = ev.target.closest('[data-confirm]');
    if (!el) return;
    var msg = el.getAttribute('data-confirm');
    if (el.tagName === 'A') {
      ev.preventDefault();
      askConfirm(msg, function () { window.location.href = el.href; });
    } else if (el.type === 'submit' && el.form) {
      ev.preventDefault();
      var form = el.form;
      askConfirm(msg, function () {
        // keep the clicked button's name/value in the submission
        if (el.name) {
          var h = document.createElement('input');
          h.type = 'hidden'; h.name = el.name; h.value = el.value;
          form.appendChild(h);
        }
        form.dataset.confirmed = '1';
        form.submit();
      });
    }
  });

  // ----- loading state on submit buttons -----
  document.addEventListener('submit', function (ev) {
    var form = ev.target;
    var btn = form.querySelector('button[type=submit][data-loading]');
    if (btn && !btn.classList.contains('btn-loading')) {
      btn.classList.add('btn-loading');
      btn.dataset.label = btn.innerHTML;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>' + (btn.getAttribute('data-loading') || 'Working...');
      setTimeout(function () { btn.disabled = true; }, 0);
    }
  });

  // ----- generic helpers -----
  // data-fill-modal: copy data-* attributes of a button into the inputs of a modal form
  document.addEventListener('click', function (ev) {
    var btn = ev.target.closest('[data-edit]');
    if (!btn) return;
    var target = document.querySelector(btn.getAttribute('data-edit'));
    if (!target) return;
    if (target.reset) target.reset();
    Object.keys(btn.dataset).forEach(function (k) {
      if (k === 'edit' || k === 'bsToggle' || k === 'bsTarget') return;
      var input = target.querySelector('[name="' + k + '"]');
      if (!input) return;
      if (input.type === 'checkbox') input.checked = btn.dataset[k] === '1';
      else input.value = btn.dataset[k];
    });
  });

  // reset modal forms when they are opened through an "Add" button
  document.querySelectorAll('[data-reset-form]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var f = document.querySelector(btn.getAttribute('data-reset-form'));
      if (!f) return;
      f.reset();
      var id = f.querySelector('input[name=id]');
      if (id) id.value = '';
    });
  });

  // auto-dismiss success alerts
  setTimeout(function () {
    document.querySelectorAll('.alert-success').forEach(function (a) {
      if (window.bootstrap) bootstrap.Alert.getOrCreateInstance(a).close();
    });
  }, 6000);
})();

/* v2: top progress bar + count-up */
(function(){
  var bar=document.createElement('div');bar.id='topbar-progress';document.body.appendChild(bar);
  bar.style.width='70%';window.addEventListener('load',function(){bar.style.width='100%';setTimeout(function(){bar.style.opacity='0'},400);});
  document.addEventListener('click',function(e){var a=e.target.closest('a[href]');if(a&&a.host===location.host&&!a.target&&!a.hasAttribute('data-bs-toggle')&&a.getAttribute('href')[0]!=='#'){bar.style.opacity='1';bar.style.width='60%';}});
  document.querySelectorAll('.stat-value').forEach(function(el){var n=parseInt(el.textContent,10);if(isNaN(n)||n<1||String(n)!==el.textContent.trim())return;var t0=null;function step(t){if(!t0)t0=t;var p=Math.min((t-t0)/700,1);el.textContent=Math.round(n*p);if(p<1)requestAnimationFrame(step);}requestAnimationFrame(step);});
})();

/* light / dark toggle */
(function(){var b=document.getElementById('themeBtn');function ap(t){document.documentElement.setAttribute('data-theme',t);try{localStorage.setItem('pps_theme',t)}catch(e){}if(b)b.innerHTML='<i class="bi bi-'+(t==='dark'?'sun':'moon-stars')+'"></i>';}
var cur=document.documentElement.getAttribute('data-theme')||'light';if(b){ap(cur);b.addEventListener('click',function(){ap(document.documentElement.getAttribute('data-theme')==='dark'?'light':'dark');});}
document.querySelectorAll('.theme-corner').forEach(function(x){x.addEventListener('click',function(){ap(document.documentElement.getAttribute('data-theme')==='dark'?'light':'dark');});});})();

/* ---- (i) info icons: long help texts become a small icon; hover (or tap) shows the explanation ---- */
(function () {
  if (typeof document === 'undefined') return;
  var ID = 0;
  function anchorFor(el) {
    var tf = el.getAttribute('data-info-for'); if (tf && document.getElementById(tf)) return document.getElementById(tf);
    var prev = el.previousElementSibling;
    if (prev && /^H[1-6]$/.test(prev.tagName)) return prev;
    var par = el.parentElement, lab = null;
    if (par) for (var i = 0; i < par.children.length; i++) { var c = par.children[i]; if (c.tagName === 'LABEL' || (c.classList && c.classList.contains('form-label'))) { lab = c; break; } }
    if (lab) return lab;
    if (el.hasAttribute('data-info')) {
      var t = (el.closest('.modal-content') || document).querySelector('.modal-title');
      if (el.closest('.modal-content') && t) return t;
      var ph = el.closest('.card-panel') && el.closest('.card-panel').querySelector('h5, h4, h3');
      return ph || document.querySelector('.page-title');
    }
    var mc = el.closest('.modal-content');
    if (mc) return mc.querySelector('.modal-title');
    var panel = el.closest('.card-panel');
    return panel ? panel.querySelector('h5, h4, h3') : null;
  }
  function wanted(el) {
    if (el.hasAttribute('data-keep') || el.dataset.tipDone) return false;
    if (el.hasAttribute('data-info')) return true;
    if ((el.textContent || '').trim().length < 24) return false;
    if (el.classList.contains('form-text')) return true;
    if (el.classList.contains('hint')) {
      if (el.tagName === 'P') return true;
      var p = el.previousElementSibling;
      return !!(p && (/^(INPUT|SELECT|TEXTAREA)$/.test(p.tagName) || p.classList.contains('input-group')));
    }
    return false;
  }
  function tipify(root) {
    if (!root || root.nodeType !== 1) return;
    var list = [];
    if (root.matches && root.matches('.form-text, .hint, [data-info]')) list.push(root);
    root.querySelectorAll('.form-text, .hint, [data-info]').forEach(function (n) { list.push(n); });
    list.forEach(function (el) {
      if (!wanted(el)) return;
      var a = anchorFor(el);
      if (!a || !a.parentNode) return;
      el.dataset.tipDone = '1';
      var ic = document.createElement('i');
      ic.className = 'bi bi-info-circle info-tip';
      ic.tabIndex = 0;
      ic.setAttribute('role', 'img');
      ic.setAttribute('aria-label', 'Help');
      ic.setAttribute('data-bs-toggle', 'tooltip');
      ic.setAttribute('data-bs-html', 'true');
      ic.setAttribute('data-bs-title', el.innerHTML);
      a.appendChild(ic);
      el.classList.add('tip-hidden');
      if (window.bootstrap && bootstrap.Tooltip) new bootstrap.Tooltip(ic, { container: 'body', trigger: 'hover focus', placement: 'top', html: true, title: el.innerHTML });
    });
  }
  function start() {
    tipify(document.body);
    new MutationObserver(function (ms) { ms.forEach(function (m) { m.addedNodes.forEach(tipify); }); }).observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
