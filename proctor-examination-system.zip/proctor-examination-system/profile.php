<?php
require_once __DIR__ . '/includes/bootstrap.php';
$user = require_login();
$pdo = db();

if (require_post_csrf()) {
    $action = input_str('action', 20);
    if ($action === 'profile') {
        [$np, $nerr] = name_parts_from_post();
        $contact = input_str('contact_number', 40);
        if ($nerr) {
            foreach ($nerr as $ne) flash('danger', $ne);
        } else {
            $pdo->prepare('UPDATE users SET full_name = ?, first_name = ?, middle_name = ?, last_name = ?, suffix = ?, gender = ?, contact_number = ? WHERE id = ?')
                ->execute([$np['full'], $np['first'], $np['middle'] ?: null, $np['last'], $np['suffix'] ?: null, $np['gender'], $contact, $user['id']]);
            $_SESSION['user']['name'] = $np['full'];
            log_activity('profile_update', 'user', $user['id'], null, null, 'Profile updated');
            flash('success', 'Profile updated.');
        }
    } elseif ($action === 'photo') {
        $err = save_avatar((int) $user['id'], $_FILES['photo'] ?? []);
        $err ? flash('danger', $err) : flash('success', 'Profile picture updated.');
    } elseif ($action === 'photo_remove') {
        remove_avatar((int) $user['id']); flash('success', 'Profile picture removed.');
    } elseif ($action === 'password') {
        $cur = (string) ($_POST['current_password'] ?? '');
        $new = (string) ($_POST['new_password'] ?? '');
        $conf = (string) ($_POST['confirm_password'] ?? '');
        $st = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
        $st->execute([$user['id']]);
        $hash = $st->fetchColumn();
        if (!password_verify($cur, (string) $hash)) {
            flash('danger', 'Current password is incorrect.');
        } elseif ($err = password_rules_error($new)) {
            flash('danger', $err);
        } elseif ($new !== $conf) {
            flash('danger', 'New password and confirmation do not match.');
        } else {
            $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), $user['id']]);
            log_activity('password_change', 'user', $user['id'], null, null, 'Password changed');
            session_regenerate_id(true);
            flash('success', 'Password changed successfully.');
        }
    }
    elseif ($action === 'otp_me') {
        $on = input_str('otp', 1) === '1';
        if ($on && !mail_ready()) flash('danger', 'E-mail sending is not set up yet (administrator: Security & OTP).');
        else { $pdo->prepare('UPDATE users SET otp_enabled = ? WHERE id = ?')->execute([$on ? 1 : 0, $user['id']]); log_activity('otp_self', 'security', $user['id'], null, null, 'Own OTP ' . ($on ? 'on' : 'off')); flash('success', 'E-mail code at login is now ' . ($on ? 'ON' : 'OFF') . ' for your account.'); }
    } elseif ($action === 'email_start') {
        $new = strtolower(input_str('new_email', 150));
        $st = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?'); $st->execute([$user['id']]);
        if (!password_verify((string) ($_POST['current_password'] ?? ''), (string) $st->fetchColumn())) flash('danger', 'Current password is incorrect.');
        elseif (!filter_var($new, FILTER_VALIDATE_EMAIL)) flash('danger', 'Enter a valid e-mail address.');
        elseif (fetch_value('SELECT COUNT(*) FROM users WHERE email = ? AND id <> ?', [$new, $user['id']])) flash('danger', 'That e-mail is already used by another account.');
        else { $r = chal_start('email' . $user['id'], $new, 'changing your account e-mail', ['new' => $new]); $r['ok'] ? flash('success', 'We sent a code to ' . mask_email($new) . '. Enter it below.') : flash('danger', $r['error']); }
    } elseif ($action === 'email_verify') {
        $r = chal_verify('email' . $user['id'], (string) ($_POST['code'] ?? ''));
        if (!$r['ok']) flash('danger', $r['error']);
        elseif (fetch_value('SELECT COUNT(*) FROM users WHERE email = ? AND id <> ?', [$r['payload']['new'], $user['id']])) flash('danger', 'That e-mail is already used.');
        else { $pdo->prepare('UPDATE users SET email = ? WHERE id = ?')->execute([$r['payload']['new'], $user['id']]); $_SESSION['user']['email'] = $r['payload']['new']; log_activity('email_changed', 'user', $user['id'], null, null, 'Account e-mail changed to ' . $r['payload']['new']); flash('success', 'Your login e-mail is now ' . $r['payload']['new'] . '. Codes are sent there.'); }
    } elseif ($action === 'email_cancel') { chal_clear('email' . $user['id']);
    } elseif ($action === 'qr_make') {
        $st = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?'); $st->execute([$user['id']]);
        if ((get_settings()['qr_login_enabled'] ?? '1') !== '1') flash('danger', 'QR login is turned off by the administrator.');
        elseif (!password_verify((string) ($_POST['current_password'] ?? ''), (string) $st->fetchColumn())) flash('danger', 'Current password is incorrect.');
        else { $tok = bin2hex(random_bytes(24)); $pdo->prepare('UPDATE users SET qr_hash = ?, qr_created_at = ? WHERE id = ?')->execute([hash('sha256', $tok), now(), $user['id']]); $_SESSION['qr_show'] = $tok; log_activity('qr_created', 'security', $user['id'], null, null, 'Personal QR created'); flash('success', 'Your QR code is ready. Save or print it now: it is shown only once.'); }
    } elseif ($action === 'qr_off') {
        $pdo->prepare('UPDATE users SET qr_hash = NULL, qr_created_at = NULL WHERE id = ?')->execute([$user['id']]); log_activity('qr_off', 'security', $user['id'], null, null, 'Personal QR turned off'); flash('success', 'QR login turned off. The old QR code no longer works.');
    }
    redirect('profile.php');
}

$st = $pdo->prepare('SELECT u.*, t.teacher_no, t.specialization, d.name AS department
                     FROM users u LEFT JOIN teachers t ON t.user_id = u.id LEFT JOIN departments d ON d.id = t.department_id WHERE u.id = ?');
$st->execute([$user['id']]);
$me = $st->fetch();

$pageTitle = 'My Profile';
$activeNav = 'profile';
require __DIR__ . '/includes/header.php';
?>
<div class="row g-3">
  <div class="col-lg-6">
    <div class="card-panel">
      <div class="panel-head"><h5><i class="bi bi-person-circle me-1"></i>Profile picture</h5></div>
      <div class="d-flex align-items-center gap-3 flex-wrap">
        <?= avatar_html($me, 'avatar avatar-xl') ?>
        <div class="flex-grow-1">
          <form method="post" enctype="multipart/form-data"><?= csrf_field() ?><input type="hidden" name="action" value="photo">
            <input class="form-control mb-2" type="file" name="photo" accept="image/jpeg,image/png,image/gif,image/webp" required>
            <div class="d-flex gap-2"><button class="btn btn-navy btn-sm" data-loading="Uploading...">Upload picture</button></div>
            <div class="form-text">JPG, PNG, GIF or WEBP, up to 3 MB. It is cropped to a square.</div></form>
          <?php if (!empty($me['photo'])): ?><form method="post" class="mt-2"><?= csrf_field() ?><input type="hidden" name="action" value="photo_remove"><button class="btn btn-outline-danger btn-sm" data-confirm="Remove your picture?">Remove picture</button></form><?php endif; ?>
        </div>
      </div>
    </div>
    <div class="card-panel">
      <div class="panel-head"><h5>Profile information</h5></div>
      <form method="post">
        <?= csrf_field() ?><input type="hidden" name="action" value="profile">
        <div class="mb-3"><label class="form-label">Email (login)</label><input class="form-control" value="<?= e($me['email']) ?>" disabled></div>
        <?php $fn = $me['first_name'] ?? ''; $ln = $me['last_name'] ?? ''; if ($fn === '' && $ln === '') { $pp = preg_split('/\s+/', trim($me['full_name']), 2); $fn = $pp[0] ?? ''; $ln = $pp[1] ?? ''; } ?>
        <div class="row g-2 mb-3">
          <div class="col-md-6"><label class="form-label">First name *</label><input class="form-control" name="first_name" value="<?= e($fn) ?>" maxlength="60" required></div>
          <div class="col-md-6"><label class="form-label">Middle name</label><input class="form-control" name="middle_name" value="<?= e($me['middle_name'] ?? '') ?>" maxlength="60"></div>
          <div class="col-md-6"><label class="form-label">Surname *</label><input class="form-control" name="last_name" value="<?= e($ln) ?>" maxlength="60" required></div>
          <div class="col-md-3"><label class="form-label">Suffix</label><select class="form-select" name="suffix"><option value="">None</option><?php foreach (NAME_SUFFIXES as $sf): ?><option <?= ($me['suffix'] ?? '') === $sf ? 'selected' : '' ?>><?= e($sf) ?></option><?php endforeach; ?></select></div>
          <div class="col-md-3"><label class="form-label">Gender *</label><select class="form-select" name="gender" required><option value="">Select</option><option <?= ($me['gender'] ?? '') === 'Male' ? 'selected' : '' ?>>Male</option><option <?= ($me['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option></select></div>
          <div class="col-12 hint">Shown as: <b><?= e(compose_name($fn, $me['middle_name'] ?? '', $ln, $me['suffix'] ?? '')) ?></b> &middot; greeting: <b><?= e(greeting($me)) ?></b></div>
        </div>
        <div class="mb-3"><label class="form-label">Contact number</label><input class="form-control" name="contact_number" value="<?= e($me['contact_number']) ?>" maxlength="40"></div>
        <?php if ($me['role'] === 'teacher'): ?>
          <div class="row">
            <div class="col-md-6 mb-3"><label class="form-label">Teacher ID</label><input class="form-control" value="<?= e($me['teacher_no']) ?>" disabled></div>
            <div class="col-md-6 mb-3"><label class="form-label">Department</label><input class="form-control" value="<?= e($me['department']) ?>" disabled></div>
          </div>
        <?php endif; ?>
        <button class="btn btn-navy" type="submit" data-loading="Saving...">Save changes</button>
      </form>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card-panel">
      <div class="panel-head"><h5>Change password</h5></div>
      <form method="post" autocomplete="off">
        <?= csrf_field() ?><input type="hidden" name="action" value="password">
        <div class="mb-3"><label class="form-label">Current password</label><input class="form-control" type="password" name="current_password" required></div>
        <div class="mb-3"><label class="form-label">New password</label><input class="form-control" type="password" name="new_password" minlength="8" required><div class="form-text">At least 8 characters, with letters and numbers.</div></div>
        <div class="mb-3"><label class="form-label">Confirm new password</label><input class="form-control" type="password" name="confirm_password" minlength="8" required></div>
        <button class="btn btn-navy" type="submit" data-loading="Updating...">Update password</button>
      </form>
    </div>
  </div>
</div>
<?php
$S = get_settings(); $qrTok = $_SESSION['qr_show'] ?? null; unset($_SESSION['qr_show']);
$base = rtrim($S['public_base_url'] ?? '', '/') ?: ((!empty($_SERVER['HTTPS']) ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost') . rtrim(BASE_URL, '/'));
$qrUrl = $qrTok ? $base . '/qr_login.php?t=' . $qrTok : null;
$echal = chal_pending('email' . $user['id']);
?>
<div class="row g-3 mt-1">
  <div class="col-lg-6">
    <div class="card-panel"><div class="panel-head"><h5><i class="bi bi-envelope-at me-1"></i>Login e-mail and code</h5></div>
      <p class="small text-muted" data-info>Codes (OTP) are sent to <b><?= e($me['email']) ?></b>.</p>
      <form method="post" class="d-flex justify-content-between align-items-center mb-3"><?= csrf_field() ?><input type="hidden" name="action" value="otp_me"><input type="hidden" name="otp" value="<?= $me['otp_enabled'] ? '0' : '1' ?>">
        <div><strong>Ask for an e-mailed code when I sign in</strong><div class="small text-muted" data-info>Extra security: after your password you must type the 6-digit code sent to your e-mail.</div></div>
        <button class="btn btn-sm <?= $me['otp_enabled'] ? 'btn-danger' : 'btn-success' ?>"><?= $me['otp_enabled'] ? 'Turn off' : 'Turn on' ?></button></form>
      <?php if ($echal): ?>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="email_verify"><label class="form-label">Code sent to <?= e(mask_email($echal['email'])) ?></label>
        <div class="input-group"><input class="form-control" name="code" inputmode="numeric" maxlength="6" placeholder="000000" required><button class="btn btn-navy">Confirm new e-mail</button><button class="btn btn-light" name="action" value="email_cancel" formnovalidate>Cancel</button></div></form>
      <?php else: ?>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="email_start"><div class="row g-2">
        <div class="col-12"><label class="form-label">Change my login e-mail (Gmail)</label><input class="form-control" type="email" name="new_email" placeholder="newaddress@gmail.com" required></div>
        <div class="col-12"><input class="form-control" type="password" name="current_password" placeholder="Current password" required></div>
        <div class="col-12"><button class="btn btn-navy">Send code to the new e-mail</button><div class="form-text">The e-mail changes only after you type the code we send to it.</div></div></div></form>
      <?php endif; ?></div>
  </div>
  <div class="col-lg-6">
    <div class="card-panel"><div class="panel-head"><h5><i class="bi bi-qr-code me-1"></i>My QR login</h5><?= $me['qr_hash'] ? '<span class="badge bg-success">On</span>' : '<span class="badge bg-secondary">Off</span>' ?></div>
      <?php if ($qrUrl): ?>
        <div class="text-center"><div id="qrBox" class="d-inline-block p-3 bg-white border rounded"></div>
          <p class="small text-muted mt-2">Save or print this now &ndash; it is shown only once. Keep it private: <b>whoever has this QR can open your account</b>.</p>
          <button class="btn btn-light btn-sm" type="button" id="qrSave"><i class="bi bi-download"></i> Save image</button> <button class="btn btn-light btn-sm" onclick="window.print()"><i class="bi bi-printer"></i> Print</button>
          <div class="small text-break text-muted mt-2"><?= e($qrUrl) ?></div></div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
        <script>(function(){var b=document.getElementById('qrBox');new QRCode(b,{text:<?= json_encode($qrUrl) ?>,width:220,height:220,correctLevel:QRCode.CorrectLevel.M});
        document.getElementById('qrSave').onclick=function(){var c=b.querySelector('canvas'),i=b.querySelector('img');var a=document.createElement('a');a.download='my-login-qr.png';a.href=c?c.toDataURL('image/png'):i.src;a.click();};})();</script>
      <?php else: ?>
        <p class="small text-muted" data-info>Sign in quickly by scanning a personal QR code (no typing). Scan it with your phone camera, or press <b>Scan QR</b> on the login page.</p>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="qr_make"><div class="input-group"><input class="form-control" type="password" name="current_password" placeholder="Current password" required><button class="btn btn-navy"><?= $me['qr_hash'] ? 'Make a new QR' : 'Create my QR' ?></button></div>
          <?php if ($me['qr_hash']): ?><div class="form-text">Making a new QR cancels the old one.</div><?php endif; ?></form>
        <?php if ($me['qr_hash']): ?><form method="post" class="mt-2"><?= csrf_field() ?><input type="hidden" name="action" value="qr_off"><button class="btn btn-outline-danger btn-sm" data-confirm="Turn off QR login? The old QR stops working.">Turn off QR login</button></form><?php endif; ?>
      <?php endif; ?></div>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
