<?php
require_once __DIR__ . '/includes/bootstrap.php';

if (is_logged_in()) {
    redirect(home_for_role($_SESSION['user']['role']));
}

$error = null;
$email = '';
$waitSeconds = 0;
if (require_post_csrf()) {
    $email = input_str('email', 150);
    $password = $_POST['password'] ?? '';
    if ($email === '' || $password === '') {
        $error = 'Please enter your email and password.';
    } else {
        [$ok, $error, $needsOtp, $waitSeconds] = attempt_login($email, (string) $password);
        if ($ok && $needsOtp) {
            redirect('otp.php');
        }
        if ($ok) {
            redirect(home_for_role($_SESSION['user']['role']));
        }
    }
}
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login · <?= e(APP_SHORT) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Merriweather:wght@700;900&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<script>try{var t=localStorage.getItem('pps_theme');if(t)document.documentElement.setAttribute('data-theme',t)}catch(e){}</script>
<link href="<?= e(url('assets/css/app.css') . '?v=' . filemtime(ROOT_PATH . '/assets/css/app.css')) ?>" rel="stylesheet">
<link href="<?= e(url('assets/css/theme.css') . '?v=' . filemtime(ROOT_PATH . '/assets/css/theme.css')) ?>" rel="stylesheet">
</head>
<body>
<div class="login-page">
  <section class="login-art">
    <div class="logo"><i class="bi bi-mortarboard-fill"></i></div>
    <h1>Proctor Assignment &amp; Examination Paper Distribution</h1>
    <p>Rooms, sections, proctors and exam papers in one place &ndash; with automatic, fair proctor assignment.</p>
    <ul class="feature-list">
      <li><i class="bi bi-door-open"></i><span>Classroom layout per room, sections and exam schedule</span></li>
      <li><i class="bi bi-magic"></i><span>Auto-assign by who is free on the day and time</span></li>
      <li><i class="bi bi-shield-check"></i><span>Login limits, cooldown and e-mail OTP</span></li>
    </ul>
  </section>
  <section class="login-form-wrap">
    <button class="theme-btn theme-corner" type="button" title="Light / Dark"><i class="bi bi-moon-stars"></i></button>
    <div class="login-box">
      <h2>Welcome back</h2><p class="text-muted mb-4">Sign in with your institutional account.</p>
      <?php foreach (flash_pull() as $f): ?><div class="alert alert-<?= e($f['type']) ?>"><?= e($f['msg']) ?></div><?php endforeach; ?>
      <?php if ($error): ?><div class="alert alert-danger"><i class="bi bi-exclamation-triangle me-1"></i><?= e($error) ?>
        <?php if ($waitSeconds > 0): ?><div class="mt-1 fw-semibold"><i class="bi bi-hourglass-split me-1"></i>Retry in <span id="cooldown" data-seconds="<?= (int) $waitSeconds ?>"><?= e(fmt_wait($waitSeconds)) ?></span></div><?php endif; ?></div><?php endif; ?>
      <form method="post" autocomplete="on" novalidate><?= csrf_field() ?>
        <div class="mb-3"><label class="form-label" for="email">Email address</label><input class="form-control" type="email" id="email" name="email" value="<?= e($email) ?>" required autofocus></div>
        <div class="mb-3"><label class="form-label" for="password">Password</label><div class="input-group"><input class="form-control" type="password" id="password" name="password" required><button class="btn btn-light border" type="button" onclick="var p=document.getElementById('password');p.type=p.type==='password'?'text':'password'"><i class="bi bi-eye"></i></button></div></div>
        <button class="btn btn-navy w-100 py-2" type="submit" data-loading="Signing in...">Sign in</button>
      </form>
      <?php $__S = get_settings(); ?>
      <div class="d-flex flex-column gap-2 mt-3">
        <?php if (($__S['qr_login_enabled'] ?? '1') === '1'): ?><button type="button" class="btn btn-light border w-100" id="scanBtn"><i class="bi bi-qr-code-scan me-1"></i>Sign in with QR</button><div id="qrReader" class="d-none"></div><div id="scanMsg" class="small text-muted"></div><?php endif; ?>
        <a class="btn btn-gold w-100" href="<?= e(url('register.php')) ?>"><i class="bi bi-person-plus me-1"></i>Create an account (Proctor / Teacher)</a>
        <div class="text-center small text-muted">Register with your Gmail. The administrator approves your account.</div>
      </div>
      <?php if (APP_DEBUG): ?><div class="explain-box mt-4 small"><strong>Development accounts</strong><br>Admin: <code>admin@proctor.local</code> / <code>Admin@12345</code><br>Teacher: <code>teacher01@proctor.local</code> / <code>Teacher@12345</code></div><?php endif; ?>
    </div>
  </section>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(url('assets/js/app.js') . '?v=' . filemtime(ROOT_PATH . '/assets/js/app.js')) ?>"></script>
<script>
(function(){var b=document.getElementById('scanBtn');if(!b)return;var started=false,msg=document.getElementById('scanMsg');
b.onclick=function(){if(started)return;started=true;msg.textContent='Opening the camera...';var s=document.createElement('script');s.src='https://cdnjs.cloudflare.com/ajax/libs/html5-qrcode/2.3.8/html5-qrcode.min.js';
 s.onerror=function(){msg.textContent='Could not load the scanner. Scan the QR with your phone camera instead.';started=false;};
 s.onload=function(){var r=document.getElementById('qrReader');r.classList.remove('d-none');var q=new Html5Qrcode('qrReader');
  q.start({facingMode:'environment'},{fps:10,qrbox:220},function(t){var m=String(t).match(/qr_login\.php\?t=([a-f0-9]{48})/i);if(m){q.stop().catch(function(){});location.href='qr_login.php?t='+m[1];}else{msg.textContent='That is not a ProctorSys login QR.';}},function(){})
  .then(function(){msg.textContent='Point the camera at your QR code.';}).catch(function(){msg.textContent='Camera not available or permission denied.';started=false;});};
 document.head.appendChild(s);};})();
</script>
<script>
(function(){var c=document.getElementById('cooldown');if(!c)return;var s=parseInt(c.dataset.seconds,10);var btn=document.querySelector('form button[type=submit]');if(btn)btn.disabled=true;
var t=setInterval(function(){s--;if(s<=0){clearInterval(t);c.textContent='0:00';if(btn)btn.disabled=false;return;}c.textContent=Math.floor(s/60)+':'+('0'+(s%60)).slice(-2);},1000);})();
</script>
</body>
</html>
