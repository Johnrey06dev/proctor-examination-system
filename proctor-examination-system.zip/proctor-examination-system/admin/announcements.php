<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_perm('announcements.view');
$pdo = db();
if (require_post_csrf()) {
    if (!user_can('announcements.send')) deny_access($user);
    $a = input_str('action', 10);
    if ($a === 'send') {
        $aud = in_array($_POST['audience'] ?? '', ['all', 'department', 'teachers'], true) ? $_POST['audience'] : 'all';
        $title = input_str('title', 150); $body = input_str('body', 2000);
        $ids = $aud === 'teachers' ? implode(',', array_map('intval', (array) ($_POST['targets'] ?? []))) : null;
        if ($title === '' || $body === '') flash('danger', 'Title and message are required.');
        elseif ($aud === 'teachers' && !$ids) flash('danger', 'Select at least one teacher.');
        else {
            $row = ['title' => $title, 'body' => $body, 'kind' => ($_POST['kind'] ?? '') === 'reminder' ? 'reminder' : 'general', 'audience' => $aud,
                'department_id' => $aud === 'department' ? input_int('department_id') : null, 'target_ids' => $ids];
            $pdo->prepare('INSERT INTO announcements (title, body, kind, audience, department_id, target_ids, created_by, created_at) VALUES (?,?,?,?,?,?,?,?)')
                ->execute([$row['title'], $row['body'], $row['kind'], $row['audience'], $row['department_id'], $row['target_ids'], $user['id'], now()]);
            $n = 0;
            foreach (announcement_recipients($row) as $uid) { notify((int) $uid, ($row['kind'] === 'reminder' ? 'Reminder: ' : 'Announcement: ') . $title, mb_substr($body, 0, 150), 'announcement', 'teacher/messages.php'); $n++; }
            log_activity('announcement', 'announcements', (int) $pdo->lastInsertId(), null, null, "Sent to $n teacher(s)");
            flash('success', "Sent to $n teacher(s).");
        }
    } elseif ($a === 'delete') {
        $pdo->prepare('DELETE FROM announcement_reads WHERE announcement_id = ?')->execute([input_int('id')]);
        $pdo->prepare('DELETE FROM announcements WHERE id = ?')->execute([input_int('id')]); flash('success', 'Deleted.');
    }
    redirect('admin/announcements.php');
}
$list = fetch_all('SELECT a.*, u.full_name AS by_name, (SELECT COUNT(*) FROM announcement_reads r WHERE r.announcement_id = a.id) AS read_count FROM announcements a LEFT JOIN users u ON u.id = a.created_by ORDER BY a.id DESC LIMIT 50');
$teachers = fetch_all("SELECT id, full_name FROM users WHERE role = 'teacher' AND status = 'active' ORDER BY full_name");
$depts = fetch_all('SELECT id, name FROM departments ORDER BY name');
$pageTitle = 'Announcements'; $activeNav = 'announcements';
require __DIR__ . '/../includes/header.php';
?>
<div class="row g-3">
<?php if (user_can('announcements.send')): ?><div class="col-lg-5"><div class="card-panel fade-up"><h5>New announcement</h5>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="send">
<div class="mb-2"><label class="form-label">Type</label><select name="kind" class="form-select"><option value="general">General announcement</option><option value="reminder">Exam reminder</option></select></div>
<div class="mb-2"><label class="form-label">Send to</label><select name="audience" id="aud" class="form-select"><option value="all">All teachers</option><option value="department">A department</option><option value="teachers">Selected teachers</option></select></div>
<div class="mb-2 d-none" id="dep"><select name="department_id" class="form-select"><?php foreach ($depts as $d): ?><option value="<?= (int) $d['id'] ?>"><?= e($d['name']) ?></option><?php endforeach; ?></select></div>
<div class="mb-2 d-none" id="tea"><label class="form-label">Teachers</label><select name="targets[]" class="form-select" multiple size="6"><?php foreach ($teachers as $t): ?><option value="<?= (int) $t['id'] ?>"><?= e($t['full_name']) ?></option><?php endforeach; ?></select><div class="hint">Ctrl + click for many.</div></div>
<div class="mb-2"><label class="form-label">Title</label><input class="form-control" name="title" maxlength="150" required></div>
<div class="mb-2"><label class="form-label">Message</label><textarea class="form-control" name="body" rows="4" maxlength="2000" required></textarea></div>
<button class="btn btn-gold w-100"><i class="bi bi-megaphone me-1"></i>Send</button></form></div></div><?php endif; ?>
<div class="col-lg-<?= user_can('announcements.send') ? 7 : 12 ?>"><div class="card-panel fade-up"><h5>Sent</h5>
<?php if (!$list): ?><?= empty_state('megaphone', 'Nothing sent yet') ?><?php endif; ?>
<?php foreach ($list as $a): $total = count(announcement_recipients($a)); ?>
<div class="border-bottom py-2"><div class="d-flex justify-content-between"><strong><?= e($a['title']) ?> <span class="badge-s <?= $a['kind'] === 'reminder' ? 'b-amber' : 'b-blue' ?>"><?= e($a['kind']) ?></span></strong>
<?php if (user_can('announcements.send')): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $a['id'] ?>"><button class="btn btn-sm btn-light" data-confirm="Delete this announcement?"><i class="bi bi-trash"></i></button></form><?php endif; ?></div>
<div class="small"><?= nl2br(e($a['body'])) ?></div><div class="small text-muted">By <?= e($a['by_name'] ?? '—') ?> &middot; <?= e(fmt_dt($a['created_at'])) ?> &middot; to <?= e($a['audience']) ?> &middot; read by <b><?= (int) $a['read_count'] ?></b> of <?= $total ?></div></div>
<?php endforeach; ?></div></div></div>
<script>(function(){var s=document.getElementById('aud');if(!s)return;function f(){document.getElementById('dep').classList.toggle('d-none',s.value!=='department');document.getElementById('tea').classList.toggle('d-none',s.value!=='teachers');}s.onchange=f;f();})();</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
