<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('staff');
$pdo = db();
$sched = new ProctorScheduler($pdo);
require __DIR__ . '/_assignment_actions.php';

/* generation result (shown once after "Generate") */
$results = [];
if (isset($_GET['result']) && !empty($_SESSION['gen_results'])) {
    $results = $_SESSION['gen_results'];
    unset($_SESSION['gen_results']);
}

/* filters */
$ft = (int) ($_GET['teacher'] ?? 0);
$fsub = (int) ($_GET['subject'] ?? 0);
$fd = (int) ($_GET['dept'] ?? 0);
$fst = $_GET['status'] ?? '';
$from = $_GET['from'] ?? '';
$to = $_GET['to'] ?? '';
$where = ['1=1']; $params = [];
if ($ft) { $where[] = 'a.teacher_id = ?'; $params[] = $ft; }
if ($fsub) { $where[] = 'e.subject_id = ?'; $params[] = $fsub; }
if ($fd) { $where[] = 'e.department_id = ?'; $params[] = $fd; }
if (in_array($fst, ['Pending Review', 'Confirmed', 'Completed', 'Cancelled'], true)) { $where[] = 'a.status = ?'; $params[] = $fst; }
else { $where[] = "a.status <> 'Cancelled'"; }
if (valid_date($from)) { $where[] = 'e.exam_date >= ?'; $params[] = $from; }
if (valid_date($to)) { $where[] = 'e.exam_date <= ?'; $params[] = $to; }

$rows = fetch_all("SELECT a.*, e.exam_code, e.name AS exam_name, e.exam_date, e.start_time, e.end_time, e.required_proctors, e.department_id AS exam_dept,
        s.code AS subject_code, r.name AS room_name, u.full_name AS teacher_name, t.teacher_no
    FROM proctor_assignments a
    JOIN examinations e ON e.id = a.examination_id JOIN subjects s ON s.id = e.subject_id JOIN rooms r ON r.id = e.room_id
    JOIN teachers t ON t.id = a.teacher_id JOIN users u ON u.id = t.user_id
    WHERE " . implode(' AND ', $where) . ' ORDER BY e.exam_date, e.start_time, e.exam_code, a.id LIMIT 500', $params);

$pending = (int) fetch_value("SELECT COUNT(*) FROM proctor_assignments WHERE status = 'Pending Review'");
$needing = (int) fetch_value("SELECT COUNT(*) FROM examinations e WHERE e.status = 'Scheduled'
    AND (SELECT COUNT(*) FROM proctor_assignments a WHERE a.examination_id = e.id AND a.status <> 'Cancelled') < e.required_proctors");
$teachers = teacher_list(); $subjects = subject_list(); $depts = dept_list();
$allTeachers = $sched->allTeachers();

$pageTitle = 'Proctor Assignments';
$activeNav = 'assignments';
$useCharts = (bool) $results;
require __DIR__ . '/../includes/header.php';
?>
<div class="row g-3 mb-3">
  <div class="col-md-4"><div class="stat-card <?= $needing ? 'danger' : 'ok' ?>"><div class="stat-icon"><i class="bi bi-exclamation-triangle"></i></div><div><div class="stat-value"><?= $needing ?></div><div class="stat-label">Examinations needing proctors</div></div></div></div>
  <div class="col-md-4"><div class="stat-card <?= $pending ? 'warn' : '' ?>"><div class="stat-icon"><i class="bi bi-hourglass-split"></i></div><div><div class="stat-value"><?= $pending ?></div><div class="stat-label">Pending review</div></div></div></div>
  <div class="col-md-4"><a class="stat-card <?= ProctorScheduler::pendingDeclines($pdo) ? 'warn' : '' ?> text-decoration-none" href="<?= e(url('admin/declined.php')) ?>"><div class="stat-icon"><i class="bi bi-arrow-repeat"></i></div><div><div class="stat-value"><?= ProctorScheduler::pendingDeclines($pdo) ?></div><div class="stat-label">Declined &ndash; Reassignment Center</div></div></a></div>
</div>
<div class="card-panel autoassign fade-up">
  <div class="d-flex flex-wrap align-items-end gap-3">
    <div><h5 class="serif mb-0"><i class="bi bi-magic me-1"></i>Auto-assign proctors</h5><small class="text-muted">Picks proctors by the exam date &amp; time, the teacher's availability and own limits, then balances the workload.</small></div>
    <form method="post" class="d-flex flex-wrap align-items-end gap-2 ms-auto"><?= csrf_field() ?><input type="hidden" name="action" value="generate_range">
      <div><label class="form-label small mb-0">From</label><input type="date" name="from" class="form-control form-control-sm"></div>
      <div><label class="form-label small mb-0">To</label><input type="date" name="to" class="form-control form-control-sm"></div>
      <button class="btn btn-navy" type="submit" data-loading="Assigning..." data-confirm="Auto-assign proctors for every scheduled exam in this date range (leave dates empty = all) that still needs proctors? Results are Pending Review."><i class="bi bi-lightning-charge-fill me-1"></i>Auto-assign</button>
    </form>
  </div>
</div>

<?php foreach ($results as $r): ?>
<div class="card-panel border-start border-4 border-primary">
  <div class="panel-head">
    <h5><i class="bi bi-cpu me-1"></i>Generation result · <?= e($r['exam']['exam_code']) ?> <?= e($r['exam']['name']) ?></h5>
    <span class="text-muted small"><?= e(fmt_date($r['exam']['exam_date'])) ?> · <?= e(time_range($r['exam']['start_time'], $r['exam']['end_time'])) ?></span>
  </div>
  <div class="explain-box mb-3">
    Required: <strong><?= (int) $r['required'] ?></strong> · Already assigned: <strong><?= (int) $r['existing'] ?></strong> · Needed: <strong><?= (int) $r['needed'] ?></strong> ·
    Eligible after hard constraints: <strong><?= count($r['eligible']) ?></strong> · Excluded: <strong><?= count($r['excluded']) ?></strong> ·
    <span class="text-success fw-semibold">Assigned now: <?= (int) $r['assigned'] ?></span>
  </div>
  <?php foreach ($r['warnings'] as $w): ?><div class="alert alert-warning py-2"><i class="bi bi-exclamation-triangle me-1"></i><?= e($w) ?></div><?php endforeach; ?>
  <?php foreach ($r['messages'] as $w): ?><div class="alert alert-info py-2" data-info><?= e($w) ?></div><?php endforeach; ?>

  <?php if ($r['eligible'] || $r['excluded']): ?>
  <div class="row g-3">
    <div class="col-lg-7">
      <h6>Why each teacher was selected or excluded</h6>
      <div class="table-responsive" style="max-height:340px"><table class="table table-modern table-sm align-middle">
        <thead><tr><th>Teacher</th><th>Decision</th><th class="text-center">Rank</th><th class="text-center">Score</th><th>Explanation</th></tr></thead><tbody>
        <?php foreach ($r['explanations'] as $x): ?>
          <tr><td><strong><?= e($x['teacher_no']) ?></strong><div class="small text-muted"><?= e($x['name']) ?></div></td>
            <td><?= $x['decision'] === 'Selected' ? '<span class="badge-status s-confirmed">Selected</span>' : ($x['decision'] === 'Excluded' ? '<span class="badge-status s-cancelled">Excluded</span>' : '<span class="badge-status s-scheduled">Eligible</span>') ?></td>
            <td class="text-center"><?= $x['rank'] ? '<span class="rank-pill">' . (int) $x['rank'] . '</span>' : '—' ?></td>
            <td class="text-center"><?= $x['score'] !== null ? e($x['score']) : '—' ?></td>
            <td class="small <?= $x['decision'] === 'Excluded' ? 'text-danger' : '' ?>"><?= e($x['text']) ?></td></tr>
        <?php endforeach; ?></tbody></table></div>
    </div>
    <div class="col-lg-5">
      <h6>Workload score of eligible teachers (lower = higher priority)</h6>
      <div style="height:260px"><canvas id="genChart<?= (int) $r['exam']['id'] ?>"></canvas></div>
    </div>
  </div>
  <?php endif; ?>
  <div class="mt-3 d-flex flex-wrap gap-2">
    <a class="btn btn-sm btn-outline-navy" href="<?= e(url('admin/exam_view.php?id=' . $r['exam']['id'])) ?>">Open examination</a>
    <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="approve_exam"><input type="hidden" name="exam_id" value="<?= (int) $r['exam']['id'] ?>">
      <button class="btn btn-sm btn-success" type="submit" data-confirm="Approve all pending proctors of <?= e($r['exam']['exam_code']) ?>?"><i class="bi bi-check2-all me-1"></i>Approve</button></form>
    <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="regenerate"><input type="hidden" name="exam_id" value="<?= (int) $r['exam']['id'] ?>">
      <button class="btn btn-sm btn-outline-warning" type="submit" data-confirm="Reject the proposed proctors and generate different ones?"><i class="bi bi-arrow-repeat me-1"></i>Reject &amp; regenerate</button></form>
  </div>
</div>
<?php endforeach; ?>

<div class="card-panel">
  <form class="filter-bar" method="get">
    <div><label class="form-label">Teacher</label><select class="form-select" name="teacher"><?= options_html($teachers, 'id', fn($t) => $t['teacher_no'] . ' ' . $t['full_name'], $ft, 'All') ?></select></div>
    <div><label class="form-label">Subject</label><select class="form-select" name="subject"><?= options_html($subjects, 'id', 'code', $fsub, 'All') ?></select></div>
    <div><label class="form-label">Department</label><select class="form-select" name="dept"><?= options_html($depts, 'id', 'code', $fd, 'All') ?></select></div>
    <div><label class="form-label">Status</label><select class="form-select" name="status"><option value="">Active (not cancelled)</option><?php foreach (['Pending Review', 'Confirmed', 'Completed', 'Cancelled'] as $s): ?><option <?= $fst === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label">From</label><input type="date" class="form-control" name="from" value="<?= e($from) ?>"></div>
    <div><label class="form-label">To</label><input type="date" class="form-control" name="to" value="<?= e($to) ?>"></div>
    <div class="d-flex gap-2"><button class="btn btn-navy" type="submit"><i class="bi bi-search me-1"></i>Filter</button><a class="btn btn-light" href="<?= e(url('admin/assignments.php')) ?>">Reset</a></div>
  </form>
</div>

<div class="card-panel">
  <div class="panel-head"><h5>Assignments</h5><span class="text-muted small"><?= count($rows) ?> record(s)</span></div>
  <?php if (!$rows): ?><?= empty_state('person-x', 'No assignments found', 'Generate assignments automatically or assign proctors manually from an examination page.') ?><?php else: ?>
  <div class="table-responsive"><table class="table table-modern align-middle">
    <thead><tr><th>Exam</th><th>Date &amp; time</th><th>Room</th><th>Proctor</th><th>Type</th><th class="text-center">Score</th><th>Status</th><th></th></tr></thead><tbody>
    <?php foreach ($rows as $a): ?><tr>
      <td><a href="<?= e(url('admin/exam_view.php?id=' . $a['examination_id'])) ?>"><strong><?= e($a['exam_code']) ?></strong></a><div class="small text-muted"><?= e($a['subject_code']) ?></div></td>
      <td><?= e(fmt_date($a['exam_date'])) ?><div class="small text-muted"><?= e(time_range($a['start_time'], $a['end_time'])) ?></div></td>
      <td><?= e($a['room_name']) ?></td>
      <td><strong><?= e($a['teacher_no']) ?></strong><div class="small text-muted"><?= e($a['teacher_name']) ?></div></td>
      <td><?= status_badge($a['assignment_type']) ?></td>
      <td class="text-center"><?= $a['workload_score'] !== null ? e(rtrim(rtrim(number_format((float) $a['workload_score'], 2), '0'), '.')) : '—' ?></td>
      <td><?= status_badge($a['status']) ?></td>
      <td class="text-end text-nowrap">
        <button class="btn btn-sm btn-light" type="button" data-bs-toggle="modal" data-bs-target="#detailModal" data-detail="<?= e($a['selection_reason'] ?: 'No explanation stored.') ?>" data-title="<?= e($a['exam_code'] . ' · ' . $a['teacher_name']) ?>" title="Details"><i class="bi bi-info-circle"></i></button>
        <?php if ($a['status'] === 'Pending Review'): ?>
          <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="approve"><input type="hidden" name="assignment_id" value="<?= (int) $a['id'] ?>"><input type="hidden" name="back" value="admin/assignments.php<?= e(qs()) ?>">
            <button class="btn btn-sm btn-success" type="submit" title="Approve"><i class="bi bi-check-lg"></i></button></form>
        <?php endif; ?>
        <?php if (in_array($a['status'], ['Pending Review', 'Confirmed'], true)): ?>
          <button class="btn btn-sm btn-light" type="button" title="Replace" data-bs-toggle="modal" data-bs-target="#replaceModal" data-edit="#replaceForm" data-assignment_id="<?= (int) $a['id'] ?>" data-label="<?= e($a['exam_code'] . ' – replacing ' . $a['teacher_name']) ?>"><i class="bi bi-arrow-left-right"></i></button>
          <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="cancel_assignment"><input type="hidden" name="assignment_id" value="<?= (int) $a['id'] ?>"><input type="hidden" name="back" value="admin/assignments.php<?= e(qs()) ?>">
            <button class="btn btn-sm btn-outline-danger" type="submit" title="Cancel / reject" data-confirm="Cancel this proctor assignment?"><i class="bi bi-x-lg"></i></button></form>
        <?php endif; ?>
      </td></tr><?php endforeach; ?>
    </tbody></table></div><?php endif; ?>
</div>

<!-- details -->
<div class="modal fade" id="detailModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content">
  <div class="modal-header"><h5 class="modal-title" id="detailTitle">Details</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body"><div class="explain-box" id="detailBody"></div></div></div></div></div>

<!-- replace -->
<div class="modal fade" id="replaceModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content">
  <form method="post" id="replaceForm"><?= csrf_field() ?><input type="hidden" name="action" value="replace"><input type="hidden" name="assignment_id" value=""><input type="hidden" name="back" value="admin/assignments.php<?= e(qs()) ?>">
    <div class="modal-header"><h5 class="modal-title">Replace proctor</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
      <p class="text-muted small mb-2" data-info>The new teacher must pass the same hard-constraint validation as automatic assignment.</p>
      <label class="form-label">New proctor</label>
      <select class="form-select" name="teacher_id" required><?= options_html($allTeachers, 'id', fn($t) => $t['teacher_no'] . ' – ' . $t['full_name'] . ' (' . $t['dept_code'] . ')', null, 'Select teacher') ?></select>
    </div>
    <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-navy" type="submit" data-loading="Validating...">Validate &amp; replace</button></div>
  </form></div></div></div>
<?php
$js = '<script>
document.getElementById("detailModal").addEventListener("show.bs.modal", function(ev){
  var b=ev.relatedTarget; document.getElementById("detailTitle").textContent=b.dataset.title; document.getElementById("detailBody").textContent=b.dataset.detail; });
</script>';
foreach ($results as $r) {
    $labels = array_map(fn($x) => $x['teacher_no'], $r['eligible']);
    $scores = array_map(fn($x) => (float) $x['score'], $r['eligible']);
    $selIds = array_column($r['selected'], 'teacher_id');
    $colors = array_map(fn($x) => in_array($x['teacher_id'], $selIds, true) ? '#1e7a46' : '#9fb3d1', $r['eligible']);
    $js .= '<script>new Chart(document.getElementById("genChart' . (int) $r['exam']['id'] . '"),{type:"bar",data:{labels:' . json_encode($labels) . ',datasets:[{label:"Workload score",data:' . json_encode($scores) . ',backgroundColor:' . json_encode($colors) . ',borderRadius:4}]},options:{maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{footer:function(){return "Green = selected";}}}},scales:{y:{beginAtZero:true,ticks:{precision:0}}}}});</script>';
}
$extraScripts = $js;
require __DIR__ . '/../includes/footer.php';
