<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('admin');
$pdo = db();
if (require_post_csrf()) {
    $a = input_str('action', 10);
    if ($a === 'save') {
        $id = input_int('id'); $name = input_str('name', 60); $desc = input_str('description', 200);
        $perms = implode(',', array_values(array_intersect((array) ($_POST['perms'] ?? []), all_perms())));
        if ($name === '') flash('danger', 'Role name is required.');
        elseif (fetch_value('SELECT COUNT(*) FROM access_roles WHERE name = ? AND id <> ?', [$name, $id])) flash('danger', 'That role name already exists.');
        else {
            if ($id) $pdo->prepare('UPDATE access_roles SET name=?, description=?, perms=? WHERE id=?')->execute([$name, $desc, $perms, $id]);
            else $pdo->prepare('INSERT INTO access_roles (name, description, perms) VALUES (?,?,?)')->execute([$name, $desc, $perms]);
            log_activity('role_saved', 'access_role', $id ?: null, null, null, $name); flash('success', 'Role saved.');
        }
    } elseif ($a === 'delete') {
        $id = input_int('id');
        $pdo->prepare('UPDATE users SET access_role_id = NULL WHERE access_role_id = ?')->execute([$id]);
        $pdo->prepare('DELETE FROM access_roles WHERE id = ?')->execute([$id]); flash('success', 'Role deleted. Its holders lost those permissions.');
    } elseif ($a === 'assign') {
        $uid = input_int('user_id'); $rid = input_int('role_id') ?: null;
        $extra = implode(',', array_values(array_intersect((array) ($_POST['extra'] ?? []), all_perms())));
        $pdo->prepare("UPDATE users SET access_role_id = ?, extra_perms = ? WHERE id = ? AND role = 'teacher'")->execute([$rid, $extra ?: null, $uid]);
        notify($uid, 'Your access changed', 'The administrator updated your role / permissions. Check the Manage menu.', 'info', 'teacher/dashboard.php');
        flash('success', 'Access updated.');
    }
    redirect('admin/roles.php');
}
$roles = fetch_all('SELECT r.*, (SELECT COUNT(*) FROM users u WHERE u.access_role_id = r.id) AS holders FROM access_roles r ORDER BY r.name');
$teachers = fetch_all("SELECT id, full_name, email, access_role_id, extra_perms FROM users WHERE role = 'teacher' ORDER BY full_name");
$edit = isset($_GET['edit']) ? fetch_one('SELECT * FROM access_roles WHERE id = ?', [(int) $_GET['edit']]) : null;
$cur = $edit ? explode(',', (string) $edit['perms']) : [];
$pageTitle = 'Roles & Access'; $activeNav = 'roles';
require __DIR__ . '/../includes/header.php';
function perm_boxes(array $checked, string $name): void {
    foreach (PERM_CATALOG as $g => $ps) { echo '<div class="mb-1"><b class="small">' . e($g) . '</b> ';
        foreach ($ps as $k => $l) echo '<label class="me-2 small"><input type="checkbox" name="' . e($name) . '[]" value="' . e($k) . '"' . (in_array($k, $checked, true) ? ' checked' : '') . '> ' . e($l) . '</label>';
        echo '</div>'; }
}
?>
<div class="row g-3">
<div class="col-lg-6"><div class="card-panel fade-up"><h5><?= $edit ? 'Edit role' : 'New role' ?></h5>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int) ($edit['id'] ?? 0) ?>">
<input class="form-control mb-2" name="name" placeholder="Role name (e.g. Scheduler)" maxlength="60" value="<?= e($edit['name'] ?? '') ?>" required>
<input class="form-control mb-2" name="description" placeholder="Description" maxlength="200" value="<?= e($edit['description'] ?? '') ?>">
<?php perm_boxes($cur, 'perms'); ?><button class="btn btn-gold mt-2">Save role</button> <?php if ($edit): ?><a class="btn btn-light mt-2" href="roles.php">Cancel</a><?php endif; ?></form></div>
<div class="card-panel fade-up mt-3"><h5>Roles</h5><?php foreach ($roles as $r): ?>
<div class="border-bottom py-2 d-flex justify-content-between"><div><strong><?= e($r['name']) ?></strong> <span class="badge-s b-blue"><?= (int) $r['holders'] ?> holder(s)</span><div class="small text-muted"><?= e($r['description']) ?></div></div>
<div class="d-flex gap-1"><a class="btn btn-sm btn-light" href="roles.php?edit=<?= (int) $r['id'] ?>">Edit</a><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-sm btn-light" data-confirm="Delete this role?"><i class="bi bi-trash"></i></button></form></div></div><?php endforeach; ?></div></div>
<div class="col-lg-6"><div class="card-panel fade-up"><h5>Give access to teachers</h5><?php foreach ($teachers as $t): ?>
<form method="post" class="border-bottom py-2"><?= csrf_field() ?><input type="hidden" name="action" value="assign"><input type="hidden" name="user_id" value="<?= (int) $t['id'] ?>">
<div class="d-flex gap-2 align-items-center"><strong class="flex-grow-1"><?= e($t['full_name']) ?></strong>
<select name="role_id" class="form-select form-select-sm w-auto"><option value="0">No role</option><?php foreach ($roles as $r): ?><option value="<?= (int) $r['id'] ?>" <?= (int) $t['access_role_id'] === (int) $r['id'] ? 'selected' : '' ?>><?= e($r['name']) ?></option><?php endforeach; ?></select>
<button class="btn btn-sm btn-navy">Save</button></div>
<details class="small mt-1"><summary>Extra permissions</summary><?php perm_boxes(explode(',', (string) $t['extra_perms']), 'extra'); ?></details></form><?php endforeach; ?></div></div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
