<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_perm('papers.view');
require_perm_for_post('papers.manage');
$pdo = db();
$pt = new PaperTracker($pdo);
$id = (int) ($_GET['id'] ?? 0);

if (require_post_csrf()) {
    $action = input_str('action', 20);
    $remarks = input_str('remarks', 255);
    switch ($action) {
        case 'prepare':  $r = $pt->startPreparing($id, $user['id'], $remarks); break;
        case 'ready':    $r = $pt->markReady($id, $user['id'], $remarks); break;
        case 'release':  $r = $pt->release($id, input_int('teacher_id'), $user['id'], $remarks); break;
        case 'return':   $r = $pt->recordReturn($id, $user['id'], $remarks); break;
        case 'complete': $r = $pt->complete($id, $user['id'], $remarks); break;
        default:         $r = ['ok' => false, 'errors' => ['Unknown action.']];
    }
    if ($r['ok']) flash('success', 'Paper status updated.'); else foreach ($r['errors'] as $er) flash('danger', $er);
    redirect('admin/paper_view.php?id=' . $id);
}

$p = $pt->get($id);
if (!$p) { flash('danger', 'Transaction not found.'); redirect('admin/papers.php'); }
$hist = $pt->history($id);
$timeline = PaperTracker::timeline($p);
$proctors = fetch_all("SELECT t.id, t.teacher_no, u.full_name FROM proctor_assignments a JOIN teachers t ON t.id = a.teacher_id JOIN users u ON u.id = t.user_id
    WHERE a.examination_id = ? AND a.status = 'Confirmed' ORDER BY u.full_name", [$p['examination_id']]);

$pageTitle = 'Paper transaction ' . $p['transaction_no'];
$activeNav = 'papers';
require __DIR__ . '/../includes/header.php';

function action_form(string $action, string $label, string $icon, string $cls, string $confirm, string $extra = ''): void { ?>
  <form method="post" class="mb-0"><?= csrf_field() ?><input type="hidden" name="action" value="<?= e($action) ?>">
    <?= $extra ?>
    <div class="mb-2"><input class="form-control form-control-sm" name="remarks" maxlength="255" placeholder="Remarks (optional)"></div>
    <button class="btn <?= e($cls) ?> w-100" type="submit" data-confirm="<?= e($confirm) ?>"><i class="bi bi-<?= e($icon) ?> me-1"></i><?= e($label) ?></button></form>
<?php } ?>
<div class="mb-3"><a href="<?= e(url('admin/papers.php')) ?>" class="text-decoration-none"><i class="bi bi-arrow-left"></i> Back to paper tracking</a></div>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="card-panel">
      <div class="panel-head"><h5><?= e($p['transaction_no']) ?></h5><?= status_badge($p['status']) ?></div>
      <dl class="detail-grid mb-0">
        <dt>Examination</dt><dd><a href="<?= e(url('admin/exam_view.php?id=' . $p['examination_id'])) ?>"><?= e($p['exam_code']) ?></a> – <?= e($p['exam_name']) ?></dd>
        <dt>Exam schedule</dt><dd><?= e(fmt_date($p['exam_date'])) ?> · <?= e(time_range($p['start_time'], $p['end_time'])) ?> · <?= e($p['room_name']) ?></dd>
        <dt>Copies (students + 5 extra)</dt><dd><?= (int) $p['paper_sets'] ?></dd>
        <dt>Assigned proctor</dt><dd><?= $p['proctor_name'] ? e($p['proctor_no'] . ' · ' . $p['proctor_name']) : '—' ?></dd>
        <dt>Receipt confirmation</dt><dd><?= $p['received_at'] ? '<i class="bi bi-check-circle-fill text-success"></i> ' . e(fmt_dt($p['received_at'])) : '<span class="text-muted">Not yet received</span>' ?></dd>
        <dt>Recorded by</dt><dd><?= e($p['recorded_by_name'] ?: '—') ?></dd>
        <dt>Remarks</dt><dd><?= e($p['remarks'] ?: '—') ?></dd>
      </dl>
    </div>
    <div class="card-panel">
      <div class="panel-head"><h6>Next action</h6></div>
      <?php switch ($p['status']):
        case 'Pending': action_form('prepare', 'Start preparing papers', 'printer', 'btn-navy', 'Start preparing the papers now?'); break;
        case 'Preparing': action_form('ready', 'Mark papers prepared', 'box-seam', 'btn-navy', 'Confirm that the papers were prepared and counted?'); break;
        case 'Ready for Release':
          if (!$proctors): ?><div class="alert alert-warning mb-0 small">No Confirmed proctor yet. Approve the proctor assignments of this examination first.</div>
          <?php else:
            $opts = '<div class="mb-2"><label class="form-label">Release to proctor</label><select class="form-select form-select-sm" name="teacher_id" required>' . options_html($proctors, 'id', fn($t) => $t['teacher_no'] . ' – ' . $t['full_name'], null, 'Select proctor') . '</select></div>';
            action_form('release', 'Release papers', 'box-arrow-right', 'btn-navy', 'Release the examination papers to the selected proctor?', $opts);
          endif; break;
        case 'Released': ?><div class="alert alert-info mb-0 small"><i class="bi bi-hourglass-split me-1"></i>Waiting for <strong><?= e($p['proctor_name']) ?></strong> to confirm receipt.</div><?php break;
        case 'Received': action_form('return', 'Record paper return', 'arrow-return-left', 'btn-navy', 'Record that the papers were returned after the examination?'); break;
        case 'Returned': action_form('complete', 'Verify & complete', 'check2-circle', 'btn-success', 'Verify the returned papers and complete this transaction?'); break;
        default: ?><div class="alert alert-success mb-0 small"><i class="bi bi-check-circle me-1"></i>Transaction completed.</div><?php
      endswitch; ?>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card-panel">
      <div class="panel-head"><h5>Status timeline</h5></div>
      <ul class="timeline">
        <?php foreach ($timeline as $t): ?>
          <li class="<?= e($t['state']) ?>"><span class="tl-dot"><?= $t['state'] === 'done' ? '<i class="bi bi-check"></i>' : '' ?></span>
            <div class="tl-title"><?= e($t['status']) ?></div>
            <div class="tl-meta"><?= $t['state'] !== 'todo' && $t['date'] ? e(fmt_dt($t['date'])) . ' · ' : '' ?><?= e($t['who']) ?></div></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card-panel">
      <div class="panel-head"><h5>Transaction history</h5></div>
      <?php foreach (array_reverse($hist) as $h): ?>
        <div class="py-2 border-bottom small">
          <div><?= $h['old_status'] ? e($h['old_status']) . ' → ' : '' ?><strong><?= e($h['new_status']) ?></strong></div>
          <div class="text-muted"><?= e($h['remarks']) ?></div>
          <div class="text-muted"><?= e($h['changed_by_name'] ?: 'System') ?> · <?= e(fmt_dt($h['created_at'])) ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
