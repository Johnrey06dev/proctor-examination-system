<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('staff');
$pdo = db();
$sched = new ProctorScheduler($pdo);

if (require_post_csrf()) {
    $action = input_str('action', 20);
    try {
        if ($action === 'dismiss') {
            $pdo->prepare('UPDATE proctor_assignments SET decline_resolved = 1 WHERE id = ? AND declined_at IS NOT NULL')->execute([input_int('assignment_id')]);
            flash('success', 'Decline marked as resolved.');
        } elseif ($action === 'reassign_all') {
            $ids = fetch_all('SELECT DISTINCT examination_id FROM proctor_assignments WHERE declined_at IS NOT NULL AND decline_resolved = 0');
            $n = 0; $left = 0;
            foreach ($ids as $r) { $res = $sched->reassignDeclined((int) $r['examination_id'], $user['id']); $n += $res['assigned']; if ($res['assigned'] < $res['needed']) $left++; }
            flash($left ? 'warning' : 'success', $n . ' replacement proctor(s) auto-assigned.' . ($left ? ' ' . $left . ' exam(s) could not be fully staffed – assign manually.' : ''));
        }
    } catch (Throwable $e) { flash('danger', 'Action failed: ' . (APP_DEBUG ? $e->getMessage() : 'unexpected error.')); }
    redirect('admin/declined.php');
}
$cols = "a.id, a.examination_id, a.declined_at, a.decline_reason, a.decline_resolved, e.exam_code, e.name AS exam_name, e.exam_date, e.start_time, e.end_time, e.required_proctors, e.status AS exam_status, u.full_name, t.teacher_no,
  (SELECT COUNT(*) FROM proctor_assignments x WHERE x.examination_id = e.id AND x.status <> 'Cancelled') AS staffed";
$join = "FROM proctor_assignments a JOIN examinations e ON e.id = a.examination_id JOIN teachers t ON t.id = a.teacher_id JOIN users u ON u.id = t.user_id WHERE a.declined_at IS NOT NULL";
$open = fetch_all("SELECT $cols $join AND a.decline_resolved = 0 ORDER BY e.exam_date, e.start_time");
$done = fetch_all("SELECT $cols $join AND a.decline_resolved = 1 ORDER BY a.declined_at DESC LIMIT 15");
$pageTitle = 'Reassignment Center';
$activeNav = 'declined';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 fade-up">
  <div><h5 class="serif mb-0">Declined assignments</h5><small class="text-muted">Proctors who rejected an exam. Decliners are never auto-picked again for the same exam.</small></div>
  <?php if ($open): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="reassign_all"><button class="btn btn-navy" type="submit" data-loading="Assigning..." data-confirm="Auto-reassign every exam that lost a proctor?"><i class="bi bi-lightning-charge-fill me-1"></i>Auto-assign all</button></form><?php endif; ?>
</div>
<div class="card-panel fade-up">
  <?php if (!$open): ?><?= empty_state('check2-circle', 'Nothing to reassign', 'No pending declines.') ?><?php else: ?>
  <div class="table-responsive"><table class="table table-modern align-middle"><thead><tr><th>Exam</th><th>Date &amp; time</th><th>Declined by</th><th>Reason</th><th class="text-center">Staffing</th><th></th></tr></thead><tbody>
  <?php foreach ($open as $r): $full = $r['staffed'] >= $r['required_proctors']; ?>
    <tr><td><strong><?= e($r['exam_code']) ?></strong><div class="small text-muted"><?= e($r['exam_name']) ?></div></td>
      <td><?= e(fmt_date($r['exam_date'])) ?><div class="small text-muted"><?= e(time_range($r['start_time'], $r['end_time'])) ?></div></td>
      <td><?= e($r['full_name']) ?><div class="small text-muted"><?= e(fmt_dt($r['declined_at'])) ?></div></td>
      <td class="small"><?= e($r['decline_reason']) ?></td>
      <td class="text-center"><span class="badge <?= $full ? 'bg-success' : 'bg-danger' ?>"><?= (int) $r['staffed'] ?>/<?= (int) $r['required_proctors'] ?></span></td>
      <td class="text-end text-nowrap">
        <?php if ($r['exam_status'] === 'Scheduled'): ?><form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="exam_id" value="<?= (int) $r['examination_id'] ?>"><button class="btn btn-sm btn-navy" formaction="<?= e(url('admin/assignments.php')) ?>" name="action" value="reassign" type="submit"><i class="bi bi-magic"></i> Auto-assign</button></form><?php endif; ?>
        <a class="btn btn-sm btn-light" href="<?= e(url('admin/exam_view.php?id=' . $r['examination_id'])) ?>">Assign manually</a>
        <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="dismiss"><input type="hidden" name="assignment_id" value="<?= (int) $r['id'] ?>"><button class="btn btn-sm btn-outline-secondary" type="submit">Dismiss</button></form></td></tr>
  <?php endforeach; ?></tbody></table></div><?php endif; ?>
</div>
<?php if ($done): ?><div class="card-panel fade-up"><div class="panel-head"><h5>Resolved history</h5></div>
  <div class="table-responsive"><table class="table table-sm"><tbody><?php foreach ($done as $r): ?><tr><td><?= e($r['exam_code']) ?></td><td><?= e($r['full_name']) ?></td><td class="small"><?= e($r['decline_reason']) ?></td><td class="small text-muted"><?= e(fmt_dt($r['declined_at'])) ?></td></tr><?php endforeach; ?></tbody></table></div></div><?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
