<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('admin');
$pdo = db();

if (require_post_csrf()) {
    $max = input_int('max_exams_per_day');
    $gap = input_int('min_gap_minutes');
    $rule = input_str('dept_rule', 20);
    $weight = (float) str_replace(',', '.', input_str('dept_weight', 8));
    $ps = input_str('period_start', 10); $pe = input_str('period_end', 10);
    $err = [];
    if ($max < 0 || $max > 20) $err[] = 'Daily limit must be between 0 (no limit) and 20.';
    if ($gap < 0 || $gap > 600) $err[] = 'Minimum gap must be between 0 and 600 minutes.';
    if (!in_array($rule, ['none', 'prefer_same', 'prefer_other', 'exclude_same'], true)) $err[] = 'Invalid department rule.';
    if ($weight < 0 || $weight > 5) $err[] = 'Department weight must be between 0 and 5.';
    if (($ps !== '' && !valid_date($ps)) || ($pe !== '' && !valid_date($pe))) $err[] = 'Invalid scheduling period date.';
    if ($ps !== '' && $pe !== '' && $ps > $pe) $err[] = 'Period start must not be after the period end.';
    if ($err) { foreach ($err as $x) flash('danger', $x); }
    else {
        $vals = ['max_exams_per_day' => (string) $max, 'min_gap_minutes' => (string) $gap, 'dept_rule' => $rule, 'dept_weight' => (string) $weight, 'period_start' => $ps, 'period_end' => $pe];
        $pdo->beginTransaction();
        foreach ($vals as $k => $v) {
            $st = $pdo->prepare('UPDATE system_settings SET setting_value = ? WHERE setting_key = ?'); $st->execute([$v, $k]);
            if ($st->rowCount() === 0 && !fetch_value('SELECT COUNT(*) FROM system_settings WHERE setting_key = ?', [$k])) {
                $pdo->prepare('INSERT INTO system_settings (setting_key, setting_value) VALUES (?,?)')->execute([$k, $v]);
            }
        }
        $pdo->commit();
        log_activity('settings_updated', 'settings', null, null, null, 'Algorithm settings updated');
        flash('success', 'Algorithm settings saved. They apply to the next generation / validation.');
    }
    redirect('admin/settings.php');
}
$s = get_settings(true);

$pageTitle = 'Algorithm Settings';
$activeNav = 'settings';
require __DIR__ . '/../includes/header.php';
?>
<div class="row g-3"><div class="col-lg-7">
<div class="card-panel">
  <div class="panel-head"><h5>Eligibility rules &amp; load-balancing configuration</h5></div>
  <form method="post"><?= csrf_field() ?>
    <h6 class="text-muted">Hard constraint rules</h6>
    <div class="row g-3 mb-3">
      <div class="col-md-6"><label class="form-label">Max assignments per teacher per day</label><input type="number" class="form-control" name="max_exams_per_day" min="0" max="20" value="<?= e($s['max_exams_per_day']) ?>"><div class="form-text">0 = no limit.</div></div>
      <div class="col-md-6"><label class="form-label">Minimum rest gap between assignments (minutes)</label><input type="number" class="form-control" name="min_gap_minutes" min="0" max="600" value="<?= e($s['min_gap_minutes']) ?>"><div class="form-text">0 = only direct overlaps are blocked.</div></div>
    </div>
    <h6 class="text-muted">Department rule</h6>
    <div class="alert alert-info py-2 small" data-info>Proctors from <b>any department</b> may supervise any examination. The scheduler no longer restricts or prefers departments; it pairs fairly by the fewest assigned subjects, then the fewest exam hours.</div>
    <input type="hidden" name="dept_rule" value="none"><input type="hidden" name="dept_weight" value="<?= e($s['dept_weight']) ?>">
    <h6 class="text-muted">Scheduling period for workload counting</h6>
    <div class="row g-3 mb-3">
      <div class="col-md-6"><label class="form-label">Period start</label><input type="date" class="form-control" name="period_start" value="<?= e($s['period_start']) ?>"></div>
      <div class="col-md-6"><label class="form-label">Period end</label><input type="date" class="form-control" name="period_end" value="<?= e($s['period_end']) ?>"><div class="form-text">Leave both empty to count all assignments.</div></div>
    </div>
    <button class="btn btn-navy" type="submit" data-loading="Saving...">Save settings</button>
  </form>
</div></div>
<div class="col-lg-5"><div class="card-panel"><div class="panel-head"><h5>What these settings do</h5></div>
  <p class="small">Hard rules <strong>exclude</strong> teachers. Soft rules only <strong>re-order</strong> teachers who already passed all hard rules.</p>
  <p class="small mb-0">Changes affect future generations and manual validation only; existing assignments are not changed.</p></div></div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
