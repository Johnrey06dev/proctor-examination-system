<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('staff');
$pdo = db();

if (is_post() && ($_POST['action'] ?? '') === 'delete_teacher' && require_post_csrf()) {
    $uid = (int) fetch_value('SELECT user_id FROM teachers WHERE id = ?', [input_int('id')]);
    $err = $uid ? delete_user_account($uid, (int) $user['id']) : 'Teacher not found.';
    $err ? flash('danger', $err) : flash('success', 'Teacher deleted (account, availability and assignments removed).');
    redirect('admin/teachers.php');
}
if (require_post_csrf()) {
    $action = input_str('action', 20);
    $id = input_int('id');

    if ($action === 'save') {
        $no = input_str('teacher_no', 30);
        [$np, $nerr] = name_parts_from_post(); $name = $np['full'];
        $email = strtolower(input_str('email', 150));
        $dept = input_int('department_id');
        $spec = input_str('specialization', 150);
        $contact = input_str('contact_number', 40);
        $avail = input_str('availability_status', 20) === 'Unavailable' ? 'Unavailable' : 'Available';
        $account = input_str('account_status', 10) === 'inactive' ? 'inactive' : 'active';
        $password = (string) ($_POST['password'] ?? '');
        $errors = [];

        if ($no === '') $errors[] = 'Teacher ID is required.';
        foreach ($nerr as $ne) $errors[] = $ne;
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email address is required.';
        if (!fetch_value('SELECT COUNT(*) FROM departments WHERE id = ?', [$dept])) $errors[] = 'Please select a department.';
        if ($id === 0 && ($err = password_rules_error($password))) $errors[] = $err;
        if ($id > 0 && $password !== '' && ($err = password_rules_error($password))) $errors[] = $err;

        // duplicate checks (friendly messages; the database unique keys are the final guard)
        $teacher = $id ? fetch_one('SELECT * FROM teachers WHERE id = ?', [$id]) : null;
        if ($id && !$teacher) $errors[] = 'Teacher not found.';
        $uidSelf = $teacher ? (int) $teacher['user_id'] : 0;
        if (fetch_value('SELECT COUNT(*) FROM teachers WHERE teacher_no = ? AND id <> ?', [$no, $id])) $errors[] = 'Teacher ID "' . $no . '" already exists.';
        if (fetch_value('SELECT COUNT(*) FROM users WHERE email = ? AND id <> ?', [$email, $uidSelf])) $errors[] = 'Email "' . $email . '" is already used by another account.';

        if (!$errors) {
            try {
                $pdo->beginTransaction();
                if ($id === 0) {
                    $pdo->prepare("INSERT INTO users (email, password_hash, full_name, first_name, middle_name, last_name, suffix, gender, role, status, contact_number, created_at) VALUES (?,?,?,?,?,?,?,?,'teacher',?,?,?)")
                        ->execute([$email, password_hash($password, PASSWORD_DEFAULT), $name, $np['first'], $np['middle'] ?: null, $np['last'], $np['suffix'] ?: null, $np['gender'], $account, $contact, now()]);
                    $uid = (int) $pdo->lastInsertId();
                    $pdo->prepare('INSERT INTO teachers (user_id, teacher_no, department_id, specialization, availability_status, created_at) VALUES (?,?,?,?,?,?)')
                        ->execute([$uid, $no, $dept, $spec, $avail, now()]);
                    $newId = (int) $pdo->lastInsertId();
                    log_activity('teacher_created', 'teacher', $newId, null, $account, 'Teacher ' . $no . ' ' . $name . ' created');
                    flash('success', 'Teacher added successfully.');
                } else {
                    $pdo->prepare('UPDATE users SET email=?, full_name=?, first_name=?, middle_name=?, last_name=?, suffix=?, gender=?, status=?, contact_number=? WHERE id=?')->execute([$email, $name, $np['first'], $np['middle'] ?: null, $np['last'], $np['suffix'] ?: null, $np['gender'], $account, $contact, $uidSelf]);
                    if ($password !== '') {
                        $pdo->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($password, PASSWORD_DEFAULT), $uidSelf]);
                    }
                    $pdo->prepare('UPDATE teachers SET teacher_no=?, department_id=?, specialization=?, availability_status=? WHERE id=?')->execute([$no, $dept, $spec, $avail, $id]);
                    log_activity('teacher_updated', 'teacher', $id, null, null, 'Teacher ' . $no . ' updated');
                    flash('success', 'Teacher updated successfully.');
                }
                $pdo->commit();
            } catch (PDOException $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                flash('danger', is_duplicate_error($e) ? 'Duplicate Teacher ID or email address.' : 'Database error: ' . (APP_DEBUG ? $e->getMessage() : 'could not save the teacher.'));
            }
        } else {
            foreach ($errors as $er) flash('danger', $er);
        }
    } elseif ($action === 'toggle') {
        $t = fetch_one('SELECT t.id, t.user_id, u.status, t.teacher_no FROM teachers t JOIN users u ON u.id = t.user_id WHERE t.id = ?', [$id]);
        if ($t) {
            $new = $t['status'] === 'active' ? 'inactive' : 'active';
            $pdo->prepare('UPDATE users SET status = ? WHERE id = ?')->execute([$new, $t['user_id']]);
            log_activity('teacher_status', 'teacher', $id, $t['status'], $new, 'Teacher ' . $t['teacher_no'] . ' account set to ' . $new);
            flash('success', 'Teacher account is now ' . $new . '.');
        }
    }
    redirect('admin/teachers.php' . qs());
}

// filters
$q = trim($_GET['q'] ?? '');
$fd = (int) ($_GET['dept'] ?? 0);
$fs = $_GET['account'] ?? '';
$fa = $_GET['avail'] ?? '';
$where = ['1=1'];
$params = [];
if ($q !== '') { $where[] = '(u.full_name LIKE ? OR t.teacher_no LIKE ? OR u.email LIKE ? OR t.specialization LIKE ?)'; array_push($params, "%$q%", "%$q%", "%$q%", "%$q%"); }
if ($fd) { $where[] = 't.department_id = ?'; $params[] = $fd; }
if (in_array($fs, ['active', 'inactive'], true)) { $where[] = 'u.status = ?'; $params[] = $fs; }
if (in_array($fa, ['Available', 'Unavailable'], true)) { $where[] = 't.availability_status = ?'; $params[] = $fa; }

$teachers = fetch_all("SELECT t.*, u.full_name, u.first_name, u.middle_name, u.last_name, u.suffix, u.gender, u.photo, u.email, u.contact_number, u.status AS account_status, u.last_login_at, d.code AS dept_code, d.name AS dept_name,
        (SELECT COUNT(*) FROM proctor_assignments a WHERE a.teacher_id = t.id AND a.status <> 'Cancelled') AS workload
    FROM teachers t JOIN users u ON u.id = t.user_id JOIN departments d ON d.id = t.department_id
    WHERE " . implode(' AND ', $where) . ' ORDER BY t.teacher_no', $params);
$depts = dept_list();

$pageTitle = 'Teachers';
$activeNav = 'teachers';
require __DIR__ . '/../includes/header.php';
?>
<div class="card-panel">
  <form class="filter-bar" method="get">
    <div style="flex:2"><label class="form-label">Search</label><input class="form-control" name="q" value="<?= e($q) ?>" placeholder="Name, ID, email, specialization"></div>
    <div><label class="form-label">Department</label><select class="form-select" name="dept"><?= options_html($depts, 'id', 'code', $fd, 'All') ?></select></div>
    <div><label class="form-label">Account</label><select class="form-select" name="account"><option value="">All</option><option value="active" <?= $fs === 'active' ? 'selected' : '' ?>>Active</option><option value="inactive" <?= $fs === 'inactive' ? 'selected' : '' ?>>Inactive</option></select></div>
    <div><label class="form-label">Availability</label><select class="form-select" name="avail"><option value="">All</option><option <?= $fa === 'Available' ? 'selected' : '' ?>>Available</option><option <?= $fa === 'Unavailable' ? 'selected' : '' ?>>Unavailable</option></select></div>
    <div class="d-flex gap-2"><button class="btn btn-navy" type="submit"><i class="bi bi-search me-1"></i>Filter</button><a class="btn btn-light" href="<?= e(url('admin/teachers.php')) ?>">Reset</a></div>
    <div class="ms-auto"><button class="btn btn-navy" type="button" data-bs-toggle="modal" data-bs-target="#teacherModal" data-reset-form="#teacherForm"><i class="bi bi-plus-lg me-1"></i>Add teacher</button></div>
  </form>
</div>

<div class="card-panel">
  <?php if (!$teachers): ?>
    <?= empty_state('people', 'No teachers found', 'Try different filters or add a new teacher.') ?>
  <?php else: ?>
  <div class="table-responsive">
    <table class="table table-modern align-middle">
      <thead><tr><th>Teacher ID</th><th>Name</th><th>Department</th><th>Specialization</th><th>Contact</th><th>Account</th><th>Availability</th><th class="text-center">Workload</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($teachers as $t): ?>
        <tr>
          <td><strong><?= e($t['teacher_no']) ?></strong></td>
          <td><div class="d-flex align-items-center gap-2"><?= avatar_html($t, 'avatar avatar-sm') ?><div><?= e($t['full_name']) ?><div class="text-muted small"><?= e($t['email']) ?></div></div></div></td>
          <td><span title="<?= e($t['dept_name']) ?>"><?= e($t['dept_code']) ?></span></td>
          <td><?= e($t['specialization']) ?></td>
          <td><?= e($t['contact_number']) ?></td>
          <td><?= status_badge(ucfirst($t['account_status'])) ?></td>
          <td><?= status_badge($t['availability_status']) ?></td>
          <td class="text-center"><span class="badge bg-secondary"><?= (int) $t['workload'] ?></span></td>
          <td class="text-end text-nowrap">
            <a class="btn btn-sm btn-light" href="<?= e(url('admin/teacher_view.php?id=' . $t['id'])) ?>" title="View"><i class="bi bi-eye"></i></a>
            <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="delete_teacher"><input type="hidden" name="id" value="<?= (int) $t['id'] ?>"><button class="btn btn-sm btn-danger" type="submit" title="Delete" data-confirm="PERMANENTLY delete <?= e($t['full_name']) ?>? Their account, availability and proctor assignments are removed."><i class="bi bi-trash"></i></button></form>
            <button class="btn btn-sm btn-light" type="button" title="Edit" data-bs-toggle="modal" data-bs-target="#teacherModal" data-edit="#teacherForm"
              data-id="<?= (int) $t['id'] ?>" data-teacher_no="<?= e($t['teacher_no']) ?>" data-first_name="<?= e($t['first_name'] ?: (preg_split('/\s+/', trim($t['full_name']), 2)[0] ?? '')) ?>" data-middle_name="<?= e($t['middle_name']) ?>" data-last_name="<?= e($t['last_name'] ?: (preg_split('/\s+/', trim($t['full_name']), 2)[1] ?? '')) ?>" data-suffix="<?= e($t['suffix']) ?>" data-gender="<?= e($t['gender']) ?>" data-email="<?= e($t['email']) ?>"
              data-department_id="<?= (int) $t['department_id'] ?>" data-specialization="<?= e($t['specialization']) ?>" data-contact_number="<?= e($t['contact_number']) ?>"
              data-availability_status="<?= e($t['availability_status']) ?>" data-account_status="<?= e($t['account_status']) ?>"><i class="bi bi-pencil"></i></button>
            <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $t['id'] ?>">
              <button class="btn btn-sm <?= $t['account_status'] === 'active' ? 'btn-outline-danger' : 'btn-outline-success' ?>" type="submit"
                data-confirm="<?= $t['account_status'] === 'active' ? 'Deactivate this account? The teacher will no longer be able to log in or be assigned.' : 'Activate this account?' ?>">
                <i class="bi bi-<?= $t['account_status'] === 'active' ? 'person-x' : 'person-check' ?>"></i></button></form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="text-muted small mt-2"><?= count($teachers) ?> teacher(s) shown</div>
  <?php endif; ?>
</div>

<div class="modal fade" id="teacherModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content">
    <form method="post" id="teacherForm" autocomplete="off">
      <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="">
      <div class="modal-header"><h5 class="modal-title">Teacher details</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body"><div class="row g-3">
        <div class="col-md-4"><label class="form-label">Teacher ID *</label><input class="form-control" name="teacher_no" required maxlength="30" placeholder="T-013"></div>
        <div class="col-md-8"><label class="form-label">First name *</label><input class="form-control" name="first_name" required maxlength="60"></div>
        <div class="col-md-4"><label class="form-label">Middle name</label><input class="form-control" name="middle_name" maxlength="60"></div>
        <div class="col-md-5"><label class="form-label">Surname *</label><input class="form-control" name="last_name" required maxlength="60"></div>
        <div class="col-md-3"><label class="form-label">Suffix</label><select class="form-select" name="suffix"><option value="">None</option><?php foreach (NAME_SUFFIXES as $sf): ?><option><?= e($sf) ?></option><?php endforeach; ?></select></div>
        <div class="col-md-4"><label class="form-label">Gender *</label><select class="form-select" name="gender" required><option value="">Select</option><option>Male</option><option>Female</option></select></div>
        <div class="col-md-6"><label class="form-label">Email address (login) *</label><input class="form-control" type="email" name="email" required maxlength="150"></div>
        <div class="col-md-6"><label class="form-label">Contact number</label><input class="form-control" name="contact_number" maxlength="40"></div>
        <div class="col-md-6"><label class="form-label">Department *</label><select class="form-select" name="department_id" required><?= options_html($depts, 'id', fn($d) => $d['code'] . ' – ' . $d['name'], null, 'Select department') ?></select></div>
        <div class="col-md-6"><label class="form-label">Subject specialization</label><input class="form-control" name="specialization" maxlength="150"></div>
        <div class="col-md-4"><label class="form-label">Account status</label><select class="form-select" name="account_status"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
        <div class="col-md-4"><label class="form-label">Availability</label><select class="form-select" name="availability_status"><option>Available</option><option>Unavailable</option></select></div>
        <div class="col-md-4"><label class="form-label">Password</label><input class="form-control" type="password" name="password" autocomplete="new-password" placeholder="New teacher: required"><div class="form-text">Editing: leave blank to keep the current password.</div></div>
      </div></div>
      <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-navy" type="submit" data-loading="Saving...">Save teacher</button></div>
    </form>
  </div></div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
