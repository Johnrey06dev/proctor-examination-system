<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('staff');
$pdo = db();
if (require_post_csrf()) {
    $a = input_str('action', 8);
    if ($a === 'reply') {
        $to = input_int('to'); $b = input_str('body', 2000);
        if ($b !== '' && $to) { send_message((int) $user['id'], $to, input_str('subject', 150) ?: 'Re: message', $b); flash('success', 'Sent.'); }
    } elseif ($a === 'read') $pdo->prepare('UPDATE messages SET is_read = 1 WHERE id = ? AND to_user = ?')->execute([input_int('id'), $user['id']]);
    elseif ($a === 'readall') $pdo->prepare('UPDATE messages SET is_read = 1 WHERE to_user = ?')->execute([$user['id']]);
    redirect('admin/messages.php');
}
$msgs = fetch_all('SELECT m.*, u.full_name FROM messages m JOIN users u ON u.id = m.from_user WHERE m.to_user = ? ORDER BY m.id DESC LIMIT 100', [$user['id']]);
$pageTitle = 'Messages'; $activeNav = 'messages';
require __DIR__ . '/../includes/header.php';
?>
<div class="card-panel fade-up"><div class="d-flex justify-content-between"><h5>Inbox</h5><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="readall"><button class="btn btn-sm btn-light">Mark all read</button></form></div>
<?php if (!$msgs): ?><?= empty_state('chat-dots', 'No messages') ?><?php endif; ?>
<?php foreach ($msgs as $m): ?><div class="border-bottom py-2 <?= $m['is_read'] ? '' : 'fw-semibold' ?>">
 <div class="d-flex justify-content-between"><span><?= $m['is_read'] ? '' : '<span class="badge-s b-amber">New</span> ' ?><?= e($m['subject']) ?> <span class="text-muted small">from <?= e($m['full_name']) ?> &middot; <?= e(fmt_dt($m['created_at'])) ?></span></span>
 <?php if (!$m['is_read']): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="read"><input type="hidden" name="id" value="<?= (int) $m['id'] ?>"><button class="btn btn-sm btn-light">Mark read</button></form><?php endif; ?></div>
 <div class="small fw-normal"><?= nl2br(e($m['body'])) ?></div>
 <form method="post" class="d-flex gap-2 mt-1"><?= csrf_field() ?><input type="hidden" name="action" value="reply"><input type="hidden" name="to" value="<?= (int) $m['from_user'] ?>"><input type="hidden" name="subject" value="Re: <?= e($m['subject']) ?>"><input class="form-control form-control-sm" name="body" placeholder="Reply..." maxlength="2000"><button class="btn btn-sm btn-navy">Reply</button></form></div>
<?php endforeach; ?></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
