<?php
/**
 * admin/_assignment_actions.php
 * Shared POST handler for proctor-assignment actions. Included by assignments.php
 * and exam_view.php (the underscore means: not a page, never opened directly).
 *
 * Expects: $user (admin), $sched (ProctorScheduler). Redirects when done.
 */
if (!isset($user, $sched)) { http_response_code(403); exit('Not allowed.'); }
if (is_post() && !(is_staff() || user_can('rooms.assign') || user_can('autoassign.apply'))) deny_access($user);

function show_errors(array $errors): void
{
    foreach ($errors as $er) flash('danger', $er);
}

if (require_post_csrf()) {
    $action = input_str('action', 30);
    $examId = input_int('exam_id');
    $assignId = input_int('assignment_id');
    $back = input_str('back', 120);
    $target = ($back !== '' && preg_match('#^admin/[a-z_]+\.php(\?[A-Za-z0-9_=&%.\-]*)?$#', $back)) ? $back : 'admin/assignments.php';

    try {
        switch ($action) {
            case 'generate':
                $r = $sched->generate($examId, $user['id']);
                $_SESSION['gen_results'] = [$r];
                flash($r['assigned'] > 0 ? 'success' : 'warning', $r['assigned'] . ' proctor(s) generated for ' . $r['exam']['exam_code'] . '. Review the explanation below, then approve.');
                foreach (array_merge($r['warnings'], $r['messages']) as $w) flash('warning', $w);
                $target = 'admin/assignments.php?result=1';
                break;

            case 'generate_all':
                $results = $sched->generateAll($user['id']);
                $_SESSION['gen_results'] = $results;
                $total = array_sum(array_column($results, 'assigned'));
                flash($results ? 'success' : 'info', $results ? ($total . ' proctor(s) generated across ' . count($results) . ' examination(s).') : 'Every scheduled examination already has all required proctors.');
                foreach ($results as $r) foreach ($r['warnings'] as $w) flash('warning', $w);
                $target = 'admin/assignments.php?result=1';
                break;

            case 'generate_range':
                $from = valid_date(input_str('from', 10)) ? input_str('from', 10) : null;
                $to = valid_date(input_str('to', 10)) ? input_str('to', 10) : null;
                $results = $sched->generateAll($user['id'], $from, $to);
                $_SESSION['gen_results'] = $results;
                $total = array_sum(array_column($results, 'assigned'));
                flash($results ? 'success' : 'info', $results ? ($total . ' proctor(s) auto-assigned across ' . count($results) . ' examination(s).') : 'No examinations in that range need proctors.');
                foreach ($results as $r) foreach ($r['warnings'] as $w) flash('warning', $w);
                $target = 'admin/assignments.php?result=1';
                break;

            case 'reassign':
                $r = $sched->reassignDeclined($examId, $user['id']);
                $_SESSION['gen_results'] = [$r];
                flash($r['assigned'] > 0 ? 'success' : 'warning', $r['assigned'] . ' replacement proctor(s) auto-assigned for ' . $r['exam']['exam_code'] . '.');
                foreach ($r['warnings'] as $w) flash('warning', $w);
                $target = 'admin/declined.php';
                break;

            case 'regenerate':
                $r = $sched->regenerate($examId, $user['id']);
                $_SESSION['gen_results'] = [$r];
                flash('success', 'Pending proposals were rejected and ' . $r['assigned'] . ' new proctor(s) were generated for ' . $r['exam']['exam_code'] . '.');
                foreach ($r['warnings'] as $w) flash('warning', $w);
                $target = 'admin/assignments.php?result=1';
                break;

            case 'approve':
                $r = $sched->approve($assignId, $user['id']);
                $r['ok'] ? flash('success', 'Assignment approved (Confirmed).') : show_errors($r['errors']);
                break;

            case 'approve_exam':
                $r = $sched->approveExam($examId, $user['id']);
                if ($r['approved']) flash('success', $r['approved'] . ' assignment(s) approved.');
                show_errors($r['errors']);
                if (!$r['approved'] && !$r['errors']) flash('info', 'Nothing to approve.');
                break;

            case 'reject_exam':
                $ids = $sched->rejectPending($examId, $user['id']);
                flash($ids ? 'success' : 'info', $ids ? count($ids) . ' pending assignment(s) rejected. You can regenerate or assign manually.' : 'No pending assignments to reject.');
                break;

            case 'cancel_assignment':
                $r = $sched->cancelAssignment($assignId, $user['id']);
                $r['ok'] ? flash('success', 'Assignment cancelled.') : show_errors($r['errors']);
                break;

            case 'manual':
                $r = $sched->manualAssign($examId, input_int('teacher_id'), input_str('status', 20), $user['id']);
                if ($r['ok']) {
                    flash('success', 'Teacher assigned manually (all hard constraints passed).');
                } else {
                    flash('danger', 'Manual assignment refused – hard constraint violation:');
                    show_errors($r['errors']);
                }
                break;

            case 'replace':
                $r = $sched->replaceAssignment($assignId, input_int('teacher_id'), $user['id']);
                if ($r['ok']) {
                    flash('success', 'Proctor replaced.');
                } else {
                    flash('danger', 'Replacement refused:');
                    show_errors($r['errors']);
                }
                break;

            default:
                flash('danger', 'Unknown action.');
        }
    } catch (SchedulingException $e) {
        show_errors($e->errors);
    } catch (Throwable $e) {
        flash('danger', 'Could not complete the action: ' . (APP_DEBUG ? $e->getMessage() : 'unexpected error.'));
    }
    if (!empty($_POST['stay']) && $back !== '' && $target !== $back) $target = $back;
    redirect($target);
}
