<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_perm('subjects.view');
require_perm_for_post('subjects.edit');
$pdo = db();

if (require_post_csrf()) {
    $a = input_str('action', 20);
    try {
        if ($a === 'add_year') {
            $dept = input_int('department_id'); $lvl = input_int('year_level');
            if (!fetch_value('SELECT COUNT(*) FROM departments WHERE id = ?', [$dept])) flash('danger', 'Choose a department from the list.');
            elseif (str_starts_with((string) ($_POST['year_level'] ?? ''), 'all_')) {   // every level of a stage for this department
                $stg = substr((string) $_POST['year_level'], 4); $made = 0;
                if (!isset(SCHOOL_STAGES[$stg])) throw new RuntimeException('Choose a year level.');
                foreach (SCHOOL_STAGES[$stg]['levels'] as $l) if (!fetch_value('SELECT COUNT(*) FROM year_configs WHERE department_id = ? AND year_level = ?', [$dept, $l])) { $pdo->prepare('INSERT INTO year_configs (department_id, year_level, created_at) VALUES (?,?,?)')->execute([$dept, $l, now()]); $made++; }
                log_activity('year_created', 'year', null, null, null, $made . ' level(s) of ' . SCHOOL_STAGES[$stg]['label'] . ' added');
                flash($made ? 'success' : 'info', $made ? $made . ' level(s) added. Open each one to add its subjects and sections.' : 'That department already has all of them.');
            }
            elseif (!isset(YEAR_LEVELS[$lvl])) flash('danger', 'Choose a year level.');
            elseif (fetch_value('SELECT COUNT(*) FROM year_configs WHERE department_id = ? AND year_level = ?', [$dept, $lvl])) flash('danger', 'That department already has ' . YEAR_LEVELS[$lvl] . '. Open it below and add its subjects.');
            else {
                $pdo->prepare('INSERT INTO year_configs (department_id, year_level, created_at) VALUES (?,?,?)')->execute([$dept, $lvl, now()]);
                log_activity('year_created', 'year', (int) $pdo->lastInsertId(), null, null, YEAR_LEVELS[$lvl] . ' added');
                flash('success', YEAR_LEVELS[$lvl] . ' added. Now add the subjects of each semester.');
            }
        } elseif ($a === 'set_levels') {
            $pick = array_values(array_filter((array) ($_POST['stages'] ?? []), fn($k) => isset(SCHOOL_STAGES[$k])));
            if (!$pick) flash('danger', 'Choose at least one school level.');
            else { $pdo->beginTransaction(); save_school_levels($pdo, $pick); $pdo->commit(); log_activity('school_levels', 'settings', null, null, null, 'School levels: ' . implode(', ', $pick)); flash('success', 'School levels saved. Elementary, Junior High and Senior High cards are created automatically.'); }
        } elseif ($a === 'del_year') {
            $id = input_int('id');
            if (fetch_value('SELECT COUNT(*) FROM class_sections WHERE year_config_id = ?', [$id])) flash('danger', 'Cannot delete: sections are registered under this year level. Delete or move those sections first.');
            elseif (fetch_value('SELECT COUNT(*) FROM exam_sections x JOIN year_subjects s ON s.id = x.year_subject_id WHERE s.year_config_id = ?', [$id])) flash('danger', 'Cannot delete: some of its subjects are already scheduled for examinations.');
            else {
                $pdo->prepare('DELETE FROM year_configs WHERE id = ?')->execute([$id]);
                log_activity('year_deleted', 'year', $id, null, null, 'Year level deleted'); flash('success', 'Year level deleted.');
            }
        } elseif ($a === 'add_subject') {
            $id = input_int('id'); $sem = input_int('semester');
            $ycs = fetch_one('SELECT * FROM year_configs WHERE id = ?', [$id]);
            if (!$ycs || !isset(sem_list((int) $ycs['year_level'])[$sem])) throw new RuntimeException('Year level or semester not found.');
            $added = 0; $dups = [];
            foreach (preg_split('/\r\n|\r|\n|;/', (string) ($_POST['names'] ?? '')) as $nm) {
                $nm = trim(preg_replace('/\s+/', ' ', mb_substr($nm, 0, 150)));
                if ($nm === '') continue;
                if (fetch_value('SELECT COUNT(*) FROM year_subjects WHERE year_config_id = ? AND semester = ? AND LOWER(name) = LOWER(?)', [$id, $sem, $nm])) { $dups[] = $nm; continue; }
                $pdo->prepare('INSERT INTO year_subjects (year_config_id, semester, name, sort_order) VALUES (?,?,?,?)')
                    ->execute([$id, $sem, $nm, (int) fetch_value('SELECT COALESCE(MAX(sort_order),0)+1 FROM year_subjects WHERE year_config_id = ? AND semester = ?', [$id, $sem])]);
                ensure_subject($pdo, (int) $pdo->lastInsertId()); $added++;
            }
            if ($added) { log_activity('year_subject_added', 'year', $id, null, null, $added . ' subject(s) added' . (sem_label($sem) ? ' to ' . sem_label($sem) : '')); flash('success', $added . ' subject(s) added.'); }
            if ($dups) flash('warning', 'Already in this semester: ' . implode(', ', $dups));
            if (!$added && !$dups) flash('danger', 'Type at least one subject name.');
        } elseif ($a === 'add_section') {
            $id = input_int('id'); $sem = input_int('semester'); $nm = trim(preg_replace('/\s+/', ' ', input_str('name', 60))); $stu = input_int('students');
            $yc = fetch_one('SELECT * FROM year_configs WHERE id = ?', [$id]);
            if (!$yc || !isset(sem_list((int) $yc['year_level'])[$sem])) flash('danger', 'Year level or semester not found.');
            elseif ($nm === '' || $stu < 1) flash('danger', 'Enter the section name and its number of students.');
            elseif (fetch_value('SELECT COUNT(*) FROM class_sections WHERE year_config_id = ? AND semester = ? AND LOWER(name) = LOWER(?)', [$id, $sem, $nm])) flash('danger', 'This ' . (level_has_sem((int) $yc['year_level']) ? 'semester' : 'year level') . ' already has a section named ' . $nm . '.');
            else {
                $pdo->prepare('INSERT INTO class_sections (name, department_id, year_config_id, semester, students, created_at) VALUES (?,?,?,?,?,?)')->execute([$nm, $yc['department_id'], $id, $sem, $stu, now()]);
                log_activity('section_created', 'section', (int) $pdo->lastInsertId(), null, null, 'Section ' . $nm . ' added (' . $stu . ' students)'); flash('success', 'Section ' . $nm . ' added.');
            }
        } elseif ($a === 'edit_section') {
            $pdo->beginTransaction();
            $errs = section_update($pdo, input_int('id'), input_str('name', 60), input_int('students'), (int) $user['id']);
            if ($errs) { $pdo->rollBack(); foreach ($errs as $er) flash('danger', $er); }
            else { $pdo->commit(); log_activity('section_updated', 'section', input_int('id'), null, null, 'Section updated'); flash('success', 'Section saved. Its exams and paper copies were updated too.'); }
        } elseif ($a === 'del_section') {
            $id = input_int('id'); $sc = fetch_one('SELECT name FROM class_sections WHERE id = ?', [$id]);
            if (!$sc) flash('danger', 'Section not found.');
            elseif ($n = (int) fetch_value('SELECT COUNT(*) FROM exam_sections WHERE section_id = ?', [$id])) flash('danger', 'Cannot delete ' . $sc['name'] . ': it has ' . $n . ' exam(s) scheduled. Remove those exams first.');
            else { $pdo->prepare('DELETE FROM class_sections WHERE id = ?')->execute([$id]); log_activity('section_deleted', 'section', $id, null, null, 'Section ' . $sc['name'] . ' deleted'); flash('success', 'Section deleted.'); }
        } elseif ($a === 'edit_subject') {
            $id = input_int('id'); $nm = trim(preg_replace('/\s+/', ' ', input_str('name', 150)));
            $ys = fetch_one('SELECT * FROM year_subjects WHERE id = ?', [$id]);
            if (!$ys || $nm === '') flash('danger', 'Subject name is required.');
            elseif (fetch_value('SELECT COUNT(*) FROM year_subjects WHERE year_config_id = ? AND semester = ? AND LOWER(name) = LOWER(?) AND id <> ?', [$ys['year_config_id'], $ys['semester'], $nm, $id])) flash('danger', 'That subject is already in this semester.');
            else {
                $pdo->prepare('UPDATE year_subjects SET name = ? WHERE id = ?')->execute([$nm, $id]);
                if ($ys['subject_id']) {   // keep the subject row used by exams in step with the Year record
                    $pdo->prepare('UPDATE examinations SET name = ? WHERE subject_id = ? AND name = ?')->execute([$nm, $ys['subject_id'], $ys['name']]);
                    $pdo->prepare('UPDATE subjects SET name = ? WHERE id = ?')->execute([$nm, $ys['subject_id']]);
                }
                log_activity('year_subject_updated', 'year', $id, null, null, $ys['name'] . ' → ' . $nm); flash('success', 'Subject renamed.');
            }
        } elseif ($a === 'del_subject') {
            $id = input_int('id'); $ys = fetch_one('SELECT * FROM year_subjects WHERE id = ?', [$id]);
            if (!$ys) flash('danger', 'Subject not found.');
            elseif ($n = (int) fetch_value('SELECT COUNT(*) FROM exam_sections WHERE year_subject_id = ?', [$id])) flash('danger', 'Cannot remove "' . $ys['name'] . '": it is scheduled for ' . $n . ' section exam(s). Remove those exams first.');
            else {
                $pdo->prepare('DELETE FROM year_subjects WHERE id = ?')->execute([$id]);
                if ($ys['subject_id'] && !fetch_value('SELECT COUNT(*) FROM examinations WHERE subject_id = ?', [$ys['subject_id']]) && !fetch_value('SELECT COUNT(*) FROM year_subjects WHERE subject_id = ?', [$ys['subject_id']]))
                    $pdo->prepare('DELETE FROM subjects WHERE id = ?')->execute([$ys['subject_id']]);
                log_activity('year_subject_deleted', 'year', $id, null, null, 'Subject ' . $ys['name'] . ' removed'); flash('success', 'Subject removed.');
            }
        }
    } catch (Throwable $e) { flash('danger', 'Could not save: ' . (APP_DEBUG ? $e->getMessage() : 'unexpected error.')); }
    redirect('admin/years.php' . qs());
}

$fd = (int) ($_GET['dept'] ?? 0);
$fs = (string) ($_GET['stage'] ?? '');
$open = (int) ($_GET['open'] ?? 0);
$depts = dept_list();
$allCat = year_catalog();
$stagesOn = enabled_stages();
$cat = array_filter($allCat, fn($c) => (!$fd || $c['dept'] === $fd) && (!$fs || $c['stage'] === $fs));
if ($open && isset($allCat[$open])) $cat = [$open => $allCat[$open]]; else $open = 0;
$canEdit = user_can('subjects.edit');
$pageTitle = 'Year Levels & Subjects';
$activeNav = 'years';
require __DIR__ . '/../includes/header.php';
$mk = fn(array $o = []) => url('admin/years.php') . ($o || $fd || $fs ? '?' . http_build_query(array_filter(array_merge(['dept' => $fd, 'stage' => $fs], $o), fn($v) => $v !== 0 && $v !== '')) : '');
?>
<?php if (!$open): ?>
<div class="card-panel">
  <div class="d-flex flex-wrap align-items-center gap-2 mb-2"><h6 class="mb-0">School levels</h6><span class="hint">Tick the levels your school has. Their grade cards are made for you.</span></div>
  <form method="post" class="d-flex flex-wrap gap-2 align-items-center"><?= csrf_field() ?><input type="hidden" name="action" value="set_levels">
    <?php foreach (SCHOOL_STAGES as $k => $st): ?>
      <input type="checkbox" class="btn-check" name="stages[]" id="stg_<?= e($k) ?>" value="<?= e($k) ?>" <?= in_array($k, $stagesOn, true) ? 'checked' : '' ?> <?= $canEdit ? '' : 'disabled' ?>>
      <label class="btn btn-outline-success" for="stg_<?= e($k) ?>"><i class="bi bi-<?= e($st['icon']) ?> me-1"></i><?= e($st['label']) ?> <small>(<?= e($st['range']) ?>)</small></label>
    <?php endforeach; ?>
    <?php if ($canEdit): ?><button class="btn btn-navy" data-loading="Saving..."><i class="bi bi-check2 me-1"></i>Save school levels</button><?php endif; ?></form>
  <div class="form-text" data-info>Elementary (Grade 1-6) and Junior High (Grade 7-10) have no semester. Senior High (Grade 11-12) and College have First and Second semester. Elementary, Junior High and Senior High get their department and all grade cards automatically; for College, add a department then its year levels.</div>
</div>
<div class="card-panel">
  <form class="filter-bar" method="get">
    <div><label class="form-label">Level</label><select class="form-select" name="stage" onchange="this.form.submit()"><option value="">All levels</option><?php foreach ($stagesOn as $k): ?><option value="<?= e($k) ?>" <?= $fs === $k ? 'selected' : '' ?>><?= e(SCHOOL_STAGES[$k]['label']) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label">Department</label><select class="form-select" name="dept" onchange="this.form.submit()"><?= options_html($depts, 'id', 'code', $fd, 'All departments') ?></select></div>
    <span class="hint"><?= count($cat) ?> card(s)</span>
    <div class="ms-auto d-flex gap-2">
      <button class="btn btn-light" type="button" data-bs-toggle="modal" data-bs-target="#lookupModal"><i class="bi bi-search me-1"></i>Find subjects &amp; sections</button>
      <?php if ($canEdit): ?><button class="btn btn-navy" type="button" data-bs-toggle="modal" data-bs-target="#yearModal"><i class="bi bi-plus-lg me-1"></i>Add year level</button><?php endif; ?></div>
  </form>
</div>
<?php if (!$cat): ?><div class="card-panel"><?= empty_state('mortarboard', 'No year levels yet', 'Tick your school levels above, or click Add year level: choose a department and a year, then add the subjects and sections.') ?></div><?php endif; ?>
<?php foreach (SCHOOL_STAGES as $sk => $st): $grp = array_filter($cat, fn($c) => $c['stage'] === $sk); if (!$grp) continue; ?>
<div class="d-flex align-items-center gap-2 mt-3 mb-2"><i class="bi bi-<?= e($st['icon']) ?>"></i><h6 class="mb-0"><?= e($st['label']) ?></h6><span class="hint"><?= e($st['range']) ?><?= $st['sem'] ? ' &middot; with semesters' : ' &middot; no semester' ?></span></div>
<div class="row g-3 year-grid">
<?php foreach ($grp as $c): $nSub = 0; $nSec = 0; $nStu = 0; foreach ($c['subjects'] as $l) $nSub += count($l); foreach ($c['sections'] as $l) { $nSec += count($l); foreach ($l as $x) $nStu += $x['students']; } ?>
  <div class="col-sm-6 col-lg-4 col-xl-3"><div class="card-panel year-tile h-100 mb-0">
    <div class="d-flex align-items-center gap-2 mb-2"><span class="room-ico"><i class="bi bi-<?= e($st['icon']) ?>"></i></span><div><b><?= e($c['label']) ?></b><div class="hint"><?= e($c['dept_code']) ?></div></div></div>
    <div class="d-flex flex-wrap gap-1 mb-3"><span class="badge-s b-blue"><?= $nSub ?> subject<?= $nSub === 1 ? '' : 's' ?></span><span class="badge-s <?= $nSec ? 'b-green' : 'b-gray' ?>"><?= $nSec ?> section<?= $nSec === 1 ? '' : 's' ?></span><span class="badge-s b-gray"><?= $nStu ?> students</span></div>
    <a class="btn btn-navy btn-sm w-100" href="<?= e($mk(['open' => $c['id']])) ?>"><i class="bi bi-box-arrow-in-right me-1"></i>Open</a></div></div>
<?php endforeach; ?>
</div>
<?php endforeach; ?>
<?php else: ?>
<div class="mb-3"><a class="btn btn-light" href="<?= e($mk()) ?>"><i class="bi bi-arrow-left me-1"></i>Back to all year levels</a></div>
<?php endif; ?>
<?php if ($open): foreach ($cat as $c): $semsOf = sem_list($c['year']); ?>
<div class="card-panel year-card fade-up">
  <div class="d-flex flex-wrap align-items-center gap-2 mb-3">
    <span class="room-ico"><i class="bi bi-<?= e(SCHOOL_STAGES[$c['stage']]['icon']) ?>"></i></span>
    <div><h5 class="mb-0"><?= e($c['label']) ?> &middot; <?= e($c['dept_code']) ?></h5><div class="hint"><?= e($c['dept_name']) ?> &middot; <?= e(SCHOOL_STAGES[$c['stage']]['label']) ?><?= $c['has_sem'] ? '' : ' (no semester)' ?></div></div>
    <?php if ($canEdit): ?><form method="post" class="ms-auto"><?= csrf_field() ?><input type="hidden" name="action" value="del_year"><input type="hidden" name="id" value="<?= $c['id'] ?>"><button class="btn btn-sm btn-outline-danger" data-confirm="Delete <?= e($c['label'] . ' ' . $c['dept_code']) ?>?"><i class="bi bi-trash me-1"></i>Delete</button></form><?php endif; ?>
  </div>
  <div class="row g-3">
  <?php foreach ($semsOf as $sn => $sl): $list = $c['subjects'][$sn]; ?>
    <div class="<?= $c['has_sem'] ? 'col-lg-6' : 'col-12' ?>"><div class="sem-box">
      <div class="d-flex align-items-center mb-2"><b><?= e($sl) ?></b><span class="badge-s <?= $list ? 'b-green' : 'b-gray' ?> ms-2"><?= count($list) ?> subject<?= count($list) === 1 ? '' : 's' ?></span></div>
      <?php if (!$list): ?><div class="hint mb-2">No subjects yet.</div><?php endif; ?>
      <?php foreach ($list as $i => $s): ?>
        <div class="subj-item"><span class="num"><?= $i + 1 ?></span>
          <?php if ($canEdit): ?>
          <form method="post" class="d-flex flex-fill gap-1"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $s['id'] ?>">
            <input class="form-control form-control-sm" name="name" value="<?= e($s['name']) ?>" maxlength="150" required>
            <button class="btn btn-sm btn-light" name="action" value="edit_subject" title="Save name"><i class="bi bi-check2"></i></button>
            <button class="btn btn-sm btn-outline-danger" name="action" value="del_subject" title="Remove" data-confirm="Remove <?= e($s['name']) ?>?"><i class="bi bi-x-lg"></i></button></form>
          <?php else: ?><span><?= e($s['name']) ?></span><?php endif; ?></div>
      <?php endforeach; ?>
      <?php if ($canEdit): ?>
      <form method="post" class="mt-2"><?= csrf_field() ?><input type="hidden" name="action" value="add_subject"><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="semester" value="<?= $sn ?>">
        <div class="input-group input-group-sm"><textarea class="form-control" name="names" rows="1" placeholder="Subject name (one per line to add several)" required></textarea><button class="btn btn-navy"><i class="bi bi-plus-lg"></i> Add</button></div></form>
      <?php endif; ?>
      <?php $plan = year_plan((int) $c['dept'], (int) $c['year'], $sn); $secs = $c['sections'][$sn]; ?>
      <hr class="my-3">
      <div class="d-flex align-items-center mb-2"><b>Sections</b><span class="badge-s <?= $secs ? 'b-green' : 'b-gray' ?> ms-2"><?= count($secs) ?> section<?= count($secs) === 1 ? '' : 's' ?></span>
        <?php if ($plan['slots']): ?><span class="hint ms-auto"><?= $plan['scheduled'] ?> of <?= $plan['slots'] ?> exams scheduled</span><?php endif; ?></div>
      <?php if (!$secs): ?><div class="hint mb-2">No sections yet. Add the sections of this semester.</div><?php endif; ?>
      <?php $byId = array_column($plan['sections'], null, 'id'); foreach ($secs as $i => $s): $sch = (int) ($byId[$s['id']]['scheduled'] ?? 0); ?>
        <div class="subj-item"><span class="num"><i class="bi bi-people" style="font-size:.7rem"></i></span>
          <?php if ($canEdit): ?>
          <form method="post" class="d-flex flex-fill gap-1 align-items-center"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $s['id'] ?>">
            <input class="form-control form-control-sm" name="name" value="<?= e($s['name']) ?>" maxlength="60" required style="min-width:90px">
            <input class="form-control form-control-sm" style="width:80px" type="number" min="1" name="students" value="<?= $s['students'] ?>" title="Number of students" required>
            <span class="hint text-nowrap" title="Subjects already scheduled"><?= $sch ?>/<?= count($c['subjects'][$sn]) ?></span>
            <button class="btn btn-sm btn-light" name="action" value="edit_section" title="Save section"><i class="bi bi-check2"></i></button>
            <button class="btn btn-sm btn-outline-danger" name="action" value="del_section" title="Delete section" data-confirm="Delete section <?= e($s['name']) ?>?"><i class="bi bi-x-lg"></i></button></form>
          <?php else: ?><span class="flex-fill"><?= e($s['name']) ?> &middot; <?= $s['students'] ?> students</span><?php endif; ?></div>
      <?php endforeach; ?>
      <?php if ($canEdit): ?>
      <form method="post" class="mt-2"><?= csrf_field() ?><input type="hidden" name="action" value="add_section"><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="semester" value="<?= $sn ?>">
        <div class="input-group input-group-sm"><input class="form-control" name="name" maxlength="60" placeholder="Section (e.g. BSCS 4A)" required><input class="form-control" style="max-width:110px" type="number" min="1" name="students" placeholder="Students" required><button class="btn btn-navy"><i class="bi bi-plus-lg"></i> Add</button></div></form>
      <?php endif; ?>
    </div></div>
  <?php endforeach; ?>
  </div>
</div>
<?php endforeach; endif; ?>

<?php if ($canEdit): ?>
<div class="modal fade" id="yearModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="add_year">
  <div class="modal-header"><h5 class="modal-title">Add year level</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body"><div class="row g-3">
    <div class="col-md-7"><label class="form-label">Department *</label><select class="form-select" name="department_id" required><?= options_html($depts, 'id', fn($d) => $d['code'] . ' – ' . $d['name'], null, 'Select department') ?></select>
      <div class="form-text" data-info>Only departments from the Departments module are listed. Each department can have each year level once.</div></div>
    <div class="col-md-5"><label class="form-label">Year level *</label><select class="form-select" name="year_level" required><option value="">Select year</option><?php foreach ($stagesOn as $sk): ?><optgroup label="<?= e(SCHOOL_STAGES[$sk]['label']) ?>"><option value="all_<?= e($sk) ?>">All <?= e(SCHOOL_STAGES[$sk]['range']) ?></option><?php foreach (SCHOOL_STAGES[$sk]['levels'] as $k): ?><option value="<?= $k ?>"><?= e(YEAR_LEVELS[$k]) ?></option><?php endforeach; ?></optgroup><?php endforeach; ?></select></div>
  </div></div>
  <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-navy" data-loading="Saving...">Add</button></div></form></div></div></div>
<?php endif; ?>
<div class="modal fade" id="lookupModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content">
  <div class="modal-header"><h5 class="modal-title">Find subjects &amp; sections</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body"><div class="row g-2 mb-3">
    <div class="col-md-5"><select class="form-select" id="lkDept"><option value="">Department</option><?= options_html($depts, 'id', 'code') ?></select></div>
    <div class="col-md-4"><select class="form-select" id="lkYear"><option value="">Year level</option><?php foreach (year_level_options() as $k => $v): ?><option value="<?= $k ?>"><?= e($v) ?></option><?php endforeach; ?></select></div>
    <div class="col-md-3" id="lkSemWrap"><select class="form-select" id="lkSem"><?php foreach (SEMESTERS as $k => $v): ?><option value="<?= $k ?>"><?= e($v) ?></option><?php endforeach; ?></select></div></div>
    <div class="form-text" data-info>Pick a department, year level and semester to see its registered subjects and sections. The scheduler, the Add section form and the Exam Schedule use this same list.</div><div id="lkOut" class="hint mt-2">Choose a department and a year level.</div></div></div></div></div>
<script>
(function(){
var CAT=<?= json_encode(array_values(year_catalog())) ?>;
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function go(){var d=+document.getElementById('lkDept').value,y=+document.getElementById('lkYear').value,o=document.getElementById('lkOut');
 var c0=CAT.filter(function(x){return x.year===y;})[0],hs=!c0||c0.has_sem;document.getElementById('lkSemWrap').style.display=hs?'':'none';var s=hs?+document.getElementById('lkSem').value:0;
 if(!d||!y){o.className='hint';o.textContent='Choose a department and a year level.';return;}
 var c=CAT.filter(function(x){return x.dept===d&&x.year===y;})[0];
 if(!c){o.className='text-danger';o.textContent='That year level is not registered for this department yet.';return;}
 var l=c.subjects[s]||[];o.className='';
 var sc=c.sections[s]||[];
 o.innerHTML='<div class="mb-2"><b>'+l.length+' subject'+(l.length===1?'':'s')+'</b></div>'+(l.length?'<ol>'+l.map(function(x){return '<li>'+esc(x.name)+'</li>';}).join('')+'</ol>':'<div class="hint">No subjects registered.</div>')
 +'<div class="mb-2 mt-2"><b>'+sc.length+' section'+(sc.length===1?'':'s')+'</b></div>'+(sc.length?'<ul class="mb-0">'+sc.map(function(x){return '<li>'+esc(x.name)+' &middot; '+x.students+' students</li>';}).join('')+'</ul>':'<div class="hint">No sections registered.</div>');}
['lkDept','lkYear','lkSem'].forEach(function(i){document.getElementById(i).addEventListener('change',go);});
})();
</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
