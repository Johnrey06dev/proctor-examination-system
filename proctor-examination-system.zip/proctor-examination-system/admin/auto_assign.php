<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_perm('autoassign.view');
$pdo = db();
$depts = dept_list();
$today = date('Y-m-d');

$deptId = (int) ($_REQUEST['dept'] ?? 0);
$from = valid_date((string) ($_REQUEST['from'] ?? '')) ? $_REQUEST['from'] : $today;
$to = valid_date((string) ($_REQUEST['to'] ?? '')) ? $_REQUEST['to'] : '';
$mode = ($_REQUEST['mode'] ?? 'fill') === 'replan' ? 'replan' : 'fill';
$S = get_settings();
$gap = isset($_REQUEST['gap']) && $_REQUEST['gap'] !== '' ? max(0, min(180, (int) $_REQUEST['gap'])) : (int) $S['min_gap_minutes'];
$perDay = isset($_REQUEST['perday']) && $_REQUEST['perday'] !== '' ? max(1, min(10, (int) $_REQUEST['perday'])) : (int) $S['max_exams_per_day'];
$yopts = year_level_options();
$year = isset($yopts[(int) ($_REQUEST['year'] ?? 0)]) ? (int) $_REQUEST['year'] : (int) array_key_first($yopts);   // one year level at a time
$sem = level_has_sem($year) ? (in_array((int) ($_REQUEST['sem'] ?? 0), [1, 2], true) ? (int) $_REQUEST['sem'] : 1) : 0;   // Grade 1-10 have no semester
$semName = $sem ? SEMESTERS[$sem] : 'no semester';
$auto = !empty($_REQUEST['auto_accept']);
$override = ['min_gap_minutes' => (string) $gap, 'max_exams_per_day' => (string) $perDay];
$qs = http_build_query(['dept' => $deptId, 'from' => $from, 'to' => $to, 'mode' => $mode, 'gap' => $gap, 'perday' => $perDay, 'sem' => $sem, 'year' => $year, 'auto_accept' => $auto ? 1 : 0]);

$preview = null;
if (is_post() && require_post_csrf()) {
    $act = input_str('action', 12);
    if (in_array($act, ['apply', 'clear'], true) && !user_can('autoassign.apply')) deny_access($user);
    $sched = (new ProctorScheduler($pdo, $override))->setAutoAccept($auto);
    try {
        if ($act === 'clear') {
            $n = $sched->clearUnanswered($user['id'], $from, $to ?: null, $deptId ?: null, $sem ?: null, $year);
            flash($n ? 'success' : 'info', $n . ' unanswered assignment(s) removed.');
            redirect('admin/auto_assign.php?' . $qs);
        }
        if ($act === 'preview' || $act === 'apply') {
            $before = $sched->workloadMap();
            $pdo->beginTransaction();                      // preview = run everything, then ROLL BACK
            try {
                $cleared = $mode === 'replan' ? $sched->clearUnanswered($user['id'], $from, $to ?: null, $deptId ?: null, $sem ?: null, $year) : 0;
                $results = $sched->generateAll($user['id'], $from, $to ?: null, $deptId ?: null, $sem ?: null, $year);
                $after = $sched->workloadMap();
                if ($act === 'apply') { $pdo->commit(); } else { $pdo->rollBack(); }
            } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
            if ($act === 'apply') {
                $tot = array_sum(array_column($results, 'assigned'));
                flash($tot ? 'success' : 'warning', $tot . ' proctor(s) assigned (' . (YEAR_LEVELS[$year] ?? '') . ', ' . $semName . '). ' . ($auto ? 'They were accepted automatically, so each subject now has its paper record (Pending).' : 'They are notified and must accept (or decline).'));
                foreach ($results as $r) foreach ($r['warnings'] as $w) flash('warning', $w);
                redirect('admin/auto_assign.php?' . $qs);
            }
            $preview = compact('results', 'before', 'after', 'cleared');
        }
    } catch (Throwable $e) { flash('danger', 'Auto-assign failed: ' . (APP_DEBUG ? $e->getMessage() : 'unexpected error.')); }
}

// 2. who is free for each exam
$sched = new ProctorScheduler($pdo, $override);
$sql = "SELECT e.id, e.exam_code, e.name, e.exam_date, e.start_time, e.end_time, e.required_proctors, r.name AS room, s.code AS subject
        FROM examinations e JOIN rooms r ON r.id = e.room_id JOIN subjects s ON s.id = e.subject_id
        WHERE e.status = 'Scheduled' AND e.exam_date >= ?";
$par = [$from];
if ($to) { $sql .= ' AND e.exam_date <= ?'; $par[] = $to; }
if ($deptId) { $sql .= ' AND e.department_id = ?'; $par[] = $deptId; }
if ($sem) { $sql .= ' AND e.id IN (SELECT x.examination_id FROM exam_sections x JOIN class_sections c ON c.id = x.section_id WHERE c.semester = ?)'; $par[] = $sem; }
$sql .= ' AND e.id IN (SELECT x.examination_id FROM exam_sections x JOIN class_sections c ON c.id = x.section_id JOIN year_configs y ON y.id = c.year_config_id WHERE y.year_level = ?)'; $par[] = $year;
$exams = fetch_all($sql . ' ORDER BY e.exam_date, e.start_time LIMIT 60', $par);
$cover = [];
$needTotal = 0; $okExams = 0;
foreach ($exams as $x) {
    $ev = $sched->evaluate((int) $x['id']);
    $reasons = [];
    foreach ($ev['excluded'] as $ex) foreach ($ex['reasons'] as $rs) { $k = preg_replace('/^H\d [^:]+: /', '', $rs); $reasons[$k] = ($reasons[$k] ?? 0) + 1; }
    arsort($reasons);
    $cover[] = ['x' => $x, 'needed' => $ev['needed'], 'free' => $ev['eligible'], 'reasons' => array_slice($reasons, 0, 3, true)];
    $needTotal += $ev['needed']; if ($ev['needed'] === 0 || count($ev['eligible']) >= $ev['needed']) $okExams++;
}
$rank = $sched->workloadRanking();
$maxLoad = max(1, ...array_map(fn($r) => (int) $r['workload'], $rank) ?: [1]);

$pageTitle = 'Auto-Assign';
$activeNav = 'autoassign';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex justify-content-end mb-2"><a class="btn btn-outline-success btn-sm" href="<?= e(url('admin/auto_schedule.php')) ?>"><i class="bi bi-calendar-plus me-1"></i>Auto-Schedule (create the exams first)</a></div>
<div class="alert alert-info fade-up" data-info><b>How pairing works.</b> Every proctor who is free on that day and time (any department) is looked at for each subject exam. The hardest-to-staff subjects are filled first, and the proctor with the fewest assigned subjects, then the fewest exam hours, is chosen. Nobody is given an overlapping exam or one outside the availability they set. A subject with no free proctor is listed with the reason, never forced.</div>

<div class="card-panel fade-up"><h5 class="serif">1. Choose what to auto-assign</h5>
<form method="post" class="row g-3"><?= csrf_field() ?>
  <div class="col-md-3"><label class="form-label small">Department</label><select class="form-select" name="dept"><option value="0">All departments</option><?= options_html($depts, 'id', fn($d) => $d['code'] . ' – ' . $d['name'], $deptId) ?></select></div>
  <div class="col-md-3"><label class="form-label small">Year level</label><select class="form-select" name="year"><?php foreach (year_level_options() as $k => $v): ?><option value="<?= (int) $k ?>" data-sem="<?= level_has_sem((int) $k) ? 1 : 0 ?>" <?= $year === (int) $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select><div class="form-text" data-info>Auto-Assign works on one year level at a time (with the semester chosen below), so the work stays small and clear. Run it again for the next year level.</div></div>
  <div class="col-md-3"><label class="form-label small">From date</label><input type="date" class="form-control" name="from" value="<?= e($from) ?>"></div>
  <div class="col-md-3"><label class="form-label small">To date (optional)</label><input type="date" class="form-control" name="to" value="<?= e($to) ?>"></div>
  <div class="col-md-3"><label class="form-label small">Gap between a teacher's exams (min)</label><input type="number" min="0" max="180" step="5" class="form-control" name="gap" value="<?= (int) $gap ?>"></div>
  <div class="col-md-3"><label class="form-label small">Max exams per teacher per day</label><input type="number" min="1" max="10" class="form-control" name="perday" value="<?= (int) $perDay ?>"></div>
  <div class="col-12" id="semBox" <?= level_has_sem($year) ? '' : 'style="display:none"' ?>><label class="form-label small d-block">Semester</label>
    <div class="btn-group" role="group" aria-label="Semester">
      <input type="radio" class="btn-check" name="sem" id="sem1" value="1" <?= $sem === 1 ? 'checked' : '' ?>><label class="btn btn-outline-success" for="sem1">First Semester</label>
      <input type="radio" class="btn-check" name="sem" id="sem2" value="2" <?= $sem === 2 ? 'checked' : '' ?>><label class="btn btn-outline-success" for="sem2">Second Semester</label></div>
    <div class="form-text" data-info>Only the exams of the chosen semester's sections are auto-assigned, so First and Second semester subjects never get mixed. "All" includes every exam, even old ones without a registered section.</div></div>
  <div class="col-12"><label class="form-label small d-block">Existing assignments</label>
    <label class="d-block"><input type="radio" name="mode" value="fill" <?= $mode === 'fill' ? 'checked' : '' ?>> <b>Fill empty slots only</b> (recommended) &ndash; keeps every assignment, only missing proctors are added.</label>
    <label class="d-block"><input type="radio" name="mode" value="replan" <?= $mode === 'replan' ? 'checked' : '' ?>> <b>Re-plan the ones nobody confirmed</b> &ndash; accepted exams stay, proposals still waiting are planned again.</label></div>
  <div class="col-12"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" id="autoAcc" name="auto_accept" value="1" <?= $auto ? 'checked' : '' ?>><label class="form-check-label" for="autoAcc">Auto-accept</label><div class="form-text" data-info>Optional. When on, the proctors picked by Auto-Assign are accepted right away, so you do not wait for each proctor to answer. The paper records (students + 5 extra copies) are created at once. Leave it off to let proctors accept or decline themselves.</div></div></div>
  <div class="col-12 d-flex gap-2"><button class="btn btn-navy" name="action" value="preview" data-loading="Calculating..."><i class="bi bi-eye me-1"></i>Preview auto-assign</button>
    <button class="btn btn-outline-danger" name="action" value="clear" data-confirm="Remove all proposals that nobody answered yet in this range?"><i class="bi bi-eraser me-1"></i>Remove all unanswered assignments</button></div>
</form></div>

<div class="card-panel fade-up"><h5 class="serif">2. Who is free for each exam?</h5>
  <p class="small text-muted" data-info>This is what Auto-assign picks from.</p>
  <div class="row g-2 mb-3"><div class="col-6 col-md-3"><div class="stat-card"><div><div class="stat-value"><?= count($cover) ?></div><div class="stat-label">Upcoming exams</div></div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><div><div class="stat-value"><?= $needTotal ?></div><div class="stat-label">Proctors still needed</div></div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card ok"><div><div class="stat-value"><?= $okExams ?></div><div class="stat-label">Can be fully staffed</div></div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card <?= count($cover) - $okExams ? 'danger' : 'ok' ?>"><div><div class="stat-value"><?= count($cover) - $okExams ?></div><div class="stat-label">Not enough free teachers</div></div></div></div></div>
  <?php if (!$cover): ?><?= empty_state('calendar-x', 'No upcoming exams in this range') ?><?php else: ?>
  <div class="table-responsive"><table class="table table-modern align-middle"><thead><tr><th>Date &amp; time</th><th>Room</th><th>Exam</th><th class="text-center">Needs</th><th>Free teachers</th></tr></thead><tbody>
  <?php foreach ($cover as $c): $x = $c['x']; ?><tr>
    <td><?= e(fmt_date($x['exam_date'])) ?><div class="small text-muted"><?= e(time_range($x['start_time'], $x['end_time'])) ?></div></td><td><?= e($x['room']) ?></td>
    <td><strong><?= e($x['exam_code']) ?></strong> <span class="text-muted small"><?= e($x['subject']) ?></span></td>
    <td class="text-center"><span class="badge bg-<?= $c['needed'] ? 'warning text-dark' : 'success' ?>"><?= (int) $c['needed'] ?></span></td>
    <td><?php if ($c['needed'] === 0): ?><span class="text-success small">Fully staffed</span><?php else: ?>
      <span class="badge bg-<?= count($c['free']) >= $c['needed'] ? 'success' : 'danger' ?>"><?= count($c['free']) ?> free</span>
      <span class="small"><?= e(implode(', ', array_map(fn($f) => $f['name'], array_slice($c['free'], 0, 5)))) ?><?= count($c['free']) > 5 ? '…' : '' ?></span>
      <?php if (count($c['free']) < $c['needed'] && $c['reasons']): ?><div class="small text-muted">Why others are not free: <?= e(implode('; ', array_map(fn($k, $v) => $k . ' (' . $v . ')', array_keys($c['reasons']), $c['reasons']))) ?></div><?php endif; ?><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</div>

<?php if ($preview):
  $tot = array_sum(array_column($preview['results'], 'assigned'));
  $label = []; // subject + section of every exam in the preview
  foreach ($preview['results'] as $r_) {
      $xid = (int) $r_['exam']['id'];
      $label[$xid] = fetch_one('SELECT b.name AS subject, x.section_name AS section FROM examinations e JOIN subjects b ON b.id = e.subject_id LEFT JOIN exam_sections x ON x.examination_id = e.id WHERE e.id = ?', [$xid]) ?: ['subject' => '', 'section' => ''];
  }
  $teachers = $sched->allTeachers();
  $slotsOf = []; $newOf = [];
  foreach ($preview['results'] as $r_) {
      foreach ($r_['eligible'] as $e_) $slotsOf[(int) $e_['teacher_id']] = ($slotsOf[(int) $e_['teacher_id']] ?? 0) + 1;
      foreach ($r_['selected'] as $s_) $newOf[(int) $s_['teacher_id']] = ($newOf[(int) $s_['teacher_id']] ?? 0) + 1;
  }
  $short = array_filter($preview['results'], fn($r_) => $r_['assigned'] < $r_['needed']);
?>
<div class="card-panel border-start border-4 border-warning fade-up"><h5 class="serif">3. Pairing preview &ndash; nothing is saved yet</h5>
  <?php if ($auto): ?><div class="alert alert-success py-2 small">Auto-accept is ON: these proctors will be confirmed right away and each subject gets its paper record.</div><?php endif; ?>
  <p><b><?= $tot ?></b> proctor(s) would be paired across <b><?= count($preview['results']) ?></b> subject exam(s)<?= $preview['cleared'] ? ', after clearing ' . (int) $preview['cleared'] . ' unanswered proposal(s)' : '' ?>. <?= $short ? '<b class="text-danger">' . count($short) . ' could not be assigned.</b>' : 'Every subject has a proctor.' ?></p>
  <div class="table-responsive"><table class="table table-modern align-middle"><thead><tr><th>Date &amp; time</th><th>Subject &amp; section</th><th>Assigned proctor</th><th>Proctor dept</th><th>Proctor available</th><th class="text-center">Subjects</th><th class="text-center">Exam hours</th></tr></thead><tbody>
  <?php foreach ($preview['results'] as $r): $ex = $r['exam']; $lb = $label[(int) $ex['id']]; $sel = $r['selected']; ?>
    <?php if (!$sel): ?><tr><td><?= e(fmt_date($ex['exam_date'])) ?><div class="small text-muted"><?= e(time_range($ex['start_time'], $ex['end_time'])) ?></div></td><td><b><?= e($lb['subject']) ?></b><div class="small text-muted"><?= e($lb['section']) ?> &middot; <?= e($ex['exam_code']) ?></div></td><td colspan="5"><?= $r['needed'] > 0 ? '<span class="badge bg-danger">Not assigned</span>' : '<span class="badge bg-success">Already staffed</span>' ?></td></tr><?php endif; ?>
    <?php foreach ($sel as $s): $tid = (int) $s['teacher_id']; ?><tr>
      <td><?= e(fmt_date($ex['exam_date'])) ?><div class="small text-muted"><?= e(time_range($ex['start_time'], $ex['end_time'])) ?></div></td>
      <td><b><?= e($lb['subject']) ?></b><div class="small text-muted"><?= e($lb['section']) ?> &middot; <?= e($ex['exam_code']) ?></div></td>
      <td><b><?= e($s['name']) ?></b> <span class="small text-muted"><?= e($s['teacher_no']) ?></span></td><td><?= e($s['dept_code']) ?></td>
      <td class="small"><?= e($sched->availabilityText($tid, $ex['exam_date'])) ?></td>
      <td class="text-center"><?= (int) ($preview['after'][$tid]['total'] ?? 0) ?></td><td class="text-center"><?= e(rtrim(rtrim(number_format((float) ($preview['after'][$tid]['hours'] ?? 0), 2), '0'), '.')) ?> h</td></tr><?php endforeach; ?>
  <?php endforeach; ?></tbody></table></div>

  <?php if ($short): ?><h6 class="mt-3 text-danger">Subjects that could not be assigned</h6>
  <div class="table-responsive"><table class="table table-sm"><thead><tr><th>Subject &amp; section</th><th>Date &amp; time</th><th>Why</th></tr></thead><tbody>
  <?php foreach ($short as $r): $ex = $r['exam']; $lb = $label[(int) $ex['id']]; $why = [];
      foreach ($r['excluded'] as $x_) foreach ($x_['reasons'] as $rs) { $k = preg_replace('/^H\d [^:]+: /', '', $rs); $why[$k] = ($why[$k] ?? 0) + 1; }
      arsort($why); ?><tr><td><b><?= e($lb['subject']) ?></b> <span class="small text-muted"><?= e($lb['section']) ?></span></td><td><?= e(fmt_date($ex['exam_date'])) ?> <span class="small text-muted"><?= e(time_range($ex['start_time'], $ex['end_time'])) ?></span></td>
      <td class="small"><?= count($r['eligible']) ?> free proctor(s) for <?= (int) $r['needed'] ?> needed. <?= $why ? 'Others are not free because: ' . e(implode('; ', array_map(fn($k, $v) => $k . ' (' . $v . ')', array_slice(array_keys($why), 0, 4), array_slice($why, 0, 4)))) : '' ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>

  <h6 class="mt-3">Workload summary of all proctors</h6>
  <div class="table-responsive"><table class="table table-sm align-middle"><thead><tr><th>Proctor</th><th>Dept</th><th class="text-center">Free for N slots</th><th class="text-center">Before (subjects / hours)</th><th class="text-center">New</th><th class="text-center">After (subjects / hours)</th><th></th></tr></thead><tbody>
  <?php $fmtH = fn($h) => rtrim(rtrim(number_format((float) $h, 2), '0'), '.') ?: '0';
  foreach ($teachers as $t): $tid = (int) $t['id']; $b = $preview['before'][$tid] ?? ['total' => 0, 'hours' => 0]; $a = $preview['after'][$tid] ?? ['total' => 0, 'hours' => 0]; $n = $newOf[$tid] ?? 0; $sl = $slotsOf[$tid] ?? 0; $off = $t['account_status'] !== 'active' || $t['availability_status'] !== 'Available'; ?><tr class="<?= $off ? 'text-muted' : '' ?>">
    <td><?= e($t['full_name']) ?> <span class="small text-muted"><?= e($t['teacher_no']) ?></span></td><td><?= e($t['dept_code']) ?></td><td class="text-center"><?= $sl ?></td>
    <td class="text-center"><?= (int) $b['total'] ?> / <?= $fmtH($b['hours']) ?> h</td><td class="text-center"><?= $n ? '<span class="text-success fw-bold">+' . $n . '</span>' : '0' ?></td><td class="text-center"><?= (int) $a['total'] ?> / <?= $fmtH($a['hours']) ?> h</td>
    <td class="small"><?= $off ? 'Not available (account or status)' : ($n ? '' : ($sl ? '<span class="text-warning">Free for ' . $sl . ' slot(s) but not needed: other proctors had fewer subjects/hours</span>' : 'No free slot in this range')) ?></td></tr><?php endforeach; ?></tbody></table></div>

  <form method="post" class="d-flex gap-2"><?= csrf_field() ?><?php foreach (['dept' => $deptId, 'from' => $from, 'to' => $to, 'mode' => $mode, 'gap' => $gap, 'perday' => $perDay, 'sem' => $sem, 'year' => $year, 'auto_accept' => $auto ? 1 : 0] as $k => $v): ?><input type="hidden" name="<?= e($k) ?>" value="<?= e($v) ?>"><?php endforeach; ?>
    <button class="btn btn-navy btn-lg" name="action" value="apply" data-loading="Saving..." <?= $tot ? '' : 'disabled' ?>><i class="bi bi-check2-circle me-1"></i>Apply these assignments</button><a class="btn btn-light btn-lg" href="<?= e(url('admin/auto_assign.php?' . $qs)) ?>">Discard preview</a></form>
</div><?php endif; ?>

<div class="card-panel fade-up"><h5 class="serif">Current workload</h5><p class="small text-muted" data-info>A smaller gap between lowest and highest means a fairer split.</p>
<div class="table-responsive"><table class="table table-modern align-middle"><thead><tr><th>Teacher</th><th>Subjects</th><th>Exam hours</th><th>Upcoming</th><th>Waiting for answer</th><th style="width:30%">Load</th></tr></thead><tbody>
<?php foreach ($rank as $t): ?><tr><td><?= e($t['full_name']) ?> <span class="small text-muted"><?= e($t['teacher_no']) ?></span></td><td><?= (int) $t['workload'] ?></td><td><?= e($t['hours']) ?> h</td><td><?= (int) $t['upcoming'] ?></td><td><?= (int) $t['new_assignments'] ?></td>
<td><div class="progress" style="height:8px"><div class="progress-bar" style="width:<?= round($t['workload'] / $maxLoad * 100) ?>%"></div></div></td></tr><?php endforeach; ?></tbody></table></div></div>
<script>
(function(){var y=document.querySelector('select[name=year]'),b=document.getElementById('semBox');if(!y||!b)return;
function t(){var o=y.options[y.selectedIndex];var on=o&&o.dataset.sem==='1';b.style.display=on?'':'none';b.querySelectorAll('input').forEach(function(i){i.disabled=!on;});}
y.addEventListener('change',t);t();})();
</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
