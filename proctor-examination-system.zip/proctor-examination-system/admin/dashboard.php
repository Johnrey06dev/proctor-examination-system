<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('staff');
$today = date('Y-m-d');

$stat = [
    'teachers'    => (int) fetch_value('SELECT COUNT(*) FROM teachers'),
    'departments' => (int) fetch_value('SELECT COUNT(*) FROM departments'),
    'exams'       => (int) fetch_value('SELECT COUNT(*) FROM examinations'),
    'assigned'    => (int) fetch_value("SELECT COUNT(*) FROM proctor_assignments WHERE status <> 'Cancelled'"),
    'unassigned'  => (int) fetch_value("SELECT COUNT(*) FROM examinations e WHERE e.status = 'Scheduled'
                       AND (SELECT COUNT(*) FROM proctor_assignments a WHERE a.examination_id = e.id AND a.status <> 'Cancelled') < e.required_proctors"),
    'upcoming'    => (int) fetch_value("SELECT COUNT(*) FROM examinations WHERE status = 'Scheduled' AND exam_date >= ?", [$today]),
    'pend_release'=> (int) fetch_value("SELECT COUNT(*) FROM paper_distribution WHERE status IN ('Pending','Preparing','Ready for Release')"),
    'pend_return' => (int) fetch_value("SELECT COUNT(*) FROM paper_distribution WHERE status IN ('Released','Received')"),
    'completed'   => (int) fetch_value("SELECT COUNT(*) FROM examinations WHERE status = 'Completed'"),
];

$upcoming = fetch_all("SELECT e.id, e.exam_code, e.name, e.exam_date, e.start_time, e.end_time, e.required_proctors, r.name AS room_name, s.code AS subject_code,
        (SELECT COUNT(*) FROM proctor_assignments a WHERE a.examination_id = e.id AND a.status <> 'Cancelled') AS assigned_count
    FROM examinations e JOIN rooms r ON r.id = e.room_id JOIN subjects s ON s.id = e.subject_id
    WHERE e.status = 'Scheduled' AND e.exam_date >= ? ORDER BY e.exam_date, e.start_time LIMIT 8", [$today]);

$activities = fetch_all('SELECT l.*, u.full_name FROM activity_logs l LEFT JOIN users u ON u.id = l.user_id ORDER BY l.id DESC LIMIT 8');

// teacher workload chart (load balancing view)
$scheduler = new ProctorScheduler(db());
$rank = $scheduler->workloadRanking();
usort($rank, fn($a, $b) => strcmp($a['teacher_no'], $b['teacher_no']));
$chartLabels = array_map(fn($r) => $r['teacher_no'], $rank);
$chartData = array_map(fn($r) => (int) $r['workload'], $rank);

// paper tracking summary
$paperRows = fetch_all('SELECT status, COUNT(*) AS c FROM paper_distribution GROUP BY status');
$paperMap = array_column($paperRows, 'c', 'status');
$paperData = [];
foreach (PaperTracker::STATUSES as $s) { $paperData[] = (int) ($paperMap[$s] ?? 0); }

// schedule overview: examinations by status
$statusRows = fetch_all('SELECT status, COUNT(*) AS c FROM examinations GROUP BY status');
$statusMap = array_column($statusRows, 'c', 'status');

$pageTitle = 'Dashboard';
$activeNav = 'dashboard';
$useCharts = true;
require __DIR__ . '/../includes/header.php';

$cards = [
    ['people', 'Registered teachers', $stat['teachers'], '', 'teachers.php'],
    ['building', 'Departments', $stat['departments'], '', 'departments.php'],
    ['calendar-event', 'Total examinations', $stat['exams'], '', 'exams.php'],
    ['person-check', 'Assigned proctors', $stat['assigned'], 'ok', 'assignments.php'],
    ['exclamation-triangle', 'Unassigned schedules', $stat['unassigned'], $stat['unassigned'] ? 'danger' : 'ok', 'exams.php?staffing=unassigned'],
    ['alarm', 'Upcoming examinations', $stat['upcoming'], '', 'exams.php?status=Scheduled'],
    ['box-arrow-right', 'Pending paper releases', $stat['pend_release'], $stat['pend_release'] ? 'warn' : '', 'papers.php'],
    ['arrow-return-left', 'Pending paper returns', $stat['pend_return'], $stat['pend_return'] ? 'warn' : '', 'papers.php'],
    ['check2-circle', 'Completed examinations', $stat['completed'], 'ok', 'exams.php?status=Completed'],
];
$soon = fetch_all("SELECT e.id, e.exam_code, e.exam_date, e.required_proctors, (SELECT COUNT(*) FROM proctor_assignments a WHERE a.examination_id = e.id AND a.status <> 'Cancelled') AS c
    FROM examinations e WHERE e.status = 'Scheduled' AND e.exam_date BETWEEN ? AND ? ORDER BY e.exam_date", [$today, date('Y-m-d', strtotime('+3 days'))]);
$soonOpen = array_filter($soon, fn($x) => $x['c'] < $x['required_proctors']);
$declN = ProctorScheduler::pendingDeclines(db());
$pendN = (int) fetch_value("SELECT COUNT(*) FROM proctor_assignments WHERE status = 'Pending Review'");
$paperSoon = (int) fetch_value("SELECT COUNT(*) FROM examinations e LEFT JOIN paper_distribution p ON p.examination_id = e.id WHERE e.status='Scheduled' AND e.exam_date BETWEEN ? AND ? AND (p.id IS NULL OR p.status IN ('Preparing','Ready for Release'))", [$today, date('Y-m-d', strtotime('+2 days'))]);
$todayExams = fetch_all("SELECT e.exam_code, e.name, e.start_time, e.end_time, r.name AS room, r.building FROM examinations e JOIN rooms r ON r.id = e.room_id WHERE e.exam_date = ? AND e.status = 'Scheduled' ORDER BY e.start_time", [$today]);
$unavail = fetch_all("SELECT u.full_name FROM teachers t JOIN users u ON u.id = t.user_id WHERE t.availability_status = 'Unavailable' LIMIT 6");
$perDay = fetch_all("SELECT exam_date, COUNT(*) AS c FROM examinations WHERE status <> 'Cancelled' AND exam_date BETWEEN ? AND ? GROUP BY exam_date ORDER BY exam_date", [$today, date('Y-m-d', strtotime('+13 days'))]);
?>
<div class="hero fade-up"><div><div class="hero-eyebrow"><?= e(date('l')) ?></div><h2 class="serif"><?= e(greeting()) ?></h2><p class="mb-0"><?= e(date('l, F j, Y')) ?> &middot; <?= count($todayExams) ?> exam(s) today</p></div>
  <div class="hero-actions"><a class="btn btn-gold" href="<?= e(url('admin/assignments.php')) ?>"><i class="bi bi-lightning-charge-fill me-1"></i>Auto-assign</a><a class="btn btn-outline-light" href="<?= e(url('admin/exams.php')) ?>"><i class="bi bi-plus-lg me-1"></i>New exam</a></div></div>
<?php if ($soonOpen || $declN || $pendN || $paperSoon): ?><div class="row g-2 mb-3 fade-up">
  <?php if ($soonOpen): ?><div class="col-md-6 col-xl-3"><a class="alert-tile danger" href="<?= e(url('admin/assignments.php')) ?>"><i class="bi bi-exclamation-octagon"></i><span><b><?= count($soonOpen) ?></b> exam(s) within 3 days still without full proctors</span></a></div><?php endif; ?>
  <?php if ($declN): ?><div class="col-md-6 col-xl-3"><a class="alert-tile warn" href="<?= e(url('admin/declined.php')) ?>"><i class="bi bi-arrow-repeat"></i><span><b><?= $declN ?></b> declined assignment(s) to reassign</span></a></div><?php endif; ?>
  <?php if ($pendN): ?><div class="col-md-6 col-xl-3"><a class="alert-tile info" href="<?= e(url('admin/assignments.php?status=Pending+Review')) ?>"><i class="bi bi-hourglass-split"></i><span><b><?= $pendN ?></b> proposal(s) waiting for approval</span></a></div><?php endif; ?>
  <?php if ($paperSoon): ?><div class="col-md-6 col-xl-3"><a class="alert-tile warn" href="<?= e(url('admin/papers.php')) ?>"><i class="bi bi-file-earmark-text"></i><span><b><?= $paperSoon ?></b> exam(s) within 48h with papers not released</span></a></div><?php endif; ?>
</div><?php endif; ?>
<div class="row g-3 mb-3"><div class="col-lg-6"><div class="card-panel h-100 fade-up"><div class="panel-head"><h5><i class="bi bi-sun me-1"></i>Today's examinations</h5></div>
<?php if (!$todayExams): ?><div class="text-muted small">No examinations today.</div><?php else: foreach ($todayExams as $t): ?><div class="today-row"><span class="time"><?= e(time_range($t['start_time'], $t['end_time'])) ?></span><span><strong><?= e($t['exam_code']) ?></strong> <?= e($t['name']) ?></span><span class="text-muted small ms-auto"><?= e($t['room']) ?><?= $t['building'] ? ' · ' . e($t['building']) : '' ?></span></div><?php endforeach; endif; ?></div></div>
<div class="col-lg-6"><div class="card-panel h-100 fade-up"><div class="panel-head"><h5><i class="bi bi-calendar-week me-1"></i>Exams, next 14 days</h5></div><div style="height:150px"><canvas id="perDay"></canvas></div>
<?php if ($unavail): ?><div class="small text-muted mt-2"><i class="bi bi-person-x me-1"></i>Unavailable: <?= e(implode(', ', array_column($unavail, 'full_name'))) ?></div><?php endif; ?></div></div></div>
<script>window.addEventListener('load',function(){var c=document.getElementById('perDay');if(c&&window.Chart)new Chart(c,{type:'bar',data:{labels:<?= json_encode(array_map(fn($r) => date('M j', strtotime($r['exam_date'])), $perDay)) ?>,datasets:[{data:<?= json_encode(array_map(fn($r) => (int) $r['c'], $perDay)) ?>,backgroundColor:'#1f3a68',borderRadius:4}]},options:{maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{precision:0}}}}});});</script>
<div class="row g-3 mb-3">
  <?php foreach ($cards as [$icon, $label, $val, $cls, $href]): ?>
    <div class="col-6 col-md-4 col-xl-3 col-xxl">
      <a href="<?= e(url('admin/' . $href)) ?>" class="text-decoration-none">
        <div class="stat-card <?= e($cls) ?>">
          <div class="stat-icon"><i class="bi bi-<?= e($icon) ?>"></i></div>
          <div><div class="stat-value"><?= (int) $val ?></div><div class="stat-label"><?= e($label) ?></div></div>
        </div>
      </a>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-3">
  <div class="col-lg-8">
    <div class="card-panel">
      <div class="panel-head"><h5>Teacher workload (assignments in scheduling period)</h5>
        <a class="btn btn-sm btn-outline-navy" href="<?= e(url('admin/workload.php')) ?>">Load balancing details</a></div>
      <div style="height:260px"><canvas id="workloadChart"></canvas></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card-panel">
      <div class="panel-head"><h5>Paper tracking summary</h5><a class="btn btn-sm btn-outline-navy" href="<?= e(url('admin/papers.php')) ?>">Open</a></div>
      <div style="height:260px"><canvas id="paperChart"></canvas></div>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-8">
    <div class="card-panel">
      <div class="panel-head"><h5>Upcoming examinations</h5><a class="btn btn-sm btn-outline-navy" href="<?= e(url('admin/exams.php')) ?>">View all</a></div>
      <?php if (!$upcoming): ?>
        <?= empty_state('calendar-x', 'No upcoming examinations', 'Create an examination to start scheduling proctors.') ?>
      <?php else: ?>
      <div class="table-responsive">
        <table class="table table-modern align-middle">
          <thead><tr><th>Code</th><th>Examination</th><th>Date &amp; time</th><th>Room</th><th>Proctors</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($upcoming as $x): $full = $x['assigned_count'] >= $x['required_proctors']; ?>
            <tr>
              <td><strong><?= e($x['exam_code']) ?></strong></td>
              <td><?= e($x['name']) ?><div class="text-muted small"><?= e($x['subject_code']) ?></div></td>
              <td><?= e(fmt_date($x['exam_date'])) ?><div class="text-muted small"><?= e(time_range($x['start_time'], $x['end_time'])) ?></div></td>
              <td><?= e($x['room_name']) ?></td>
              <td><span class="badge <?= $full ? 'bg-success' : 'bg-danger' ?>"><?= (int) $x['assigned_count'] ?>/<?= (int) $x['required_proctors'] ?></span></td>
              <td class="text-end"><a class="btn btn-sm btn-light" href="<?= e(url('admin/exam_view.php?id=' . $x['id'])) ?>">Open</a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card-panel">
      <div class="panel-head"><h5>Examination schedule overview</h5></div>
      <?php foreach (['Scheduled', 'Completed', 'Cancelled'] as $s): ?>
        <div class="d-flex justify-content-between align-items-center py-2 border-bottom"><?= status_badge($s) ?><strong><?= (int) ($statusMap[$s] ?? 0) ?></strong></div>
      <?php endforeach; ?>
    </div>
    <div class="card-panel">
      <div class="panel-head"><h5>Recent activity</h5><a class="btn btn-sm btn-outline-navy" href="<?= e(url('admin/logs.php')) ?>">All logs</a></div>
      <?php if (!$activities): ?><?= empty_state('clock-history', 'No activity yet') ?><?php endif; ?>
      <?php foreach ($activities as $a): ?>
        <div class="py-2 border-bottom small">
          <div class="fw-semibold"><?= e($a['description'] ?: $a['action']) ?></div>
          <div class="text-muted"><?= e($a['full_name'] ?: 'System') ?> · <?= e(fmt_dt($a['created_at'])) ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<?php
$extraScripts = '<script>
new Chart(document.getElementById("workloadChart"), {type:"bar",
  data:{labels:' . json_encode($chartLabels) . ',datasets:[{label:"Assignments",data:' . json_encode($chartData) . ',backgroundColor:"#13315c",borderRadius:4}]},
  options:{maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{precision:0}}}}});
new Chart(document.getElementById("paperChart"), {type:"doughnut",
  data:{labels:' . json_encode(PaperTracker::STATUSES) . ',datasets:[{data:' . json_encode($paperData) . ',backgroundColor:["#e3c565","#c9d3e3","#7fa3d6","#8c7bd6","#2f8f5b","#2c93a3","#0b2545"]}]},
  options:{maintainAspectRatio:false,plugins:{legend:{position:"bottom",labels:{boxWidth:12}}}}});
</script>';
require __DIR__ . '/../includes/footer.php';
