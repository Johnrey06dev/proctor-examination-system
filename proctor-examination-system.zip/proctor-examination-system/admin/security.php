<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('admin');
$pdo = db();
function set_setting(string $k, string $v): void
{
    $st = db()->prepare('UPDATE system_settings SET setting_value = ? WHERE setting_key = ?');
    $st->execute([$v, $k]);
    if (!$st->rowCount() && !fetch_value('SELECT COUNT(*) FROM system_settings WHERE setting_key = ?', [$k])) {
        db()->prepare('INSERT INTO system_settings (setting_key, setting_value) VALUES (?,?)')->execute([$k, $v]);
    }
}
if (require_post_csrf()) {
    $a = input_str('action', 20);
    try {
        if ($a === 'test_mail') {
            if (!Mailer::configured()) throw new RuntimeException('Save the sender Gmail and its App Password first.');
            Mailer::send(Mailer::user(), 'Test e-mail – ' . APP_SHORT, 'SMTP works. You can now enable OTP.', Mailer::html('SMTP test', 'Your Gmail SMTP settings work.'));
            set_setting('smtp_verified', '1');
            log_activity('smtp_verified', 'security', null, null, null, 'SMTP test succeeded');
            flash('success', 'Test e-mail sent to ' . Mailer::user() . ' (check its Inbox/Spam). You can now enable OTP and registration.');
        } elseif ($a === 'toggle_otp') {
            $on = input_str('otp', 1) === '1';
            if ($on && get_settings(true)['smtp_verified'] !== '1') throw new RuntimeException('Send a successful test e-mail first.');
            set_setting('otp_enabled', $on ? '1' : '0');
            log_activity('otp_toggled', 'security', null, null, null, 'OTP ' . ($on ? 'enabled' : 'disabled'));
            flash('success', 'OTP login ' . ($on ? 'enabled' : 'disabled') . '.');
        } elseif ($a === 'toggle_mail') {
            $on = input_str('mail', 1) === '1';
            if ($on && get_settings(true)['smtp_verified'] !== '1') throw new RuntimeException('Send a successful test e-mail first.');
            set_setting('email_notifications', $on ? '1' : '0');
            flash('success', 'E-mail notifications ' . ($on ? 'enabled' : 'disabled') . '.');
        } elseif ($a === 'save_mail') {
            $u = trim(input_str('mail_user', 150)); $pw = preg_replace('/\s+/', '', (string) ($_POST['mail_pass'] ?? ''));
            if (!filter_var($u, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Enter the sender Gmail address.');
            if ($pw === '' && trim((string) (get_settings(true)['mail_pass'] ?? '')) === '') throw new RuntimeException('Enter the 16-letter App Password.');
            set_setting('mail_user', $u);
            if ($pw !== '') set_setting('mail_pass', $pw);
            set_setting('smtp_verified', '0');
            log_activity('mail_saved', 'security', null, null, null, 'Sender e-mail saved: ' . $u);
            flash('success', 'Saved. Now press "Send test e-mail to the sender Gmail".');
        } elseif ($a === 'toggle_setting') {
            $k = input_str('key', 40);
            if (!in_array($k, ['registration_open', 'registration_approval', 'qr_login_enabled'], true)) throw new RuntimeException('Unknown setting.');
            set_setting($k, input_str('value', 1) === '1' ? '1' : '0');
            flash('success', 'Saved.');
        } elseif ($a === 'public_url') {
            $u = rtrim(input_str('public_base_url', 200), '/');
            if ($u !== '' && !preg_match('#^https?://[^\s/]+(/[^\s]*)?$#', $u)) throw new RuntimeException('Enter a full address like http://192.168.1.10/EXAMINATION');
            set_setting('public_base_url', $u);
            flash('success', 'Saved.');
        } elseif ($a === 'unblock') {
            $pdo->prepare('DELETE FROM rate_limits WHERE rl_key = ?')->execute([input_str('key', 190)]);
            flash('success', 'Block removed.');
        }
    } catch (Throwable $e) { flash('danger', $e->getMessage()); }
    redirect('admin/security.php');
}
$s = get_settings(true);
try { $blocked = fetch_all('SELECT rl_key, hits, blocked_until FROM rate_limits WHERE blocked_until > ? ORDER BY blocked_until DESC', [time()]); } catch (Throwable $e) { $blocked = []; }
$pageTitle = 'Security & OTP';
$activeNav = 'security';
require __DIR__ . '/../includes/header.php';
$cfg = Mailer::configured();
?>
<div class="row g-3">
 <div class="col-lg-6"><div class="card-panel fade-up h-100">
  <div class="panel-head"><h5><i class="bi bi-envelope-at me-1"></i>Gmail (SMTP)</h5><span class="badge <?= $s['smtp_verified'] === '1' ? 'bg-success' : 'bg-secondary' ?>"><?= $s['smtp_verified'] === '1' ? 'Verified' : 'Not verified' ?></span></div>
  <p class="small text-muted mb-2" data-keep>Status: <strong><?= $cfg ? 'saved (' . e(Mailer::user()) . ')' : 'not set up' ?></strong>. Use a Gmail that has <b>2-Step Verification</b> and a Google <b>App Password</b> (<a href="https://myaccount.google.com/apppasswords" target="_blank" rel="noopener">create one here</a>). The normal Gmail password will NOT work.</p>
  <form method="post" class="mb-3"><?= csrf_field() ?><input type="hidden" name="action" value="save_mail">
    <div class="mb-2"><label class="form-label small mb-1">Sender Gmail (sends the codes)</label><input class="form-control" type="email" name="mail_user" value="<?= e(Mailer::user()) ?>" placeholder="yourname@gmail.com" required></div>
    <div class="mb-2"><label class="form-label small mb-1">App Password (16 letters)</label><input class="form-control" type="password" name="mail_pass" placeholder="<?= $cfg ? '•••••••• (leave empty to keep)' : 'abcd efgh ijkl mnop' ?>" autocomplete="new-password"></div>
    <button class="btn btn-light border">Save</button></form>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="test_mail"><button class="btn btn-navy" data-loading="Sending..." <?= $cfg ? '' : 'disabled' ?>><i class="bi bi-send me-1"></i>Send test e-mail to the sender Gmail</button></form>
 </div></div>
 <div class="col-lg-6"><div class="card-panel fade-up h-100" style="--d:80ms">
  <div class="panel-head"><h5><i class="bi bi-shield-lock me-1"></i>Login protection</h5></div>
  <form method="post" class="mb-2"><?= csrf_field() ?><input type="hidden" name="action" value="toggle_otp"><input type="hidden" name="otp" value="<?= $s['otp_enabled'] === '1' ? '0' : '1' ?>">
    <div class="d-flex justify-content-between align-items-center"><div><strong>Require OTP for EVERYONE</strong><div class="small text-muted" data-info>6-digit code by e-mail. Even when this is off, any user (and you, the admin) can turn OTP on for his own account in My Profile.</div></div>
    <button class="btn btn-sm <?= $s['otp_enabled'] === '1' ? 'btn-danger' : 'btn-success' ?>" <?= $s['smtp_verified'] === '1' ? '' : 'disabled' ?>><?= $s['otp_enabled'] === '1' ? 'Disable' : 'Enable' ?></button></div></form>
  <form method="post" class="mb-2"><?= csrf_field() ?><input type="hidden" name="action" value="toggle_mail"><input type="hidden" name="mail" value="<?= $s['email_notifications'] === '1' ? '0' : '1' ?>">
    <div class="d-flex justify-content-between align-items-center"><div><strong>E-mail copy of notifications</strong><div class="small text-muted" data-info>Schedule details are also e-mailed.</div></div>
    <button class="btn btn-sm <?= $s['email_notifications'] === '1' ? 'btn-danger' : 'btn-success' ?>" <?= $s['smtp_verified'] === '1' ? '' : 'disabled' ?>><?= $s['email_notifications'] === '1' ? 'Disable' : 'Enable' ?></button></div></form>
  <div class="small text-muted" data-info>Rate limits: 5 failed logins / 15 min per account (5 min cooldown), 20 / 10 min per IP (10 min), 300 requests / min per IP.</div>
 </div></div>
</div>
<?php function sw(string $key, string $title, string $desc, array $s): void { $on = ($s[$key] ?? '0') === '1'; ?>
  <form method="post" class="mb-2"><?= csrf_field() ?><input type="hidden" name="action" value="toggle_setting"><input type="hidden" name="key" value="<?= e($key) ?>"><input type="hidden" name="value" value="<?= $on ? '0' : '1' ?>">
    <div class="d-flex justify-content-between align-items-center"><div><strong><?= e($title) ?></strong><div class="small text-muted" data-info><?= e($desc) ?></div></div><button class="btn btn-sm <?= $on ? 'btn-danger' : 'btn-success' ?>"><?= $on ? 'Turn off' : 'Turn on' ?></button></div></form>
<?php } ?>
<div class="card-panel fade-up mt-3"><div class="panel-head"><h5><i class="bi bi-person-plus me-1"></i>Registration and QR login</h5></div>
  <?php sw('registration_open', 'Teachers can register with Gmail', 'Shows "Create an account" on the login page. A 6-digit code is e-mailed first (needs verified Gmail SMTP).', $s);
  sw('registration_approval', 'New accounts need my approval', 'A new teacher cannot sign in until you activate the account in User Accounts.', $s);
  sw('qr_login_enabled', 'Allow personal QR login', 'Users can create a QR code in My Profile and sign in by scanning it.', $s); ?>
  <form method="post" class="mt-2"><?= csrf_field() ?><input type="hidden" name="action" value="public_url"><label class="form-label small mb-1">Address that phones can open (used inside QR codes)</label>
    <div class="input-group"><input class="form-control" name="public_base_url" value="<?= e($s['public_base_url'] ?? '') ?>" placeholder="http://192.168.1.10/EXAMINATION"><button class="btn btn-navy">Save</button></div>
    <div class="form-text">Phones cannot open <code>localhost</code>. Put your computer's Wi-Fi IP address (run <code>ipconfig</code>) followed by the folder name. Leave empty to use the address in your browser.</div></form>
</div>
<div class="card-panel fade-up mt-3"><div class="panel-head"><h5>Currently blocked</h5></div>
<?php if (!$blocked): ?><?= empty_state('shield-check', 'No active blocks') ?><?php else: ?>
<table class="table table-modern"><thead><tr><th>Key</th><th>Hits</th><th>Remaining</th><th></th></tr></thead><tbody>
<?php foreach ($blocked as $b): ?><tr><td><code><?= e($b['rl_key']) ?></code></td><td><?= (int) $b['hits'] ?></td><td><?= e(fmt_wait((int) $b['blocked_until'] - time())) ?></td>
<td class="text-end"><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="unblock"><input type="hidden" name="key" value="<?= e($b['rl_key']) ?>"><button class="btn btn-sm btn-light">Unblock</button></form></td></tr><?php endforeach; ?></tbody></table><?php endif; ?></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
