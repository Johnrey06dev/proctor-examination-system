<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_perm('autoassign.view');
$pdo = db();
$depts = dept_list();
$today = date('Y-m-d');

$deptId = (int) ($_REQUEST['dept'] ?? 0);
$yopts = year_level_options();
$year = isset($yopts[(int) ($_REQUEST['year'] ?? 0)]) ? (int) $_REQUEST['year'] : (int) array_key_first($yopts);   // one year level at a time
$sem = level_has_sem($year) ? (in_array((int) ($_REQUEST['sem'] ?? 0), [1, 2], true) ? (int) $_REQUEST['sem'] : 1) : 0;   // Grade 1-10 have no semester
$from = valid_date((string) ($_REQUEST['from'] ?? '')) ? $_REQUEST['from'] : $today;
$to = valid_date((string) ($_REQUEST['to'] ?? '')) ? $_REQUEST['to'] : date('Y-m-d', strtotime('+13 days'));
$slotTxt = trim((string) ($_REQUEST['slots'] ?? '')) !== '' ? (string) $_REQUEST['slots'] : "08:00-10:00\n10:30-12:30\n13:30-15:30";
$perDay = max(1, min(6, (int) ($_REQUEST['perday'] ?? 2)));
$slots = auto_slots($slotTxt);

$result = null; $run = null;
if (is_post() && require_post_csrf()) {
    $act = input_str('action', 12);
    if ($act === 'apply' && !user_can('autoassign.apply')) deny_access($user);
    if (!$slots) flash('danger', 'Enter at least one valid time slot, like 08:00-10:00.');
    elseif ($from > $to) flash('danger', 'The end date must not be before the start date.');
    else {
        try {
            $plan = auto_schedule_plan($pdo, ['sem' => $sem, 'dept' => $deptId, 'year' => $year, 'from' => $from, 'to' => $to, 'slots' => $slots, 'perday' => $perDay]);
            $run = auto_schedule_run($pdo, new ProctorScheduler($pdo), $plan, $user['id'], $act === 'apply');
            $result = $plan;
            if ($act === 'apply') {
                if ($run['errors']) { foreach (array_slice($run['errors'], 0, 8) as $er) flash('danger', $er); flash('warning', 'Nothing was saved. Fix the problems above and try again.'); }
                else {
                    log_activity('auto_schedule', 'examination', null, null, null, $run['made'] . ' exam(s) scheduled for ' . YEAR_LEVELS[$year] . ($sem ? ', ' . SEMESTERS[$sem] : ''), $user['id']);
                    flash($run['made'] ? 'success' : 'info', $run['made'] . ' exam(s) scheduled for ' . YEAR_LEVELS[$year] . ($sem ? ', ' . SEMESTERS[$sem] : '') . '. Next: run Auto-Assign to pick the proctors.' . ($plan['unplaced'] ? ' ' . count($plan['unplaced']) . ' subject(s) could not be placed.' : ''));
                    redirect('admin/auto_schedule.php?' . http_build_query(['sem' => $sem, 'dept' => $deptId, 'year' => $year, 'from' => $from, 'to' => $to, 'perday' => $perDay, 'slots' => $slotTxt]));
                }
            }
        } catch (Throwable $e) { flash('danger', 'Auto-schedule failed: ' . (APP_DEBUG ? $e->getMessage() : 'unexpected error.')); }
    }
}

$pageTitle = 'Auto-Schedule';
$activeNav = 'autoassign';
require __DIR__ . '/../includes/header.php';
?>
<div class="alert alert-info fade-up" data-info><b>How it works.</b> Auto-Schedule reads the Year Levels you registered (sections, students and subjects) and creates the exams of <b>one year level at a time</b> (and one semester for Senior High and College; Grade 1-10 have none). Each subject gets a date, a time slot and the section's room. No Sundays, no past dates, no two exams of a section at the same time, and a room is used by one exam per slot. Then use <a href="<?= e(url('admin/auto_assign.php?sem=' . $sem)) ?>">Auto-Assign</a> to give every subject its proctor.</div>

<div class="card-panel fade-up"><h5 class="serif">Auto-Schedule exams</h5>
<form method="post" class="row g-3"><?= csrf_field() ?>
  <div class="col-12" id="semBox" <?= level_has_sem($year) ? '' : 'style="display:none"' ?>><label class="form-label small d-block">Semester</label>
    <div class="btn-group" role="group">
      <input type="radio" class="btn-check" name="sem" id="s1" value="1" <?= $sem === 1 ? 'checked' : '' ?>><label class="btn btn-outline-success" for="s1">First Semester</label>
      <input type="radio" class="btn-check" name="sem" id="s2" value="2" <?= $sem === 2 ? 'checked' : '' ?>><label class="btn btn-outline-success" for="s2">Second Semester</label></div>
    <div class="form-text" data-info>Only this semester's sections and subjects are scheduled, so First and Second semester never mix.</div></div>
  <div class="col-md-3"><label class="form-label small">Department</label><select class="form-select" name="dept"><option value="0">All departments</option><?= options_html($depts, 'id', fn($d) => $d['code'] . ' – ' . $d['name'], $deptId) ?></select></div>
  <div class="col-md-3"><label class="form-label small">Year level</label><select class="form-select" name="year"><?php foreach (year_level_options() as $k => $v): ?><option value="<?= (int) $k ?>" data-sem="<?= level_has_sem((int) $k) ? 1 : 0 ?>" <?= $year === (int) $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select></div>
  <div class="col-md-3"><label class="form-label small">First exam day</label><input type="date" class="form-control" name="from" value="<?= e($from) ?>" min="<?= e($today) ?>"></div>
  <div class="col-md-3"><label class="form-label small">Last exam day</label><input type="date" class="form-control" name="to" value="<?= e($to) ?>"></div>
  <div class="col-md-6"><label class="form-label small">Time slots (one per line, start-end)</label><textarea class="form-control" name="slots" rows="4"><?= e($slotTxt) ?></textarea><div class="form-text" data-info>Every exam must fit one of these slots, for example 08:00-10:00. Rooms used are the ones marked Available in the Rooms page.</div></div>
  <div class="col-md-3"><label class="form-label small">Max exams per section per day</label><input type="number" min="1" max="6" class="form-control" name="perday" value="<?= (int) $perDay ?>"></div>
  <div class="col-12 d-flex gap-2"><button class="btn btn-navy" name="action" value="preview" data-loading="Calculating..."><i class="bi bi-eye me-1"></i>Preview schedule</button></div>
</form></div>

<?php if ($result !== null): ?>
<div class="card-panel fade-up"><h5 class="serif">Preview &ndash; <?= e(YEAR_LEVELS[$year] . ($sem ? ', ' . SEMESTERS[$sem] : '')) ?></h5>
<?php $total = array_sum(array_map(fn($p) => count($p['items']), $result['plans'])); ?>
<p class="small text-muted"><?= (int) $total ?> exam(s) to create for <?= count($result['plans']) ?> section(s) across <?= (int) $result['days'] ?> day(s). Nothing is saved yet.</p>
<?php if ($run['errors']): ?><div class="alert alert-danger"><b>Problems found:</b><ul class="mb-0"><?php foreach (array_slice($run['errors'], 0, 10) as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<?php if ($result['unplaced']): ?><div class="alert alert-warning"><b>Could not place:</b><ul class="mb-0"><?php foreach ($result['unplaced'] as [$l, $why]): ?><li><?= e($l) ?> &ndash; <?= e($why) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<?php foreach ($result['plans'] as $p): ?>
<div class="mb-3"><b><?= e($p['label']) ?></b> <span class="small text-muted">&middot; <?= (int) $p['students'] ?> students &middot; <?= e($p['room']['name']) ?></span>
<div class="table-responsive"><table class="table table-modern table-sm align-middle mb-0"><thead><tr><th>Subject</th><th>Date</th><th>Time</th></tr></thead><tbody>
<?php foreach ($p['items'] as $it): ?><tr><td><?= e($it['name']) ?></td><td><?= e(date('D, M j, Y', strtotime($it['date']))) ?></td><td><?= e($it['start']) ?> &ndash; <?= e($it['end']) ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
<?php endforeach; ?>
<?php if (!$result['plans']): ?><p class="text-muted mb-0">Nothing to schedule: every subject of this selection already has an exam, or nothing could be placed.</p><?php endif; ?>
<?php if ($result['plans'] && !$run['errors'] && user_can('autoassign.apply')): ?>
<form method="post" class="mt-3"><?= csrf_field() ?>
  <?php foreach (['sem' => $sem, 'dept' => $deptId, 'year' => $year, 'from' => $from, 'to' => $to, 'perday' => $perDay, 'slots' => $slotTxt] as $k => $v): ?><input type="hidden" name="<?= e($k) ?>" value="<?= e($v) ?>"><?php endforeach; ?>
  <button class="btn btn-success" name="action" value="apply" data-confirm="Create <?= (int) $total ?> exam(s) for <?= e(YEAR_LEVELS[$year] . ($sem ? ', ' . SEMESTERS[$sem] : '')) ?>?"><i class="bi bi-check2-circle me-1"></i>Create these <?= (int) $total ?> exams</button></form>
<?php endif; ?></div>
<?php endif; ?>
<script>
(function(){var y=document.querySelector('select[name=year]'),b=document.getElementById('semBox');if(!y||!b)return;
function t(){var o=y.options[y.selectedIndex];var on=o&&o.dataset.sem==='1';b.style.display=on?'':'none';b.querySelectorAll('input').forEach(function(i){i.disabled=!on;});}
y.addEventListener('change',t);t();})();
</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
