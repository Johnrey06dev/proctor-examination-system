<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_perm('records.view');
$q = trim((string) ($_GET['q'] ?? ''));
$rows = fetch_all("SELECT e.id, e.exam_code, e.name, e.exam_date, e.start_time, e.end_time, r.name AS room, s.code AS subject, es.section_name
    FROM examinations e JOIN rooms r ON r.id = e.room_id JOIN subjects s ON s.id = e.subject_id LEFT JOIN exam_sections es ON es.examination_id = e.id
    WHERE e.status = 'Completed'" . ($q !== '' ? " AND (e.exam_code LIKE ? OR e.name LIKE ? OR es.section_name LIKE ?)" : '') . ' ORDER BY e.exam_date DESC, e.start_time LIMIT 200', $q !== '' ? ["%$q%", "%$q%", "%$q%"] : []);
$pageTitle = 'Exam Records'; $activeNav = 'records';
require __DIR__ . '/../includes/header.php';
?>
<form class="mb-3 d-flex gap-2"><input class="form-control" name="q" value="<?= e($q) ?>" placeholder="Search code, exam or section"><button class="btn btn-navy">Search</button></form>
<?php if (!$rows): ?><div class="card-panel"><?= empty_state('archive', 'No completed exams yet') ?></div><?php endif; ?>
<?php $by = []; foreach ($rows as $r) $by[$r['section_name'] ?? 'No section'][] = $r; foreach ($by as $sec => $list): ?>
<div class="card-panel fade-up mb-3"><h5><?= e($sec) ?></h5>
<?php foreach ($list as $x):
  $pr = fetch_all("SELECT u.full_name, p.proctor_role, a.time_in, a.time_out FROM proctor_assignments p JOIN teachers t ON t.id = p.teacher_id JOIN users u ON u.id = t.user_id LEFT JOIN attendance a ON a.examination_id = p.examination_id AND a.teacher_id = p.teacher_id WHERE p.examination_id = ? AND p.status = 'Confirmed'", [$x['id']]);
  $tl = fetch_all('SELECT h.new_status, h.created_at FROM paper_tracking_history h JOIN paper_distribution d ON d.id = h.distribution_id WHERE d.examination_id = ? ORDER BY h.id', [$x['id']]); ?>
<div class="border-top pt-2 mt-2"><strong><?= e($x['exam_code']) ?></strong> <?= e($x['name']) ?> <span class="text-muted small"><?= e($x['subject']) ?> &middot; <?= e(fmt_date($x['exam_date'])) ?> <?= e(time_range($x['start_time'], $x['end_time'])) ?> &middot; <?= e($x['room']) ?></span>
<div class="small mt-1"><?php foreach ($pr as $p): ?><div><i class="bi bi-person-check"></i> <?= e($p['full_name']) ?> (<?= e($p['proctor_role'] ?? 'Proctor') ?>) &middot; in <?= $p['time_in'] ? e(date('g:i A', strtotime($p['time_in']))) : '—' ?> / out <?= $p['time_out'] ? e(date('g:i A', strtotime($p['time_out']))) : '—' ?></div><?php endforeach; ?></div>
<?php if ($tl): ?><div class="small text-muted">Papers: <?= e(implode(' → ', array_map(fn($t) => $t['new_status'], $tl))) ?></div><?php endif; ?></div>
<?php endforeach; ?></div><?php endforeach; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
