<?php
/**
 * admin/rooms.php – Rooms (grid of tiles)  +  ?r=ID  room detail (classroom layout, sections & exams, proctors, schedule editor)
 * Modelled on the ProctorPlan prototype: a room has sections; each section has subjects = exams (date, time, proctors needed).
 */
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_perm('rooms.view');
$pdo = db();
$sched = new ProctorScheduler($pdo);
$rid = (int) ($_GET['r'] ?? $_POST['room_id'] ?? 0);
$here = 'admin/rooms.php' . ($rid ? '?r=' . $rid : '');

/** Deletes one exam together with everything that hangs on it. */
/** seat grid derived from the capacity (the room is described only by its capacity) */
function grid_for(int $cap): array
{
    $cols = max(4, min(12, (int) ceil(sqrt($cap * 1.6)))); $rows = max(1, (int) ceil($cap / $cols));
    return [$rows, $cols];
}
function opt_int($v): ?int { $v = trim((string) $v); return $v === '' ? null : max(1, min(500, (int) $v)); }

if (require_post_csrf()) {
    $action = input_str('action', 24);
    $id = input_int('id');
    $need = ['bulk' => 'rooms.add', 'save' => $id ? 'rooms.edit' : 'rooms.add', 'delete' => 'rooms.delete', 'remove_exam' => 'rooms.delete', 'remove_section' => 'rooms.delete', 'schedule' => 'rooms.edit',
             'assign' => 'rooms.assign', 'replace' => 'rooms.assign', 'remove_proctor' => 'rooms.assign', 'autoassign' => 'rooms.assign'][$action] ?? 'rooms.edit';
    if (!user_can($need)) deny_access($user);
    try {
        if ($action === 'bulk') {
            $n = max(1, min(50, input_int('count'))); $prefix = input_str('prefix', 40) ?: 'Room'; $startNo = max(1, input_int('start_no') ?: 1);
            $cap = max(1, min(500, input_int('capacity') ?: 40)); [$sr, $sc] = grid_for($cap); $ms = opt_int($_POST['max_sections'] ?? '');
            $bd = input_str('building', 100); $bd = $bd === '' ? null : $bd; $made = 0; $skipped = 0;
            for ($i = 0; $i < $n; $i++) {
                $nm = trim($prefix . ' ' . ($startNo + $i));
                if (fetch_value('SELECT COUNT(*) FROM rooms WHERE name = ?', [$nm])) { $skipped++; continue; }
                $pdo->prepare('INSERT INTO rooms (name, building, seat_rows, seat_cols, capacity, max_sections, status, created_at) VALUES (?,?,?,?,?,?,?,?)')->execute([$nm, $bd, $sr, $sc, $cap, $ms, 'Available', now()]);
                $made++;
            }
            log_activity('rooms_bulk_created', 'room', null, null, null, $made . ' room(s) created (' . $prefix . ')');
            flash($made ? 'success' : 'warning', $made . ' room(s) added' . ($skipped ? ', ' . $skipped . ' skipped (name already exists)' : '') . '. Click Open to add sections, exams and proctors.');
            redirect('admin/rooms.php');
        }
        if ($action === 'save') {
            $name = input_str('name', 60); $bd = input_str('building', 100); $bd = $bd === '' ? null : $bd;
            $cap = max(1, min(500, input_int('capacity'))); [$sr, $sc] = grid_for($cap); $ms = opt_int($_POST['max_sections'] ?? '');
            $status = input_str('status', 20) === 'Maintenance' ? 'Maintenance' : 'Available';
            $used = $id ? (int) fetch_value("SELECT COUNT(DISTINCT LOWER(s.section_name)) FROM examinations e JOIN exam_sections s ON s.examination_id = e.id WHERE e.room_id = ? AND e.status = 'Scheduled'", [$id]) : 0;
            $big = $id ? (int) fetch_value("SELECT COALESCE(MAX(s.examinees),0) FROM examinations e JOIN exam_sections s ON s.examination_id = e.id WHERE e.room_id = ? AND e.status = 'Scheduled'", [$id]) : 0;
            if ($name === '') flash('danger', 'Room name is required.');
            elseif (fetch_value('SELECT COUNT(*) FROM rooms WHERE name = ? AND id <> ?', [$name, $id])) flash('danger', 'Room "' . $name . '" already exists.');
            elseif ($id && $big > $cap) flash('danger', 'A section in this room has ' . $big . ' students; the capacity cannot be lower than that.');
            elseif ($id && $ms !== null && $used > $ms) flash('danger', 'This room already has ' . $used . ' sections; the section limit cannot be lower.');
            elseif ($id) {
                $pdo->prepare('UPDATE rooms SET name=?, building=?, seat_rows=?, seat_cols=?, capacity=?, max_sections=?, status=? WHERE id=?')->execute([$name, $bd, $sr, $sc, $cap, $ms, $status, $id]);
                log_activity('room_updated', 'room', $id, null, null, 'Room ' . $name . ' updated'); flash('success', 'Room updated (capacity ' . $cap . ').');
            } else {
                $pdo->prepare('INSERT INTO rooms (name, building, seat_rows, seat_cols, capacity, max_sections, status, created_at) VALUES (?,?,?,?,?,?,?,?)')->execute([$name, $bd, $sr, $sc, $cap, $ms, $status, now()]);
                log_activity('room_created', 'room', (int) $pdo->lastInsertId(), null, null, 'Room ' . $name . ' created'); flash('success', 'Room added.');
            }
            redirect($here);
        }
        if ($action === 'delete') {
            $pdo->beginTransaction();
            $exIds = array_column(fetch_all('SELECT id FROM examinations WHERE room_id = ?', [$id]), 'id');
            foreach ($exIds as $x) purge_exam($pdo, (int) $x);
            $pdo->prepare('DELETE FROM rooms WHERE id = ?')->execute([$id]);
            log_activity('room_deleted', 'room', $id, null, null, 'Room deleted (with ' . count($exIds) . ' exam(s))');
            $pdo->commit();
            flash('success', 'Room deleted' . ($exIds ? ' together with ' . count($exIds) . ' exam(s).' : '.'));
            redirect('admin/rooms.php');
        }
        $room = $rid ? fetch_one('SELECT * FROM rooms WHERE id = ?', [$rid]) : null;
        if (!$room) { flash('danger', 'Room not found.'); redirect('admin/rooms.php'); }

        if ($action === 'remove_exam') {
            $x = input_int('exam_id');
            if (fetch_value('SELECT COUNT(*) FROM examinations WHERE id = ? AND room_id = ?', [$x, $rid])) {
                $pdo->beginTransaction(); purge_exam($pdo, $x); log_activity('exam_removed', 'examination', $x, null, null, 'Exam removed from room ' . $room['name']); $pdo->commit();
                flash('success', 'Exam removed.');
            }
            redirect($here);
        }
        if ($action === 'assign' || $action === 'replace') {
            $x = input_int('exam_id'); $tid = input_int('teacher_id');
            if ($action === 'assign') $r = $sched->manualAssign($x, $tid, 'Pending Review', (int) $user['id']);
            else $r = $sched->replaceAssignment(input_int('assignment_id'), $tid, (int) $user['id']);
            if ($r['ok']) flash('success', 'Proctor assigned. The teacher is notified and must accept.');
            else { flash('danger', 'Not possible:'); foreach ($r['errors'] as $er) flash('warning', $er); }
            redirect($here . '&x=' . $x);
        }
        if ($action === 'remove_proctor') {
            $r = $sched->cancelAssignment(input_int('assignment_id'), (int) $user['id']);
            $r['ok'] ? flash('success', 'Proctor removed.') : flash('danger', implode(' ', $r['errors']));
            redirect($here . '&x=' . input_int('exam_id'));
        }
        if ($action === 'autoassign') {
            $x = input_int('exam_id'); $res = $sched->generate($x, (int) $user['id']);
            flash($res['assigned'] > 0 ? 'success' : 'warning', $res['assigned'] . ' proctor(s) auto-assigned (Pending – they must accept).');
            foreach ($res['warnings'] as $w) flash('warning', $w);
            redirect($here . '&x=' . $x);
        }
        if ($action === 'remove_section') {
            $sn = input_str('section', 60); $n = 0;
            foreach (fetch_all("SELECT e.id FROM examinations e JOIN exam_sections s ON s.examination_id = e.id WHERE e.room_id = ? AND e.status = 'Scheduled' AND LOWER(s.section_name) = LOWER(?)", [$rid, $sn]) as $r_) { purge_exam($pdo, (int) $r_['id']); $n++; }
            log_activity('section_removed', 'room', $rid, null, null, 'Section ' . $sn . ' removed from room (' . $n . ' exam(s))');
            flash('success', 'Section ' . $sn . ' removed from this room (' . $n . ' exam(s)).');
            redirect($here);
        }
        if ($action === 'schedule') {
            $pdo->beginTransaction();
            $res = section_save($pdo, $sched, $room, $_POST, (int) $user['id']);
            if ($res['errors']) { $pdo->rollBack(); foreach ($res['errors'] as $er) flash('danger', $er); }
            else {
                log_activity('room_schedule_saved', 'room', $rid, null, null, 'Room ' . $room['name'] . ': ' . $res['made'] . ' exam(s) added, ' . $res['upd'] . ' updated, ' . $res['removed'] . ' removed');
                $pdo->commit();
                $need = section_requirements($res['section_id']);
                flash('success', 'Section saved: ' . $res['made'] . ' exam(s) added, ' . $res['upd'] . ' updated' . ($res['removed'] ? ', ' . $res['removed'] . ' removed' : '') . '. Required proctors for this section: ' . $need['proctors'] . ' (one per subject).');
                foreach ($res['warnings'] as $w) flash('warning', $w);
            }
            redirect($here);
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('danger', 'Could not complete the action: ' . (APP_DEBUG ? $e->getMessage() : 'unexpected error.'));
        redirect($here);
    }
}

/* ------------------------------------------------------------------ data ------------------------------------------------------------------ */
$subjects = subject_list();
$allRooms = fetch_all('SELECT * FROM rooms ORDER BY name');
$exByRoom = [];
foreach (fetch_all("SELECT e.id, e.exam_code, e.name, e.room_id, e.subject_id, e.exam_date, e.start_time, e.end_time, e.required_proctors, e.status, e.department_id, s.code AS subj_code,
        (SELECT section_name FROM exam_sections x WHERE x.examination_id = e.id ORDER BY x.sort_order, x.id LIMIT 1) AS section,
        (SELECT section_id FROM exam_sections x WHERE x.examination_id = e.id ORDER BY x.sort_order, x.id LIMIT 1) AS section_id,
        (SELECT year_subject_id FROM exam_sections x WHERE x.examination_id = e.id ORDER BY x.sort_order, x.id LIMIT 1) AS year_subject_id,
        (SELECT examinees FROM exam_sections x WHERE x.examination_id = e.id ORDER BY x.sort_order, x.id LIMIT 1) AS students,
        (SELECT COUNT(*) FROM proctor_assignments a WHERE a.examination_id = e.id AND a.status IN ('Pending Review','Confirmed')) AS have
    FROM examinations e JOIN subjects s ON s.id = e.subject_id WHERE e.status = 'Scheduled' ORDER BY e.exam_date, e.start_time") as $x) $exByRoom[(int) $x['room_id']][] = $x;
function room_info(array $room, array $exByRoom): array
{
    $ex = $exByRoom[(int) $room['id']] ?? [];
    $needs = count(array_filter($ex, fn($e) => $e['have'] < $e['required_proctors']));
    return ['exams' => $ex, 'needs' => $needs, 'assigned' => array_sum(array_column($ex, 'have')), 'needed' => array_sum(array_column($ex, 'required_proctors')),
        'sections' => array_values(array_unique(array_filter(array_column($ex, 'section'))))];
}
$view = $rid ? fetch_one('SELECT * FROM rooms WHERE id = ?', [$rid]) : null;
$pageTitle = $view ? 'Room ' . $view['name'] : 'Rooms';
$activeNav = 'rooms';
require __DIR__ . '/../includes/header.php';

/* ================================================================== DETAIL ================================================================== */
if ($view):
    $inf = room_info($view, $exByRoom); $exams = $inf['exams'];
    $today = date('Y-m-d');
    $sel = (int) ($_GET['x'] ?? 0);
    if (!array_filter($exams, fn($e) => (int) $e['id'] === $sel)) { $sel = 0; foreach ($exams as $e) if ($e['exam_date'] >= $today) { $sel = (int) $e['id']; break; } if (!$sel && $exams) $sel = (int) $exams[0]['id']; }
    $selExam = null; foreach ($exams as $e) if ((int) $e['id'] === $sel) $selExam = $e;
    $assign = [];
    foreach (fetch_all("SELECT a.id, a.examination_id, a.status, a.proctor_role, a.declined_at, t.id AS tid, u.full_name FROM proctor_assignments a JOIN teachers t ON t.id = a.teacher_id JOIN users u ON u.id = t.user_id
                        WHERE a.status IN ('Pending Review','Confirmed') AND a.examination_id IN (SELECT id FROM examinations WHERE room_id = ?) ORDER BY a.id", [$rid]) as $a) $assign[(int) $a['examination_id']][] = $a;
    $seats = (int) $view['capacity']; [$rowsN, $cols] = grid_for($seats);
    $taken = $selExam ? min((int) $selExam['students'], $seats) : 0;
    $bySec = [];
    foreach ($exams as $e) $bySec[$e['section'] ?: '(no section)'][] = $e;
?>
<div class="d-flex flex-wrap gap-2 mb-3 no-print fade-up">
  <a class="btn btn-light" href="<?= e(url('admin/rooms.php')) ?>"><i class="bi bi-arrow-left"></i> All rooms</a>
  <?php if (user_can('rooms.edit')): ?><button class="btn btn-gold" type="button" id="addSecBtn"><i class="bi bi-plus-lg me-1"></i>Add section</button><?php endif; ?>
  <button class="btn btn-light" type="button" data-bs-toggle="modal" data-bs-target="#roomModal" data-edit="#roomForm" data-id="<?= (int) $view['id'] ?>" data-name="<?= e($view['name']) ?>" data-building="<?= e($view['building']) ?>" data-capacity="<?= $seats ?>" data-max_sections="<?= e($view['max_sections']) ?>" data-status="<?= e($view['status']) ?>"><i class="bi bi-gear me-1"></i>Room settings</button>
  <button class="btn btn-light" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print</button>
  <form method="post" class="ms-auto"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $view['id'] ?>"><button class="btn btn-danger" data-confirm="Delete room <?= e($view['name']) ?> and its <?= count($exams) ?> exam(s)?"><i class="bi bi-trash"></i> Delete room</button></form>
</div>
<div class="card-panel fade-up"><div class="room-head"><span class="room-ico"><i class="bi bi-door-open"></i></span><div class="info"><h2><?= e($view['name']) ?></h2>
  <div class="room-meta"><span>Building <b><?= $view['building'] ? e($view['building']) : '—' ?></b></span><span>Capacity <b><?= $seats ?></b></span><span>Sections <b><?= count($inf['sections']) ?><?= $view['max_sections'] ? ' / ' . (int) $view['max_sections'] : '' ?></b></span><span>Exams <b><?= count($exams) ?></b></span>
  <?= $exams ? ($inf['needs'] ? '<span class="badge-s b-red">' . $inf['needs'] . ' need proctors</span>' : '<span class="badge-s b-green">All staffed</span>') : '' ?></div></div></div></div>
<div class="room-split">
  <div class="card-panel fade-up"><h5 class="mb-1">Classroom layout</h5><p class="hint">Pick an exam to see how the room looks for it.</p>
    <?php if ($exams): ?><div class="layout-chips"><?php foreach ($exams as $e): ?><a class="<?= (int) $e['id'] === $sel ? 'active' : '' ?>" href="<?= e(url('admin/rooms.php?r=' . $rid . '&x=' . (int) $e['id'])) ?>"><?= e($e['section'] ?: $e['exam_code']) ?> &middot; <?= e($e['subj_code']) ?> &middot; <?= e(fmt_date($e['exam_date'])) ?>, <?= e(fmt_time($e['start_time'])) ?></a><?php endforeach; ?></div><?php endif; ?>
    <div class="classroom">
      <div class="cls-front"><div class="door">DOOR</div><div class="board">BOARD</div></div>
      <div class="cls-desk"><span class="desk-label">Proctors</span>
        <?php if ($selExam): foreach ($assign[$sel] ?? [] as $a): ?><span class="proctor-spot <?= $a['status'] === 'Confirmed' ? '' : 'waiting' ?>"><?= e($a['full_name']) ?></span><?php endforeach;
          $open = (int) $selExam['required_proctors'] - count($assign[$sel] ?? []); if ($open > 0): ?><span class="proctor-spot empty"><?= $open ?> proctor<?= $open === 1 ? '' : 's' ?> needed</span><?php endif; else: ?><span class="hint">Pick an exam</span><?php endif; ?></div>
      <div class="seats"><?php $n = 0; for ($r = 0; $r < $rowsN; $r++): ?><div class="seat-row"><?php for ($c = 0; $c < $cols && $n < $seats; $c++, $n++): ?><span class="seat <?= $n < $taken ? 'taken' : '' ?> <?= $c % 2 === 1 && $c < $cols - 1 ? 'aisle' : '' ?>" title="Seat <?= $n + 1 ?>"></span><?php endfor; ?></div><?php endfor; ?></div>
      <div class="cls-legend"><span><i class="taken"></i>Students (<?= $taken ?>)</span><span><i></i>Free seats (<?= $seats - $taken ?>)</span><span><i class="proc"></i>Proctor</span><span><?= $seats ?> seats</span></div>
    </div>
  </div>
  <div class="card-panel fade-up" style="--d:80ms"><h5 class="mb-1">Sections and exams</h5><p class="hint">Who is assigned, and when each section takes its exam.</p>
  <?php if (!$exams): ?><div class="text-muted">No section yet. Click <b>Add section</b> to register a section and pick its subjects.</div><?php endif; ?>
  <?php foreach ($bySec as $secName => $list): ?><div class="sec-card"><div class="sec-card-head"><h3><?= e($secName) ?></h3><span class="hint"><?= (int) $list[0]['students'] ?> students &middot; <?= count($list) ?> subject<?= count($list) === 1 ? '' : 's' ?> &middot; <?= array_sum(array_column($list, 'required_proctors')) ?> proctor<?= array_sum(array_column($list, 'required_proctors')) === 1 ? '' : 's' ?> needed</span>
      <span class="ms-auto no-print"><?php if (user_can('rooms.edit')): ?><button class="btn btn-sm btn-light" type="button" data-editsec="<?= e($secName) ?>"><i class="bi bi-pencil"></i> Edit section</button> <?php endif; ?>
      <?php if (user_can('rooms.delete')): ?><form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="remove_section"><input type="hidden" name="room_id" value="<?= $rid ?>"><input type="hidden" name="section" value="<?= e($secName) ?>"><button class="btn btn-sm btn-danger" data-confirm="Remove section <?= e($secName) ?> and its <?= count($list) ?> exam(s) from this room?"><i class="bi bi-trash"></i></button></form><?php endif; ?></span></div>
    <?php foreach ($list as $e): $ids = $assign[(int) $e['id']] ?? []; $need = (int) $e['required_proctors']; ?>
    <div class="exam-line <?= (int) $e['id'] === $sel ? 'sel' : '' ?>">
      <div><b><?= e($e['exam_code']) ?></b><div class="hint"><?= e($e['name']) ?> &middot; <?= e($e['subj_code']) ?></div></div>
      <div><b><?= e(fmt_date($e['exam_date'])) ?></b><div class="hint"><?= e(time_range($e['start_time'], $e['end_time'])) ?></div></div>
      <div><?php foreach ($ids as $a): ?><div class="mb-1"><?= e($a['full_name']) ?> <?= $a['status'] === 'Confirmed' ? '<span class="badge-s b-green">Accepted</span>' : '<span class="badge-s b-amber">Waiting</span>' ?>
          <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="remove_proctor"><input type="hidden" name="assignment_id" value="<?= (int) $a['id'] ?>"><input type="hidden" name="exam_id" value="<?= (int) $e['id'] ?>"><input type="hidden" name="room_id" value="<?= $rid ?>"><button class="btn btn-sm btn-link text-danger p-0" title="Remove"><i class="bi bi-x-circle"></i></button></form></div><?php endforeach; ?>
        <?= count($ids) < $need ? '<span class="badge-s b-red">' . (count($ids) ? 'needs ' . ($need - count($ids)) . ' more' : 'Not assigned') . '</span>' : '' ?></div>
      <div class="actions no-print">
        <a class="btn btn-sm btn-light" href="<?= e(url('admin/rooms.php?r=' . $rid . '&x=' . (int) $e['id'])) ?>">Layout</a>
        <button class="btn btn-sm <?= $ids ? 'btn-light' : 'btn-navy' ?>" type="button" data-assign="<?= (int) $e['id'] ?>" data-label="<?= e($e['exam_code'] . ' · ' . fmt_date($e['exam_date']) . ' ' . time_range($e['start_time'], $e['end_time'])) ?>"><?= $ids ? 'Change proctor' : 'Assign proctor' ?></button>
        <?php if (count($ids) < $need): ?><form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="autoassign"><input type="hidden" name="exam_id" value="<?= (int) $e['id'] ?>"><input type="hidden" name="room_id" value="<?= $rid ?>"><button class="btn btn-sm btn-gold" data-loading="..."><i class="bi bi-magic"></i> Auto-assign</button></form><?php endif; ?>
        <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="remove_exam"><input type="hidden" name="exam_id" value="<?= (int) $e['id'] ?>"><input type="hidden" name="room_id" value="<?= $rid ?>"><button class="btn btn-sm btn-danger" data-confirm="Remove <?= e($e['exam_code']) ?>?">Remove</button></form>
      </div></div><?php endforeach; ?></div><?php endforeach; ?>
  </div>
</div>

<!-- Assign proctor modal: only teachers free on that day AND time -->
<div class="modal fade" id="assignModal" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content">
  <div class="modal-header"><h5 class="modal-title">Assign proctor <small class="text-muted" id="asgLabel"></small></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body" id="asgBody"><div class="text-muted">Loading…</div></div></div></div></div>
<?php
    // pre-compute free teachers per exam of this room (hard constraints) for the modal
    $free = [];
    foreach ($exams as $e) {
        $ev = $sched->evaluate((int) $e['id']);
        $free[(int) $e['id']] = ['free' => array_map(fn($t) => ['id' => $t['teacher_id'], 'name' => $t['name'], 'no' => $t['teacher_no'], 'score' => $t['score']], $ev['eligible']),
            'busy' => array_map(fn($t) => ['name' => $t['name'], 'why' => preg_replace('/^H\d [^:]+: /', '', $t['reasons'][0] ?? '')], array_slice($ev['excluded'], 0, 8))];
    }
?>
<!-- Add / edit ONE section of this room -->
<?php
  $catalog = year_catalog(); $depts = dept_list();
  $secInfo = []; $known = [];
  foreach (fetch_all('SELECT c.id, c.name, c.department_id, c.semester, c.students, y.year_level FROM class_sections c JOIN year_configs y ON y.id = c.year_config_id ORDER BY c.name') as $c_) {
      $secInfo[mb_strtolower($c_['name'])] = ['id' => (int) $c_['id'], 'name' => $c_['name'], 'dept' => (int) $c_['department_id'], 'year' => (int) $c_['year_level'], 'sem' => (int) $c_['semester'], 'students' => (int) $c_['students']];
      $known[mb_strtolower($c_['name'])] = $c_['name'];
  }
  foreach (fetch_all('SELECT section_name, examinees FROM exam_sections ORDER BY id') as $k_) { $key = mb_strtolower($k_['section_name']); $known[$key] = $known[$key] ?? $k_['section_name']; if (!isset($secInfo[$key])) $secInfo[$key] = ['id' => 0, 'name' => $k_['section_name'], 'dept' => 0, 'year' => 0, 'sem' => 0, 'students' => (int) $k_['examinees']]; }
  $elsewhere = [];
  foreach (fetch_all("SELECT x.section_id, x.year_subject_id, r.name AS rn FROM exam_sections x JOIN examinations e ON e.id = x.examination_id JOIN rooms r ON r.id = e.room_id WHERE e.room_id <> ? AND e.status = 'Scheduled' AND x.section_id IS NOT NULL AND x.year_subject_id IS NOT NULL", [$rid]) as $el) $elsewhere[(int) $el['section_id']][(int) $el['year_subject_id']] = $el['rn'];
  $pre = [];
  foreach ($bySec as $secName => $list) {
      $si = ['id' => 0, 'dept' => 0, 'year' => 0, 'sem' => 0, 'students' => (int) $list[0]['students']];
      if ($sid0 = (int) ($list[0]['section_id'] ?? 0)) {
          $c_ = fetch_one('SELECT c.id, c.department_id, c.semester, c.students, y.year_level FROM class_sections c JOIN year_configs y ON y.id = c.year_config_id WHERE c.id = ?', [$sid0]);
          if ($c_) $si = ['id' => (int) $c_['id'], 'dept' => (int) $c_['department_id'], 'year' => (int) $c_['year_level'], 'sem' => (int) $c_['semester'], 'students' => (int) $c_['students']];
      }
      if (!$si['dept']) $si['dept'] = (int) ($list[0]['department_id'] ?? 0);
      // an older section (typed in before the Year module): work out its year / semester from the subjects its exams already use
      if (!$si['year'] && $si['dept']) {
          $common = null; $map = [];
          foreach ($list as $e) {
              $keys = [];
              foreach (fetch_all('SELECT y.year_level, s.semester, s.id AS ys FROM year_subjects s JOIN year_configs y ON y.id = s.year_config_id WHERE y.department_id = ? AND s.subject_id = ?', [$si['dept'], $e['subject_id']]) as $m_) $keys[$m_['year_level'] . '|' . $m_['semester']] = (int) $m_['ys'];
              $map[(int) $e['id']] = $keys; $common = $common === null ? array_keys($keys) : array_intersect($common, array_keys($keys));
          }
          if ($common) { [$si['year'], $si['sem']] = array_map('intval', explode('|', reset($common))); foreach ($list as $k_ => $e) $list[$k_]['year_subject_id'] = $map[(int) $e['id']][reset($common)] ?? null; }
      }
      $pre[$secName] = ['id' => $si['id'], 'name' => $secName === '(no section)' ? '' : $secName, 'dept' => $si['dept'], 'year' => $si['year'], 'sem' => $si['sem'], 'students' => $si['students'],
          'subj' => array_values(array_map(fn($e) => ['ys' => (int) $e['year_subject_id'], 'eid' => (int) $e['id'], 'date' => $e['exam_date'], 'start' => substr($e['start_time'], 0, 5), 'end' => substr($e['end_time'], 0, 5)], array_filter($list, fn($e) => $e['year_subject_id']))),
          'old' => array_values(array_map(fn($e) => $e['exam_code'], array_filter($list, fn($e) => !$e['year_subject_id'])))];
  }
?>
<datalist id="knownSections"><?php foreach ($known as $k_): ?><option value="<?= e($k_) ?>"><?php endforeach; ?></datalist>
<div class="modal fade" id="schedModal" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content"><form method="post" id="schedForm"><?= csrf_field() ?><input type="hidden" name="action" value="schedule"><input type="hidden" name="room_id" value="<?= $rid ?>"><input type="hidden" name="section_id" id="secId" value="0">
  <div class="modal-header"><h5 class="modal-title" id="schedTitle">Add section &middot; <?= e($view['name']) ?> <small class="text-muted">(<?= $seats ?> seats)</small></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body"><div id="secList"></div></div>
  <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-navy" data-loading="Saving...">Save section</button></div></form></div></div></div>
<script>
(function(){
var CAT=<?= json_encode(array_values($catalog)) ?>, SEC=<?= json_encode($secInfo, JSON_FORCE_OBJECT) ?>, ELSE=<?= json_encode($elsewhere, JSON_FORCE_OBJECT) ?>;
var DEPTS=<?= json_encode(array_map(fn($d) => ['id' => (int) $d['id'], 'code' => $d['code'], 'name' => $d['name']], $depts)) ?>, YEARS=<?= json_encode(YEAR_LEVELS, JSON_FORCE_OBJECT) ?>, SEMS=<?= json_encode(SEMESTERS, JSON_FORCE_OBJECT) ?>, YEARURL=<?= json_encode(url('admin/years.php')) ?>;
var DATA=<?= json_encode((object) $pre) ?>;
var FREE=<?= json_encode($free) ?>, CSRF=<?= json_encode(csrf_token()) ?>, RID=<?= $rid ?>, MIN=<?= json_encode(date('Y-m-d')) ?>, CAP=<?= $seats ?>;
var ROOMNAME=<?= json_encode(e($view['name']) . ' <small class="text-muted">(' . $seats . ' seats)</small>') ?>;
var list=document.getElementById('secList'), cur=null;
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function rank(y){y=+y;return y>=100?y-100:y+20;}
function semReady(){var c=cfg(cur.dept,cur.year);return !!c&&(c.has_sem?cur.sem>0:true);}
function cfg(d,y){return CAT.filter(function(c){return c.dept==d&&c.year==y;})[0];}
function yearOpts(d,sel){var ys=CAT.filter(function(c){return c.dept==d;}).map(function(c){return c.year;}).sort(function(a,b){return rank(a)-rank(b);});
 return '<option value="">'+(d?(ys.length?'Select year level':'No year level registered'):'Select department first')+'</option>'+ys.map(function(y){return '<option value="'+y+'"'+(y==sel?' selected':'')+'>'+esc(YEARS[y])+'</option>';}).join('');}
function semOpts(d,y,sel){var c=cfg(d,y);if(c&&!c.has_sem){var n0=c.subjects[0].length;return '<option value="0" selected>Whole school year ('+n0+' subject'+(n0==1?'':'s')+')</option>';}return '<option value="">Select semester</option>'+Object.keys(SEMS).map(function(k){var n=c?c.subjects[k].length:0;return '<option value="'+k+'"'+(k==sel?' selected':'')+(c&&!n?' disabled':'')+'>'+esc(SEMS[k])+(c?' ('+n+' subject'+(n==1?'':'s')+')':'')+'</option>';}).join('');}
function subjHtml(){
 var c=cfg(cur.dept,cur.year), l=c&&semReady()?c.subjects[cur.sem]:[], out='';
 if(!cur.dept||!cur.year||!semReady()) return '<div class="hint">Choose the department and year level (and semester, if it has one) to load the subjects.</div>';
 if(!l.length) return '<div class="alert alert-warning mb-0">No subjects are registered for this combination. <a href="'+YEARURL+'">Add them in the Year module</a>.</div>';
 var el=ELSE[cur.id||0]||{};
 l.forEach(function(s){var p=cur.picked[s.id],b='subj['+s.id+']',away=el[s.id];
  out+='<div class="subj-check'+(p||away?' on':'')+'" data-ys="'+s.id+'"><label class="d-flex align-items-center gap-2 mb-0"><input type="checkbox" class="form-check-input mt-0 ys-on" name="'+b+'[on]" value="1"'+(p?' checked':'')+(away?' checked disabled':'')+'><b>'+esc(s.name)+'</b>'+(away?' <span class="badge-s b-blue">Scheduled in '+esc(away)+'</span>':'')+'</label>'
  +(away?'':'<div class="sched"><input type="hidden" name="'+b+'[id]" value="'+(p?p.eid:0)+'">'
  +'<div><label class="form-label small mb-0">Exam date</label><input type="date" class="form-control form-control-sm" name="'+b+'[date]" value="'+esc(p?p.date:'')+'" '+(p&&p.eid?'':'min="'+MIN+'" ')+(p?'required':'')+'></div>'
  +'<div><label class="form-label small mb-0">Start</label><input type="time" class="form-control form-control-sm" name="'+b+'[start]" value="'+esc(p?p.start:'08:00')+'"></div>'
  +'<div><label class="form-label small mb-0">End</label><input type="time" class="form-control form-control-sm" name="'+b+'[end]" value="'+esc(p?p.end:'10:00')+'"></div></div>')+'</div>';});
 return out;}
function summary(){var n=list.querySelectorAll('.subj-check input.ys-on:checked').length;var s=document.getElementById('secSum');if(s)s.innerHTML='<span>Total subjects: <b>'+n+'</b></span><span>Required proctors: <b>'+n+'</b></span><span class="hint">One proctor for each subject.</span>';}
function sync(){list.querySelectorAll('.subj-check').forEach(function(w){var on=w.querySelector('.ys-on').checked,d=w.querySelector('input[type=date]');w.classList.toggle('on',on);if(d)d.required=on&&!w.querySelector('.ys-on').disabled;});summary();}
function capture(){list.querySelectorAll('.subj-check').forEach(function(w){var k=w.dataset.ys,on=w.querySelector('.ys-on');if(on.disabled)return;if(on.checked){var i=w.querySelectorAll('input');cur.picked[k]={eid:+w.querySelector('input[type=hidden]').value,date:w.querySelector('input[type=date]').value,start:w.querySelector('input[type=time]').value,end:w.querySelectorAll('input[type=time]')[1].value};}else delete cur.picked[k];});}
function draw(){
 var fixed=cur.fixed&&cur.id>0, dis=fixed?' disabled':'', c0=cfg(cur.dept,cur.year), secs=c0&&semReady()?c0.sections[cur.sem]:[];
 var secField;
 if(cur.legacy){secField='<div class="col-md-6"><label class="form-label">Section name *</label><input class="form-control" name="name" value="'+esc(cur.name)+'" maxlength="60" required><div class="form-text" data-info>This older section is not registered in the Year module yet. Saving registers it under the department, year level and semester you choose.</div></div><div class="col-md-6"><label class="form-label">Number of students *</label><input type="number" min="1" max="'+CAP+'" class="form-control" name="students" value="'+esc(cur.students)+'" required></div>';}
 else{secField='<div class="col-md-8"><label class="form-label">Section *</label><select class="form-select" id="secPick"'+dis+' required><option value="">'+(semReady()?(secs.length?'Select section':'No section registered'):'Select department and year level first')+'</option>'+secs.map(function(s){return '<option value="'+s.id+'" data-stu="'+s.students+'"'+(s.id==cur.id?' selected':'')+'>'+esc(s.name)+' – '+s.students+' students</option>';}).join('')+'</select><div class="form-text" data-info>Sections come from the Year module. To add or rename a section, or change its number of students, go to Year Levels.</div></div><div class="col-md-4"><label class="form-label">Students</label><div class="form-control bg-light" id="secStuShow">'+(cur.id?esc(cur.students):'—')+'</div></div>';}
 list.innerHTML='<div class="row g-3">'
 +'<div class="col-md-4"><label class="form-label">Department *</label><select class="form-select" id="secDept" name="department_id"'+dis+' required><option value="">Select department</option>'+DEPTS.map(function(d){return '<option value="'+d.id+'"'+(d.id==cur.dept?' selected':'')+'>'+esc(d.code+' – '+d.name)+'</option>';}).join('')+'</select></div>'
 +'<div class="col-md-4"><label class="form-label">Year level *</label><select class="form-select" id="secYear" name="year_level"'+dis+' required>'+yearOpts(cur.dept,cur.year)+'</select></div>'
 +'<div class="col-md-4"><label class="form-label">Semester *</label><select class="form-select" id="secSem" name="semester"'+dis+' required>'+semOpts(cur.dept,cur.year,cur.sem)+'</select></div>'
 +secField
 +'<div class="col-12"><label class="form-label">Subjects *</label><div class="form-text" data-info>The subjects come from the Year module for the chosen department, year level and semester. Tick every subject the section will take, then give each one its date and time.</div><div id="secSubj">'+subjHtml()+'</div></div>'
 +(cur.old&&cur.old.length?'<div class="col-12 hint">Older exams of this section stay unchanged: '+esc(cur.old.join(', '))+'.</div>':'')
 +'<div class="col-12"><div class="proctor-sum" id="secSum"></div></div></div>';
 document.getElementById('secId').value=cur.id||0; sync();
 var dp=document.getElementById('secDept'),yr=document.getElementById('secYear'),sm=document.getElementById('secSem'),pk=document.getElementById('secPick');
 function reset(){capture();cur.picked={};}
 dp.addEventListener('change',function(){reset();cur.dept=+dp.value||0;cur.year=0;cur.sem=0;if(!cur.legacy){cur.id=0;cur.name='';cur.students='';}draw();});
 yr.addEventListener('change',function(){reset();cur.year=+yr.value||0;cur.sem=0;if(!cur.legacy){cur.id=0;cur.name='';cur.students='';}draw();});
 sm.addEventListener('change',function(){reset();cur.sem=+sm.value||0;if(!cur.legacy){cur.id=0;cur.name='';cur.students='';}draw();});
 if(pk)pk.addEventListener('change',function(){capture();var o=pk.options[pk.selectedIndex];cur.id=+pk.value||0;cur.name=o?o.textContent.split(' – ')[0]:'';cur.students=o&&o.dataset.stu?o.dataset.stu:'';draw();});
}
list.addEventListener('change',function(e){if(e.target.classList.contains('ys-on'))sync();});
function openSection(d,editing){cur=d||{id:0,name:'',students:'',dept:0,year:0,sem:0,subj:[],old:[]};cur.fixed=!!editing;cur.legacy=!!editing&&!cur.id&&!!cur.name;cur.picked={};(cur.subj||[]).forEach(function(s){if(s.ys)cur.picked[s.ys]={eid:s.eid,date:s.date,start:s.start,end:s.end};});
 var tt=document.getElementById('schedTitle');tt.innerHTML=(editing?'Edit section':'Add section')+' &middot; '+ROOMNAME;draw();
 new bootstrap.Modal(document.getElementById('schedModal')).show();}
var ab=document.getElementById('addSecBtn');if(ab)ab.onclick=function(){openSection(null,false);};
document.querySelectorAll('[data-editsec]').forEach(function(b){b.onclick=function(){var d=DATA[b.dataset.editsec];if(d){d=JSON.parse(JSON.stringify(d));openSection(d,true);}};});
// assign proctor modal
document.querySelectorAll('[data-assign]').forEach(function(b){b.onclick=function(){var id=b.dataset.assign,f=FREE[id]||{free:[],busy:[]};document.getElementById('asgLabel').textContent=b.dataset.label;
 var h='<p class="hint">Only teachers who are <b>free on that day and time</b> are listed. The teacher is notified and must accept.</p>';
 h+=f.free.length?f.free.map(function(t){return '<form method="post" class="pick"><input type="hidden" name="csrf_token" value="'+esc(CSRF)+'"><input type="hidden" name="action" value="assign"><input type="hidden" name="room_id" value="'+RID+'"><input type="hidden" name="exam_id" value="'+id+'"><input type="hidden" name="teacher_id" value="'+t.id+'"><div class="pick-main"><b>'+esc(t.name)+'</b><small>'+esc(t.no)+' · workload score '+esc(t.score)+'</small></div><button class="btn btn-sm btn-navy">Assign</button></form>';}).join(''):'<div class="alert alert-warning">No teacher is free for this exam.</div>';
 if(f.busy.length)h+='<div class="hint mt-3">Not available:</div>'+f.busy.map(function(t){return '<div class="pick off"><div class="pick-main"><b>'+esc(t.name)+'</b><small>'+esc(t.why)+'</small></div></div>';}).join('');
 document.getElementById('asgBody').innerHTML=h;new bootstrap.Modal(document.getElementById('assignModal')).show();};});
})();
</script>
<?php
/* ================================================================== GRID ================================================================== */
else:
    $all = array_map(fn($r) => ['room' => $r] + room_info($r, $exByRoom), $allRooms);
    $q = strtolower(trim((string) ($_GET['q'] ?? ''))); $flt = (string) ($_GET['f'] ?? '');
    $list = array_filter($all, function ($c) use ($q, $flt) {
        if ($flt === 'used' && !$c['exams']) return false; if ($flt === 'empty' && $c['exams']) return false; if ($flt === 'needs' && !$c['needs']) return false;
        if ($q !== '' && strpos(strtolower($c['room']['name'] . ' ' . implode(' ', array_map(fn($e) => $e['section'] . ' ' . $e['exam_code'] . ' ' . $e['name'], $c['exams']))), $q) === false) return false;
        return true;
    });
?>
<div class="row g-3 mb-3">
  <div class="col-6 col-lg-3"><div class="stat-card"><div class="stat-icon"><i class="bi bi-door-open"></i></div><div><div class="stat-value"><?= count($all) ?></div><div class="stat-label">Rooms</div></div></div></div>
  <div class="col-6 col-lg-3"><div class="stat-card"><div class="stat-icon"><i class="bi bi-calendar-event"></i></div><div><div class="stat-value"><?= array_sum(array_map(fn($c) => count($c['exams']), $all)) ?></div><div class="stat-label">Exams scheduled</div></div></div></div>
  <div class="col-6 col-lg-3"><div class="stat-card ok"><div class="stat-icon"><i class="bi bi-check2-circle"></i></div><div><div class="stat-value"><?= count(array_filter($all, fn($c) => $c['exams'] && !$c['needs'])) ?></div><div class="stat-label">Fully staffed rooms</div></div></div></div>
  <div class="col-6 col-lg-3"><?php $nn = count(array_filter($all, fn($c) => $c['needs'])); ?><div class="stat-card <?= $nn ? 'warn' : 'ok' ?>"><div class="stat-icon"><i class="bi bi-exclamation-triangle"></i></div><div><div class="stat-value"><?= $nn ?></div><div class="stat-label">Rooms that need proctors</div></div></div></div>
</div>
<form method="get" class="filter-bar fade-up"><input type="text" class="form-control" name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="Search room, section or subject">
  <select class="form-select" name="f" onchange="this.form.submit()"><option value="">All rooms</option><option value="used" <?= $flt === 'used' ? 'selected' : '' ?>>With exams</option><option value="empty" <?= $flt === 'empty' ? 'selected' : '' ?>>Empty</option><option value="needs" <?= $flt === 'needs' ? 'selected' : '' ?>>Need proctors</option></select>
  <span class="hint"><?= count($list) ?> of <?= count($all) ?> rooms</span><span class="ms-auto"></span>
  <?php if (user_can('rooms.add')): ?><button class="btn btn-navy" type="button" data-bs-toggle="modal" data-bs-target="#bulkModal"><i class="bi bi-plus-lg me-1"></i>Add rooms</button><?php endif; ?></form>
<?php if (!$all): ?><div class="card-panel"><?= empty_state('door-open', 'No rooms yet', 'Click Add rooms to create them.') ?></div>
<?php elseif (!$list): ?><div class="card-panel text-muted">No rooms match.</div>
<?php else: ?><div class="room-grid">
<?php foreach ($list as $i => $c): $r = $c['room']; ?>
  <div class="room-tile fade-up <?= $c['exams'] ? ($c['needs'] ? 'needs' : 'staffed') : '' ?>" style="--d:<?= min($i, 8) * 50 ?>ms">
    <div class="room-tile-head"><span class="room-ico"><i class="bi bi-door-open"></i></span><div><h3><?= e($r['name']) ?></h3><div class="hint">Capacity <?= (int) $r['capacity'] ?><?= $r['building'] ? ' · ' . e($r['building']) : '' ?></div></div><span class="ms-auto"></span>
      <?= $c['exams'] ? ($c['needs'] ? '<span class="badge-s b-red">Needs proctors</span>' : '<span class="badge-s b-green">All staffed</span>') : '<span class="badge-s b-gray">Empty</span>' ?></div>
    <div class="dept-counts"><div><b><?= count($c['sections']) ?><?= $r['max_sections'] ? '/' . (int) $r['max_sections'] : '' ?></b><span>Sections</span></div><div><b><?= count($c['exams']) ?></b><span>Exams</span></div><div><b><?= (int) $c['assigned'] ?>/<?= (int) $c['needed'] ?></b><span>Proctors</span></div></div>
    <div><?php foreach (array_slice($c['sections'], 0, 4) as $sc): ?><span class="badge-s b-blue me-1"><?= e($sc) ?></span><?php endforeach; ?><?= count($c['sections']) > 4 ? '<span class="hint">+' . (count($c['sections']) - 4) . ' more</span>' : '' ?></div>
    <div class="room-actions"><a class="btn btn-navy btn-sm" href="<?= e(url('admin/rooms.php?r=' . (int) $r['id'])) ?>">Open</a>
      <button class="btn btn-light btn-sm" type="button" data-bs-toggle="modal" data-bs-target="#roomModal" data-edit="#roomForm" data-id="<?= (int) $r['id'] ?>" data-name="<?= e($r['name']) ?>" data-building="<?= e($r['building']) ?>" data-capacity="<?= (int) $r['capacity'] ?>" data-max_sections="<?= e($r['max_sections']) ?>" data-status="<?= e($r['status']) ?>">Edit</button>
      <form method="post" class="d-flex flex-fill"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-danger btn-sm w-100" data-confirm="Delete room <?= e($r['name']) ?>?<?= $c['exams'] ? ' Its ' . count($c['exams']) . ' exam(s) are deleted too.' : '' ?>">Delete</button></form></div>
  </div>
<?php endforeach; ?></div><?php endif; ?>
<div class="modal fade" id="bulkModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="bulk">
  <div class="modal-header"><h5 class="modal-title">Add rooms</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body"><div class="row g-3">
    <div class="col-md-4"><label class="form-label">How many rooms *</label><input type="number" min="1" max="50" class="form-control" name="count" value="5" required></div>
    <div class="col-md-4"><label class="form-label">Name prefix</label><input class="form-control" name="prefix" value="Room" maxlength="40"></div>
    <div class="col-md-4"><label class="form-label">Start number</label><input type="number" min="1" class="form-control" name="start_no" value="101"></div>
    <div class="col-md-4"><label class="form-label">Capacity (students) *</label><input type="number" min="1" max="500" class="form-control" name="capacity" value="60" required></div>
    <div class="col-md-4"><label class="form-label">Building <span class="text-muted">(optional)</span></label><input class="form-control" name="building" maxlength="100"></div>
    <div class="col-md-4"><label class="form-label">Max sections <span class="text-muted">(optional)</span></label><input type="number" min="1" max="100" class="form-control" name="max_sections" placeholder="No limit"></div>
    <div class="col-12 hint">Capacity is the limit of students per section. Example: 5 rooms, prefix "Room", start 101 &rarr; Room 101 ... Room 105. Then Open each room to add sections, exams and proctors.</div></div></div>
  <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-navy" data-loading="Creating...">Create rooms</button></div></form></div></div></div>
<?php endif; ?>
<div class="modal fade" id="roomModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form method="post" id="roomForm"><?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value=""><input type="hidden" name="room_id" value="<?= (int) $rid ?>">
  <div class="modal-header"><h5 class="modal-title">Room</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body"><div class="row g-3">
    <div class="col-md-6"><label class="form-label">Room name *</label><input class="form-control" name="name" required maxlength="60"></div>
    <div class="col-md-6"><label class="form-label">Building <span class="text-muted">(optional)</span></label><input class="form-control" name="building" maxlength="100"></div>
    <div class="col-md-4"><label class="form-label">Capacity (students) *</label><input type="number" min="1" max="500" class="form-control" name="capacity" value="60" required></div>
    <div class="col-md-4"><label class="form-label">Max sections <span class="text-muted">(optional)</span></label><input type="number" min="1" max="100" class="form-control" name="max_sections" placeholder="No limit"></div>
    <div class="col-md-4"><label class="form-label">Status</label><select class="form-select" name="status"><option>Available</option><option>Maintenance</option></select></div>
    <div class="col-12 hint">Capacity is the most students one section may have in this room. Max sections is optional.</div></div></div>
  <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-navy" data-loading="Saving...">Save</button></div></form></div></div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
