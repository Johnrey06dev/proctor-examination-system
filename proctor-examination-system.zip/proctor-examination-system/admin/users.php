<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('admin');
$pdo = db();

if (require_post_csrf()) {
    $action = input_str('action', 20);
    $id = input_int('id');
    if ($action === 'delete') {
        $err = delete_user_account(input_int('id'), (int) $user['id']);
        $err ? flash('danger', $err) : flash('success', 'Account deleted.');
    } elseif ($action === 'create_admin') {
        $newRole = input_str('role', 12) === 'coordinator' ? 'coordinator' : 'admin';
        $name = input_str('full_name', 150); $email = strtolower(input_str('email', 150)); $pw = (string) ($_POST['password'] ?? '');
        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) flash('danger', 'Full name and a valid email are required.');
        elseif ($err = password_rules_error($pw)) flash('danger', $err);
        elseif (fetch_value('SELECT COUNT(*) FROM users WHERE email = ?', [$email])) flash('danger', 'That email is already used.');
        else {
            $pdo->prepare("INSERT INTO users (email, password_hash, full_name, role, status, created_at) VALUES (?,?,?,'" . $newRole . "','active',?)")->execute([$email, password_hash($pw, PASSWORD_DEFAULT), $name, now()]);
            log_activity('admin_created', 'user', (int) $pdo->lastInsertId(), null, null, ucfirst($newRole) . ' account ' . $email . ' created');
            flash('success', ($newRole === 'coordinator' ? 'Scheduler' : 'Administrator') . ' account created.');
        }
    } elseif ($action === 'email') {
        $em = strtolower(input_str('email', 150));
        if (!filter_var($em, FILTER_VALIDATE_EMAIL)) flash('danger', 'Enter a valid e-mail address.');
        elseif (fetch_value('SELECT COUNT(*) FROM users WHERE email = ? AND id <> ?', [$em, $id])) flash('danger', 'That e-mail is already used.');
        else {
            $pdo->prepare('UPDATE users SET email = ? WHERE id = ?')->execute([$em, $id]);
            log_activity('user_email', 'user', $id, null, null, 'E-mail changed to ' . $em);
            flash('success', 'E-mail updated (this is where OTP codes are sent).');
        }
    } elseif ($action === 'toggle') {
        $u = fetch_one('SELECT * FROM users WHERE id = ?', [$id]);
        if (!$u) flash('danger', 'User not found.');
        elseif ($id === (int) $user['id']) flash('danger', 'You cannot deactivate your own account.');
        else {
            $new = $u['status'] === 'active' ? 'inactive' : 'active';
            $pdo->prepare('UPDATE users SET status = ? WHERE id = ?')->execute([$new, $id]);
            log_activity('user_status', 'user', $id, $u['status'], $new, $u['email'] . ' set to ' . $new);
            if ($new === 'active' && $u['role'] === 'teacher' && !$u['last_login_at']) { send_account_mail($u['email'], 'Your ProctorSys account is approved', 'Hi ' . $u['full_name'] . ', the administrator approved your account. You can sign in with your Gmail and the password you chose.'); notify($id, 'Account approved', 'Your account is active.', 'info', 'teacher/dashboard.php'); }
            flash('success', 'Account is now ' . $new . '.');
        }
    } elseif ($action === 'reset') {
        $pw = (string) ($_POST['password'] ?? '');
        if ($err = password_rules_error($pw)) flash('danger', $err);
        elseif (fetch_one('SELECT id FROM users WHERE id = ?', [$id])) {
            $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($pw, PASSWORD_DEFAULT), $id]);
            log_activity('password_reset', 'user', $id, null, null, 'Password reset by administrator');
            flash('success', 'Password reset.');
        }
    }
    redirect('admin/users.php');
}
$rows = fetch_all('SELECT * FROM users ORDER BY role, full_name');

$pageTitle = 'User Accounts';
$activeNav = 'users';
require __DIR__ . '/../includes/header.php';
?>
<?php $pending = array_filter($rows, fn($u) => $u['role'] === 'teacher' && $u['status'] === 'inactive' && !$u['last_login_at']); if ($pending): ?>
<div class="card-panel fade-up" style="border-left:5px solid var(--gold)"><div class="panel-head"><h5><i class="bi bi-person-plus me-1"></i>Waiting for your approval <span class="badge bg-warning text-dark"><?= count($pending) ?></span></h5></div>
  <?php foreach ($pending as $u): ?><div class="d-flex flex-wrap justify-content-between align-items-center border-top py-2"><div><strong><?= e($u['full_name']) ?></strong> <span class="text-muted small"><?= e($u['email']) ?> &middot; registered <?= e(fmt_dt($u['created_at'])) ?></span></div>
    <div class="d-flex gap-1"><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $u['id'] ?>"><button class="btn btn-sm btn-success"><i class="bi bi-check2"></i> Approve</button></form>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $u['id'] ?>"><button class="btn btn-sm btn-outline-danger" data-confirm="Reject and delete this registration?"><i class="bi bi-x"></i> Reject</button></form></div></div><?php endforeach; ?></div>
<?php endif; ?>
<div class="card-panel">
  <div class="panel-head"><h5>All accounts</h5><button class="btn btn-navy" type="button" data-bs-toggle="modal" data-bs-target="#adminModal"><i class="bi bi-plus-lg me-1"></i>Add administrator</button></div>
  <div class="table-responsive"><table class="table table-modern align-middle">
    <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Last login</th><th></th></tr></thead><tbody>
    <?php foreach ($rows as $u): ?><tr><td><?= e($u['full_name']) ?></td><td><?= e($u['email']) ?> <button type="button" class="btn btn-sm btn-link p-0" title="Edit e-mail" data-bs-toggle="modal" data-bs-target="#mailModal" data-edit="#mailForm" data-id="<?= (int) $u['id'] ?>" data-email="<?= e($u['email']) ?>"><i class="bi bi-pencil"></i></button></td><td><?= status_badge($u['role'] === 'coordinator' ? 'Scheduler' : ucfirst($u['role'])) ?></td><td><?= status_badge(ucfirst($u['status'])) ?></td><td class="small"><?= e(fmt_dt($u['last_login_at'])) ?></td>
      <td class="text-end text-nowrap">
        <button class="btn btn-sm btn-light" type="button" data-bs-toggle="modal" data-bs-target="#resetModal" data-edit="#resetForm" data-id="<?= (int) $u['id'] ?>" title="Reset password"><i class="bi bi-key"></i></button>
        <?php if ((int) $u['id'] !== (int) $user['id']): ?>
        <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
          <button class="btn btn-sm <?= $u['status'] === 'active' ? 'btn-outline-danger' : 'btn-outline-success' ?>" type="submit" data-confirm="<?= $u['status'] === 'active' ? 'Deactivate' : 'Activate' ?> this account?"><i class="bi bi-<?= $u['status'] === 'active' ? 'person-x' : 'person-check' ?>"></i></button></form>
        <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $u['id'] ?>"><button class="btn btn-sm btn-danger" type="submit" title="Delete account" data-confirm="PERMANENTLY delete <?= e($u['email']) ?>? <?= $u['role'] === 'teacher' ? 'Their proctor assignments and availability are removed too.' : '' ?>"><i class="bi bi-trash"></i></button></form>
        <?php endif; ?>
      </td></tr><?php endforeach; ?></tbody></table></div>
</div>
<div class="modal fade" id="adminModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form method="post" autocomplete="off"><?= csrf_field() ?><input type="hidden" name="action" value="create_admin">
  <div class="modal-header"><h5 class="modal-title">New staff account</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body"><div class="mb-3"><label class="form-label">Full name *</label><input class="form-control" name="full_name" required></div>
    <div class="mb-3"><label class="form-label">Email *</label><input class="form-control" type="email" name="email" required></div>
    <div class="mb-3"><label class="form-label">Role *</label><select class="form-select" name="role"><option value="coordinator">Scheduler / Coordinator – can arrange schedules &amp; proctors</option><option value="admin">Administrator – full access</option></select></div>
    <div class="mb-3"><label class="form-label">Password *</label><input class="form-control" type="password" name="password" minlength="8" required autocomplete="new-password"></div></div>
  <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-navy" type="submit">Create</button></div></form></div></div></div>
<div class="modal fade" id="resetModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form method="post" id="resetForm" autocomplete="off"><?= csrf_field() ?><input type="hidden" name="action" value="reset"><input type="hidden" name="id" value="">
  <div class="modal-header"><h5 class="modal-title">Reset password</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body"><label class="form-label">New password</label><input class="form-control" type="password" name="password" minlength="8" required autocomplete="new-password"><div class="form-text">At least 8 characters with letters and numbers.</div></div>
  <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-navy" type="submit">Reset password</button></div></form></div></div></div>
<div class="modal fade" id="mailModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form method="post" id="mailForm"><?= csrf_field() ?><input type="hidden" name="action" value="email"><input type="hidden" name="id" value="">
  <div class="modal-header"><h5 class="modal-title">Registered e-mail (Gmail)</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body"><input class="form-control" type="email" name="email" required><div class="form-text">OTP codes and notification e-mails go here.</div></div>
  <div class="modal-footer"><button class="btn btn-navy">Save</button></div></form></div></div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
