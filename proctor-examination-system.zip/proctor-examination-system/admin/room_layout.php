<?php
require_once __DIR__ . "/../includes/bootstrap.php";
$r = (int) ($_GET["room_id"] ?? 0);
if (!$r && !empty($_GET["exam_id"])) $r = (int) fetch_value("SELECT room_id FROM examinations WHERE id = ?", [(int) $_GET["exam_id"]]);
redirect("admin/rooms.php" . ($r ? "?r=" . $r : ""));
