<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_perm('papers.view');
require_perm_for_post('papers.manage');
$pdo = db();
$pt = new PaperTracker($pdo);

/* Paper transactions are created AUTOMATICALLY when a proctor accepts an exam (students + 5 extra copies). */

if (is_post() && require_post_csrf() && input_str('action', 12) === 'delete') {
    $r = $pt->deleteCompleted(input_int('id'), (int) $user['id']);
    if ($r['ok']) flash('success', 'Completed paper record deleted.'); else foreach ($r['errors'] as $er) flash('danger', $er);
    redirect('admin/papers.php' . qs());
}
if (is_post() && require_post_csrf() && input_str('action', 12) === 'status') {
    $r = $pt->advance(input_int('id'), input_str('to', 30), (int) $user['id']);
    if ($r['ok']) flash('success', 'Paper status updated.'); else foreach ($r['errors'] as $er) flash('danger', $er);
    redirect('admin/papers.php' . qs());
}

$fst = $_GET['status'] ?? '';
$q = trim($_GET['q'] ?? '');
$where = ['1=1']; $params = [];
if (in_array($fst, PaperTracker::STATUSES, true)) { $where[] = 'p.status = ?'; $params[] = $fst; }
if ($q !== '') { $where[] = '(p.transaction_no LIKE ? OR e.exam_code LIKE ? OR b.name LIKE ? OR x.section_name LIKE ?)'; array_push($params, "%$q%", "%$q%", "%$q%", "%$q%"); }
// one row per SUBJECT + SECTION (= one examination); the proctor shown is the one currently assigned
$rows = fetch_all("SELECT p.*, e.exam_code, e.exam_date, e.start_time, e.end_time, b.name AS subject_name, d.code AS dept_code, x.section_name, x.examinees,
        (SELECT u.full_name FROM proctor_assignments a JOIN teachers t ON t.id = a.teacher_id JOIN users u ON u.id = t.user_id
          WHERE a.examination_id = e.id AND a.status IN ('Confirmed','Pending Review') ORDER BY (a.status = 'Confirmed') DESC, a.id DESC LIMIT 1) AS proctor_name
    FROM paper_distribution p JOIN examinations e ON e.id = p.examination_id JOIN subjects b ON b.id = e.subject_id JOIN departments d ON d.id = e.department_id
    LEFT JOIN exam_sections x ON x.examination_id = e.id
    WHERE " . implode(' AND ', $where) . ' ORDER BY e.exam_date, e.start_time, p.id', $params);
$counts = [];
foreach (fetch_all('SELECT status, COUNT(*) AS n FROM paper_distribution GROUP BY status') as $c_) $counts[$c_['status']] = (int) $c_['n'];
$NEXT = ['Pending' => ['Preparing'], 'Preparing' => ['Ready for Release'], 'Ready for Release' => ['Released']];

$pageTitle = 'Paper Tracking';
$activeNav = 'papers';
require __DIR__ . '/../includes/header.php';
?>
<div class="row g-2 mb-3">
  <?php foreach (PaperTracker::STATUSES as $s): ?>
    <div class="col-6 col-md"><a class="text-decoration-none" href="<?= e(url('admin/papers.php?status=' . urlencode($s))) ?>"><div class="stat-card"><div><div class="stat-value"><?= (int) ($counts[$s] ?? 0) ?></div><div class="stat-label"><?= e($s) ?></div></div></div></a></div>
  <?php endforeach; ?>
</div>
<div class="card-panel">
  <form class="filter-bar" method="get">
    <div style="flex:2"><label class="form-label">Search</label><input class="form-control" name="q" value="<?= e($q) ?>" placeholder="Transaction, exam code or name"></div>
    <div><label class="form-label">Status</label><select class="form-select" name="status"><option value="">All</option><?php foreach (PaperTracker::STATUSES as $s): ?><option <?= $fst === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?></select></div>
    <div class="d-flex gap-2"><button class="btn btn-navy" type="submit">Filter</button><a class="btn btn-light" href="<?= e(url('admin/papers.php')) ?>">Reset</a></div>
    <div class="ms-auto"></div>
  </form>
</div>
<div class="card-panel">
  <?php if (!$rows): ?><?= empty_state('file-earmark-text', 'No paper records yet', 'A record appears automatically for each subject when its proctor accepts: students + 5 extra copies.') ?><?php else: ?>
  <div class="table-responsive"><table class="table table-modern align-middle">
    <thead><tr><th>Subject</th><th>Dept</th><th>Section</th><th class="text-center">Students</th><th class="text-center">Extra</th><th class="text-center">Required papers</th><th>Exam date</th><th>Time</th><th>Proctor</th><th>Status</th><th></th></tr></thead><tbody>
    <?php foreach ($rows as $p): $stu = (int) $p['examinees']; $nx = $NEXT[$p['status']] ?? []; ?><tr>
      <td><strong><?= e($p['subject_name']) ?></strong><div class="small text-muted"><?= e($p['exam_code']) ?> &middot; <?= e($p['transaction_no']) ?></div></td>
      <td><?= e($p['dept_code']) ?></td><td><?= e($p['section_name'] ?? '—') ?></td>
      <td class="text-center"><?= $stu ?></td><td class="text-center"><?= (int) PaperTracker::EXTRA_COPIES ?></td><td class="text-center"><strong><?= (int) $p['paper_sets'] ?></strong></td>
      <td><?= e(fmt_date($p['exam_date'])) ?></td><td class="text-nowrap"><?= e(time_range($p['start_time'], $p['end_time'])) ?></td>
      <td><?= $p['proctor_name'] ? e($p['proctor_name']) : '<span class="text-muted">—</span>' ?></td>
      <td><?= status_badge($p['status']) ?></td>
      <td class="text-end text-nowrap">
        <?php if ($nx): ?><form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="status"><input type="hidden" name="id" value="<?= (int) $p['id'] ?>"><input type="hidden" name="to" value="<?= e($nx[0]) ?>">
          <button class="btn btn-sm btn-navy" title="Move to <?= e($nx[0]) ?>"><?= e($nx[0] === 'Ready for Release' ? 'Mark ready' : ($nx[0] === 'Released' ? 'Release' : 'Start preparing')) ?></button></form><?php endif; ?>
        <?php if ($p['status'] === 'Completed'): ?><form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $p['id'] ?>"><button class="btn btn-sm btn-outline-danger" title="Delete this completed record" data-confirm="Delete the completed paper record of <?= e($p['subject_name']) ?> (<?= e($p['section_name'] ?? '') ?>)?"><i class="bi bi-trash"></i></button></form><?php endif; ?>
        <a class="btn btn-sm btn-light" href="<?= e(url('admin/paper_view.php?id=' . $p['id'])) ?>"><i class="bi bi-eye"></i></a></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</div>
<?php
require __DIR__ . '/../includes/footer.php';
