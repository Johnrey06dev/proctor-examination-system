<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../backend/ReportBuilder.php';
require_once __DIR__ . '/../backend/SimplePDF.php';
$user = require_role('staff');

$type = $_GET['type'] ?? 'assignments';
if (!isset(ReportBuilder::TYPES[$type])) $type = 'assignments';
$f = [
    'from' => $_GET['from'] ?? '', 'to' => $_GET['to'] ?? '', 'dept' => (int) ($_GET['dept'] ?? 0),
    'teacher' => (int) ($_GET['teacher'] ?? 0), 'subject' => (int) ($_GET['subject'] ?? 0), 'status' => $_GET['status'] ?? '',
];
$report = (new ReportBuilder(db()))->build($type, $f);
$format = $_GET['format'] ?? 'html';

if ($format === 'csv') {
    log_activity('report_exported', 'report', null, null, 'CSV', $report['title'] . ' exported to CSV');
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $type . '_' . date('Ymd_His') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, [$report['title']]);
    fputcsv($out, [$report['filters']]);
    fputcsv($out, $report['columns']);
    foreach ($report['rows'] as $row) {
        // neutralise spreadsheet formulas
        fputcsv($out, array_map(fn($v) => is_string($v) && preg_match('/^[=+\-@]/', $v) ? "'" . $v : $v, $row));
    }
    fclose($out);
    exit;
}
if ($format === 'pdf') {
    log_activity('report_exported', 'report', null, null, 'PDF', $report['title'] . ' exported to PDF');
    $pdf = SimplePDF::table($report['title'], $report['filters'], $report['columns'], $report['rows']);
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $type . '_' . date('Ymd_His') . '.pdf"');
    header('Content-Length: ' . strlen($pdf));
    echo $pdf;
    exit;
}

$print = isset($_GET['print']);
$pageTitle = 'Reports';
$activeNav = 'reports';
if ($print) {
    echo '<!doctype html><html><head><meta charset="utf-8"><title>' . e($report['title']) . '</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body{padding:24px;font-size:12px} h3{color:#0b2545} th{background:#e9edf3!important} @page{size:landscape;margin:12mm}</style></head><body onload="window.print()">
    <h3>' . e($report['title']) . '</h3><div class="text-muted mb-2">' . e($report['filters']) . ' · Generated ' . e(date('M d, Y g:i A')) . ' by ' . e($user['name']) . '</div>
    <table class="table table-sm table-bordered"><thead><tr>';
    foreach ($report['columns'] as $c) echo '<th>' . e($c) . '</th>';
    echo '</tr></thead><tbody>';
    foreach ($report['rows'] as $r) { echo '<tr>'; foreach ($r as $v) echo '<td>' . e($v) . '</td>'; echo '</tr>'; }
    echo '</tbody></table><div class="text-muted">' . count($report['rows']) . ' record(s)</div></body></html>';
    exit;
}

$depts = dept_list(); $subjects = subject_list(); $teachers = teacher_list();
require __DIR__ . '/../includes/header.php';
?>
<div class="card-panel">
  <form class="filter-bar" method="get">
    <div style="flex:2;min-width:240px"><label class="form-label">Report</label><select class="form-select" name="type"><?php foreach (ReportBuilder::TYPES as $k => $l): ?><option value="<?= e($k) ?>" <?= $type === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label">From</label><input type="date" class="form-control" name="from" value="<?= e($f['from']) ?>"></div>
    <div><label class="form-label">To</label><input type="date" class="form-control" name="to" value="<?= e($f['to']) ?>"></div>
    <div><label class="form-label">Department</label><select class="form-select" name="dept"><?= options_html($depts, 'id', 'code', $f['dept'], 'All') ?></select></div>
    <div><label class="form-label">Teacher</label><select class="form-select" name="teacher"><?= options_html($teachers, 'id', fn($t) => $t['teacher_no'] . ' ' . $t['full_name'], $f['teacher'], 'All') ?></select></div>
    <div><label class="form-label">Subject</label><select class="form-select" name="subject"><?= options_html($subjects, 'id', 'code', $f['subject'], 'All') ?></select></div>
    <div><label class="form-label">Exam status</label><select class="form-select" name="status"><option value="">All</option><?php foreach (['Scheduled', 'Completed', 'Cancelled'] as $s): ?><option <?= $f['status'] === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?></select></div>
    <div><button class="btn btn-navy" type="submit"><i class="bi bi-funnel me-1"></i>Generate</button></div>
  </form>
</div>
<div class="card-panel">
  <div class="panel-head">
    <div><h5><?= e($report['title']) ?></h5><div class="small text-muted"><?= e($report['filters']) ?> · <?= count($report['rows']) ?> record(s)</div></div>
    <div class="d-flex gap-2 no-print">
      <a class="btn btn-sm btn-outline-navy" href="<?= e(url('admin/reports.php' . qs(['format' => 'csv']))) ?>"><i class="bi bi-filetype-csv me-1"></i>CSV</a>
      <a class="btn btn-sm btn-outline-navy" href="<?= e(url('admin/reports.php' . qs(['format' => 'pdf']))) ?>"><i class="bi bi-filetype-pdf me-1"></i>PDF</a>
      <a class="btn btn-sm btn-navy" target="_blank" href="<?= e(url('admin/reports.php' . qs(['print' => 1]))) ?>"><i class="bi bi-printer me-1"></i>Print</a>
    </div>
  </div>
  <?php if (!$report['rows']): ?><?= empty_state('file-earmark-x', 'No records match these filters') ?><?php else: ?>
  <div class="table-responsive"><table class="table table-modern table-sm align-middle">
    <thead><tr><?php foreach ($report['columns'] as $c): ?><th><?= e($c) ?></th><?php endforeach; ?></tr></thead><tbody>
    <?php foreach ($report['rows'] as $r): ?><tr><?php foreach ($r as $v): ?><td><?= e($v) ?></td><?php endforeach; ?></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
