<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_perm('departments.view');
require_perm_for_post('departments.edit');
$pdo = db();

if (require_post_csrf()) {
    $action = input_str('action', 20);
    $id = input_int('id');
    if ($action === 'save') {
        $code = strtoupper(input_str('code', 20));
        $name = input_str('name', 150);
        $desc = input_str('description', 255);
        if ($code === '' || $name === '') {
            flash('danger', 'Department code and name are required.');
        } elseif (fetch_value('SELECT COUNT(*) FROM departments WHERE (code = ? OR name = ?) AND id <> ?', [$code, $name, $id])) {
            flash('danger', 'A department with the same code or name already exists.');
        } else {
            if ($id) {
                $pdo->prepare('UPDATE departments SET code=?, name=?, description=? WHERE id=?')->execute([$code, $name, $desc, $id]);
                log_activity('department_updated', 'department', $id, null, null, 'Department ' . $code . ' updated');
                flash('success', 'Department updated.');
            } else {
                $pdo->prepare('INSERT INTO departments (code, name, description, created_at) VALUES (?,?,?,?)')->execute([$code, $name, $desc, now()]);
                log_activity('department_created', 'department', (int) $pdo->lastInsertId(), null, null, 'Department ' . $code . ' created');
                flash('success', 'Department added.');
            }
        }
    } elseif ($action === 'delete') {
        $d = fetch_one('SELECT code FROM departments WHERE id = ?', [$id]);
        $pdo->beginTransaction();
        try {
            $ids = function ($sql) use ($pdo, $id) { $q = $pdo->prepare($sql); $q->execute([$id]); return $q->fetchAll(PDO::FETCH_COLUMN); };
            foreach ($ids('SELECT id FROM examinations WHERE department_id = ?') as $e1) purge_exam($pdo, (int) $e1);
            $pdo->prepare('DELETE FROM class_sections WHERE department_id = ?')->execute([$id]);
            $pdo->prepare('DELETE FROM year_configs WHERE department_id = ?')->execute([$id]);
            foreach ($ids('SELECT s.id FROM subjects s WHERE s.department_id = ?') as $sid) {
                foreach (fetch_all('SELECT id FROM examinations WHERE subject_id = ?', [$sid]) as $e2) purge_exam($pdo, (int) $e2['id']);
                $pdo->prepare('DELETE FROM exam_sections WHERE subject_id = ?')->execute([$sid]);
                $pdo->prepare('DELETE FROM subjects WHERE id = ?')->execute([$sid]);
            }
            $uids = $ids('SELECT user_id FROM teachers WHERE department_id = ?');
            foreach ($uids as $uid) { $er = delete_user_account((int) $uid, (int) $user['id']); if ($er) throw new RuntimeException($er); }
            $pdo->prepare('DELETE FROM departments WHERE id = ?')->execute([$id]);
            $pdo->commit(); log_activity('department_deleted', 'department', $id, null, null, 'Department ' . ($d['code'] ?? $id) . ' deleted');
            flash('success', 'Department deleted (with its year levels, sections, subjects, examinations and teachers).');
        } catch (Throwable $e) { $pdo->rollBack(); flash('danger', 'Could not delete: ' . $e->getMessage()); }
    }
    redirect('admin/departments.php');
}

$rows = fetch_all('SELECT d.*,
    (SELECT COUNT(*) FROM teachers t WHERE t.department_id = d.id) AS teachers,
    (SELECT COUNT(*) FROM subjects s WHERE s.department_id = d.id) AS subjects,
    (SELECT COUNT(*) FROM examinations e WHERE e.department_id = d.id) AS exams
    FROM departments d ORDER BY d.code');

$viewId = (int) ($_GET['view'] ?? 0);
$view = $viewId ? fetch_one('SELECT * FROM departments WHERE id = ?', [$viewId]) : null;
if ($view) {
    $vTeachers = fetch_all('SELECT t.teacher_no, u.full_name, t.specialization FROM teachers t JOIN users u ON u.id = t.user_id WHERE t.department_id = ? ORDER BY u.full_name', [$viewId]);
    $vSubjects = fetch_all('SELECT code, name FROM subjects WHERE department_id = ? ORDER BY code', [$viewId]);
}

$pageTitle = 'Departments';
$activeNav = 'departments';
require __DIR__ . '/../includes/header.php';
?>
<div class="card-panel">
  <div class="panel-head"><h5>Departments</h5>
    <button class="btn btn-navy" type="button" data-bs-toggle="modal" data-bs-target="#deptModal" data-reset-form="#deptForm"><i class="bi bi-plus-lg me-1"></i>Add department</button></div>
  <?php if (!$rows): ?><?= empty_state('building', 'No departments yet') ?><?php else: ?>
  <div class="table-responsive"><table class="table table-modern align-middle">
    <thead><tr><th>Code</th><th>Name</th><th>Description</th><th class="text-center">Teachers</th><th class="text-center">Subjects</th><th class="text-center">Exams</th><th></th></tr></thead><tbody>
    <?php foreach ($rows as $d): $dep = $d['teachers'] + $d['subjects'] + $d['exams']; ?>
      <tr><td><strong><?= e($d['code']) ?></strong></td><td><?= e($d['name']) ?></td><td class="text-muted"><?= e($d['description']) ?></td>
        <td class="text-center"><?= (int) $d['teachers'] ?></td><td class="text-center"><?= (int) $d['subjects'] ?></td><td class="text-center"><?= (int) $d['exams'] ?></td>
        <td class="text-end text-nowrap">
          <a class="btn btn-sm btn-light" href="<?= e(url('admin/departments.php?view=' . $d['id'])) ?>" title="View"><i class="bi bi-eye"></i></a>
          <button class="btn btn-sm btn-light" type="button" data-bs-toggle="modal" data-bs-target="#deptModal" data-edit="#deptForm" data-id="<?= (int) $d['id'] ?>" data-code="<?= e($d['code']) ?>" data-name="<?= e($d['name']) ?>" data-description="<?= e($d['description']) ?>"><i class="bi bi-pencil"></i></button>
          <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
            <button class="btn btn-sm btn-outline-danger" type="submit" data-confirm="Delete department <?= e($d['code']) ?>? Its subjects, examinations and teacher accounts will be deleted too. This cannot be undone."><i class="bi bi-trash"></i></button></form>
        </td></tr>
    <?php endforeach; ?></tbody></table></div><?php endif; ?>
</div>

<?php if ($view): ?>
<div class="card-panel">
  <div class="panel-head"><h5><?= e($view['code']) ?> – <?= e($view['name']) ?></h5><a class="btn btn-sm btn-light" href="<?= e(url('admin/departments.php')) ?>">Close</a></div>
  <div class="row g-3">
    <div class="col-md-6"><h6>Teachers (<?= count($vTeachers) ?>)</h6>
      <?php if (!$vTeachers): ?><div class="text-muted small">None</div><?php endif; ?>
      <ul class="list-unstyled small mb-0"><?php foreach ($vTeachers as $t): ?><li class="py-1 border-bottom"><?= e($t['teacher_no']) ?> · <?= e($t['full_name']) ?> <span class="text-muted">(<?= e($t['specialization']) ?>)</span></li><?php endforeach; ?></ul></div>
    <div class="col-md-6"><h6>Subjects (<?= count($vSubjects) ?>)</h6>
      <?php if (!$vSubjects): ?><div class="text-muted small">None</div><?php endif; ?>
      <ul class="list-unstyled small mb-0"><?php foreach ($vSubjects as $s): ?><li class="py-1 border-bottom"><?= e($s['code']) ?> · <?= e($s['name']) ?></li><?php endforeach; ?></ul></div>
  </div>
</div>
<?php endif; ?>

<div class="modal fade" id="deptModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content">
  <form method="post" id="deptForm"><?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="">
    <div class="modal-header"><h5 class="modal-title">Department</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
      <div class="mb-3"><label class="form-label">Code *</label><input class="form-control" name="code" required maxlength="20" placeholder="CCS"></div>
      <div class="mb-3"><label class="form-label">Name *</label><input class="form-control" name="name" required maxlength="150"></div>
      <div class="mb-3"><label class="form-label">Description</label><input class="form-control" name="description" maxlength="255"></div>
    </div>
    <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-navy" type="submit" data-loading="Saving...">Save</button></div>
  </form></div></div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
