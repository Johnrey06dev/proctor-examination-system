<?php
// The Subjects panel was replaced by the Year module (Department > Year level > Semester > Subjects).
require_once __DIR__ . '/../includes/bootstrap.php';
redirect('admin/years.php');
