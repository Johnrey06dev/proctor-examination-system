<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_perm('exams.view');
if (is_post() && !is_staff()) deny_access($user);
$pdo = db();
$sched = new ProctorScheduler($pdo);

if (require_post_csrf()) {
    $a = input_str('action', 20); $id = input_int('id');
    try {
        if ($a === 'master') {
            $on = input_int('on') ? '1' : '0';
            if (fetch_value("SELECT COUNT(*) FROM system_settings WHERE setting_key = 'public_schedule'")) $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'public_schedule'")->execute([$on]);
            else $pdo->prepare("INSERT INTO system_settings (setting_key, setting_value, description) VALUES ('public_schedule', ?, 'The exam schedule is shown on the public home page')")->execute([$on]);
            flash('success', $on === '1' ? 'The schedule is now shown on the public home page.' : 'The public home page no longer shows the schedule.');
        } elseif ($a === 'toggle') {
            $pdo->prepare('UPDATE examinations SET is_public = 1 - is_public WHERE id = ?')->execute([$id]);
            flash('success', 'Visibility changed.');
        } elseif ($a === 'edit') {
            $pdo->beginTransaction();
            $errs = exam_reschedule($pdo, $sched, $id, input_int('room_id'), (string) ($_POST['exam_date'] ?? ''), (string) ($_POST['start_time'] ?? ''), (string) ($_POST['end_time'] ?? ''));
            if ($errs) { $pdo->rollBack(); foreach ($errs as $er) flash('danger', $er); }
            else { log_activity('exam_rescheduled', 'examination', $id, null, null, 'Exam moved from the posted schedule'); $pdo->commit(); flash('success', 'Schedule updated. The assigned proctors were notified.'); }
        } elseif ($a === 'delete') {
            $x = fetch_one('SELECT exam_code FROM examinations WHERE id = ?', [$id]);
            if (!$x) flash('danger', 'Examination not found.');
            else {
                $pdo->beginTransaction();
                try { purge_exam($pdo, $id); $pdo->commit(); log_activity('exam_deleted', 'examination', $id, null, null, 'Examination ' . $x['exam_code'] . ' deleted from the posted schedule'); flash('success', $x['exam_code'] . ' deleted together with its proctors, attendance and paper record.'); }
                catch (Throwable $e) { $pdo->rollBack(); flash('danger', 'Could not delete: ' . $e->getMessage()); }
            }
        }
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); flash('danger', 'Could not save: ' . (APP_DEBUG ? $e->getMessage() : 'unexpected error.')); }
    redirect('admin/schedule_board.php' . qs());
}

$f = ['dept' => (int) ($_GET['dept'] ?? 0), 'year' => (int) ($_GET['year'] ?? 0), 'q' => trim((string) ($_GET['q'] ?? '')), 'past' => !empty($_GET['past'])];
$board = schedule_board($f, true);
$depts = dept_list();
$rooms = fetch_all("SELECT id, name, capacity FROM rooms ORDER BY name");
$on = (get_settings()['public_schedule'] ?? '1') === '1';
$pageTitle = 'Posted Schedule';
$activeNav = 'board';
require __DIR__ . '/../includes/header.php';
?>
<div class="card-panel d-flex flex-wrap align-items-center gap-3">
  <span class="room-ico"><i class="bi bi-megaphone"></i></span>
  <div class="flex-fill"><h5 class="mb-0">Posted exam schedule</h5><div class="hint">What students see on the home page (no login): date, time and room. Proctors are never shown.</div></div>
  <a class="btn btn-light" target="_blank" href="<?= e(url('index.php?public=1')) ?>"><i class="bi bi-box-arrow-up-right me-1"></i>View public page</a>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="master"><input type="hidden" name="on" value="<?= $on ? 0 : 1 ?>">
    <button class="btn <?= $on ? 'btn-outline-danger' : 'btn-navy' ?>" data-confirm="<?= $on ? 'Hide the schedule from the public home page?' : 'Show the schedule on the public home page?' ?>"><?= $on ? '<i class="bi bi-eye-slash me-1"></i>Stop posting' : '<i class="bi bi-megaphone me-1"></i>Post schedule' ?></button></form>
  <span class="badge-s <?= $on ? 'b-green' : 'b-gray' ?>"><?= $on ? 'Posted' : 'Not posted' ?></span>
</div>
<div class="card-panel">
  <form class="filter-bar" method="get">
    <div><label class="form-label">Search</label><input class="form-control" name="q" value="<?= e($f['q']) ?>" placeholder="Section, subject or room"></div>
    <div><label class="form-label">Department</label><select class="form-select" name="dept" onchange="this.form.submit()"><?= options_html($depts, 'id', 'code', $f['dept'] ?: null, 'All') ?></select></div>
    <div><label class="form-label">Year level</label><select class="form-select" name="year" onchange="this.form.submit()"><option value="0">All</option><?php foreach (year_level_options() as $k => $v): ?><option value="<?= $k ?>" <?= $f['year'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?><option value="9" <?= $f['year'] === 9 ? 'selected' : '' ?>>Other</option></select></div>
    <div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="past" value="1" id="pst" <?= $f['past'] ? 'checked' : '' ?> onchange="this.form.submit()"><label class="form-check-label" for="pst">Include past</label></div>
    <button class="btn btn-navy">Filter</button><span class="hint ms-auto"><?= $board['total'] ?> exam(s)</span>
  </form>
</div>
<?php if (!$board['total']): ?><div class="card-panel"><?= empty_state('calendar-x', 'No exams to post', 'Add sections to a room (Rooms) or schedule exams (Exam Schedule) and they appear here.') ?></div><?php endif; ?>
<?php foreach ($board['years'] as $y): ?>
<h5 class="pub-year-h mt-4"><i class="bi bi-mortarboard me-2"></i><?= e($y['label']) ?></h5>
<?php foreach ($y['sections'] as $s): ?>
<div class="card-panel fade-up">
  <div class="d-flex flex-wrap align-items-center gap-2 mb-2"><h6 class="mb-0"><?= e($s['name']) ?></h6><span class="badge-s b-blue"><?= e($s['dept']) ?></span><?php if ($s['semester']): ?><span class="badge-s b-gray"><?= e($s['semester']) ?></span><?php endif; ?><span class="hint ms-auto"><?= $s['students'] ?> students &middot; <?= count($s['exams']) ?> exam(s)</span></div>
  <div class="table-responsive"><table class="table table-modern align-middle mb-0"><thead><tr><th>Date</th><th>Time</th><th>Subject</th><th>Room</th><th>Status</th><th></th></tr></thead><tbody>
  <?php foreach ($s['exams'] as $x): ?><tr class="<?= $x['is_public'] ? '' : 'text-muted' ?>">
    <td class="text-nowrap"><?= e(fmt_date($x['exam_date'])) ?></td><td class="text-nowrap"><?= e(time_range($x['start_time'], $x['end_time'])) ?></td>
    <td><b><?= e($x['subject']) ?></b><div class="small text-muted"><?= e($x['exam_code']) ?></div></td><td><?= e($x['room']) ?></td>
    <td><span class="badge-s <?= $x['is_public'] ? 'b-green' : 'b-gray' ?>"><?= $x['is_public'] ? 'Posted' : 'Hidden' ?></span></td>
    <td class="text-end text-nowrap">
      <button class="btn btn-sm btn-light" type="button" data-edit-exam="<?= (int) $x['id'] ?>" data-room="<?= (int) $x['room_id'] ?>" data-date="<?= e($x['exam_date']) ?>" data-start="<?= e(substr($x['start_time'], 0, 5)) ?>" data-end="<?= e(substr($x['end_time'], 0, 5)) ?>" data-title="<?= e($s['name'] . ' · ' . $x['subject']) ?>" title="Edit date, time and room"><i class="bi bi-pencil"></i></button>
      <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $x['id'] ?>"><button class="btn btn-sm btn-light" title="<?= $x['is_public'] ? 'Hide from the public page' : 'Show on the public page' ?>"><i class="bi bi-eye<?= $x['is_public'] ? '-slash' : '' ?>"></i></button></form>
      <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $x['id'] ?>"><button class="btn btn-sm btn-outline-danger" title="Delete" data-confirm="Delete <?= e($x['subject']) ?> of <?= e($s['name']) ?>? Its proctor assignment, attendance and paper record are deleted too."><i class="bi bi-trash"></i></button></form>
    </td></tr><?php endforeach; ?></tbody></table></div>
</div>
<?php endforeach; endforeach; ?>

<div class="modal fade" id="editExam" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="edit"><input type="hidden" name="id" id="eeId">
  <div class="modal-header"><h5 class="modal-title" id="eeTitle">Edit schedule</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body"><div class="row g-3">
    <div class="col-md-6"><label class="form-label">Exam date *</label><input type="date" class="form-control" name="exam_date" id="eeDate" required><div class="form-text" data-info>The room, the section and every assigned proctor are checked again. Assigned proctors are notified of the change.</div></div>
    <div class="col-md-6"><label class="form-label">Room *</label><select class="form-select" name="room_id" id="eeRoom" required><?php foreach ($rooms as $r): ?><option value="<?= $r['id'] ?>"><?= e($r['name']) ?> (<?= (int) $r['capacity'] ?> seats)</option><?php endforeach; ?></select></div>
    <div class="col-md-6"><label class="form-label">Start *</label><input type="time" class="form-control" name="start_time" id="eeStart" required></div>
    <div class="col-md-6"><label class="form-label">End *</label><input type="time" class="form-control" name="end_time" id="eeEnd" required></div>
  </div></div>
  <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-navy" data-loading="Saving...">Save changes</button></div></form></div></div></div>
<script>
document.querySelectorAll('[data-edit-exam]').forEach(function(b){b.addEventListener('click',function(){
  document.getElementById('eeId').value=b.dataset.editExam;document.getElementById('eeDate').value=b.dataset.date;document.getElementById('eeRoom').value=b.dataset.room;
  document.getElementById('eeStart').value=b.dataset.start;document.getElementById('eeEnd').value=b.dataset.end;document.getElementById('eeTitle').textContent='Edit schedule · '+b.dataset.title;
  new bootstrap.Modal(document.getElementById('editExam')).show();});});
</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
