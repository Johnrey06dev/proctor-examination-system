<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_perm('exams.view');
$pdo = db();
$sched = new ProctorScheduler($pdo);
$id = (int) ($_GET['id'] ?? 0);
$_POST_BACK = 'admin/exam_view.php?id=' . $id;
if (is_post()) { $_POST['back'] = $_POST_BACK; $_POST['exam_id'] = $_POST['exam_id'] ?? $id; }
$exam = $sched->getExam($id);
if (!$exam) { flash('danger', 'Examination not found.'); redirect('admin/exams.php'); }
// generation from this page shows its explanation on the assignments page
require __DIR__ . '/_assignment_actions.php';

if (is_post()) { exit; }

$assign = fetch_all("SELECT a.*, u.full_name, t.teacher_no, d.code AS dept_code FROM proctor_assignments a
    JOIN teachers t ON t.id = a.teacher_id JOIN users u ON u.id = t.user_id JOIN departments d ON d.id = t.department_id
    WHERE a.examination_id = ? ORDER BY CASE WHEN a.status = 'Cancelled' THEN 1 ELSE 0 END, a.id", [$id]);
$active = $sched->activeCount($id);
$paper = fetch_one('SELECT id, transaction_no, status FROM paper_distribution WHERE examination_id = ?', [$id]);
$run = fetch_one('SELECT * FROM assignment_runs WHERE examination_id = ? ORDER BY id DESC LIMIT 1', [$id]);
$runExp = $run ? json_decode($run['explanation'], true) : [];
$pendingCount = count(array_filter($assign, fn($a) => $a['status'] === 'Pending Review'));
$allTeachers = $sched->allTeachers();

$pageTitle = $exam['exam_code'] . ' – Examination details';
$activeNav = 'exams';
require __DIR__ . '/../includes/header.php';
?>
<div class="mb-3"><a href="<?= e(url('admin/exams.php')) ?>" class="text-decoration-none"><i class="bi bi-arrow-left"></i> Back to examinations</a></div>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="card-panel">
      <div class="panel-head"><h5><?= e($exam['name']) ?></h5><?= status_badge($exam['status']) ?></div>
      <dl class="detail-grid mb-0">
        <dt>Examination ID</dt><dd><?= e($exam['exam_code']) ?> · <?= e($exam['exam_type']) ?></dd>
        <dt>Subject</dt><dd><?= e($exam['subject_code'] . ' – ' . $exam['subject_name']) ?></dd>
        <dt>Department</dt><dd><?= e($exam['dept_name']) ?></dd>
        <dt>Date</dt><dd><?= e(fmt_date($exam['exam_date'])) ?></dd>
        <dt>Time</dt><dd><?= e(time_range($exam['start_time'], $exam['end_time'])) ?></dd>
        <dt>Room</dt><dd><?= e($exam['room_name']) ?></dd>
        <dt>Proctors (assigned / required)</dt><dd><?= $active ?> / <?= (int) $exam['required_proctors'] ?></dd>
        <dt>Copies</dt><dd><?= (int) $exam['paper_sets'] ?></dd>
        <dt>Notes</dt><dd><?= e($exam['notes'] ?: '—') ?></dd>
        <dt>Paper tracking</dt><dd><?= $paper ? '<a href="' . e(url('admin/paper_view.php?id=' . $paper['id'])) . '">' . e($paper['transaction_no']) . '</a> ' . status_badge($paper['status']) : '<span class="text-muted">No transaction yet</span>' ?></dd>
      </dl>
      <?php if ($exam['status'] === 'Scheduled'): ?>
      <hr>
      <div class="d-flex flex-wrap gap-2">
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="complete">
          <button class="btn btn-sm btn-success" type="submit" formaction="<?= e(url('admin/exams.php')) ?>" name="id" value="<?= (int) $id ?>" data-confirm="Mark this examination as completed? Confirmed proctors become Completed; pending proposals are cancelled."><i class="bi bi-check2-circle me-1"></i>Mark completed</button></form>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="cancel">
          <button class="btn btn-sm btn-outline-danger" type="submit" formaction="<?= e(url('admin/exams.php')) ?>" name="id" value="<?= (int) $id ?>" data-confirm="Cancel this examination?"><i class="bi bi-x-circle me-1"></i>Cancel exam</button></form>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="card-panel">
      <div class="panel-head"><h5>Proctor assignments</h5>
        <?php if ($exam['status'] === 'Scheduled'): ?>
        <div class="d-flex flex-wrap gap-2">
          <a class="btn btn-sm btn-outline-navy" href="<?= e(url('admin/room_layout.php?exam_id=' . (int) $id)) ?>"><i class="bi bi-grid-3x3-gap me-1"></i>Room layout</a>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="generate"><button class="btn btn-sm btn-navy" type="submit" data-loading="Generating..." <?= $active >= $exam['required_proctors'] ? 'disabled' : '' ?>><i class="bi bi-magic me-1"></i>Generate assignments</button></form>
          <?php if ($pendingCount): ?>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="approve_exam"><button class="btn btn-sm btn-success" type="submit" data-confirm="Approve all pending proctors?"><i class="bi bi-check2-all me-1"></i>Approve all</button></form>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="regenerate"><button class="btn btn-sm btn-outline-warning" type="submit" data-confirm="Reject pending proctors and generate different ones?"><i class="bi bi-arrow-repeat me-1"></i>Reject &amp; regenerate</button></form>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="reject_exam"><button class="btn btn-sm btn-outline-danger" type="submit" data-confirm="Reject all pending proctors?"><i class="bi bi-x-lg me-1"></i>Reject</button></form>
          <?php endif; ?>
        </div>
        <?php endif; ?>
      </div>
      <?php if (!$assign): ?><?= empty_state('person-plus', 'No proctors assigned', 'Use "Generate assignments" or assign a teacher manually below.') ?><?php else: ?>
      <div class="table-responsive"><table class="table table-modern align-middle">
        <thead><tr><th>Proctor</th><th>Type</th><th class="text-center">Score</th><th>Status</th><th>Reason</th><th></th></tr></thead><tbody>
        <?php foreach ($assign as $a): ?><tr class="<?= $a['status'] === 'Cancelled' ? 'text-muted' : '' ?>">
          <td><strong><?= e($a['teacher_no']) ?></strong> · <?= e($a['full_name']) ?><div class="small text-muted"><?= e($a['dept_code']) ?></div></td>
          <td><?= status_badge($a['assignment_type']) ?></td>
          <td class="text-center"><?= $a['workload_score'] !== null ? e(rtrim(rtrim(number_format((float) $a['workload_score'], 2), '0'), '.')) : '—' ?></td>
          <td><?= status_badge($a['status']) ?></td>
          <td class="small text-muted" style="max-width:260px"><?= e($a['selection_reason']) ?></td>
          <td class="text-end text-nowrap">
            <?php if ($a['status'] === 'Pending Review'): ?>
              <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="approve"><input type="hidden" name="assignment_id" value="<?= (int) $a['id'] ?>"><button class="btn btn-sm btn-success" type="submit" title="Approve"><i class="bi bi-check-lg"></i></button></form>
            <?php endif; ?>
            <?php if (in_array($a['status'], ['Pending Review', 'Confirmed'], true)): ?>
              <button class="btn btn-sm btn-light" type="button" title="Replace" data-bs-toggle="modal" data-bs-target="#replaceModal" data-edit="#replaceForm" data-assignment_id="<?= (int) $a['id'] ?>"><i class="bi bi-arrow-left-right"></i></button>
              <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="cancel_assignment"><input type="hidden" name="assignment_id" value="<?= (int) $a['id'] ?>"><button class="btn btn-sm btn-outline-danger" type="submit" title="Cancel" data-confirm="Cancel this proctor assignment?"><i class="bi bi-x-lg"></i></button></form>
            <?php endif; ?>
          </td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
    </div>

    <?php if ($exam['status'] === 'Scheduled'): ?>
    <div class="card-panel">
      <div class="panel-head"><h5>Manual assignment</h5><span class="small text-muted">Validated with the same hard constraints as automatic assignment</span></div>
      <form method="post" class="row g-2 align-items-end"><?= csrf_field() ?><input type="hidden" name="action" value="manual">
        <div class="col-md-6"><label class="form-label">Teacher</label><select class="form-select" name="teacher_id" required><?= options_html($allTeachers, 'id', fn($t) => $t['teacher_no'] . ' – ' . $t['full_name'] . ' (' . $t['dept_code'] . ')', null, 'Select teacher') ?></select></div>
        <div class="col-md-3"><label class="form-label">Status</label><select class="form-select" name="status"><option>Confirmed</option><option>Pending Review</option></select></div>
        <div class="col-md-3"><button class="btn btn-navy w-100" type="submit" data-loading="Validating...">Validate &amp; assign</button></div>
      </form>
    </div>
    <?php endif; ?>

    <?php if ($runExp): ?>
    <div class="card-panel">
      <div class="panel-head"><h5>Last algorithm run</h5><span class="small text-muted"><?= e(fmt_dt($run['created_at'])) ?> · needed <?= (int) $run['needed'] ?>, assigned <?= (int) $run['assigned'] ?></span></div>
      <div class="table-responsive" style="max-height:300px"><table class="table table-modern table-sm"><thead><tr><th>Teacher</th><th>Decision</th><th>Explanation</th></tr></thead><tbody>
        <?php foreach ($runExp as $x): ?><tr><td><?= e($x['teacher_no'] . ' ' . $x['name']) ?></td><td><?= e($x['decision']) ?></td><td class="small"><?= e($x['text']) ?></td></tr><?php endforeach; ?></tbody></table></div>
    </div>
    <?php endif; ?>
  </div>
</div>

<div class="modal fade" id="replaceModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content">
  <form method="post" id="replaceForm"><?= csrf_field() ?><input type="hidden" name="action" value="replace"><input type="hidden" name="assignment_id" value="">
    <div class="modal-header"><h5 class="modal-title">Replace proctor</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body"><label class="form-label">New proctor</label>
      <select class="form-select" name="teacher_id" required><?= options_html($allTeachers, 'id', fn($t) => $t['teacher_no'] . ' – ' . $t['full_name'] . ' (' . $t['dept_code'] . ')', null, 'Select teacher') ?></select></div>
    <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-navy" type="submit">Validate &amp; replace</button></div>
  </form></div></div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
