<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('staff');
$pdo = db();
$id = (int) ($_GET['id'] ?? 0);

$t = fetch_one("SELECT t.*, u.full_name, u.first_name, u.photo, u.gender, u.email, u.contact_number, u.status AS account_status, u.last_login_at, d.code AS dept_code, d.name AS dept_name
                FROM teachers t JOIN users u ON u.id = t.user_id JOIN departments d ON d.id = t.department_id WHERE t.id = ?", [$id]);
if (!$t) {
    flash('danger', 'Teacher not found.');
    redirect('admin/teachers.php');
}

$sched = new ProctorScheduler($pdo);
$work = $sched->workloadMap()[$id] ?? ProctorScheduler::emptyWorkload();
$rank = 0;
foreach ($sched->workloadRanking() as $r) { if ((int) $r['id'] === $id) { $rank = $r['rank']; } }

$history = fetch_all("SELECT a.*, e.exam_code, e.name AS exam_name, e.exam_date, e.start_time, e.end_time, r.name AS room_name
    FROM proctor_assignments a JOIN examinations e ON e.id = a.examination_id JOIN rooms r ON r.id = e.room_id
    WHERE a.teacher_id = ? ORDER BY e.exam_date DESC, e.start_time DESC", [$id]);
$weekly = fetch_all('SELECT weekday, start_time, end_time FROM teacher_weekly_availability WHERE teacher_id = ? AND weekday BETWEEN 1 AND 7 ORDER BY weekday, start_time', [$id]);
$days = [1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday'];

$pageTitle = 'Teacher details';
$activeNav = 'teachers';
require __DIR__ . '/../includes/header.php';
?>
<div class="mb-3"><a href="<?= e(url('admin/teachers.php')) ?>" class="text-decoration-none"><i class="bi bi-arrow-left"></i> Back to teachers</a></div>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="card-panel">
      <div class="d-flex align-items-center gap-3 mb-3"><?= avatar_html($t, 'avatar avatar-lg') ?>
        <div><h5 class="mb-0"><?= e($t['full_name']) ?></h5><div class="text-muted"><?= e($t['teacher_no']) ?></div></div></div>
      <dl class="detail-grid mb-0">
        <dt>Email</dt><dd><?= e($t['email']) ?></dd>
        <dt>Department</dt><dd><?= e($t['dept_name']) ?></dd>
        <dt>Specialization</dt><dd><?= e($t['specialization'] ?: '—') ?></dd>
        <dt>Contact</dt><dd><?= e($t['contact_number'] ?: '—') ?></dd>
        <dt>Account / Availability</dt><dd><?= status_badge(ucfirst($t['account_status'])) ?> <?= status_badge($t['availability_status']) ?></dd>
        <dt>Last login</dt><dd><?= e(fmt_dt($t['last_login_at'])) ?></dd>
      </dl>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="row g-3 mb-3">
      <div class="col-6 col-md-3"><div class="stat-card"><div><div class="stat-value"><?= (int) $work['total'] ?></div><div class="stat-label">Workload (period)</div></div></div></div>
      <div class="col-6 col-md-3"><div class="stat-card"><div><div class="stat-value"><?= (int) $work['upcoming'] ?></div><div class="stat-label">Upcoming</div></div></div></div>
      <div class="col-6 col-md-3"><div class="stat-card"><div><div class="stat-value"><?= (int) $work['completed'] ?></div><div class="stat-label">Completed</div></div></div></div>
      <div class="col-6 col-md-3"><div class="stat-card"><div><div class="stat-value">#<?= (int) $rank ?></div><div class="stat-label">Workload rank (1 = lightest)</div></div></div></div>
    </div>
    <div class="card-panel">
      <div class="panel-head"><h5>Weekly availability</h5><span class="small text-muted">set by the teacher</span></div>
      <?php if (!$weekly): ?><div class="alert alert-warning mb-0">This teacher has not set any available day or time yet, so auto-assign will not pick him/her.</div><?php else: ?>
      <div class="table-responsive"><table class="table table-modern align-middle mb-0"><tbody>
        <?php foreach ($days as $n => $dn): $r = array_filter($weekly, fn($w) => (int) $w['weekday'] === $n); ?>
        <tr><td style="width:130px"><b><?= $dn ?></b></td><td><?php if (!$r): ?><span class="text-muted">Not available</span><?php endif; foreach ($r as $w): ?><span class="badge-s b-green me-1"><?= e(time_range($w['start_time'], $w['end_time'])) ?></span><?php endforeach; ?></td></tr>
        <?php endforeach; ?></tbody></table></div><?php endif; ?>
    </div>
  </div>
</div>
<div class="card-panel">
  <div class="panel-head"><h5>Assignment history</h5></div>
  <?php if (!$history): ?><?= empty_state('journal-x', 'No assignments yet') ?><?php else: ?>
  <div class="table-responsive"><table class="table table-modern"><thead><tr><th>Exam</th><th>Date &amp; time</th><th>Room</th><th>Type</th><th>Status</th><th>Reason / notes</th></tr></thead><tbody>
    <?php foreach ($history as $h): ?><tr>
      <td><a href="<?= e(url('admin/exam_view.php?id=' . $h['examination_id'])) ?>"><strong><?= e($h['exam_code']) ?></strong></a><div class="small text-muted"><?= e($h['exam_name']) ?></div></td>
      <td><?= e(fmt_date($h['exam_date'])) ?><div class="small text-muted"><?= e(time_range($h['start_time'], $h['end_time'])) ?></div></td>
      <td><?= e($h['room_name']) ?></td><td><?= status_badge($h['assignment_type']) ?></td><td><?= status_badge($h['status']) ?></td>
      <td class="small text-muted" style="max-width:340px"><?= e($h['selection_reason']) ?></td></tr><?php endforeach; ?>
  </tbody></table></div><?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
