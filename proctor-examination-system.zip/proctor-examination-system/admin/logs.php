<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_perm('activity.view');
$q = trim($_GET['q'] ?? '');
$fu = (int) ($_GET['user'] ?? 0);
$from = $_GET['from'] ?? '';
$to = $_GET['to'] ?? '';
$where = ['1=1']; $params = [];
if ($q !== '') { $where[] = '(l.action LIKE ? OR l.description LIKE ? OR l.entity_type LIKE ?)'; array_push($params, "%$q%", "%$q%", "%$q%"); }
if ($fu) { $where[] = 'l.user_id = ?'; $params[] = $fu; }
if (valid_date($from)) { $where[] = 'l.created_at >= ?'; $params[] = $from . ' 00:00:00'; }
if (valid_date($to)) { $where[] = 'l.created_at <= ?'; $params[] = $to . ' 23:59:59'; }
$rows = fetch_all('SELECT l.*, u.full_name FROM activity_logs l LEFT JOIN users u ON u.id = l.user_id WHERE ' . implode(' AND ', $where) . ' ORDER BY l.id DESC LIMIT 300', $params);
$users = fetch_all('SELECT id, full_name FROM users ORDER BY full_name');

$pageTitle = 'Activity Logs';
$activeNav = 'logs';
require __DIR__ . '/../includes/header.php';
?>
<div class="card-panel">
  <form class="filter-bar" method="get">
    <div style="flex:2"><label class="form-label">Search</label><input class="form-control" name="q" value="<?= e($q) ?>" placeholder="Action, description, record type"></div>
    <div><label class="form-label">User</label><select class="form-select" name="user"><?= options_html($users, 'id', 'full_name', $fu, 'All') ?></select></div>
    <div><label class="form-label">From</label><input type="date" class="form-control" name="from" value="<?= e($from) ?>"></div>
    <div><label class="form-label">To</label><input type="date" class="form-control" name="to" value="<?= e($to) ?>"></div>
    <div class="d-flex gap-2"><button class="btn btn-navy" type="submit">Filter</button><a class="btn btn-light" href="<?= e(url('admin/logs.php')) ?>">Reset</a></div>
  </form>
</div>
<div class="card-panel">
  <?php if (!$rows): ?><?= empty_state('clock-history', 'No log entries found') ?><?php else: ?>
  <div class="table-responsive"><table class="table table-modern table-sm align-middle">
    <thead><tr><th>Date &amp; time</th><th>User</th><th>Action</th><th>Related record</th><th>Previous → new</th><th>Description</th><th>IP</th></tr></thead><tbody>
    <?php foreach ($rows as $l): ?><tr>
      <td class="text-nowrap"><?= e(fmt_dt($l['created_at'])) ?></td><td><?= e($l['full_name'] ?: 'System') ?></td><td><code><?= e($l['action']) ?></code></td>
      <td><?= e($l['entity_type'] ? $l['entity_type'] . ($l['entity_id'] ? ' #' . $l['entity_id'] : '') : '—') ?></td>
      <td class="small"><?= ($l['old_value'] || $l['new_value']) ? e(($l['old_value'] ?: '—') . ' → ' . ($l['new_value'] ?: '—')) : '—' ?></td>
      <td class="small"><?= e($l['description']) ?></td><td class="small text-muted"><?= e($l['ip_address']) ?></td></tr><?php endforeach; ?></tbody></table></div>
  <div class="text-muted small mt-2">Showing the latest <?= count($rows) ?> entries (max 300).</div><?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
