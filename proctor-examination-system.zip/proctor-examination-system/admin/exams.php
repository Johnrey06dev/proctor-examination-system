<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_perm('exams.view');
if (is_post() && !is_staff()) deny_access($user);
$pdo = db();
$sched = new ProctorScheduler($pdo);

if (require_post_csrf()) {
    $action = input_str('action', 20);
    $id = input_int('id');

    if ($action === 'save') {
        $name = input_str('name', 150);
        $type = input_str('exam_type', 20);
        if (!in_array($type, ['Quiz', 'Midterm', 'Final', 'Make-up', 'Other'], true)) $type = 'Midterm';
        $subject = input_int('subject_id');
        $dept = input_int('department_id');
        $room = input_int('room_id');
        $date = input_str('exam_date', 10);
        $start = norm_time(input_str('start_time', 8));
        $end = norm_time(input_str('end_time', 8));
        $req = 1;   // every subject of a section needs exactly ONE proctor
        $section = trim(preg_replace('/\s+/', ' ', input_str('section', 60))); $students = input_int('students');
        if ($section !== '' && $students < 1) $students = (int) fetch_value('SELECT examinees FROM exam_sections WHERE LOWER(section_name) = LOWER(?) ORDER BY id DESC LIMIT 1', [$section]);
        $sets = $students + PaperTracker::EXTRA_COPIES;
        $notes = input_str('notes', 255);
        $errors = [];

        $old = $id ? fetch_one('SELECT * FROM examinations WHERE id = ?', [$id]) : null;
        if ($id && !$old) $errors[] = 'Examination not found.';
        if ($old && $old['status'] !== 'Scheduled') $errors[] = 'Only Scheduled examinations can be edited.';
        if ($name === '') $errors[] = 'Examination name is required.';
        if (!fetch_value('SELECT COUNT(*) FROM subjects WHERE id = ?', [$subject])) $errors[] = 'Select a valid subject.';
        if (!fetch_value('SELECT COUNT(*) FROM departments WHERE id = ?', [$dept])) $errors[] = 'Select a valid department.';
        if (!fetch_value("SELECT COUNT(*) FROM rooms WHERE id = ? AND status = 'Available'", [$room])) $errors[] = 'Select an available room.';
        if (!valid_date($date)) $errors[] = 'Enter a valid examination date.';
        elseif (!$old && $date < date('Y-m-d')) $errors[] = 'The examination date cannot be in the past.';
        if (!$start || !$end) $errors[] = 'Enter valid start and end times.';
        elseif ($start >= $end) $errors[] = 'Invalid time range: the end time must be later than the start time.';
        if ($req < 1 || $req > 50) $errors[] = 'Required proctors must be between 1 and 50.';
        if ($section === '') $errors[] = 'Enter the section that takes this exam.';
        if ($students < 1) $errors[] = 'Enter how many students take the exam.';

        if (!$errors) foreach (section_rule_errors($section, $students, $subject, $room, $date, $start, $end, $id) as $er) $errors[] = $er;
        if (!$errors) {
            // room clash
            $clash = fetch_one("SELECT exam_code FROM examinations WHERE room_id = ? AND exam_date = ? AND status <> 'Cancelled' AND id <> ? AND start_time < ? AND end_time > ?",
                [$room, $date, $id, $end, $start]);
            if ($clash) $errors[] = 'Room conflict: the room is already used by ' . $clash['exam_code'] . ' at that time.';
        }
        if (!$errors && $old) {
            $active = $sched->activeCount($id);
            if ($req < $active) $errors[] = 'Required proctors (' . $req . ') cannot be lower than the ' . $active . ' proctor(s) already assigned. Cancel some assignments first.';
            $changedTime = $old['exam_date'] !== $date || substr($old['start_time'], 0, 5) !== substr($start, 0, 5) || substr($old['end_time'], 0, 5) !== substr($end, 0, 5);
            if (!$errors && $changedTime) {
                $new = $old; $new['exam_date'] = $date; $new['start_time'] = $start; $new['end_time'] = $end;
                foreach ($sched->rescheduleConflicts($new) as $c) $errors[] = 'Cannot reschedule – ' . $c;
            }
        }

        if ($errors) {
            foreach ($errors as $er) flash('danger', $er);
        } else {
            try {
                if ($id) {
                    $pdo->prepare('UPDATE examinations SET name=?, exam_type=?, subject_id=?, department_id=?, room_id=?, exam_date=?, start_time=?, end_time=?, required_proctors=?, paper_sets=?, notes=? WHERE id=?')
                        ->execute([$name, $type, $subject, $dept, $room, $date, $start, $end, $req, $sets, $notes, $id]);
                    $pdo->prepare('DELETE FROM exam_sections WHERE examination_id = ?')->execute([$id]);
                    [$lnkSec, $lnkYs] = section_link($section, $subject);
                    $pdo->prepare('INSERT INTO exam_sections (examination_id, section_name, subject_id, examinees, sort_order, section_id, year_subject_id) VALUES (?,?,?,?,1,?,?)')->execute([$id, $section, $subject, $students, $lnkSec, $lnkYs]);
                    PaperTracker::sync($pdo, $id, (int) $user['id']);
                    log_activity('exam_updated', 'examination', $id, null, null, 'Examination ' . $old['exam_code'] . ' updated');
                    $changed = $old['exam_date'] !== $date || $old['start_time'] !== $start || $old['end_time'] !== $end || (int) $old['room_id'] !== $room;
                    if ($changed) {
                        foreach (fetch_all("SELECT teacher_id FROM proctor_assignments WHERE examination_id = ? AND status IN ('Pending Review','Confirmed')", [$id]) as $a) {
                            if ($uid = teacher_user_id((int) $a['teacher_id'])) {
                                notify($uid, 'Examination schedule updated', $old['exam_code'] . ' is now on ' . fmt_date($date) . ' ' . time_range($start, $end) . '.', 'schedule_update', 'teacher/assignments.php');
                            }
                        }
                    }
                    flash('success', 'Examination updated.');
                } else {
                    $code = next_code('examinations', 'exam_code', 'EX-');
                    $pdo->prepare('INSERT INTO examinations (exam_code, name, exam_type, subject_id, department_id, room_id, exam_date, start_time, end_time, required_proctors, paper_sets, status, notes, created_by, created_at)
                                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
                        ->execute([$code, $name, $type, $subject, $dept, $room, $date, $start, $end, $req, $sets, 'Scheduled', $notes, $user['id'], now()]);
                    $newId = (int) $pdo->lastInsertId();
                    [$lnkSec, $lnkYs] = section_link($section, $subject);
                    $pdo->prepare('INSERT INTO exam_sections (examination_id, section_name, subject_id, examinees, sort_order, section_id, year_subject_id) VALUES (?,?,?,?,1,?,?)')->execute([$newId, $section, $subject, $students, $lnkSec, $lnkYs]);
                    log_activity('exam_created', 'examination', $newId, null, 'Scheduled', 'Examination ' . $code . ' created for ' . $section);
                    flash('success', 'Examination ' . $code . ' created. You can now generate proctors for it.');
                }
            } catch (PDOException $e) {
                flash('danger', 'Database error: ' . (APP_DEBUG ? $e->getMessage() : 'could not save the examination.'));
            }
        }
    } elseif ($action === 'cancel') {
        $x = fetch_one('SELECT status FROM examinations WHERE id = ?', [$id]);
        if ($x && $x['status'] === 'Scheduled') { $sched->cancelExam($id, $user['id']); flash('success', 'Examination cancelled and its proctors were notified.'); }
        else flash('danger', 'Only Scheduled examinations can be cancelled.');
    } elseif ($action === 'delete') {
        $x = fetch_one('SELECT exam_code FROM examinations WHERE id = ?', [$id]);
        if (!$x) { flash('danger', 'Examination not found.'); }
        else {
            $pdo->beginTransaction();
            try { purge_exam($pdo, $id); $pdo->commit(); log_activity('exam_deleted', 'examination', $id, null, null, 'Examination ' . $x['exam_code'] . ' deleted'); flash('success', 'Examination ' . $x['exam_code'] . ' deleted together with its proctors, attendance and paper record.'); }
            catch (Throwable $e) { $pdo->rollBack(); flash('danger', 'Could not delete: ' . $e->getMessage()); }
        }
    } elseif ($action === 'complete') {
        $x = fetch_one('SELECT status FROM examinations WHERE id = ?', [$id]);
        if ($x && $x['status'] === 'Scheduled') { $sched->completeExam($id, $user['id']); flash('success', 'Examination marked as completed.'); }
    }
    redirect('admin/exams.php' . qs());
}

/* ---------- filters ---------- */
$view = ($_GET['view'] ?? 'table') === 'calendar' ? 'calendar' : 'table';
$q = trim($_GET['q'] ?? '');
$fd = (int) ($_GET['dept'] ?? 0);
$fsub = (int) ($_GET['subject'] ?? 0);
$fst = $_GET['status'] ?? '';
$from = $_GET['from'] ?? '';
$to = $_GET['to'] ?? '';
$staffing = $_GET['staffing'] ?? '';

$where = ['1=1']; $params = [];
if ($q !== '') { $where[] = '(e.exam_code LIKE ? OR e.name LIKE ?)'; array_push($params, "%$q%", "%$q%"); }
if ($fd) { $where[] = 'e.department_id = ?'; $params[] = $fd; }
if ($fsub) { $where[] = 'e.subject_id = ?'; $params[] = $fsub; }
if (in_array($fst, ['Scheduled', 'Completed', 'Cancelled'], true)) { $where[] = 'e.status = ?'; $params[] = $fst; }
if ($staffing === 'unassigned') {
    $where[] = "e.status = 'Scheduled' AND (SELECT COUNT(*) FROM proctor_assignments a WHERE a.examination_id = e.id AND a.status <> 'Cancelled') < e.required_proctors";
}

$month = $_GET['month'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $month)) $month = date('Y-m');
if ($view === 'calendar') {
    $where[] = 'e.exam_date >= ? AND e.exam_date <= ?'; array_push($params, $month . '-01', $month . '-31');
} else {
    if (valid_date($from)) { $where[] = 'e.exam_date >= ?'; $params[] = $from; }
    if (valid_date($to)) { $where[] = 'e.exam_date <= ?'; $params[] = $to; }
}

$exams = fetch_all("SELECT e.*, s.code AS subject_code, s.name AS subject_name, d.code AS dept_code, r.name AS room_name,
        (SELECT COUNT(*) FROM proctor_assignments a WHERE a.examination_id = e.id AND a.status <> 'Cancelled') AS assigned_count,
        (SELECT section_name FROM exam_sections z WHERE z.examination_id = e.id ORDER BY z.id LIMIT 1) AS section, (SELECT examinees FROM exam_sections z WHERE z.examination_id = e.id ORDER BY z.id LIMIT 1) AS students
    FROM examinations e JOIN subjects s ON s.id = e.subject_id JOIN departments d ON d.id = e.department_id JOIN rooms r ON r.id = e.room_id
    WHERE " . implode(' AND ', $where) . ' ORDER BY e.exam_date, e.start_time, e.id', $params);

$depts = dept_list(); $subjects = subject_list(); $rooms = room_list();

$pageTitle = 'Examinations';
$activeNav = 'exams';
require __DIR__ . '/../includes/header.php';
?>
<div class="card-panel">
  <form class="filter-bar" method="get">
    <input type="hidden" name="view" value="<?= e($view) ?>">
    <div style="flex:2"><label class="form-label">Search</label><input class="form-control" name="q" value="<?= e($q) ?>" placeholder="Code or name"></div>
    <div><label class="form-label">Department</label><select class="form-select" name="dept"><?= options_html($depts, 'id', 'code', $fd, 'All') ?></select></div>
    <div><label class="form-label">Subject</label><select class="form-select" name="subject"><?= options_html($subjects, 'id', 'code', $fsub, 'All') ?></select></div>
    <div><label class="form-label">Status</label><select class="form-select" name="status"><option value="">All</option><?php foreach (['Scheduled', 'Completed', 'Cancelled'] as $s): ?><option <?= $fst === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?></select></div>
    <?php if ($view === 'table'): ?>
      <div><label class="form-label">From</label><input type="date" class="form-control" name="from" value="<?= e($from) ?>"></div>
      <div><label class="form-label">To</label><input type="date" class="form-control" name="to" value="<?= e($to) ?>"></div>
    <?php else: ?>
      <div><label class="form-label">Month</label><input type="month" class="form-control" name="month" value="<?= e($month) ?>"></div>
    <?php endif; ?>
    <div><label class="form-label">Staffing</label><select class="form-select" name="staffing"><option value="">All</option><option value="unassigned" <?= $staffing === 'unassigned' ? 'selected' : '' ?>>Needs proctors</option></select></div>
    <div class="d-flex gap-2"><button class="btn btn-navy" type="submit"><i class="bi bi-search me-1"></i>Filter</button><a class="btn btn-light" href="<?= e(url('admin/exams.php?view=' . $view)) ?>">Reset</a></div>
  </form>
</div>

<div class="card-panel">
  <div class="panel-head">
    <div class="btn-group">
      <a class="btn btn-sm <?= $view === 'table' ? 'btn-navy' : 'btn-outline-navy' ?>" href="<?= e(url('admin/exams.php' . qs(['view' => 'table']))) ?>"><i class="bi bi-table me-1"></i>Table</a>
      <a class="btn btn-sm <?= $view === 'calendar' ? 'btn-navy' : 'btn-outline-navy' ?>" href="<?= e(url('admin/exams.php' . qs(['view' => 'calendar']))) ?>"><i class="bi bi-calendar3 me-1"></i>Calendar</a>
    </div>
    <button class="btn btn-navy" type="button" data-bs-toggle="modal" data-bs-target="#examModal" data-reset-form="#examForm"><i class="bi bi-plus-lg me-1"></i>Create examination</button>
  </div>

  <?php if ($view === 'calendar'):
    $first = strtotime($month . '-01');
    $daysIn = (int) date('t', $first);
    $lead = (int) date('w', $first);
    $byDay = [];
    foreach ($exams as $x) { $byDay[$x['exam_date']][] = $x; }
    $prev = date('Y-m', strtotime('-1 month', $first));
    $next = date('Y-m', strtotime('+1 month', $first));
  ?>
    <div class="d-flex justify-content-between align-items-center mb-2">
      <a class="btn btn-sm btn-light" href="<?= e(url('admin/exams.php' . qs(['month' => $prev]))) ?>"><i class="bi bi-chevron-left"></i></a>
      <h6 class="mb-0"><?= e(date('F Y', $first)) ?></h6>
      <a class="btn btn-sm btn-light" href="<?= e(url('admin/exams.php' . qs(['month' => $next]))) ?>"><i class="bi bi-chevron-right"></i></a>
    </div>
    <div class="cal-grid">
      <?php foreach (['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] as $dn): ?><div class="cal-head"><?= $dn ?></div><?php endforeach; ?>
      <?php for ($i = 0; $i < $lead; $i++): ?><div class="cal-cell muted"></div><?php endfor; ?>
      <?php for ($d = 1; $d <= $daysIn; $d++): $ds = $month . '-' . str_pad((string) $d, 2, '0', STR_PAD_LEFT); ?>
        <div class="cal-cell <?= $ds === date('Y-m-d') ? 'today' : '' ?>"><span class="d"><?= $d ?></span>
          <?php foreach ($byDay[$ds] ?? [] as $x): ?>
            <a class="cal-ev <?= $x['status'] === 'Completed' ? 'done' : ($x['status'] === 'Cancelled' ? 'cancel' : '') ?>" href="<?= e(url('admin/exam_view.php?id=' . $x['id'])) ?>"
               title="<?= e($x['exam_code'] . ' ' . $x['name'] . ' – ' . time_range($x['start_time'], $x['end_time']) . ' – ' . $x['room_name']) ?>">
              <?= e(date('g:ia', strtotime($x['start_time']))) ?> <?= e($x['subject_code']) ?> (<?= (int) $x['assigned_count'] ?>/<?= (int) $x['required_proctors'] ?>)</a>
          <?php endforeach; ?>
        </div>
      <?php endfor; ?>
      <?php $tail = (7 - (($lead + $daysIn) % 7)) % 7; for ($i = 0; $i < $tail; $i++): ?><div class="cal-cell muted"></div><?php endfor; ?>
    </div>
    <div class="text-muted small mt-2">Format: time · subject · (assigned/required proctors). Blue = scheduled, green = completed, red = cancelled.</div>

  <?php elseif (!$exams): ?>
    <?= empty_state('calendar-x', 'No examinations found', 'Adjust the filters or create a new examination.') ?>
  <?php else: ?>
    <div class="table-responsive"><table class="table table-modern align-middle">
      <thead><tr><th>Code</th><th>Examination</th><th>Date &amp; time</th><th>Room</th><th>Section</th><th class="text-center">Proctors</th><th class="text-center">Copies</th><th>Status</th><th></th></tr></thead><tbody>
      <?php foreach ($exams as $x): $full = $x['assigned_count'] >= $x['required_proctors']; ?>
        <tr>
          <td><strong><?= e($x['exam_code']) ?></strong></td>
          <td><?= e($x['name']) ?><div class="small text-muted"><?= e($x['subject_code']) ?> · <?= e($x['dept_code']) ?> · <?= e($x['exam_type']) ?></div></td>
          <td><?= e(fmt_date($x['exam_date'])) ?><div class="small text-muted"><?= e(time_range($x['start_time'], $x['end_time'])) ?></div></td>
          <td><?= e($x['room_name']) ?></td>
          <td><?= e($x['section'] ?? '—') ?><div class="small text-muted"><?= (int) $x['students'] ?> students</div></td>
          <td class="text-center"><span class="badge <?= $full ? 'bg-success' : 'bg-danger' ?>"><?= (int) $x['assigned_count'] ?>/<?= (int) $x['required_proctors'] ?></span></td>
          <td class="text-center"><?= (int) $x['paper_sets'] ?></td>
          <td><?= status_badge($x['status']) ?></td>
          <td class="text-end text-nowrap">
            <a class="btn btn-sm btn-light" href="<?= e(url('admin/exam_view.php?id=' . $x['id'])) ?>" title="View"><i class="bi bi-eye"></i></a>
            <?php if ($x['status'] === 'Scheduled'): ?>
            <button class="btn btn-sm btn-light" type="button" title="Edit" data-bs-toggle="modal" data-bs-target="#examModal" data-edit="#examForm"
              data-id="<?= (int) $x['id'] ?>" data-name="<?= e($x['name']) ?>" data-exam_type="<?= e($x['exam_type']) ?>" data-subject_id="<?= (int) $x['subject_id'] ?>" data-department_id="<?= (int) $x['department_id'] ?>"
              data-room_id="<?= (int) $x['room_id'] ?>" data-exam_date="<?= e($x['exam_date']) ?>" data-start_time="<?= e(substr($x['start_time'], 0, 5)) ?>" data-end_time="<?= e(substr($x['end_time'], 0, 5)) ?>"
              data-required_proctors="<?= (int) $x['required_proctors'] ?>" data-section="<?= e($x['section']) ?>" data-students="<?= (int) $x['students'] ?>" data-notes="<?= e($x['notes']) ?>"><i class="bi bi-pencil"></i></button>
            <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="cancel"><input type="hidden" name="id" value="<?= (int) $x['id'] ?>">
              <button class="btn btn-sm btn-outline-warning" type="submit" title="Cancel" data-confirm="Cancel <?= e($x['exam_code']) ?>? Assigned proctors will be notified and their assignments cancelled."><i class="bi bi-x-circle"></i></button></form>
            <?php endif; ?>
            <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $x['id'] ?>">
              <button class="btn btn-sm btn-outline-danger" type="submit" title="Delete" data-confirm="Permanently delete <?= e($x['exam_code']) ?>? This also removes its proctor assignments, attendance and paper record."><i class="bi bi-trash"></i></button></form>
          </td>
        </tr>
      <?php endforeach; ?></tbody></table></div>
    <div class="text-muted small mt-2"><?= count($exams) ?> examination(s)</div>
  <?php endif; ?>
</div>

<div class="modal fade" id="examModal" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content">
  <form method="post" id="examForm"><?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="">
    <div class="modal-header"><h5 class="modal-title">Examination</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body"><div class="row g-3">
      <div class="col-md-8"><label class="form-label">Examination name *</label><input class="form-control" name="name" required maxlength="150" placeholder="IT101 Midterm Examination"></div>
      <div class="col-md-4"><label class="form-label">Type</label><select class="form-select" name="exam_type"><?php foreach (['Quiz', 'Midterm', 'Final', 'Make-up', 'Other'] as $t): ?><option><?= e($t) ?></option><?php endforeach; ?></select></div>
      <div class="col-md-6"><label class="form-label">Subject *</label>
        <select class="form-select" name="subject_id" id="subjectSel" required><option value="">Select subject</option>
          <?php foreach ($subjects as $s): ?><option value="<?= (int) $s['id'] ?>" data-dept="<?= (int) $s['department_id'] ?>"><?= e($s['code'] . ' – ' . $s['name']) ?></option><?php endforeach; ?></select></div>
      <div class="col-md-6"><label class="form-label">Department *</label><select class="form-select" name="department_id" id="deptSel" required><?= options_html($depts, 'id', fn($d) => $d['code'] . ' – ' . $d['name'], null, 'Select department') ?></select></div>
      <div class="col-md-4"><label class="form-label">Date *</label><input type="date" class="form-control" name="exam_date" required></div>
      <div class="col-md-4"><label class="form-label">Start time *</label><input type="time" class="form-control" name="start_time" required></div>
      <div class="col-md-4"><label class="form-label">End time *</label><input type="time" class="form-control" name="end_time" required></div>
      <div class="col-md-6"><label class="form-label">Room *</label><select class="form-select" name="room_id" required><?= options_html(array_filter($rooms, fn($r) => $r['status'] === 'Available'), 'id', fn($r) => $r['name'] . ' (cap. ' . $r['capacity'] . ')', null, 'Select room') ?></select></div>
      <div class="col-md-6"><label class="form-label">Section *</label><input class="form-control" name="section" id="exSec" list="knownSecs" maxlength="60" placeholder="e.g. BSIT 3A" required autocomplete="off"></div>
      <div class="col-md-6"><label class="form-label">Students taking the exam *</label><input type="number" min="1" class="form-control" name="students" id="exStu" required><div class="hint">Auto-filled for a known section. Papers = students + <?= (int) PaperTracker::EXTRA_COPIES ?> extra copies (created automatically when a proctor accepts).</div></div>
      <datalist id="knownSecs"><?php foreach (known_sections() as $k_): ?><option value="<?= e($k_['name']) ?>"><?php endforeach; ?></datalist>
      <script>(function(){var K=<?= json_encode(known_sections(), JSON_FORCE_OBJECT) ?>,n=document.getElementById('exSec'),s=document.getElementById('exStu');function f(){var k=K[n.value.trim().toLowerCase().replace(/\s+/g,' ')];if(k)s.value=k.students;}n.addEventListener('input',f);n.addEventListener('change',f);})();</script>
      <div class="col-12"><label class="form-label">Notes</label><input class="form-control" name="notes" maxlength="255"></div>
    </div></div>
    <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-navy" type="submit" data-loading="Saving...">Save examination</button></div>
  </form></div></div></div>
<?php
$extraScripts = '<script>
document.getElementById("subjectSel").addEventListener("change", function(){
  var o=this.options[this.selectedIndex]; if(o && o.dataset.dept){ document.getElementById("deptSel").value=o.dataset.dept; }
});</script>';
require __DIR__ . '/../includes/footer.php';
