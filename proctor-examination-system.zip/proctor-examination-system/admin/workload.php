<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('staff');
$sched = new ProctorScheduler(db());
$rank = $sched->workloadRanking();
$s = $sched->settings();

$byNo = $rank;
usort($byNo, fn($a, $b) => strcmp($a['teacher_no'], $b['teacher_no']));
$labels = array_column($byNo, 'teacher_no');
$total = array_map('intval', array_column($byNo, 'workload'));
$upc = array_map('intval', array_column($byNo, 'upcoming'));
$done = array_map('intval', array_column($byNo, 'completed'));

$pageTitle = 'Workload Balance';
$activeNav = 'workload';
$useCharts = true;
require __DIR__ . '/../includes/header.php';
?>
<div class="row g-3">
  <div class="col-lg-8">
    <div class="card-panel">
      <div class="panel-head"><h5>Workload distribution</h5></div>
      <div style="height:300px"><canvas id="wl"></canvas></div>
    </div>
    <div class="card-panel">
      <div class="panel-head"><h5>Workload ranking (1 = lightest workload, first in line for new assignments)</h5></div>
      <div class="table-responsive"><table class="table table-modern align-middle">
        <thead><tr><th class="text-center">Rank</th><th>Teacher</th><th>Dept</th><th class="text-center">Assignments (period)</th><th class="text-center">All-time</th><th class="text-center">Upcoming</th><th class="text-center">Completed</th><th class="text-center">New (pending review)</th><th>Last exam</th><th>Eligibility</th></tr></thead><tbody>
        <?php foreach ($rank as $r): $ok = $r['account_status'] === 'active' && $r['availability_status'] === 'Available'; ?><tr class="<?= $ok ? '' : 'text-muted' ?>">
          <td class="text-center"><span class="rank-pill"><?= (int) $r['rank'] ?></span></td>
          <td><strong><?= e($r['teacher_no']) ?></strong> · <?= e($r['full_name']) ?></td><td><?= e($r['dept_code']) ?></td>
          <td class="text-center"><strong><?= (int) $r['workload'] ?></strong></td><td class="text-center"><?= (int) $r['all_time'] ?></td>
          <td class="text-center"><?= (int) $r['upcoming'] ?></td><td class="text-center"><?= (int) $r['completed'] ?></td><td class="text-center"><?= (int) $r['new_assignments'] ?></td>
          <td class="small"><?= $r['last_date'] ? e(fmt_date($r['last_date'])) : 'never' ?></td>
          <td><?= $ok ? status_badge('Available') : status_badge($r['account_status'] !== 'active' ? 'Inactive' : 'Unavailable') ?></td></tr><?php endforeach; ?></tbody></table></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card-panel">
      <div class="panel-head"><h5>How the algorithm decides</h5></div>
      <div class="explain-box mb-3">
        <strong>Step 1 – Hard constraints (filter).</strong> A teacher must be active, available, free of overlapping/too-close exams, not already on the exam, within the daily limit and eligible. Violators are excluded — never forced.
      </div>
      <div class="explain-box mb-3">
        <strong>Step 2 – Workload.</strong> Workload = number of non-cancelled assignments inside the scheduling period
        (<?= $s['period_start'] || $s['period_end'] ? e(($s['period_start'] ?: '…') . ' to ' . ($s['period_end'] ?: '…')) : 'all dates' ?>).
      </div>
      <div class="explain-box mb-3">
        <strong>Step 3 – Ranking.</strong> Score = workload<?= $s['dept_rule'] !== 'none' && $s['dept_rule'] !== 'exclude_same' ? ' + ' . e($s['dept_weight']) . ' department penalty (' . e($s['dept_rule']) . ')' : '' ?>.
        Lowest score first; ties → teacher who was assigned least recently (never = first); remaining ties → teacher number A→Z, so results are consistent.
      </div>
      <div class="explain-box">
        <strong>Step 4 – Select.</strong> The top <em>N</em> teachers are chosen, where N = required − already assigned. The result is saved as <em>Pending Review</em> until you approve it.
      </div>
      <div class="mt-3"><a class="btn btn-outline-navy btn-sm" href="<?= e(url('admin/settings.php')) ?>"><i class="bi bi-sliders me-1"></i>Algorithm settings</a></div>
    </div>
  </div>
</div>
<?php
$extraScripts = '<script>new Chart(document.getElementById("wl"),{type:"bar",data:{labels:' . json_encode($labels) . ',datasets:[
{label:"Period workload",data:' . json_encode($total) . ',backgroundColor:"#13315c",borderRadius:4},
{label:"Upcoming",data:' . json_encode($upc) . ',backgroundColor:"#7fa3d6",borderRadius:4},
{label:"Completed",data:' . json_encode($done) . ',backgroundColor:"#2f8f5b",borderRadius:4}]},
options:{maintainAspectRatio:false,plugins:{legend:{position:"bottom"}},scales:{y:{beginAtZero:true,ticks:{precision:0}}}}});</script>';
require __DIR__ . '/../includes/footer.php';
