<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_perm('attendance.view');
$pdo = db();
if (require_post_csrf()) {
    $a = input_str('action', 12);
    if ($a === 'reset') {
        if (!user_can('attendance.reset')) deny_access($user);
        $pdo->prepare('DELETE FROM attendance WHERE examination_id = ? AND teacher_id = ?')->execute([input_int('exam_id'), input_int('teacher_id')]);
        log_activity('attendance_reset', 'attendance', input_int('exam_id'), null, null, 'Attendance reset'); flash('success', 'Time in/out reset.');
    } elseif ($a === 'testing') {
        if ($user['role'] !== 'admin') deny_access($user);
        $on = input_str('on', 1) === '1';
        $st = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'testing_mode'"); $st->execute([$on ? '1' : '0']);
        if (!$st->rowCount() && !fetch_value("SELECT COUNT(*) FROM system_settings WHERE setting_key='testing_mode'")) $pdo->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES ('testing_mode', ?)")->execute([$on ? '1' : '0']);
        flash('success', 'Testing mode ' . ($on ? 'ON' : 'OFF') . '.');
    } elseif ($a === 'minutes' && $user['role'] === 'admin') {
        $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'attendance_open_minutes'")->execute([(string) max(0, min(240, input_int('minutes')))]); flash('success', 'Saved.');
    }
    redirect('admin/attendance.php?date=' . urlencode(input_str('date', 10)));
}
$date = valid_date((string) ($_GET['date'] ?? '')) ? $_GET['date'] : date('Y-m-d');
$rows = fetch_all("SELECT e.id AS eid, e.exam_code, e.start_time, e.end_time, e.exam_date, r.name AS room, u.full_name, t.id AS tid, t.teacher_no, a.time_in, a.time_out
    FROM proctor_assignments p JOIN examinations e ON e.id = p.examination_id JOIN rooms r ON r.id = e.room_id JOIN teachers t ON t.id = p.teacher_id JOIN users u ON u.id = t.user_id
    LEFT JOIN attendance a ON a.examination_id = e.id AND a.teacher_id = t.id
    WHERE p.status = 'Confirmed' AND e.status <> 'Cancelled' AND e.exam_date = ? ORDER BY e.start_time, u.full_name", [$date]);
$S = get_settings(true);
$pageTitle = 'Attendance';
$activeNav = 'attendance';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex flex-wrap gap-2 align-items-end mb-3 fade-up">
  <form class="d-flex gap-2 align-items-end"><div><label class="form-label small mb-0">Exam day</label><input type="date" class="form-control" name="date" value="<?= e($date) ?>" onchange="this.form.submit()"></div></form>
  <?php if ($user['role'] === 'admin'): ?><span class="ms-auto"></span>
  <form method="post" class="d-flex gap-2 align-items-end"><?= csrf_field() ?><input type="hidden" name="action" value="minutes"><input type="hidden" name="date" value="<?= e($date) ?>"><div><label class="form-label small mb-0">Time in opens (min before)</label><input type="number" class="form-control" name="minutes" min="0" max="240" value="<?= (int) $S['attendance_open_minutes'] ?>" style="width:110px"></div><button class="btn btn-light">Save</button></form>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="testing"><input type="hidden" name="date" value="<?= e($date) ?>"><input type="hidden" name="on" value="<?= $S['testing_mode'] === '1' ? '0' : '1' ?>"><button class="btn <?= $S['testing_mode'] === '1' ? 'btn-danger' : 'btn-light' ?>">Testing mode: <?= $S['testing_mode'] === '1' ? 'ON' : 'OFF' ?></button></form><?php endif; ?>
</div>
<div class="card-panel fade-up"><?php if (!$rows): ?><?= empty_state('clipboard-check', 'No confirmed proctors on this day') ?><?php else: ?>
<div class="table-responsive"><table class="table table-modern align-middle"><thead><tr><th>Exam</th><th>Time</th><th>Room</th><th>Proctor</th><th>Time in</th><th>Time out</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach ($rows as $r): $ended = strtotime($r['exam_date'] . ' ' . $r['end_time']) < time();
  $stt = $r['time_out'] ? ['Done', 'b-green'] : ($r['time_in'] ? ['On duty', 'b-amber'] : ($ended ? ['Absent', 'b-red'] : ['Waiting', 'b-gray'])); ?>
  <tr><td><strong><?= e($r['exam_code']) ?></strong></td><td><?= e(time_range($r['start_time'], $r['end_time'])) ?></td><td><?= e($r['room']) ?></td><td><?= e($r['full_name']) ?> <span class="small text-muted"><?= e($r['teacher_no']) ?></span></td>
  <td><?= $r['time_in'] ? e(date('g:i A', strtotime($r['time_in']))) : '—' ?></td><td><?= $r['time_out'] ? e(date('g:i A', strtotime($r['time_out']))) : '—' ?></td><td><span class="badge-s <?= $stt[1] ?>"><?= $stt[0] ?></span></td>
  <td class="text-end"><?php if (user_can('attendance.reset') && $r['time_in']): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="reset"><input type="hidden" name="date" value="<?= e($date) ?>"><input type="hidden" name="exam_id" value="<?= (int) $r['eid'] ?>"><input type="hidden" name="teacher_id" value="<?= (int) $r['tid'] ?>"><button class="btn btn-sm btn-light" data-confirm="Reset this time in/out?">Reset</button></form><?php endif; ?></td></tr>
<?php endforeach; ?></tbody></table></div><?php endif; ?></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
