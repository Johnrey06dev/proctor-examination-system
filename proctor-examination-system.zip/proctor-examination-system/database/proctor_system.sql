-- =====================================================================
--  Proctor Assignment and Examination Paper Distribution System
--  Database : proctor_examination_system   (MySQL / MariaDB, XAMPP)
--  Import   : phpMyAdmin > proctor_examination_system > Import
--
--  NOTE: This script uses CREATE TABLE IF NOT EXISTS and never drops
--  anything, so importing it again will NOT erase existing data (it will
--  simply report duplicate-key errors for the sample rows).
--
--  Development logins (passwords are stored as bcrypt hashes created with
--  PHP password_hash(); change them after first login):
--     Admin   : admin@proctor.local      / Admin@12345
--     Teacher : teacher01@proctor.local  / Teacher@12345   (… teacher12)
-- =====================================================================

CREATE DATABASE IF NOT EXISTS proctor_examination_system
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE proctor_examination_system;

SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- users : login accounts for both roles
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  email VARCHAR(150) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  first_name VARCHAR(60) DEFAULT NULL,
  middle_name VARCHAR(60) DEFAULT NULL,
  last_name VARCHAR(60) DEFAULT NULL,
  suffix VARCHAR(10) DEFAULT NULL,
  gender ENUM('Male','Female') DEFAULT NULL,
  photo VARCHAR(120) DEFAULT NULL,
  role ENUM('admin','coordinator','teacher') NOT NULL DEFAULT 'teacher',
  access_role_id INT UNSIGNED DEFAULT NULL,
  extra_perms VARCHAR(500) DEFAULT NULL,
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  contact_number VARCHAR(40) DEFAULT NULL,
  otp_enabled TINYINT(1) NOT NULL DEFAULT 0,
  qr_hash VARCHAR(64) DEFAULT NULL,
  qr_created_at DATETIME DEFAULT NULL,
  last_login_at DATETIME DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  KEY idx_users_role_status (role, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS departments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code VARCHAR(20) NOT NULL,
  name VARCHAR(150) NOT NULL,
  description VARCHAR(255) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_departments_code (code),
  UNIQUE KEY uq_departments_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS subjects (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code VARCHAR(30) NOT NULL,
  name VARCHAR(150) NOT NULL,
  department_id INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_subjects_code (code),
  KEY idx_subjects_department (department_id),
  CONSTRAINT fk_subjects_department FOREIGN KEY (department_id)
    REFERENCES departments (id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS teachers (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  teacher_no VARCHAR(30) NOT NULL,
  department_id INT UNSIGNED NOT NULL,
  specialization VARCHAR(150) DEFAULT NULL,
  availability_status ENUM('Available','Unavailable') NOT NULL DEFAULT 'Available',
  max_assignments INT UNSIGNED DEFAULT NULL,
  max_per_day TINYINT UNSIGNED DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_teachers_user (user_id),
  UNIQUE KEY uq_teachers_no (teacher_no),
  KEY idx_teachers_department (department_id),
  CONSTRAINT fk_teachers_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_teachers_department FOREIGN KEY (department_id)
    REFERENCES departments (id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rooms (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(60) NOT NULL,
  building VARCHAR(100) DEFAULT NULL,
  seat_rows INT UNSIGNED NOT NULL DEFAULT 5,
  seat_cols INT UNSIGNED NOT NULL DEFAULT 8,
  capacity INT UNSIGNED NOT NULL DEFAULT 40,
  max_sections INT UNSIGNED DEFAULT NULL,
  status ENUM('Available','Maintenance') NOT NULL DEFAULT 'Available',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_rooms_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS examinations (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  exam_code VARCHAR(30) NOT NULL,
  name VARCHAR(150) NOT NULL,
  exam_type ENUM('Quiz','Midterm','Final','Make-up','Other') NOT NULL DEFAULT 'Midterm',
  subject_id INT UNSIGNED NOT NULL,
  department_id INT UNSIGNED NOT NULL,
  room_id INT UNSIGNED NOT NULL,
  exam_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  required_proctors TINYINT UNSIGNED NOT NULL DEFAULT 2,
  paper_sets INT UNSIGNED NOT NULL DEFAULT 1,
  is_public TINYINT(1) NOT NULL DEFAULT 1,
  status ENUM('Scheduled','Completed','Cancelled') NOT NULL DEFAULT 'Scheduled',
  notes VARCHAR(255) DEFAULT NULL,
  layout_mode ENUM('blocks','interleave') NOT NULL DEFAULT 'blocks',
  created_by INT UNSIGNED DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_exam_code (exam_code),
  KEY idx_exam_schedule (exam_date, start_time),
  KEY idx_exam_status (status),
  KEY idx_exam_subject (subject_id),
  KEY idx_exam_department (department_id),
  KEY idx_exam_room (room_id),
  CONSTRAINT fk_exam_subject FOREIGN KEY (subject_id)
    REFERENCES subjects (id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_exam_department FOREIGN KEY (department_id)
    REFERENCES departments (id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_exam_room FOREIGN KEY (room_id)
    REFERENCES rooms (id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_exam_creator FOREIGN KEY (created_by)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Blocks of time in which a teacher can NOT proctor (hard constraint #2)
CREATE TABLE IF NOT EXISTS teacher_availability (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  teacher_id INT UNSIGNED NOT NULL,
  unavailable_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  reason VARCHAR(255) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_avail_teacher_date (teacher_id, unavailable_date),
  CONSTRAINT fk_avail_teacher FOREIGN KEY (teacher_id)
    REFERENCES teachers (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Weekly availability: which weekday (1 = Monday ... 6 = Saturday) and which hours a teacher can proctor
CREATE TABLE IF NOT EXISTS teacher_weekly_availability (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  teacher_id INT UNSIGNED NOT NULL,
  weekday TINYINT UNSIGNED NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_twa_teacher (teacher_id, weekday),
  CONSTRAINT fk_twa_teacher FOREIGN KEY (teacher_id)
    REFERENCES teachers (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS proctor_assignments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  examination_id INT UNSIGNED NOT NULL,
  teacher_id INT UNSIGNED NOT NULL,
  status ENUM('Pending Review','Confirmed','Completed','Cancelled') NOT NULL DEFAULT 'Pending Review',
  assignment_type ENUM('Automatic','Manual') NOT NULL DEFAULT 'Automatic',
  workload_score DECIMAL(6,2) DEFAULT NULL,
  rank_position INT UNSIGNED DEFAULT NULL,
  selection_reason TEXT DEFAULT NULL,
  assigned_by INT UNSIGNED DEFAULT NULL,
  confirmed_at DATETIME DEFAULT NULL,
  declined_at DATETIME DEFAULT NULL,
  decline_reason VARCHAR(255) DEFAULT NULL,
  proctor_role ENUM('Head Proctor','Proctor','Assistant Proctor') NOT NULL DEFAULT 'Proctor',
  decline_resolved TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_assignment_exam_teacher (examination_id, teacher_id),
  KEY idx_assignment_teacher_status (teacher_id, status),
  KEY idx_assignment_status (status),
  CONSTRAINT fk_assign_exam FOREIGN KEY (examination_id)
    REFERENCES examinations (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_assign_teacher FOREIGN KEY (teacher_id)
    REFERENCES teachers (id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_assign_by FOREIGN KEY (assigned_by)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Saved explanation of every automatic run (who was selected / excluded and why)
CREATE TABLE IF NOT EXISTS assignment_runs (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  examination_id INT UNSIGNED NOT NULL,
  run_by INT UNSIGNED DEFAULT NULL,
  needed INT UNSIGNED NOT NULL DEFAULT 0,
  assigned INT UNSIGNED NOT NULL DEFAULT 0,
  explanation TEXT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_runs_exam (examination_id),
  CONSTRAINT fk_runs_exam FOREIGN KEY (examination_id)
    REFERENCES examinations (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_runs_user FOREIGN KEY (run_by)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS paper_distribution (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  transaction_no VARCHAR(30) NOT NULL,
  examination_id INT UNSIGNED NOT NULL,
  proctor_teacher_id INT UNSIGNED DEFAULT NULL,
  paper_sets INT UNSIGNED NOT NULL DEFAULT 1,
  status ENUM('Pending','Preparing','Ready for Release','Released','Received','Returned','Completed') NOT NULL DEFAULT 'Pending',
  prepared_at DATETIME DEFAULT NULL,
  released_at DATETIME DEFAULT NULL,
  received_at DATETIME DEFAULT NULL,
  returned_at DATETIME DEFAULT NULL,
  completed_at DATETIME DEFAULT NULL,
  recorded_by INT UNSIGNED DEFAULT NULL,
  remarks VARCHAR(255) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_paper_txn (transaction_no),
  UNIQUE KEY uq_paper_exam (examination_id),
  KEY idx_paper_status (status),
  KEY idx_paper_proctor (proctor_teacher_id),
  CONSTRAINT fk_paper_exam FOREIGN KEY (examination_id)
    REFERENCES examinations (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_paper_proctor FOREIGN KEY (proctor_teacher_id)
    REFERENCES teachers (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_paper_user FOREIGN KEY (recorded_by)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS paper_tracking_history (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  distribution_id INT UNSIGNED NOT NULL,
  old_status VARCHAR(30) DEFAULT NULL,
  new_status VARCHAR(30) NOT NULL,
  changed_by INT UNSIGNED DEFAULT NULL,
  remarks VARCHAR(255) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_history_distribution (distribution_id),
  CONSTRAINT fk_history_distribution FOREIGN KEY (distribution_id)
    REFERENCES paper_distribution (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_history_user FOREIGN KEY (changed_by)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notifications (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(150) NOT NULL,
  message VARCHAR(500) NOT NULL,
  type VARCHAR(40) NOT NULL DEFAULT 'info',
  link VARCHAR(255) DEFAULT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_notif_user_read (user_id, is_read),
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS activity_logs (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED DEFAULT NULL,
  action VARCHAR(80) NOT NULL,
  entity_type VARCHAR(40) DEFAULT NULL,
  entity_id INT UNSIGNED DEFAULT NULL,
  old_value VARCHAR(255) DEFAULT NULL,
  new_value VARCHAR(255) DEFAULT NULL,
  description VARCHAR(500) DEFAULT NULL,
  ip_address VARCHAR(45) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_logs_created (created_at),
  KEY idx_logs_user (user_id),
  KEY idx_logs_entity (entity_type, entity_id),
  CONSTRAINT fk_logs_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Algorithm / system settings configured by the administrator
CREATE TABLE IF NOT EXISTS system_settings (
  setting_key VARCHAR(60) NOT NULL,
  setting_value VARCHAR(255) NOT NULL DEFAULT '',
  description VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Year module: department + year level, each with First / Second Semester subjects (replaces the old Subjects panel)
CREATE TABLE IF NOT EXISTS year_configs (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  department_id INT UNSIGNED NOT NULL,
  year_level TINYINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_year_dept_level (department_id, year_level),
  CONSTRAINT fk_year_department FOREIGN KEY (department_id)
    REFERENCES departments (id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS year_subjects (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  year_config_id INT UNSIGNED NOT NULL,
  semester TINYINT UNSIGNED NOT NULL,
  name VARCHAR(150) NOT NULL,
  subject_id INT UNSIGNED DEFAULT NULL,
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uq_year_subject (year_config_id, semester, name),
  KEY idx_ys_subject (subject_id),
  CONSTRAINT fk_ys_year FOREIGN KEY (year_config_id)
    REFERENCES year_configs (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_ys_subject FOREIGN KEY (subject_id)
    REFERENCES subjects (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- A registered class section (department + year level + semester + number of students)
CREATE TABLE IF NOT EXISTS class_sections (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(60) NOT NULL,
  department_id INT UNSIGNED NOT NULL,
  year_config_id INT UNSIGNED NOT NULL,
  semester TINYINT UNSIGNED NOT NULL,
  students INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_class_section (year_config_id, semester, name),
  KEY idx_cs_year (year_config_id),
  CONSTRAINT fk_cs_department FOREIGN KEY (department_id)
    REFERENCES departments (id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_cs_year FOREIGN KEY (year_config_id)
    REFERENCES year_configs (id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sections that sit the exam in one room (subject + number of examinees per section)
CREATE TABLE IF NOT EXISTS exam_sections (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  examination_id INT UNSIGNED NOT NULL,
  section_name VARCHAR(60) NOT NULL,
  subject_id INT UNSIGNED NOT NULL,
  examinees INT UNSIGNED NOT NULL DEFAULT 0,
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  section_id INT UNSIGNED DEFAULT NULL,
  year_subject_id INT UNSIGNED DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_sec_yearsubject (section_id, year_subject_id),
  KEY idx_sections_exam (examination_id),
  CONSTRAINT fk_sections_exam FOREIGN KEY (examination_id)
    REFERENCES examinations (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_sections_subject FOREIGN KEY (subject_id)
    REFERENCES subjects (id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_sections_class FOREIGN KEY (section_id)
    REFERENCES class_sections (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_sections_ys FOREIGN KEY (year_subject_id)
    REFERENCES year_subjects (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Request / login throttling (rate limiting + cooldown)
CREATE TABLE IF NOT EXISTS rate_limits (
  rl_key VARCHAR(150) NOT NULL,
  hits INT UNSIGNED NOT NULL DEFAULT 0,
  window_start INT UNSIGNED NOT NULL DEFAULT 0,
  blocked_until INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (rl_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- One-time passwords e-mailed at login (stored hashed)
CREATE TABLE IF NOT EXISTS otp_codes (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  code_hash VARCHAR(255) NOT NULL,
  expires_at DATETIME NOT NULL,
  attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
  used_at DATETIME DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_otp_user (user_id),
  CONSTRAINT fk_otp_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Time in / time out of proctors on the exam day
CREATE TABLE IF NOT EXISTS attendance (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  examination_id INT UNSIGNED NOT NULL,
  teacher_id INT UNSIGNED NOT NULL,
  time_in DATETIME DEFAULT NULL,
  time_out DATETIME DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_attendance (examination_id, teacher_id),
  CONSTRAINT fk_att_exam FOREIGN KEY (examination_id) REFERENCES examinations (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_att_teacher FOREIGN KEY (teacher_id) REFERENCES teachers (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Announcements and exam reminders
CREATE TABLE IF NOT EXISTS announcements (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(150) NOT NULL,
  body TEXT NOT NULL,
  kind ENUM('general','reminder') NOT NULL DEFAULT 'general',
  audience ENUM('all','department','teachers') NOT NULL DEFAULT 'all',
  department_id INT UNSIGNED DEFAULT NULL,
  target_ids VARCHAR(500) DEFAULT NULL,
  created_by INT UNSIGNED DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS announcement_reads (
  announcement_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  read_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (announcement_id, user_id),
  CONSTRAINT fk_ar_ann FOREIGN KEY (announcement_id) REFERENCES announcements (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_ar_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Direct messages (teacher <-> admin / people with a role)
CREATE TABLE IF NOT EXISTS messages (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  from_user INT UNSIGNED NOT NULL,
  to_user INT UNSIGNED NOT NULL,
  subject VARCHAR(150) NOT NULL,
  body TEXT NOT NULL,
  examination_id INT UNSIGNED DEFAULT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_msg_to (to_user, is_read),
  CONSTRAINT fk_msg_from FOREIGN KEY (from_user) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_msg_to FOREIGN KEY (to_user) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Roles and access: a role is a bundle of "module.action" permissions
CREATE TABLE IF NOT EXISTS access_roles (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(60) NOT NULL,
  description VARCHAR(200) DEFAULT NULL,
  perms TEXT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_access_role_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
--  SAMPLE DATA
-- =====================================================================

INSERT INTO system_settings (setting_key, setting_value, description) VALUES
 ('max_exams_per_day',   '3',    'Eligibility rule: maximum proctoring assignments a teacher may hold on one day'),
 ('min_gap_minutes',     '0',    'Eligibility rule: minimum rest gap (minutes) between two assignments on the same day'),
 ('dept_rule',           'none', 'Department rule: none | prefer_same | prefer_other | exclude_same'),
 ('dept_weight',         '0.5',  'Soft-constraint penalty added to the workload score when the department preference is not met'),
 ('period_start',        '',     'Scheduling period start (YYYY-MM-DD). Empty = no lower limit'),
 ('period_end',          '',     'Scheduling period end (YYYY-MM-DD). Empty = no upper limit'),
 ('examinees_per_proctor','30',  'Suggested number of examinees one proctor can supervise'),
 ('otp_enabled',         '0',    'Require an e-mailed one-time code (OTP) at login: 1 = on, 0 = off'),
 ('smtp_verified',       '0',    'Set to 1 automatically after a successful test e-mail'),
 ('email_notifications', '0',    'Also e-mail assignment / schedule notifications: 1 = on, 0 = off');

INSERT INTO departments (id, code, name, description) VALUES
 (1, 'CCS', 'College of Computer Studies',  'Information Technology and Computer Science'),
 (2, 'CBA', 'College of Business Administration', 'Business, Accountancy and Management'),
 (3, 'CAS', 'College of Arts and Sciences', 'Mathematics, Sciences and Humanities'),
 (4, 'COE', 'College of Engineering',       'Engineering programs'),
 (5, 'CED', 'College of Education',         'Teacher education programs');

INSERT INTO subjects (id, code, name, department_id) VALUES
 (1, 'IT101',   'Introduction to Computing',   1),
 (2, 'IT102',   'Computer Programming 1',      1),
 (3, 'CS201',   'Data Structures and Algorithms', 1),
 (4, 'BA101',   'Principles of Management',    2),
 (5, 'BA102',   'Financial Accounting',        2),
 (6, 'MATH101', 'College Algebra',             3),
 (7, 'PHY101',  'General Physics',             4),
 (8, 'ENG101',  'Purposive Communication',     5);

INSERT INTO rooms (id, name, building, seat_rows, seat_cols, capacity, status) VALUES
 (1, 'R101', 'Main Building', 5, 8, 40, 'Available'),
 (2, 'R102', 'Main Building', 5, 8, 40, 'Available'),
 (3, 'R201', 'Science Building', 5, 10, 50, 'Available'),
 (4, 'R202', 'Science Building', 5, 10, 50, 'Available'),
 (5, 'LAB1', 'IT Building', 5, 6, 30, 'Available'),
 (6, 'AUD',  NULL, 10, 15, 150, 'Available');

-- users: 1 admin + 12 teachers (password hashes are bcrypt, never plain text)
INSERT INTO users (id, email, password_hash, full_name, role, status, contact_number) VALUES
 (1,  'admin@proctor.local',     '$2y$10$L1vW/DmnUiyL9Ol9/.sftOiCVQq57NyTFCHx0tZOcdLh193o7vzGi', 'System Administrator', 'admin', 'active', '0917-000-0001'),
 (2,  'teacher01@proctor.local', '$2y$10$FhC8jvrOUkgpXH7zshJo2udJ0JvRxl1hQBsauklKidmG.p5ygjxV2', 'Maria Clara Santos',  'teacher', 'active', '0917-100-0001'),
 (3,  'teacher02@proctor.local', '$2y$10$FhC8jvrOUkgpXH7zshJo2udJ0JvRxl1hQBsauklKidmG.p5ygjxV2', 'Juan Dela Cruz',      'teacher', 'active', '0917-100-0002'),
 (4,  'teacher03@proctor.local', '$2y$10$FhC8jvrOUkgpXH7zshJo2udJ0JvRxl1hQBsauklKidmG.p5ygjxV2', 'Ana Reyes',           'teacher', 'active', '0917-100-0003'),
 (5,  'teacher04@proctor.local', '$2y$10$FhC8jvrOUkgpXH7zshJo2udJ0JvRxl1hQBsauklKidmG.p5ygjxV2', 'Jose Ramos',          'teacher', 'active', '0917-100-0004'),
 (6,  'teacher05@proctor.local', '$2y$10$FhC8jvrOUkgpXH7zshJo2udJ0JvRxl1hQBsauklKidmG.p5ygjxV2', 'Liza Mendoza',        'teacher', 'active', '0917-100-0005'),
 (7,  'teacher06@proctor.local', '$2y$10$FhC8jvrOUkgpXH7zshJo2udJ0JvRxl1hQBsauklKidmG.p5ygjxV2', 'Carlo Bautista',      'teacher', 'active', '0917-100-0006'),
 (8,  'teacher07@proctor.local', '$2y$10$FhC8jvrOUkgpXH7zshJo2udJ0JvRxl1hQBsauklKidmG.p5ygjxV2', 'Grace Villanueva',    'teacher', 'active', '0917-100-0007'),
 (9,  'teacher08@proctor.local', '$2y$10$FhC8jvrOUkgpXH7zshJo2udJ0JvRxl1hQBsauklKidmG.p5ygjxV2', 'Mark Aquino',         'teacher', 'active', '0917-100-0008'),
 (10, 'teacher09@proctor.local', '$2y$10$FhC8jvrOUkgpXH7zshJo2udJ0JvRxl1hQBsauklKidmG.p5ygjxV2', 'Patricia Lim',       'teacher', 'active', '0917-100-0009'),
 (11, 'teacher10@proctor.local', '$2y$10$FhC8jvrOUkgpXH7zshJo2udJ0JvRxl1hQBsauklKidmG.p5ygjxV2', 'Ramon Flores',        'teacher', 'active', '0917-100-0010'),
 (12, 'teacher11@proctor.local', '$2y$10$FhC8jvrOUkgpXH7zshJo2udJ0JvRxl1hQBsauklKidmG.p5ygjxV2', 'Teresa Navarro',      'teacher', 'active', '0917-100-0011'),
 (13, 'teacher12@proctor.local', '$2y$10$FhC8jvrOUkgpXH7zshJo2udJ0JvRxl1hQBsauklKidmG.p5ygjxV2', 'Eduardo Castillo',    'teacher', 'inactive', '0917-100-0012');

-- teachers.id 1..12 map to users 2..13
-- teacher 10 (Ramon Flores) = availability "Unavailable"; teacher 12 has an inactive account.
INSERT INTO teachers (id, user_id, teacher_no, department_id, specialization, availability_status) VALUES
 (1,  2,  'T-001', 1, 'Programming',          'Available'),
 (2,  3,  'T-002', 1, 'Database Systems',     'Available'),
 (3,  4,  'T-003', 1, 'Computer Networks',    'Available'),
 (4,  5,  'T-004', 2, 'Management',           'Available'),
 (5,  6,  'T-005', 2, 'Accounting',           'Available'),
 (6,  7,  'T-006', 3, 'Mathematics',          'Available'),
 (7,  8,  'T-007', 3, 'Physics',              'Available'),
 (8,  9,  'T-008', 4, 'Civil Engineering',    'Available'),
 (9,  10, 'T-009', 4, 'Electrical Engineering','Available'),
 (10, 11, 'T-010', 5, 'English Education',    'Unavailable'),
 (11, 12, 'T-011', 5, 'Language Teaching',    'Available'),
 (12, 13, 'T-012', 2, 'Marketing',            'Available');

-- Examinations (dates are relative to the day you import, so there are always upcoming exams)
INSERT INTO examinations (id, exam_code, name, exam_type, subject_id, department_id, room_id, exam_date, start_time, end_time, required_proctors, paper_sets, status, created_by) VALUES
 (1, 'EX-0001', 'IT101 Midterm Examination',      'Midterm', 1, 1, 1, DATE_ADD(CURDATE(), INTERVAL 2 DAY), '09:00:00', '11:00:00', 2, 40, 'Scheduled', 1),
 (2, 'EX-0002', 'BA101 Midterm Examination',      'Midterm', 4, 2, 2, DATE_ADD(CURDATE(), INTERVAL 2 DAY), '09:30:00', '11:30:00', 2, 38, 'Scheduled', 1),
 (3, 'EX-0003', 'MATH101 Midterm Examination',    'Midterm', 6, 3, 3, DATE_ADD(CURDATE(), INTERVAL 3 DAY), '13:00:00', '15:00:00', 3, 48, 'Scheduled', 1),
 (4, 'EX-0004', 'ENG101 Midterm Examination',     'Midterm', 8, 5, 4, DATE_ADD(CURDATE(), INTERVAL 4 DAY), '08:00:00', '10:00:00', 2, 45, 'Scheduled', 1),
 (5, 'EX-0005', 'CS201 Midterm Examination',      'Midterm', 3, 1, 5, DATE_ADD(CURDATE(), INTERVAL 5 DAY), '10:00:00', '12:00:00', 2, 28, 'Scheduled', 1),
 (6, 'EX-0006', 'BA102 Midterm Examination',      'Midterm', 5, 2, 1, DATE_ADD(CURDATE(), INTERVAL 5 DAY), '10:00:00', '12:00:00', 2, 40, 'Scheduled', 1),
 (7, 'EX-0007', 'PHY101 Midterm Examination',     'Midterm', 7, 4, 6, DATE_ADD(CURDATE(), INTERVAL 7 DAY), '14:00:00', '16:00:00', 4, 100, 'Scheduled', 1),
 (8, 'EX-0008', 'IT102 Quiz 3',                   'Quiz',    2, 1, 1, DATE_ADD(CURDATE(), INTERVAL -6 DAY), '09:00:00', '10:00:00', 2, 38, 'Completed', 1),
 (9, 'EX-0009', 'BA102 Quiz 2',                   'Quiz',    5, 2, 2, DATE_ADD(CURDATE(), INTERVAL -2 DAY), '13:00:00', '14:00:00', 2, 36, 'Completed', 1);

-- Teachers 10 (Ramon, availability Unavailable) – nothing; teacher 11 (Teresa) is blocked during EX-0003
INSERT INTO teacher_availability (teacher_id, unavailable_date, start_time, end_time, reason) VALUES
 (11, DATE_ADD(CURDATE(), INTERVAL 3 DAY), '12:00:00', '16:00:00', 'Faculty meeting'),
 (4,  DATE_ADD(CURDATE(), INTERVAL 7 DAY), '08:00:00', '18:00:00', 'Seminar out of campus');

INSERT INTO proctor_assignments (id, examination_id, teacher_id, status, assignment_type, workload_score, rank_position, selection_reason, assigned_by, confirmed_at, created_at) VALUES
 (1, 1, 1, 'Confirmed', 'Manual',    0, NULL, 'Manually assigned by administrator', 1, NOW(), NOW()),
 (2, 1, 2, 'Confirmed', 'Manual',    0, NULL, 'Manually assigned by administrator', 1, NOW(), NOW()),
 (3, 4, 6, 'Pending Review', 'Automatic', 0, 1, 'Rank 1: lowest workload score (0) among eligible teachers', 1, NULL, NOW()),
 (4, 4, 7, 'Pending Review', 'Automatic', 0, 2, 'Rank 2: lowest workload score (0); tie broken by teacher number', 1, NULL, NOW()),
 (5, 8, 3, 'Completed', 'Automatic', 0, 1, 'Historical sample assignment', 1, DATE_ADD(NOW(), INTERVAL -7 DAY), DATE_ADD(NOW(), INTERVAL -8 DAY)),
 (6, 8, 4, 'Completed', 'Automatic', 0, 2, 'Historical sample assignment', 1, DATE_ADD(NOW(), INTERVAL -7 DAY), DATE_ADD(NOW(), INTERVAL -8 DAY)),
 (7, 9, 5, 'Completed', 'Automatic', 0, 1, 'Historical sample assignment', 1, DATE_ADD(NOW(), INTERVAL -3 DAY), DATE_ADD(NOW(), INTERVAL -4 DAY)),
 (8, 9, 4, 'Completed', 'Automatic', 1, 2, 'Historical sample assignment', 1, DATE_ADD(NOW(), INTERVAL -3 DAY), DATE_ADD(NOW(), INTERVAL -4 DAY));

INSERT INTO paper_distribution (id, transaction_no, examination_id, proctor_teacher_id, paper_sets, status, prepared_at, released_at, received_at, returned_at, completed_at, recorded_by, remarks) VALUES
 (1, 'PD-SAMPLE-0001', 1, 1, 40, 'Released',  DATE_ADD(NOW(), INTERVAL -1 DAY), NOW(), NULL, NULL, NULL, 1, 'Released to proctor T-001'),
 (2, 'PD-SAMPLE-0002', 8, 3, 38, 'Completed', DATE_ADD(NOW(), INTERVAL -7 DAY), DATE_ADD(NOW(), INTERVAL -6 DAY), DATE_ADD(NOW(), INTERVAL -6 DAY), DATE_ADD(NOW(), INTERVAL -6 DAY), DATE_ADD(NOW(), INTERVAL -5 DAY), 1, 'All sets returned complete'),
 (3, 'PD-SAMPLE-0003', 9, 5, 36, 'Returned',  DATE_ADD(NOW(), INTERVAL -3 DAY), DATE_ADD(NOW(), INTERVAL -2 DAY), DATE_ADD(NOW(), INTERVAL -2 DAY), DATE_ADD(NOW(), INTERVAL -2 DAY), NULL, 1, 'Awaiting verification');

INSERT INTO paper_tracking_history (distribution_id, old_status, new_status, changed_by, remarks, created_at) VALUES
 (1, NULL, 'Preparing', 1, 'Transaction created', DATE_ADD(NOW(), INTERVAL -1 DAY)),
 (1, 'Preparing', 'Ready for Release', 1, 'Papers prepared', DATE_ADD(NOW(), INTERVAL -1 DAY)),
 (1, 'Ready for Release', 'Released', 1, 'Released to proctor T-001', NOW()),
 (2, NULL, 'Preparing', 1, 'Transaction created', DATE_ADD(NOW(), INTERVAL -8 DAY)),
 (2, 'Preparing', 'Ready for Release', 1, 'Papers prepared', DATE_ADD(NOW(), INTERVAL -7 DAY)),
 (2, 'Ready for Release', 'Released', 1, 'Released to proctor T-003', DATE_ADD(NOW(), INTERVAL -6 DAY)),
 (2, 'Released', 'Received', 4, 'Receipt confirmed by proctor', DATE_ADD(NOW(), INTERVAL -6 DAY)),
 (2, 'Received', 'Returned', 1, 'Papers returned', DATE_ADD(NOW(), INTERVAL -6 DAY)),
 (2, 'Returned', 'Completed', 1, 'Verified complete', DATE_ADD(NOW(), INTERVAL -5 DAY)),
 (3, NULL, 'Preparing', 1, 'Transaction created', DATE_ADD(NOW(), INTERVAL -4 DAY)),
 (3, 'Preparing', 'Ready for Release', 1, 'Papers prepared', DATE_ADD(NOW(), INTERVAL -3 DAY)),
 (3, 'Ready for Release', 'Released', 1, 'Released to proctor T-005', DATE_ADD(NOW(), INTERVAL -2 DAY)),
 (3, 'Released', 'Received', 6, 'Receipt confirmed by proctor', DATE_ADD(NOW(), INTERVAL -2 DAY)),
 (3, 'Received', 'Returned', 1, 'Papers returned', DATE_ADD(NOW(), INTERVAL -2 DAY));

INSERT INTO notifications (user_id, title, message, type, link, is_read) VALUES
 (2, 'Paper released', 'Examination papers for EX-0001 were released to you. Please confirm receipt.', 'paper_release', '/teacher/papers.php', 0),
 (2, 'Assignment confirmed', 'Your proctor assignment for EX-0001 was confirmed.', 'assignment_confirmed', '/teacher/assignments.php', 0),
 (8, 'New proctor assignment', 'You were proposed as proctor for EX-0004 (pending admin review).', 'assignment_new', '/teacher/assignments.php', 0);

INSERT INTO activity_logs (user_id, action, entity_type, entity_id, old_value, new_value, description, ip_address) VALUES
 (1, 'seed', 'system', NULL, NULL, NULL, 'Sample database imported', '127.0.0.1');

-- Sections per exam (subject + examinees). A room can host several sections / subjects.
INSERT INTO exam_sections (examination_id, section_name, subject_id, examinees, sort_order) VALUES
 (1, 'Section A', 1, 20, 1), (1, 'Section B', 2, 18, 2),
 (2, 'BSBA 1-A', 4, 38, 1),
 (3, 'Section 1', 6, 24, 1), (3, 'Section 2', 6, 24, 2),
 (4, 'Section A', 8, 25, 1), (4, 'Section B', 8, 20, 2),
 (5, 'CS 2-A', 3, 28, 1),
 (6, 'ACC 1-A', 5, 20, 1), (6, 'ACC 1-B', 5, 20, 2),
 (7, 'ENG 1-A', 7, 33, 1), (7, 'ENG 1-B', 7, 33, 2), (7, 'ENG 1-C', 7, 33, 3),
 (8, 'Section A', 2, 38, 1),
 (9, 'ACC 1-A', 5, 36, 1);

-- Sample: T-001 declined EX-0005 (shows up in the Reassignment Center)
INSERT INTO proctor_assignments (examination_id, teacher_id, status, assignment_type, workload_score, rank_position, selection_reason, assigned_by, declined_at, decline_reason, decline_resolved, created_at, updated_at) VALUES
 (5, 1, 'Cancelled', 'Automatic', 1, 1, 'Sample declined assignment', 1, NOW(), 'Medical appointment that morning', 0, NOW(), NOW());

INSERT INTO system_settings (setting_key, setting_value, description) VALUES
 ('attendance_open_minutes','60','Time in opens this many minutes before the exam starts'),
 ('testing_mode',          '0',  'Testing mode: 1 = time in/out and completion ignore the exam day (for demos only)');

INSERT INTO system_settings (setting_key, setting_value, description) VALUES
 ('public_schedule',       '1',  'The exam schedule is shown on the public home page (no login needed)'),
 ('school_levels',         'college', 'School levels this school uses (elementary, junior, senior, college)'),
 ('registration_open',     '1',  'Teachers may register themselves with a Gmail address (e-mail code required)'),
 ('registration_approval', '1',  'New self-registered accounts wait for the administrator to activate them'),
 ('qr_login_enabled',      '1',  'Users may create a personal QR code for quick login');

-- Sample: every sample teacher is available every day 7:00 AM - 6:00 PM, so the sample exams (whatever day they fall on) can be assigned; real teachers set Monday-Saturday in My Availability
INSERT INTO teacher_weekly_availability (teacher_id, weekday, start_time, end_time)
 SELECT t.id, d.n, '07:00:00', '18:00:00' FROM teachers t
 JOIN (SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7) d;

INSERT INTO access_roles (name, description, perms) VALUES
 ('Scheduler',          'Arranges rooms, exams and proctors',            'departments.view,subjects.view,rooms.view,rooms.add,rooms.edit,rooms.assign,exams.view,autoassign.view,autoassign.apply'),
 ('Paper Custodian',    'Prepares, releases and receives exam papers',   'exams.view,papers.view,papers.manage'),
 ('Attendance Monitor', 'Watches proctor time in / time out',            'exams.view,attendance.view,attendance.reset'),
 ('Announcer',          'Sends announcements and exam reminders',        'announcements.view,announcements.send'),
 ('Records Officer',    'Views exam records and the activity log',       'records.view,activity.view');

-- sample paper records: copies = students of the section + 5 extra copies
UPDATE paper_distribution SET paper_sets = (SELECT COALESCE(SUM(x.examinees),0) FROM exam_sections x WHERE x.examination_id = paper_distribution.examination_id) + 5;
