-- =====================================================================
--  MIGRATION v2  (run ONCE on the database you already imported)
--  phpMyAdmin > proctor_examination_system > Import (or the SQL tab)
--  Keeps all your existing data. Adds: room grid, exam sections,
--  teacher exam limits, decline/reassignment, rate limiting, OTP.
--  If a statement says "Duplicate column name", it was already applied.
-- =====================================================================
USE proctor_examination_system;

ALTER TABLE rooms ADD COLUMN seat_rows INT UNSIGNED NOT NULL DEFAULT 5;
ALTER TABLE rooms ADD COLUMN seat_cols INT UNSIGNED NOT NULL DEFAULT 8;
ALTER TABLE examinations ADD COLUMN layout_mode ENUM('blocks','interleave') NOT NULL DEFAULT 'blocks';
ALTER TABLE teachers ADD COLUMN max_assignments INT UNSIGNED DEFAULT NULL;
ALTER TABLE teachers ADD COLUMN max_per_day TINYINT UNSIGNED DEFAULT NULL;
ALTER TABLE proctor_assignments ADD COLUMN declined_at DATETIME DEFAULT NULL;
ALTER TABLE proctor_assignments ADD COLUMN decline_reason VARCHAR(255) DEFAULT NULL;
ALTER TABLE proctor_assignments ADD COLUMN decline_resolved TINYINT(1) NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS exam_sections (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  examination_id INT UNSIGNED NOT NULL,
  section_name VARCHAR(60) NOT NULL,
  subject_id INT UNSIGNED NOT NULL,
  examinees INT UNSIGNED NOT NULL DEFAULT 0,
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY idx_sections_exam (examination_id),
  CONSTRAINT fk_sections_exam FOREIGN KEY (examination_id)
    REFERENCES examinations (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_sections_subject FOREIGN KEY (subject_id)
    REFERENCES subjects (id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rate_limits (
  rl_key VARCHAR(150) NOT NULL,
  hits INT UNSIGNED NOT NULL DEFAULT 0,
  window_start INT UNSIGNED NOT NULL DEFAULT 0,
  blocked_until INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (rl_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS otp_codes (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  code_hash VARCHAR(255) NOT NULL,
  expires_at DATETIME NOT NULL,
  attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
  used_at DATETIME DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_otp_user (user_id),
  CONSTRAINT fk_otp_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO system_settings (setting_key, setting_value, description) VALUES
 ('examinees_per_proctor','30',  'Suggested number of examinees one proctor can supervise'),
 ('otp_enabled',         '0',    'Require an e-mailed one-time code (OTP) at login: 1 = on, 0 = off'),
 ('smtp_verified',       '0',    'Set to 1 automatically after a successful test e-mail'),
 ('email_notifications', '0',    'Also e-mail assignment / schedule notifications: 1 = on, 0 = off');

-- Make the existing rooms match the new grid (rows x columns = capacity)
UPDATE rooms SET seat_rows = 5, seat_cols = 8  WHERE capacity = 40;
UPDATE rooms SET seat_rows = 5, seat_cols = 10 WHERE capacity = 50;
UPDATE rooms SET seat_rows = 5, seat_cols = 6  WHERE capacity = 30;
UPDATE rooms SET seat_rows = 10, seat_cols = 15 WHERE capacity = 150;

-- Sample sections for the existing sample exams (one section = the whole paper count)
INSERT INTO exam_sections (examination_id, section_name, subject_id, examinees, sort_order)
SELECT e.id, 'Section A', e.subject_id, e.paper_sets, 1 FROM examinations e
WHERE NOT EXISTS (SELECT 1 FROM exam_sections x WHERE x.examination_id = e.id);

ALTER TABLE users MODIFY role ENUM('admin','coordinator','teacher') NOT NULL DEFAULT 'teacher';
ALTER TABLE proctor_assignments ADD COLUMN proctor_role ENUM('Head Proctor','Proctor','Assistant Proctor') NOT NULL DEFAULT 'Proctor';

-- Time in / time out of proctors on the exam day
CREATE TABLE IF NOT EXISTS attendance (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  examination_id INT UNSIGNED NOT NULL,
  teacher_id INT UNSIGNED NOT NULL,
  time_in DATETIME DEFAULT NULL,
  time_out DATETIME DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_attendance (examination_id, teacher_id),
  CONSTRAINT fk_att_exam FOREIGN KEY (examination_id) REFERENCES examinations (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_att_teacher FOREIGN KEY (teacher_id) REFERENCES teachers (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Announcements and exam reminders
CREATE TABLE IF NOT EXISTS announcements (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(150) NOT NULL,
  body TEXT NOT NULL,
  kind ENUM('general','reminder') NOT NULL DEFAULT 'general',
  audience ENUM('all','department','teachers') NOT NULL DEFAULT 'all',
  department_id INT UNSIGNED DEFAULT NULL,
  target_ids VARCHAR(500) DEFAULT NULL,
  created_by INT UNSIGNED DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS announcement_reads (
  announcement_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  read_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (announcement_id, user_id),
  CONSTRAINT fk_ar_ann FOREIGN KEY (announcement_id) REFERENCES announcements (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_ar_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Direct messages (teacher <-> admin / people with a role)
CREATE TABLE IF NOT EXISTS messages (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  from_user INT UNSIGNED NOT NULL,
  to_user INT UNSIGNED NOT NULL,
  subject VARCHAR(150) NOT NULL,
  body TEXT NOT NULL,
  examination_id INT UNSIGNED DEFAULT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_msg_to (to_user, is_read),
  CONSTRAINT fk_msg_from FOREIGN KEY (from_user) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_msg_to FOREIGN KEY (to_user) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Roles and access: a role is a bundle of "module.action" permissions
CREATE TABLE IF NOT EXISTS access_roles (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(60) NOT NULL,
  description VARCHAR(200) DEFAULT NULL,
  perms TEXT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_access_role_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE users ADD COLUMN access_role_id INT UNSIGNED DEFAULT NULL;
ALTER TABLE users ADD COLUMN extra_perms VARCHAR(500) DEFAULT NULL;

INSERT INTO system_settings (setting_key, setting_value, description) VALUES
 ('attendance_open_minutes','60','Time in opens this many minutes before the exam starts'),
 ('testing_mode',          '0',  'Testing mode: 1 = time in/out and completion ignore the exam day (for demos only)');

INSERT INTO access_roles (name, description, perms) VALUES
 ('Scheduler',          'Arranges rooms, exams and proctors',            'departments.view,subjects.view,rooms.view,rooms.add,rooms.edit,rooms.assign,exams.view,autoassign.view,autoassign.apply'),
 ('Paper Custodian',    'Prepares, releases and receives exam papers',   'exams.view,papers.view,papers.manage'),
 ('Attendance Monitor', 'Watches proctor time in / time out',            'exams.view,attendance.view,attendance.reset'),
 ('Announcer',          'Sends announcements and exam reminders',        'announcements.view,announcements.send'),
 ('Records Officer',    'Views exam records and the activity log',       'records.view,activity.view');


-- ---- V4: room capacity limit, weekly availability, registration, per-user OTP, QR login ----
ALTER TABLE users ADD COLUMN otp_enabled TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN qr_hash VARCHAR(64) DEFAULT NULL;
ALTER TABLE users ADD COLUMN qr_created_at DATETIME DEFAULT NULL;
ALTER TABLE rooms ADD COLUMN max_sections INT UNSIGNED DEFAULT NULL;
CREATE TABLE IF NOT EXISTS teacher_weekly_availability (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  teacher_id INT UNSIGNED NOT NULL,
  weekday TINYINT UNSIGNED NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_twa_teacher (teacher_id, weekday),
  CONSTRAINT fk_twa_teacher FOREIGN KEY (teacher_id) REFERENCES teachers (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO system_settings (setting_key, setting_value, description) VALUES
 ('registration_open',     '1',  'Teachers may register themselves with a Gmail address (e-mail code required)'),
 ('registration_approval', '1',  'New self-registered accounts wait for the administrator to activate them'),
 ('qr_login_enabled',      '1',  'Users may create a personal QR code for quick login');

-- Sample: every sample teacher is available every day 7:00 AM - 6:00 PM, so the sample exams (whatever day they fall on) can be assigned; real teachers set Monday-Saturday in My Availability
INSERT INTO teacher_weekly_availability (teacher_id, weekday, start_time, end_time)
 SELECT t.id, d.n, '07:00:00', '18:00:00' FROM teachers t
 JOIN (SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7) d;

-- ---- V5: split name, gender, profile photo ----
ALTER TABLE users ADD COLUMN first_name VARCHAR(60) DEFAULT NULL;
ALTER TABLE users ADD COLUMN middle_name VARCHAR(60) DEFAULT NULL;
ALTER TABLE users ADD COLUMN last_name VARCHAR(60) DEFAULT NULL;
ALTER TABLE users ADD COLUMN suffix VARCHAR(10) DEFAULT NULL;
ALTER TABLE users ADD COLUMN gender ENUM('Male','Female') DEFAULT NULL;
ALTER TABLE users ADD COLUMN photo VARCHAR(120) DEFAULT NULL;

-- ===== V6: Year module, class sections, per-subject paper tracker =====
-- Year module: department + year level, each with First / Second Semester subjects (replaces the old Subjects panel)
CREATE TABLE IF NOT EXISTS year_configs (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  department_id INT UNSIGNED NOT NULL,
  year_level TINYINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_year_dept_level (department_id, year_level),
  CONSTRAINT fk_year_department FOREIGN KEY (department_id)
    REFERENCES departments (id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS year_subjects (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  year_config_id INT UNSIGNED NOT NULL,
  semester TINYINT UNSIGNED NOT NULL,
  name VARCHAR(150) NOT NULL,
  subject_id INT UNSIGNED DEFAULT NULL,
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uq_year_subject (year_config_id, semester, name),
  KEY idx_ys_subject (subject_id),
  CONSTRAINT fk_ys_year FOREIGN KEY (year_config_id)
    REFERENCES year_configs (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_ys_subject FOREIGN KEY (subject_id)
    REFERENCES subjects (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- A registered class section (department + year level + semester + number of students)
CREATE TABLE IF NOT EXISTS class_sections (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(60) NOT NULL,
  department_id INT UNSIGNED NOT NULL,
  year_config_id INT UNSIGNED NOT NULL,
  semester TINYINT UNSIGNED NOT NULL,
  students INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_class_section (year_config_id, semester, name),
  KEY idx_cs_year (year_config_id),
  CONSTRAINT fk_cs_department FOREIGN KEY (department_id)
    REFERENCES departments (id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_cs_year FOREIGN KEY (year_config_id)
    REFERENCES year_configs (id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE exam_sections ADD COLUMN section_id INT UNSIGNED DEFAULT NULL, ADD COLUMN year_subject_id INT UNSIGNED DEFAULT NULL;
ALTER TABLE exam_sections ADD UNIQUE KEY uq_sec_yearsubject (section_id, year_subject_id);
ALTER TABLE exam_sections ADD CONSTRAINT fk_sections_class FOREIGN KEY (section_id) REFERENCES class_sections (id) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE exam_sections ADD CONSTRAINT fk_sections_ys FOREIGN KEY (year_subject_id) REFERENCES year_subjects (id) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE paper_distribution MODIFY status ENUM('Pending','Preparing','Ready for Release','Released','Received','Returned','Completed') NOT NULL DEFAULT 'Pending';
-- Existing exams that already have a paper record keep their status; new automatic records start as 'Pending'.
-- V6.1: a section belongs to ONE department + year level + semester (the same name may exist in another semester)
-- Only needed if you already ran the V6 block above BEFORE this line existed in your copy:
-- ALTER TABLE class_sections DROP INDEX uq_class_section_name, ADD UNIQUE KEY uq_class_section (year_config_id, semester, name);

-- ===== V7: public exam schedule board =====
ALTER TABLE examinations ADD COLUMN is_public TINYINT(1) NOT NULL DEFAULT 1;
INSERT IGNORE INTO system_settings (setting_key, setting_value, description) VALUES ('public_schedule', '1', 'The exam schedule is shown on the public home page (no login needed)');

-- V9 (Elementary / Junior High / Senior High / College) -- no table changes: Grade 1-12 are stored as year levels 101-112
-- (College stays 1-4) and a section with no semester stores semester 0. Only this setting is new:
INSERT IGNORE INTO system_settings (setting_key, setting_value, description) VALUES ('school_levels', 'college', 'School levels this school uses (elementary, junior, senior, college)');
