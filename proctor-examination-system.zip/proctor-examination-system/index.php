<?php
require_once __DIR__ . '/includes/bootstrap.php';
// Signed-in users go to their own dashboard; everyone else sees the public exam schedule.
if (is_logged_in() && !isset($_GET['public'])) {
    redirect(home_for_role($_SESSION['user']['role']));
}
require __DIR__ . '/schedule.php';
