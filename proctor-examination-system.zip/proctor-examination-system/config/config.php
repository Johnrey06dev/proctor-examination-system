<?php
/**
 * config/config.php
 * Global application settings. Edit BASE_URL only if you rename the project folder.
 */

define('APP_NAME', 'Proctor Assignment & Examination Paper Distribution System');
define('APP_SHORT', 'ProctorSys');
define('APP_TIMEZONE', 'Asia/Manila');
define('SESSION_TIMEOUT', 1800);          // seconds of inactivity before auto-logout
define('APP_DEBUG', true);                // set to false on a real server

// Absolute filesystem path of the project root
define('ROOT_PATH', dirname(__DIR__));

// URL path of the project (no trailing slash). AUTOMATIC: it follows the folder name inside htdocs,
// so you can rename the folder (e.g. to EXAMINATION) without editing anything.
$__base = getenv('PES_BASE_URL');
if ($__base === false) {
    $__doc = isset($_SERVER['DOCUMENT_ROOT']) ? str_replace('\\', '/', (string) realpath($_SERVER['DOCUMENT_ROOT'])) : '';
    $__root = str_replace('\\', '/', ROOT_PATH);
    $__base = ($__doc !== '' && strpos($__root, $__doc) === 0) ? rtrim(substr($__root, strlen($__doc)), '/') : '/proctor-examination-system';
}
define('BASE_URL', $__base);

date_default_timezone_set(APP_TIMEZONE);

if (APP_DEBUG) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
}
