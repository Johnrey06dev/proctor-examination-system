<?php
/**
 * config/mail.php  –  e-mail (SMTP) settings used for OTP codes and optional notification e-mails.
 *
 * HOW TO USE A GMAIL ACCOUNT AS THE SENDER
 *  1. Sign in to the Gmail account that will SEND the codes (e.g. yourschool.system@gmail.com).
 *  2. Turn on 2-Step Verification:  https://myaccount.google.com/security
 *  3. Create an "App password":     https://myaccount.google.com/apppasswords
 *     (name it "Proctor system", Google shows a 16-letter password).
 *  4. Put the Gmail address in MAIL_USERNAME and the 16-letter app password in MAIL_PASSWORD.
 *     (NOT your normal Gmail password.)  Keep this file private – never share or upload it.
 *  5. Admin > Security > "Send test e-mail". When it succeeds you can switch OTP on.
 */
define('MAIL_HOST',       getenv('PES_MAIL_HOST') ?: 'smtp.gmail.com');
define('MAIL_PORT',       (int) (getenv('PES_MAIL_PORT') ?: 587));
define('MAIL_ENCRYPTION', getenv('PES_MAIL_ENC') ?: 'tls');      // 'tls' (STARTTLS, port 587), 'ssl' (port 465) or 'none'
define('MAIL_USERNAME',   getenv('PES_MAIL_USER') ?: '');         // sender Gmail address
define('MAIL_PASSWORD',   getenv('PES_MAIL_PASS') ?: '');         // Gmail APP PASSWORD (16 letters)
define('MAIL_FROM_EMAIL', MAIL_USERNAME);
define('MAIL_FROM_NAME',  'ProctorSys – Exam Office');
