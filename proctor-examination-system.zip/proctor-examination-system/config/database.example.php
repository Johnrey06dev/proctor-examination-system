<?php
/**
 * config/database.php
 * Reusable PDO connection. Credentials live ONLY here (server side) and are
 * never printed to the browser or sent to JavaScript.
 *
 * Standard XAMPP defaults: user "root", EMPTY password, port 3306.
 * If your MySQL uses a different user / password / port, change the 5 lines below.
 */

define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'proctor_examination_system');
define('DB_USER', 'root');
define('DB_PASS', '');

/**
 * Returns a shared PDO instance (created on first use).
 */
function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    try {
        $sqliteFile = getenv('PES_SQLITE'); // used only by the automated test harness
        if ($sqliteFile) {
            $pdo = new PDO('sqlite:' . $sqliteFile);
            $pdo->exec('PRAGMA foreign_keys = ON');
        } else {
            $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            $pdo->exec("SET time_zone = '+08:00'");
        }
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        db_connection_error($e);
    }
    return $pdo;
}

/**
 * Friendly error page for connection problems (never shows the password).
 */
function db_connection_error(PDOException $e): void
{
    http_response_code(500);
    $code = (int) $e->getCode();
    $hint = 'Check config/database.php and make sure MySQL is running in the XAMPP Control Panel.';
    if ($code === 1049) {
        $hint = 'Unknown database: create "' . DB_NAME . '" in phpMyAdmin and import database/proctor_system.sql.';
    } elseif ($code === 1045) {
        $hint = 'Access denied: the MySQL username/password in config/database.php is wrong.';
    } elseif ($code === 2002) {
        $hint = 'Connection refused: MySQL is not running or the port (' . DB_PORT . ') is different. Start MySQL in XAMPP.';
    }
    echo '<!doctype html><meta charset="utf-8"><title>Database connection failed</title>'
        . '<body style="font-family:Segoe UI,Arial,sans-serif;background:#f4f6f9;padding:40px">'
        . '<div style="max-width:640px;margin:auto;background:#fff;border-left:5px solid #b42318;padding:24px;border-radius:6px">'
        . '<h2 style="margin-top:0;color:#0b2545">Database connection failed</h2>'
        . '<p>' . htmlspecialchars($hint) . '</p>'
        . (defined('APP_DEBUG') && APP_DEBUG ? '<pre style="background:#f4f6f9;padding:10px;white-space:pre-wrap">' . htmlspecialchars($e->getMessage()) . '</pre>' : '')
        . '</div></body>';
    exit;
}
