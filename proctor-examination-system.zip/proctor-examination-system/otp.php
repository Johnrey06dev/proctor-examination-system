<?php
require_once __DIR__ . '/includes/bootstrap.php';

if (is_logged_in()) redirect(home_for_role($_SESSION['user']['role']));
$pending = $_SESSION['otp_pending'] ?? null;
if (!$pending || $pending['exp'] < time()) {
    unset($_SESSION['otp_pending']);
    flash('warning', 'Your verification session expired. Please sign in again.');
    redirect('login.php');
}
$uid = (int) $pending['uid'];

if (require_post_csrf()) {
    $action = input_str('action', 10);
    if ($action === 'cancel') {
        unset($_SESSION['otp_pending']);
        redirect('login.php');
    }
    if ($action === 'resend') {
        $u = load_login_user('u.id = ?', $uid);
        $r = $u ? otp_issue($u) : ['ok' => false, 'error' => 'Account not found.'];
        $r['ok'] ? flash('success', 'A new code was sent to ' . $pending['email'] . '.') : flash('danger', $r['error']);
        redirect('otp.php');
    }
    $r = otp_verify($uid, input_str('code', 12));
    if ($r['ok']) {
        $u = load_login_user('u.id = ?', $uid);
        if ($u && $u['status'] === 'active') {
            complete_login($u);
            redirect(home_for_role($u['role']));
        }
        flash('danger', 'This account is inactive.');
        redirect('login.php');
    }
    log_activity('otp_failed', 'security', $uid, null, null, 'Wrong or expired OTP', $uid);
    flash('danger', $r['error']);
    redirect('otp.php');
}
$cool = otp_cooldown_left($uid);
$blocked = rl_blocked('otp:verify:' . $uid);
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Verify login · <?= e(APP_SHORT) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Merriweather:wght@700&display=swap" rel="stylesheet">
<link href="<?= e(url('assets/css/app.css') . '?v=' . filemtime(ROOT_PATH . '/assets/css/app.css')) ?>" rel="stylesheet">
<link href="<?= e(url('assets/css/theme.css') . '?v=' . filemtime(ROOT_PATH . '/assets/css/theme.css')) ?>" rel="stylesheet">
</head>
<body class="auth-body">
<div class="auth-bg"><span><i class="bi bi-book"></i></span><span><i class="bi bi-pencil"></i></span><span><i class="bi bi-mortarboard"></i></span><span><i class="bi bi-journal-text"></i></span><span><i class="bi bi-award"></i></span></div>
<div class="auth-card">
  <div class="auth-crest"><i class="bi bi-shield-lock"></i></div>
  <h4>Two-step verification</h4>
  <p class="text-muted">We sent a 6-digit code to <strong><?= e($pending['email']) ?></strong>. It expires in 5 minutes.</p>
  <?php foreach (flash_pull() as $fl): ?><div class="alert alert-<?= e($fl['type']) ?> py-2"><?= e($fl['msg']) ?></div><?php endforeach; ?>
  <form method="post" autocomplete="off">
    <?= csrf_field() ?><input type="hidden" name="action" value="verify">
    <input class="form-control otp-input" name="code" inputmode="numeric" pattern="[0-9]*" maxlength="6" placeholder="••••••" required autofocus <?= $blocked ? 'disabled' : '' ?>>
    <?php if ($blocked): ?><div class="text-danger small mt-2">Too many wrong codes. Try again in <?= e(fmt_wait($blocked)) ?>.</div><?php endif; ?>
    <button class="btn btn-navy w-100 py-2 mt-3" type="submit" data-loading="Verifying..." <?= $blocked ? 'disabled' : '' ?>>Verify &amp; sign in</button>
  </form>
  <div class="d-flex justify-content-between align-items-center mt-3">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="resend">
      <button class="btn btn-link p-0" type="submit" id="resendBtn" <?= $cool ? 'disabled' : '' ?>>Resend code<span id="resendTimer" data-seconds="<?= (int) $cool ?>"><?= $cool ? ' (' . (int) $cool . 's)' : '' ?></span></button></form>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="cancel"><button class="btn btn-link p-0 text-muted" type="submit">Cancel</button></form>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(url('assets/js/app.js') . '?v=' . filemtime(ROOT_PATH . '/assets/js/app.js')) ?>"></script>
<script>
(function(){var t=document.getElementById('resendTimer'),b=document.getElementById('resendBtn');if(!t)return;var s=parseInt(t.dataset.seconds,10);if(s<=0)return;
var i=setInterval(function(){s--;if(s<=0){clearInterval(i);t.textContent='';b.disabled=false;return;}t.textContent=' ('+s+'s)';},1000);})();
</script>
</body>
</html>
