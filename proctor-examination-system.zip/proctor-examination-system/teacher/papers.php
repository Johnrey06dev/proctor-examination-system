<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('teacher');
$tid = my_teacher_id();
$pt = new PaperTracker(db());

if (require_post_csrf()) {
    // Ownership is enforced inside PaperTracker::confirmReceipt (proctor_teacher_id must equal my teacher id).
    $r = $pt->confirmReceipt(input_int('id'), $tid, (int) $user['id']);
    if ($r['ok']) flash('success', 'Receipt confirmed. The administrator was notified.'); else foreach ($r['errors'] as $er) flash('danger', $er);
    redirect('teacher/papers.php');
}
$rows = fetch_all("SELECT p.*, e.exam_code, e.name AS exam_name, e.exam_date, e.start_time, e.end_time, r.name AS room_name
    FROM paper_distribution p JOIN examinations e ON e.id = p.examination_id JOIN rooms r ON r.id = e.room_id
    WHERE p.proctor_teacher_id = ? ORDER BY p.id DESC", [$tid]);

$pageTitle = 'Examination Papers';
$activeNav = 'papers';
require __DIR__ . '/../includes/header.php';
?>
<div class="card-panel">
  <div class="panel-head"><h5>Papers released to me</h5></div>
  <div class="explain-box mb-3" data-info><strong>Return instructions:</strong> after the examination, bring all answer sheets and unused papers back to the examination office. The administrator records the return and verifies the count; the transaction then becomes <em>Completed</em>.</div>
  <?php if (!$rows): ?><?= empty_state('inbox', 'No papers released to you yet', 'When the administrator releases papers for one of your examinations, they appear here.') ?><?php else: ?>
  <div class="table-responsive"><table class="table table-modern align-middle">
    <thead><tr><th>Transaction</th><th>Exam</th><th>Date &amp; room</th><th class="text-center">Sets</th><th>Status</th><th>Receipt</th><th>Return</th><th></th></tr></thead><tbody>
    <?php foreach ($rows as $p): ?><tr>
      <td><strong><?= e($p['transaction_no']) ?></strong></td><td><?= e($p['exam_code']) ?><div class="small text-muted"><?= e($p['exam_name']) ?></div></td>
      <td><?= e(fmt_date($p['exam_date'])) ?><div class="small text-muted"><?= e(time_range($p['start_time'], $p['end_time'])) ?> · <?= e($p['room_name']) ?></div></td>
      <td class="text-center"><?= (int) $p['paper_sets'] ?></td><td><?= status_badge($p['status']) ?></td>
      <td class="small"><?= $p['received_at'] ? '<i class="bi bi-check-circle-fill text-success"></i> ' . e(fmt_dt($p['received_at'])) : 'Pending' ?></td>
      <td class="small"><?= $p['returned_at'] ? e(fmt_dt($p['returned_at'])) : 'Not yet returned' ?></td>
      <td class="text-end"><?php if ($p['status'] === 'Released'): ?>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $p['id'] ?>"><button class="btn btn-sm btn-navy" type="submit" data-confirm="Confirm that you physically received the <?= (int) $p['paper_sets'] ?> paper set(s) for <?= e($p['exam_code']) ?>?"><i class="bi bi-check2-square me-1"></i>Confirm receipt</button></form><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
