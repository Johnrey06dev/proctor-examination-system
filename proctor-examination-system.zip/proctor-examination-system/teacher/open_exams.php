<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('teacher');
$tid = my_teacher_id();
$sched = new ProctorScheduler(db());

if (require_post_csrf()) {
    $examId = input_int('exam_id');
    $r = $sched->manualAssign($examId, $tid, 'Confirmed', (int) $user['id']);   // same hard constraints as everyone else
    if ($r['ok']) {
        $ex = $sched->getExam($examId);
        notify_admins('Proctor took an open exam', $user['name'] . ' took ' . $ex['exam_code'] . ' (' . fmt_date($ex['exam_date']) . ').', 'assignment_taken', 'admin/assignments.php');
        flash('success', 'You took this exam. It is now in My Assignments.');
    } else { flash('danger', 'You cannot take this exam:'); foreach ($r['errors'] as $er) flash('warning', $er); }
    redirect('teacher/open_exams.php');
}
$me = fetch_one('SELECT department_id FROM teachers WHERE id = ?', [$tid]);
$all = fetch_all("SELECT e.id, e.exam_code, e.name, e.exam_date, e.start_time, e.end_time, e.required_proctors, e.department_id, r.name AS room, r.building, s.code AS subject,
    (SELECT COUNT(*) FROM proctor_assignments a WHERE a.examination_id = e.id AND a.status <> 'Cancelled') AS have
    FROM examinations e JOIN rooms r ON r.id = e.room_id JOIN subjects s ON s.id = e.subject_id
    WHERE e.status = 'Scheduled' AND e.exam_date >= ? ORDER BY e.exam_date, e.start_time", [date('Y-m-d')]);
$open = []; $locked = 0;
foreach ($all as $x) {
    if ((int) $x['have'] >= (int) $x['required_proctors']) continue;
    if ((int) $x['department_id'] !== (int) $me['department_id']) continue;
    if (fetch_value("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id = ? AND teacher_id = ? AND status <> 'Cancelled'", [$x['id'], $tid])) continue;
    $why = $sched->validateTeacher($tid, $sched->getExam((int) $x['id']));
    $x['why'] = $why; $open[] = $x;
}
$pageTitle = 'Open Exams';
$activeNav = 'openexams';
require __DIR__ . '/../includes/header.php';
?>
<div class="mb-3 fade-up"><h5 class="serif mb-0">Open exams in my department</h5><small class="text-muted">Exams that still need proctors. You can take one if you are free and have no conflict.</small></div>
<?php if (!$open): ?><div class="card-panel"><?= empty_state('check2-circle', 'No open exams', 'Every upcoming exam in your department already has its proctors.') ?></div><?php else: ?>
<div class="row g-3">
<?php foreach ($open as $i => $x): ?><div class="col-md-6 col-xl-4 fade-up" style="--d:<?= min($i, 8) * 60 ?>ms"><div class="card-panel h-100">
  <div class="d-flex justify-content-between"><strong><?= e($x['exam_code']) ?></strong><span class="badge bg-danger"><?= (int) $x['have'] ?>/<?= (int) $x['required_proctors'] ?> proctors</span></div>
  <div class="mt-1"><?= e($x['name']) ?> <span class="text-muted small"><?= e($x['subject']) ?></span></div>
  <div class="small text-muted mt-1"><i class="bi bi-calendar-event me-1"></i><?= e(fmt_date($x['exam_date'])) ?> &middot; <?= e(time_range($x['start_time'], $x['end_time'])) ?><br><i class="bi bi-door-open me-1"></i><?= e($x['room']) ?><?= $x['building'] ? ' · ' . e($x['building']) : '' ?></div>
  <?php if ($x['why']): ?><div class="alert alert-warning py-1 px-2 small mt-2 mb-2"><?= e($x['why'][0]) ?></div><button class="btn btn-sm btn-light w-100" disabled>Cannot take</button>
  <?php else: ?><form method="post" class="mt-2"><?= csrf_field() ?><input type="hidden" name="exam_id" value="<?= (int) $x['id'] ?>"><button class="btn btn-navy w-100" data-confirm="Take <?= e($x['exam_code']) ?> as proctor?"><i class="bi bi-hand-index-thumb me-1"></i>Take this exam</button></form><?php endif; ?>
</div></div><?php endforeach; ?></div><?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
