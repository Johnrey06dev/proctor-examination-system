<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('teacher');
$pdo = db(); $uid = (int) $user['id'];
if (require_post_csrf()) {
    $a = input_str('action', 8);
    if ($a === 'send') {
        $to = input_int('to'); $b = input_str('body', 2000);
        if ($b === '' || !is_staff_id($to)) flash('danger', 'Choose a recipient and write a message.');
        else { send_message($uid, $to, input_str('subject', 150) ?: 'Message from ' . $user['name'], $b); flash('success', 'Sent.'); }
    } elseif ($a === 'readann') {
        $ann = fetch_one('SELECT * FROM announcements WHERE id = ?', [input_int('id')]);
        if ($ann && announcement_visible_to($ann, $uid) && !fetch_value('SELECT COUNT(*) FROM announcement_reads WHERE announcement_id = ? AND user_id = ?', [$ann['id'], $uid]))
            $pdo->prepare('INSERT INTO announcement_reads (announcement_id, user_id, read_at) VALUES (?,?,?)')->execute([$ann['id'], $uid, now()]);
    } elseif ($a === 'read') $pdo->prepare('UPDATE messages SET is_read = 1 WHERE id = ? AND to_user = ?')->execute([input_int('id'), $uid]);
    redirect('teacher/messages.php');
}
$anns = array_filter(fetch_all('SELECT a.*, (SELECT COUNT(*) FROM announcement_reads r WHERE r.announcement_id = a.id AND r.user_id = ?) AS isread FROM announcements a ORDER BY a.id DESC LIMIT 60', [$uid]), fn($a) => announcement_visible_to($a, $uid));
$msgs = fetch_all('SELECT m.*, u.full_name FROM messages m JOIN users u ON u.id = m.from_user WHERE m.to_user = ? ORDER BY m.id DESC LIMIT 50', [$uid]);
$targets = message_targets();
$quick = ["I can't make this schedule", 'I need to swap my exam', 'I have a question about my assignment', 'My availability changed'];
$pageTitle = 'Messages'; $activeNav = 'messages';
require __DIR__ . '/../includes/header.php';
?>
<div class="row g-3"><div class="col-lg-5"><div class="card-panel fade-up"><h5>Message the scheduler</h5>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="send">
<select name="to" class="form-select mb-2"><?php foreach ($targets as $t): ?><option value="<?= (int) $t['id'] ?>"><?= e($t['full_name']) ?> (<?= $t['role'] === 'admin' ? 'Admin' : 'Scheduler' ?>)</option><?php endforeach; ?></select>
<div class="mb-2"><input class="form-control" name="subject" id="sub" placeholder="Subject" maxlength="150"><div class="d-flex flex-wrap gap-1 mt-1"><?php foreach ($quick as $q): ?><button type="button" class="btn btn-sm btn-light" onclick="document.getElementById('sub').value=this.textContent"><?= e($q) ?></button><?php endforeach; ?></div></div>
<textarea class="form-control mb-2" name="body" rows="4" maxlength="2000" placeholder="Message" required></textarea><button class="btn btn-gold w-100">Send</button></form></div></div>
<div class="col-lg-7"><div class="card-panel fade-up mb-3"><h5>Announcements</h5>
<?php if (!$anns): ?><?= empty_state('megaphone', 'No announcements') ?><?php endif; ?>
<?php foreach ($anns as $a): ?><div class="border-bottom py-2"><div class="d-flex justify-content-between"><strong><?= e($a['title']) ?> <span class="badge-s <?= $a['kind'] === 'reminder' ? 'b-amber' : 'b-blue' ?>"><?= e($a['kind']) ?></span></strong>
<?php if (!$a['isread']): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="readann"><input type="hidden" name="id" value="<?= (int) $a['id'] ?>"><button class="btn btn-sm btn-light">Mark read</button></form><?php else: ?><span class="badge-s b-green">Read</span><?php endif; ?></div>
<div class="small"><?= nl2br(e($a['body'])) ?></div><div class="small text-muted"><?= e(fmt_dt($a['created_at'])) ?></div></div><?php endforeach; ?></div>
<div class="card-panel fade-up"><h5>Inbox</h5><?php if (!$msgs): ?><?= empty_state('chat-dots', 'No messages') ?><?php endif; ?>
<?php foreach ($msgs as $m): ?><div class="border-bottom py-2"><div class="d-flex justify-content-between"><strong><?= e($m['subject']) ?></strong><?php if (!$m['is_read']): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="read"><input type="hidden" name="id" value="<?= (int) $m['id'] ?>"><button class="btn btn-sm btn-light">Mark read</button></form><?php endif; ?></div><div class="small"><?= nl2br(e($m['body'])) ?></div><div class="small text-muted">from <?= e($m['full_name']) ?> &middot; <?= e(fmt_dt($m['created_at'])) ?></div></div><?php endforeach; ?></div></div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
