<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('teacher');
$tid = my_teacher_id();
$today = date('Y-m-d');

$base = "SELECT a.*, e.exam_code, e.name AS exam_name, e.exam_date, e.start_time, e.end_time, r.name AS room_name, s.code AS subject_code, s.name AS subject_name,
        p.id AS paper_id, p.status AS paper_status, p.proctor_teacher_id AS paper_proctor
    FROM proctor_assignments a JOIN examinations e ON e.id = a.examination_id JOIN rooms r ON r.id = e.room_id JOIN subjects s ON s.id = e.subject_id
    LEFT JOIN paper_distribution p ON p.examination_id = e.id WHERE a.teacher_id = ? ";
$upcoming = fetch_all($base . "AND a.status IN ('Pending Review','Confirmed') AND e.status = 'Scheduled' AND e.exam_date >= ? ORDER BY e.exam_date, e.start_time LIMIT 10", [$tid, $today]);
$recent = fetch_all($base . "AND (a.status IN ('Completed','Cancelled') OR e.exam_date < ?) ORDER BY e.exam_date DESC, e.start_time DESC LIMIT 5", [$tid, $today]);

$cnt = fn($st) => (int) fetch_value("SELECT COUNT(*) FROM proctor_assignments a JOIN examinations e ON e.id = a.examination_id WHERE a.teacher_id = ? AND a.status = ? AND e.exam_date >= ?", [$tid, $st, $today]);
$pending = $cnt('Pending Review'); $confirmed = $cnt('Confirmed');
$awaiting = (int) fetch_value("SELECT COUNT(*) FROM paper_distribution WHERE proctor_teacher_id = ? AND status = 'Released'", [$tid]);
$completed = (int) fetch_value("SELECT COUNT(*) FROM proctor_assignments WHERE teacher_id = ? AND status = 'Completed'", [$tid]);

function paper_cell(array $a, int $tid): string
{
    if (!$a['paper_id']) return '<span class="text-muted small">No papers yet</span>';
    if ((int) $a['paper_proctor'] !== $tid) return $a['paper_proctor'] ? '<span class="text-muted small">Held by another proctor</span>' : '<span class="text-muted small">Not released</span>';
    return status_badge($a['paper_status']);
}

$pageTitle = 'My Dashboard';
$activeNav = 'dashboard';
require __DIR__ . '/../includes/header.php';
?>
<div class="card-panel" style="background:var(--navy);color:#fff;border:0">
  <h4 class="mb-1"><?= e(greeting()) ?></h4><div class="small text-muted mb-1"><?= e($user['name']) ?></div>
  <div style="color:#b9c8e0">Here are your proctoring duties and examination papers.</div>
</div>
<div class="row g-3 mb-3">
  <div class="col-6 col-lg-3"><div class="stat-card <?= $pending ? 'warn' : '' ?>"><div class="stat-icon"><i class="bi bi-hourglass-split"></i></div><div><div class="stat-value"><?= $pending ?></div><div class="stat-label">Pending assignments</div></div></div></div>
  <div class="col-6 col-lg-3"><div class="stat-card ok"><div class="stat-icon"><i class="bi bi-check2-circle"></i></div><div><div class="stat-value"><?= $confirmed ?></div><div class="stat-label">Confirmed (upcoming)</div></div></div></div>
  <div class="col-6 col-lg-3"><a href="<?= e(url('teacher/papers.php')) ?>" class="text-decoration-none"><div class="stat-card <?= $awaiting ? 'danger' : '' ?>"><div class="stat-icon"><i class="bi bi-inbox"></i></div><div><div class="stat-value"><?= $awaiting ?></div><div class="stat-label">Papers awaiting your receipt</div></div></div></a></div>
  <div class="col-6 col-lg-3"><div class="stat-card"><div class="stat-icon"><i class="bi bi-journal-check"></i></div><div><div class="stat-value"><?= $completed ?></div><div class="stat-label">Completed duties</div></div></div></div>
</div>
<div class="card-panel">
  <div class="panel-head"><h5>Upcoming examination assignments</h5><a class="btn btn-sm btn-outline-navy" href="<?= e(url('teacher/assignments.php')) ?>">All assignments</a></div>
  <?php if (!$upcoming): ?><?= empty_state('calendar-check', 'No upcoming assignments', 'You will be notified when you are assigned as a proctor.') ?><?php else: ?>
  <div class="table-responsive"><table class="table table-modern align-middle">
    <thead><tr><th>Exam</th><th>Subject</th><th>Date &amp; time</th><th>Room</th><th>Assignment</th><th>Paper receipt / return</th></tr></thead><tbody>
    <?php foreach ($upcoming as $a): ?><tr><td><strong><?= e($a['exam_code']) ?></strong><div class="small text-muted"><?= e($a['exam_name']) ?></div></td><td><?= e($a['subject_code']) ?></td>
      <td><?= e(fmt_date($a['exam_date'])) ?><div class="small text-muted"><?= e(time_range($a['start_time'], $a['end_time'])) ?></div></td><td><?= e($a['room_name']) ?></td>
      <td><?= status_badge($a['status']) ?></td><td><?= paper_cell($a, $tid) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</div>
<div class="card-panel">
  <div class="panel-head"><h5>Recent assignment history</h5><a class="btn btn-sm btn-outline-navy" href="<?= e(url('teacher/history.php')) ?>">Full history</a></div>
  <?php if (!$recent): ?><?= empty_state('journal-x', 'No history yet') ?><?php else: ?>
  <div class="table-responsive"><table class="table table-modern"><thead><tr><th>Exam</th><th>Date</th><th>Room</th><th>Status</th><th>Papers</th></tr></thead><tbody>
    <?php foreach ($recent as $a): ?><tr><td><strong><?= e($a['exam_code']) ?></strong> <span class="text-muted small"><?= e($a['subject_code']) ?></span></td><td><?= e(fmt_date($a['exam_date'])) ?></td><td><?= e($a['room_name']) ?></td><td><?= status_badge($a['status']) ?></td><td><?= paper_cell($a, $tid) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
