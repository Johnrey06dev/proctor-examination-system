<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('teacher');
$pdo = db(); $tid = my_teacher_id();
if (require_post_csrf()) {
    $x = input_int('exam_id');
    $r = input_str('action', 8) === 'out' ? Attendance::timeOut($pdo, $x, $tid) : Attendance::timeIn($pdo, $x, $tid);
    $r['ok'] ? flash('success', 'Recorded at ' . date('g:i A') . '.') : flash('danger', $r['error']);
    redirect('teacher/today.php');
}
$today = Attendance::testing() ? null : date('Y-m-d');
$sql = "SELECT e.id, e.exam_code, e.name, e.exam_date, e.start_time, e.end_time, r.name AS room, r.building, s.code AS subject, a.time_in, a.time_out
    FROM proctor_assignments p JOIN examinations e ON e.id = p.examination_id JOIN rooms r ON r.id = e.room_id JOIN subjects s ON s.id = e.subject_id
    LEFT JOIN attendance a ON a.examination_id = e.id AND a.teacher_id = p.teacher_id
    WHERE p.teacher_id = ? AND p.status = 'Confirmed' AND e.status = 'Scheduled'" . ($today ? ' AND e.exam_date = ?' : ' AND e.exam_date >= ?');
$rows = fetch_all($sql . ' ORDER BY e.exam_date, e.start_time', [$tid, $today ?: date('Y-m-d')]);
$next = fetch_one("SELECT e.exam_date, e.start_time, e.exam_code FROM proctor_assignments p JOIN examinations e ON e.id = p.examination_id WHERE p.teacher_id = ? AND p.status = 'Confirmed' AND e.status = 'Scheduled' AND e.exam_date > ? ORDER BY e.exam_date, e.start_time LIMIT 1", [$tid, date('Y-m-d')]);
$pageTitle = 'Exam Day';
$activeNav = 'today';
require __DIR__ . '/../includes/header.php';
?>
<div class="hero fade-up"><div><div class="hero-eyebrow">Server time</div><h2 id="clock" class="serif" data-ts="<?= time() ?>"><?= e(date('g:i:s A')) ?></h2><p class="mb-0"><?= e(date('l, F j, Y')) ?><?= Attendance::testing() ? ' &middot; <b>TESTING MODE</b>' : '' ?></p></div>
  <div class="text-end small" style="color:#cdd9ee">Time in opens <?= Attendance::openMinutes() ?> minutes before the exam.</div></div>
<?php if (!$rows): ?><div class="card-panel"><?= empty_state('calendar-check', 'No exam for you today', $next ? 'Your next exam: ' . $next['exam_code'] . ', ' . fmt_date($next['exam_date']) . ' ' . fmt_time($next['start_time']) . '.' : 'No confirmed exam yet.') ?></div>
<?php else: ?><div class="row g-3">
<?php foreach ($rows as $x): $why = Attendance::whyNotIn(['exam_date' => $x['exam_date'], 'start_time' => $x['start_time'], 'end_time' => $x['end_time']]); $live = !$x['time_in'] && !$why; ?>
  <div class="col-lg-6"><div class="card-panel h-100 <?= $live || ($x['time_in'] && !$x['time_out']) ? 'border-warning border-2' : '' ?>">
    <div class="d-flex justify-content-between"><strong><?= e($x['exam_code']) ?></strong><?= $x['time_out'] ? '<span class="badge-s b-green">Done</span>' : ($x['time_in'] ? '<span class="badge-s b-amber">On duty</span>' : '<span class="badge-s b-gray">Not yet</span>') ?></div>
    <h5 class="mt-1"><?= e($x['name']) ?> <small class="text-muted"><?= e($x['subject']) ?></small></h5>
    <div class="small text-muted mb-2"><i class="bi bi-calendar-event me-1"></i><?= e(fmt_date($x['exam_date'])) ?> &middot; <?= e(time_range($x['start_time'], $x['end_time'])) ?> &middot; <i class="bi bi-door-open"></i> <?= e($x['room']) ?><?= $x['building'] ? ' · ' . e($x['building']) : '' ?></div>
    <div class="small mb-2">Time in: <b><?= $x['time_in'] ? e(fmt_dt($x['time_in'])) : '—' ?></b> &nbsp; Time out: <b><?= $x['time_out'] ? e(fmt_dt($x['time_out'])) : '—' ?></b></div>
    <?php if (!$x['time_in']): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="exam_id" value="<?= (int) $x['id'] ?>"><input type="hidden" name="action" value="in">
      <button class="btn btn-<?= $live ? 'gold' : 'light' ?> w-100" <?= $why ? 'disabled' : '' ?>><i class="bi bi-box-arrow-in-right me-1"></i>Time in</button><?php if ($why): ?><div class="hint mt-1"><?= e($why) ?></div><?php endif; ?></form>
    <?php elseif (!$x['time_out']): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="exam_id" value="<?= (int) $x['id'] ?>"><input type="hidden" name="action" value="out"><button class="btn btn-navy w-100"><i class="bi bi-box-arrow-right me-1"></i>Time out</button></form><?php endif; ?>
  </div></div><?php endforeach; ?></div><?php endif; ?>
<script>(function(){var c=document.getElementById('clock');if(!c)return;var base=parseInt(c.dataset.ts,10)*1000,t0=Date.now();setInterval(function(){var d=new Date(base+Date.now()-t0);c.textContent=d.toLocaleTimeString([], {hour:'numeric',minute:'2-digit',second:'2-digit'});},1000);})();</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
