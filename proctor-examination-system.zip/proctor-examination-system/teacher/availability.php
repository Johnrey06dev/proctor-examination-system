<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('teacher');
$pdo = db();
$tid = my_teacher_id();

if (require_post_csrf()) {
    $action = input_str('action', 20);
    if ($action === 'status') {
        $new = input_str('availability_status', 20) === 'Unavailable' ? 'Unavailable' : 'Available';
        $pdo->prepare('UPDATE teachers SET availability_status = ? WHERE id = ?')->execute([$new, $tid]);
        log_activity('availability_status', 'teacher', $tid, null, $new, 'Own availability set to ' . $new);
        flash('success', 'Availability status updated.');
    } elseif ($action === 'limits') {
        $ma = trim($_POST['max_assignments'] ?? ''); $md = trim($_POST['max_per_day'] ?? '');
        $ma = $ma === '' ? null : max(0, min(200, (int) $ma)); $md = $md === '' ? null : max(1, min(10, (int) $md));
        $pdo->prepare('UPDATE teachers SET max_assignments = ?, max_per_day = ? WHERE id = ?')->execute([$ma, $md, $tid]);
        log_activity('teacher_limits', 'teacher', $tid, null, null, 'Own limits: max exams ' . ($ma ?? 'none') . ', per day ' . ($md ?? 'none'));
        flash('success', 'Your exam-load limits were saved. The auto-assign will respect them.');
    } elseif ($action === 'weekly') {
        $rows = []; $bad = 0;
        foreach ((array) ($_POST['w'] ?? []) as $w) {
            $d = (int) ($w['day'] ?? 0); $st = norm_time((string) ($w['start'] ?? '')); $en = norm_time((string) ($w['end'] ?? ''));
            if ($d < 1 || $d > 6) continue;
            if (!$st || !$en || $st >= $en) { $bad++; continue; }
            $rows[] = [$d, $st, $en];
        }
        if ($bad) flash('danger', 'Some rows were ignored: the end time must be later than the start time.');
        $pdo->beginTransaction();
        $pdo->prepare('DELETE FROM teacher_weekly_availability WHERE teacher_id = ?')->execute([$tid]);
        foreach ($rows as $r) $pdo->prepare('INSERT INTO teacher_weekly_availability (teacher_id, weekday, start_time, end_time) VALUES (?,?,?,?)')->execute([$tid, $r[0], $r[1], $r[2]]);
        $pdo->commit();
        log_activity('availability_weekly', 'teacher', $tid, null, null, 'Weekly availability saved (' . count($rows) . ' time range(s))');
        flash('success', count($rows) ? 'Your weekly availability was saved. Auto-assign will only use you on these days and hours.' : 'Saved. You have no available time, so you will not be assigned.');
    }
    redirect('teacher/availability.php');
}
$me = fetch_one('SELECT availability_status, max_assignments, max_per_day FROM teachers WHERE id = ?', [$tid]);
$cur = (int) fetch_value("SELECT COUNT(*) FROM proctor_assignments a JOIN examinations e ON e.id = a.examination_id WHERE a.teacher_id = ? AND a.status IN ('Pending Review','Confirmed') AND e.status = 'Scheduled'", [$tid]);
$weekly = fetch_all('SELECT weekday, start_time, end_time FROM teacher_weekly_availability WHERE teacher_id = ? AND weekday BETWEEN 1 AND 6 ORDER BY weekday, start_time', [$tid]);
$days = [1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday'];

$pageTitle = 'My Availability';
$activeNav = 'availability';
require __DIR__ . '/../includes/header.php';
?>
<div class="row g-3">
  <div class="col-lg-5">
    <div class="card-panel"><div class="panel-head"><h5>General availability</h5><?= status_badge($me['availability_status']) ?></div>
      <form method="post" class="d-flex gap-2"><?= csrf_field() ?><input type="hidden" name="action" value="status">
        <select class="form-select" name="availability_status"><option <?= $me['availability_status'] === 'Available' ? 'selected' : '' ?>>Available</option><option <?= $me['availability_status'] === 'Unavailable' ? 'selected' : '' ?>>Unavailable</option></select>
        <button class="btn btn-navy" type="submit">Save</button></form>
      <div class="form-text mt-2">"Unavailable" excludes you from all automatic and manual proctor assignments.</div></div>
    <div class="card-panel"><div class="panel-head"><h5>How many exams can I take?</h5><span class="badge bg-light text-dark border">Now: <?= $cur ?> upcoming</span></div>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="limits"><div class="row g-2">
        <div class="col-6"><label class="form-label small">Max exams (whole period)</label><input type="number" min="0" max="200" class="form-control" name="max_assignments" value="<?= e($me['max_assignments']) ?>" placeholder="No limit"></div>
        <div class="col-6"><label class="form-label small">Max exams per day</label><input type="number" min="1" max="10" class="form-control" name="max_per_day" value="<?= e($me['max_per_day']) ?>" placeholder="System default"></div>
        <?php if ($me['max_assignments'] !== null && (int) $me['max_assignments'] > 0): $pc = min(100, round($cur / $me['max_assignments'] * 100)); ?><div class="col-12"><div class="progress" style="height:8px"><div class="progress-bar" style="width:<?= $pc ?>%"></div></div><small class="text-muted"><?= $cur ?> of <?= (int) $me['max_assignments'] ?> used</small></div><?php endif; ?>
        <div class="col-12"><button class="btn btn-navy w-100" type="submit">Save my limits</button></div></div></form>
      <div class="form-text mt-2">Leave empty for no limit. The auto-assign will never exceed these numbers.</div></div>
  </div>
  <div class="col-lg-7"><div class="card-panel"><div class="panel-head"><h5>My weekly availability</h5><span class="badge bg-light text-dark border">Monday – Saturday</span></div>
    <p class="hint">Choose the days and the hours you can proctor. Auto-assign gives you an exam <b>only</b> when its day and whole time fall inside these hours. Add as many time ranges as you need (e.g. morning and afternoon).</p>
    <?php if (!$weekly): ?><div class="alert alert-warning">You have not set any time yet, so you will not be assigned to any exam.</div><?php endif; ?>
    <form method="post" id="wForm"><?= csrf_field() ?><input type="hidden" name="action" value="weekly">
      <div id="wRows"></div>
      <div class="d-flex flex-wrap gap-2 mt-2"><button type="button" class="btn btn-light btn-sm" id="wAdd"><i class="bi bi-plus-lg"></i> Add time</button>
        <button type="button" class="btn btn-light btn-sm" id="wPreset">Mon–Sat, 7:00 AM – 6:00 PM</button><button type="button" class="btn btn-light btn-sm" id="wClear">Clear all</button><span class="ms-auto"></span><button class="btn btn-navy" type="submit">Save availability</button></div></form>
  </div>
  <div class="card-panel"><div class="panel-head"><h5>My week at a glance</h5></div><div class="table-responsive"><table class="table table-modern mb-0"><tbody>
    <?php foreach ($days as $n => $dn): $r = array_filter($weekly, fn($w) => (int) $w['weekday'] === $n); ?><tr><td style="width:120px"><b><?= $dn ?></b></td><td><?php if (!$r): ?><span class="text-muted">Not available</span><?php endif; foreach ($r as $w): ?><span class="badge-s b-green me-1"><?= e(time_range($w['start_time'], $w['end_time'])) ?></span><?php endforeach; ?></td></tr><?php endforeach; ?></tbody></table></div></div></div>
</div>
<script>(function(){
var DAYS=<?= json_encode($days) ?>,INIT=<?= json_encode(array_map(fn($w) => ['day' => (int) $w['weekday'], 'start' => substr($w['start_time'], 0, 5), 'end' => substr($w['end_time'], 0, 5)], $weekly)) ?>;
var box=document.getElementById('wRows'),i=0;
function row(d){var k=i++;var o=Object.keys(DAYS).map(function(n){return '<option value="'+n+'"'+(+n===d.day?' selected':'')+'>'+DAYS[n]+'</option>';}).join('');
 var el=document.createElement('div');el.className='row g-2 mb-2 align-items-end';
 el.innerHTML='<div class="col-5"><select class="form-select" name="w['+k+'][day]">'+o+'</select></div><div class="col-3"><input type="time" class="form-control" name="w['+k+'][start]" value="'+d.start+'" required></div><div class="col-3"><input type="time" class="form-control" name="w['+k+'][end]" value="'+d.end+'" required></div><div class="col-1"><button type="button" class="btn btn-link text-danger p-0" title="Remove"><i class="bi bi-x-circle"></i></button></div>';
 el.querySelector('button').onclick=function(){el.remove();};box.appendChild(el);}
INIT.forEach(row);
document.getElementById('wAdd').onclick=function(){row({day:1,start:'08:00',end:'17:00'});};
document.getElementById('wClear').onclick=function(){box.innerHTML='';};
document.getElementById('wPreset').onclick=function(){box.innerHTML='';for(var n=1;n<=6;n++)row({day:n,start:'07:00',end:'18:00'});};
})();</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
