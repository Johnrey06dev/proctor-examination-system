<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('teacher');
$tid = my_teacher_id();
if (require_post_csrf()) {
    $sc = new ProctorScheduler(db());
    $act = input_str('action', 12);
    if ($act === 'accept' || $act === 'accept_all') {
        $ids = $act === 'accept' ? [input_int('assignment_id')] : array_column(fetch_all("SELECT id FROM proctor_assignments WHERE teacher_id = ? AND status = 'Pending Review'", [$tid]), 'id');
        $ok = 0;
        foreach ($ids as $aid) { $r = $sc->acceptByTeacher((int) $aid, $tid); if ($r['ok']) $ok++; else foreach ($r['errors'] as $er) flash('danger', $er); }
        if ($ok) flash('success', $ok . ' assignment(s) accepted. Thank you!');
    } else {
        $r = $sc->decline(input_int('assignment_id'), $tid, input_str('reason', 255));
        if ($r['ok']) flash('success', 'Assignment declined. The administrator was notified and will assign a replacement.');
        else foreach ($r['errors'] as $er) flash('danger', $er);
    }
    redirect('teacher/assignments.php');
}
$fst = $_GET['status'] ?? '';
$where = 'a.teacher_id = ?'; $params = [$tid];
if (in_array($fst, ['Pending Review', 'Confirmed'], true)) { $where .= ' AND a.status = ?'; $params[] = $fst; }
else { $where .= " AND a.status IN ('Pending Review','Confirmed')"; }
$rows = fetch_all("SELECT a.*, e.exam_code, e.name AS exam_name, e.exam_type, e.exam_date, e.start_time, e.end_time, e.paper_sets, e.notes, r.name AS room_name, r.building,
        s.code AS subject_code, s.name AS subject_name, p.status AS paper_status, p.proctor_teacher_id AS paper_proctor
    FROM proctor_assignments a JOIN examinations e ON e.id = a.examination_id JOIN rooms r ON r.id = e.room_id JOIN subjects s ON s.id = e.subject_id
    LEFT JOIN paper_distribution p ON p.examination_id = e.id WHERE $where ORDER BY e.exam_date, e.start_time", $params);

$pageTitle = 'My Assignments';
$activeNav = 'assignments';
require __DIR__ . '/../includes/header.php';
?>
<div class="card-panel">
  <div class="panel-head"><h5>Proctor assignments</h5>
    <div class="btn-group">
      <?php foreach (['' => 'Active', 'Pending Review' => 'Pending', 'Confirmed' => 'Confirmed'] as $k => $l): ?>
        <a class="btn btn-sm <?= $fst === $k ? 'btn-navy' : 'btn-outline-navy' ?>" href="<?= e(url('teacher/assignments.php' . ($k ? '?status=' . urlencode($k) : ''))) ?>"><?= e($l) ?></a><?php endforeach; ?></div></div>
  <?php $pendN = count(array_filter($rows, fn($r) => $r['status'] === 'Pending Review')); if ($pendN): ?><form method="post" class="mb-3"><?= csrf_field() ?><input type="hidden" name="action" value="accept_all"><button class="btn btn-success"><i class="bi bi-check2-all me-1"></i>Accept all (<?= $pendN ?>) pending</button></form><?php endif; ?>
  <div class="small text-muted mb-3" data-info><i class="bi bi-info-circle me-1"></i>"Pending Review" assignments are proposed by the system and become "Confirmed" once the administrator approves them.</div>
  <?php if (!$rows): ?><?= empty_state('calendar-x', 'No assignments to show') ?><?php else: ?>
  <div class="row g-3">
    <?php foreach ($rows as $a): $mine = (int) $a['paper_proctor'] === $tid; ?>
    <div class="col-lg-6"><div class="card-panel mb-0 h-100">
      <div class="d-flex justify-content-between"><div><strong><?= e($a['exam_code']) ?></strong> · <?= e($a['exam_type']) ?></div><?= status_badge($a['status']) ?></div>
      <h6 class="mt-1"><?= e($a['exam_name']) ?></h6>
      <dl class="row mb-0">
        <dt class="col-4">My role</dt><dd class="col-8"><span class="badge bg-info text-dark"><?= e($a['proctor_role'] ?? 'Proctor') ?></span></dd>
        <dt class="col-4">Subject</dt><dd class="col-8"><?= e($a['subject_code'] . ' – ' . $a['subject_name']) ?></dd>
        <dt class="col-4">Date</dt><dd class="col-8"><?= e(fmt_date($a['exam_date'])) ?></dd>
        <dt class="col-4">Time</dt><dd class="col-8"><?= e(time_range($a['start_time'], $a['end_time'])) ?></dd>
        <dt class="col-4">Room</dt><dd class="col-8"><?= e($a['room_name']) ?><?= $a['building'] ? ' · ' . e($a['building']) : '' ?></dd>
        <dt class="col-4">Papers</dt><dd class="col-8"><?= (int) $a['paper_sets'] ?> copies · <?= !$a['paper_status'] ? 'not prepared yet' : ($mine ? status_badge($a['paper_status']) : 'with ' . ($a['paper_proctor'] ? 'another proctor' : 'exam office')) ?></dd>
      </dl>
      <?php if (strtotime($a['exam_date'] . ' ' . $a['start_time']) > time() && !$a['paper_status']): ?>
      <div class="mt-3 d-flex gap-2 justify-content-end">
        <?php if ($a['status'] === 'Pending Review'): ?><form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="accept"><input type="hidden" name="assignment_id" value="<?= (int) $a['id'] ?>"><button class="btn btn-sm btn-success"><i class="bi bi-check2-circle me-1"></i>Accept</button></form><?php endif; ?><button class="btn btn-sm btn-outline-danger" type="button" data-bs-toggle="modal" data-bs-target="#declineModal" data-edit="#declineForm" data-assignment_id="<?= (int) $a['id'] ?>"><i class="bi bi-x-circle me-1"></i>Decline</button></div><?php endif; ?>
    </div></div>
    <?php endforeach; ?>
  </div><?php endif; ?>
</div>
<div class="modal fade" id="declineModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form method="post" id="declineForm"><?= csrf_field() ?><input type="hidden" name="action" value="decline"><input type="hidden" name="assignment_id" value="">
  <div class="modal-header"><h5 class="modal-title">Decline this assignment</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body"><label class="form-label">Reason *</label><textarea class="form-control" name="reason" rows="3" maxlength="255" required></textarea><div class="form-text">The admin sees your reason and the system assigns someone else.</div></div>
  <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-danger" type="submit">Decline</button></div></form></div></div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
