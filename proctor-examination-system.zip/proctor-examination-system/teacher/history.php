<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$user = require_role('teacher');
$tid = my_teacher_id();
$rows = fetch_all("SELECT a.*, e.exam_code, e.name AS exam_name, e.exam_date, e.start_time, e.end_time, r.name AS room_name, s.code AS subject_code
    FROM proctor_assignments a JOIN examinations e ON e.id = a.examination_id JOIN rooms r ON r.id = e.room_id JOIN subjects s ON s.id = e.subject_id
    WHERE a.teacher_id = ? ORDER BY e.exam_date DESC, e.start_time DESC", [$tid]);
$pageTitle = 'Assignment History';
$activeNav = 'history';
require __DIR__ . '/../includes/header.php';
?>
<div class="card-panel">
  <div class="panel-head"><h5>All my assignments</h5><span class="text-muted small"><?= count($rows) ?> record(s)</span></div>
  <?php if (!$rows): ?><?= empty_state('journal-x', 'No history yet') ?><?php else: ?>
  <div class="table-responsive"><table class="table table-modern align-middle"><thead><tr><th>Exam</th><th>Subject</th><th>Date &amp; time</th><th>Room</th><th>Type</th><th>Status</th></tr></thead><tbody>
    <?php foreach ($rows as $a): ?><tr><td><strong><?= e($a['exam_code']) ?></strong><div class="small text-muted"><?= e($a['exam_name']) ?></div></td><td><?= e($a['subject_code']) ?></td>
      <td><?= e(fmt_date($a['exam_date'])) ?><div class="small text-muted"><?= e(time_range($a['start_time'], $a['end_time'])) ?></div></td><td><?= e($a['room_name']) ?></td><td><?= status_badge($a['assignment_type']) ?></td><td><?= status_badge($a['status']) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
