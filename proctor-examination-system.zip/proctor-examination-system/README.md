# Proctor Assignment and Examination Paper Distribution System

Web-based system using **constraint-based scheduling** and a **load-balancing algorithm** to assign exam proctors and track exam papers.
Built with **PHP 8, MySQL/MariaDB and Bootstrap 5** (no framework). Works for Elementary, Junior High, Senior High and College.

## Features
- Roles: Admin, Coordinator, Teacher
- Year Levels (Grade 1-12 and College) with subjects and sections; semesters for Senior High and College only
- Auto-Schedule (creates exams: date, time, room) and Auto-Assign (fair proctor pairing, optional auto-accept)
- Exam Papers tracker per subject (Pending to Completed)
- Public exam schedule on the home page (by year level and section)
- Teacher availability, notifications, e-mail OTP, QR login

## Install (XAMPP / Windows)
1. Copy this folder to `C:\xampp\htdocs\proctor-examination-system`.
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. In phpMyAdmin, create database `proctor_examination_system` and import `database/proctor_system.sql`.
4. Copy `config/database.example.php` to `config/database.php` (and `config/mail.example.php` to `config/mail.php`), then fill in your own values.
5. Open `http://localhost/proctor-examination-system/`.

More details: `docs/SETUP_GUIDE.md`. Automated tests: `tests/run_tests.php`.

## Security
`config/database.php` and `config/mail.php` hold passwords and are excluded by `.gitignore`. Never commit them.
Change the default admin password after the first login.
