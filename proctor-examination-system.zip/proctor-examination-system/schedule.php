<?php
/** Public exam schedule board: no login needed. Shows WHEN and WHERE each section sits its exams. Proctors are never shown. */
require_once __DIR__ . '/includes/bootstrap.php';
$S = get_settings();
$on = ($S['public_schedule'] ?? '1') === '1';
$f = ['dept' => (int) ($_GET['dept'] ?? 0), 'year' => (int) ($_GET['year'] ?? 0), 'q' => trim((string) ($_GET['q'] ?? '')), 'past' => !empty($_GET['past'])];
$board = $on ? schedule_board($f) : ['years' => [], 'total' => 0];
$depts = dept_list();
$nSections = 0; foreach ($board['years'] as $y) $nSections += count($y['sections']);
$first = null;
foreach ($board['years'] as $y) foreach ($y['sections'] as $s) { $e = $s['exams'][0]; if (!$first || [$e['exam_date'], $e['start_time']] < [$first['exam_date'], $first['start_time']]) $first = $e; }
$link = fn(array $over = []) => url('index.php') . '?' . http_build_query(array_filter(array_merge(['dept' => $f['dept'], 'year' => $f['year'], 'q' => $f['q'], 'past' => $f['past'] ? 1 : 0], $over), fn($v) => $v !== '' && $v !== 0 && $v !== null));
$fmt = fn($d) => date('D, M j, Y', strtotime($d));
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Exam Schedule · <?= e(APP_SHORT) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Merriweather:wght@700;900&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<script>try{var t=localStorage.getItem('pps_theme');if(t)document.documentElement.setAttribute('data-theme',t)}catch(e){}</script>
<link href="<?= e(url('assets/css/app.css') . '?v=' . filemtime(ROOT_PATH . '/assets/css/app.css')) ?>" rel="stylesheet">
<link href="<?= e(url('assets/css/theme.css') . '?v=' . filemtime(ROOT_PATH . '/assets/css/theme.css')) ?>" rel="stylesheet">
</head>
<body class="pub-body">
<header class="pub-top"><div class="pub-wrap d-flex align-items-center gap-3">
  <span class="pub-logo"><i class="bi bi-mortarboard-fill"></i></span>
  <div class="flex-fill"><div class="pub-title">Examination Schedule</div><div class="pub-sub">Find your section's exam date, time and room</div></div>
  <a class="btn btn-gold" href="<?= e(url('login.php')) ?>"><i class="bi bi-box-arrow-in-right me-1"></i>Sign in</a>
</div></header>

<main class="pub-wrap py-4">
<?php if (!$on): ?>
  <div class="card-panel"><?= empty_state('calendar-x', 'The schedule is not posted yet', 'Please check again later.') ?></div>
<?php else: ?>
  <form class="card-panel pub-filter" method="get">
    <div class="row g-2 align-items-end">
      <div class="col-md-4"><label class="form-label small">Search</label><input class="form-control" name="q" value="<?= e($f['q']) ?>" placeholder="Section, subject or room"></div>
      <div class="col-md-3"><label class="form-label small">Department</label><select class="form-select" name="dept"><?= options_html($depts, 'id', 'code', $f['dept'] ?: null, 'All departments') ?></select></div>
      <div class="col-md-3"><div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="past" value="1" id="pastChk" <?= $f['past'] ? 'checked' : '' ?>><label class="form-check-label" for="pastChk">Include past exams</label></div></div>
      <?php if ($f['year']): ?><input type="hidden" name="year" value="<?= (int) $f['year'] ?>"><?php endif; ?>
      <div class="col-md-2 d-grid"><button class="btn btn-navy"><i class="bi bi-search me-1"></i>Search</button></div>
    </div>
    <div class="pub-pills mt-3">
      <a class="pill <?= !$f['year'] ? 'on' : '' ?>" href="<?= e($link(['year' => 0])) ?>">All year levels</a>
      <?php foreach (year_level_options() as $k => $v): ?><a class="pill <?= $f['year'] === $k ? 'on' : '' ?>" href="<?= e($link(['year' => $k])) ?>"><?= e($v) ?></a><?php endforeach; ?>
      <a class="pill <?= $f['year'] === 9 ? 'on' : '' ?>" href="<?= e($link(['year' => 9])) ?>">Other</a>
    </div>
  </form>

  <?php if ($board['total']): ?>
  <div class="pub-stats">
    <div><b><?= $board['total'] ?></b><span>exam<?= $board['total'] === 1 ? '' : 's' ?></span></div>
    <div><b><?= $nSections ?></b><span>section<?= $nSections === 1 ? '' : 's' ?></span></div>
    <?php if ($first): ?><div class="flex-fill"><b><?= e($fmt($first['exam_date'])) ?></b><span>first exam day &middot; <?= e(fmt_time($first['start_time'])) ?></span></div><?php endif; ?>
  </div>
  <?php else: ?><div class="card-panel"><?= empty_state('calendar-x', 'No exams found', 'Try another year level, department or search.') ?></div><?php endif; ?>

  <?php foreach ($board['years'] as $y): ?>
  <section class="pub-year">
    <h2 class="pub-year-h"><i class="bi bi-mortarboard me-2"></i><?= e($y['label']) ?></h2>
    <div class="row g-3">
    <?php foreach ($y['sections'] as $s): $e0 = $s['exams'][0]; $today = $e0['exam_date'] === date('Y-m-d'); ?>
      <div class="col-lg-6"><article class="pub-sec">
        <header>
          <div class="d-flex align-items-center flex-wrap gap-2"><h3><?= e($s['name']) ?></h3><span class="badge-s b-blue"><?= e($s['dept']) ?></span><?php if ($s['semester']): ?><span class="badge-s b-gray"><?= e($s['semester']) ?></span><?php endif; ?></div>
          <div class="pub-first"><i class="bi bi-flag-fill me-1"></i>First exam: <b><?= e($fmt($e0['exam_date'])) ?></b>, <?= e(fmt_time($e0['start_time'])) ?> &middot; <i class="bi bi-door-open me-1"></i><?= e($e0['room']) ?><?= $today ? ' <span class="badge-s b-green">Today</span>' : '' ?></div>
        </header>
        <div class="table-responsive"><table class="table pub-table mb-0"><thead><tr><th>Date</th><th>Time</th><th>Subject</th><th>Room</th></tr></thead><tbody>
          <?php foreach ($s['exams'] as $x): ?><tr>
            <td class="text-nowrap"><?= e(date('D, M j', strtotime($x['exam_date']))) ?><?= $x['exam_date'] === date('Y-m-d') ? ' <span class="badge-s b-green">Today</span>' : '' ?></td>
            <td class="text-nowrap"><?= e(time_range($x['start_time'], $x['end_time'])) ?></td>
            <td><?= e($x['subject']) ?></td>
            <td class="text-nowrap"><?= e($x['room']) ?><?= $x['building'] ? '<div class="small text-muted">' . e($x['building']) . '</div>' : '' ?></td></tr><?php endforeach; ?>
        </tbody></table></div>
      </article></div>
    <?php endforeach; ?>
    </div>
  </section>
  <?php endforeach; ?>
<?php endif; ?>
</main>
<footer class="pub-foot">&copy; <?= date('Y') ?> <?= e(APP_SHORT) ?> &middot; Schedules may change. Please check this page for updates.</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
