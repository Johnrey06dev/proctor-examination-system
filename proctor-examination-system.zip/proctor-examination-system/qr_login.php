<?php
/** qr_login.php?t=TOKEN – quick login with the personal QR code made in My Profile. */
require_once __DIR__ . '/includes/bootstrap.php';
if (is_logged_in()) redirect(home_for_role($_SESSION['user']['role']));
$t = preg_replace('/[^a-f0-9]/', '', strtolower((string) ($_GET['t'] ?? '')));
$fail = function (string $msg) { flash('danger', $msg); redirect('login.php'); };
if (($ip = rl_blocked('qr:ip:' . client_ip()))) $fail('Too many tries. Try again in ' . fmt_wait($ip) . ' minutes.');
if ((get_settings()['qr_login_enabled'] ?? '1') !== '1') $fail('QR login is turned off by the administrator.');
if (strlen($t) !== 48) { rl_hit('qr:ip:' . client_ip(), 10, 600, 600); $fail('This QR code is not valid.'); }
$u = load_login_user('u.qr_hash = ?', hash('sha256', $t));
if (!$u) { rl_hit('qr:ip:' . client_ip(), 10, 600, 600); log_activity('qr_failed', 'security', null, null, null, 'Invalid or revoked QR code used', null); $fail('This QR code is not valid any more. Sign in with your password.'); }
if ($u['status'] !== 'active') $fail('This account is not active.');
complete_login($u);
log_activity('qr_login', 'user', (int) $u['id'], null, null, 'Signed in with QR code', (int) $u['id']);
notify((int) $u['id'], 'Signed in with your QR code', 'Your account was opened with your personal QR code on ' . date('M j, g:i A') . '. If this was not you, regenerate or turn off the QR in My Profile.', 'security', 'profile.php');
redirect(home_for_role($u['role']));
