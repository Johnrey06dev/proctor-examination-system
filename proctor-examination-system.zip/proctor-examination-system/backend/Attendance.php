<?php
/**
 * backend/Attendance.php – proctor time in / time out on the exam day.
 * The SERVER clock decides (never the browser). Time in opens N minutes before the exam (setting) and
 * only works on the exam day, unless Testing mode is ON (for demos).
 */
class Attendance
{
    public static function testing(): bool { return (get_settings()['testing_mode'] ?? '0') === '1'; }

    public static function openMinutes(): int { return max(0, (int) (get_settings()['attendance_open_minutes'] ?? 60)); }

    /** [openTs, startTs, endTs] of an exam */
    public static function window(array $exam): array
    {
        $start = strtotime($exam['exam_date'] . ' ' . $exam['start_time']);
        $end = strtotime($exam['exam_date'] . ' ' . $exam['end_time']);
        return [$start - self::openMinutes() * 60, $start, $end];
    }

    /** can the teacher time in right now? returns null (yes) or the reason */
    public static function whyNotIn(array $exam): ?string
    {
        if (self::testing()) return null;
        [$open, , $end] = self::window($exam);
        $now = time();
        if ($exam['exam_date'] !== date('Y-m-d')) return 'Time in works only on the exam day (' . fmt_date($exam['exam_date']) . ').';
        if ($now < $open) return 'Time in opens at ' . date('g:i A', $open) . ' (' . self::openMinutes() . ' minutes before the exam).';
        if ($now > $end) return 'The exam already ended.';
        return null;
    }

    public static function row(PDO $pdo, int $examId, int $teacherId): ?array
    {
        $st = $pdo->prepare('SELECT * FROM attendance WHERE examination_id = ? AND teacher_id = ?');
        $st->execute([$examId, $teacherId]);
        return $st->fetch() ?: null;
    }

    public static function timeIn(PDO $pdo, int $examId, int $teacherId): array
    {
        $exam = (new ProctorScheduler($pdo))->getExam($examId);
        $ok = $exam && $exam['status'] === 'Scheduled' && (int) $pdo->query("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id = $examId AND teacher_id = $teacherId AND status = 'Confirmed'")->fetchColumn();
        if (!$ok) return ['ok' => false, 'error' => 'You are not a confirmed proctor of this exam.'];
        if ($why = self::whyNotIn($exam)) return ['ok' => false, 'error' => $why];
        if (self::row($pdo, $examId, $teacherId)) return ['ok' => false, 'error' => 'You already timed in.'];
        $pdo->prepare('INSERT INTO attendance (examination_id, teacher_id, time_in) VALUES (?,?,?)')->execute([$examId, $teacherId, now()]);
        log_activity('time_in', 'attendance', $examId, null, null, 'Time in: teacher #' . $teacherId . ' for ' . $exam['exam_code']);
        notify_admins('Proctor timed in', ($_SESSION['user']['name'] ?? 'Teacher') . ' timed in for ' . $exam['exam_code'] . ' at ' . date('g:i A') . '.', 'attendance', 'admin/attendance.php');
        return ['ok' => true, 'error' => null];
    }

    public static function timeOut(PDO $pdo, int $examId, int $teacherId): array
    {
        $r = self::row($pdo, $examId, $teacherId);
        if (!$r || !$r['time_in']) return ['ok' => false, 'error' => 'Time in first.'];
        if ($r['time_out']) return ['ok' => false, 'error' => 'You already timed out.'];
        $pdo->prepare('UPDATE attendance SET time_out = ? WHERE id = ?')->execute([now(), $r['id']]);
        log_activity('time_out', 'attendance', $examId, null, null, 'Time out: teacher #' . $teacherId);
        return ['ok' => true, 'error' => null];
    }
}
