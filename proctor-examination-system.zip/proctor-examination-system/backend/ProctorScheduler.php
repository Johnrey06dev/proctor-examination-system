<?php
/**
 * backend/ProctorScheduler.php
 * ---------------------------------------------------------------------
 * CONSTRAINT-BASED SCHEDULING + LOAD BALANCING for proctor assignment.
 *
 * Pipeline used by generate():
 *   1. Retrieve the examination.
 *   2. Retrieve all teachers (and their account data).
 *   3. Check availability (global status + blocked time slots).
 *   4. Check existing assignments (same exam / same day).
 *   5. HARD constraints  -> teachers that violate any rule are EXCLUDED (never assigned).
 *   6. Calculate each remaining teacher's workload.
 *   7. SOFT constraints  -> rank eligible teachers (load balancing).
 *   8. Select exactly the number of missing proctors (never more than required).
 *   9. Save as "Pending Review" and store the explanation.
 *
 * HARD constraints (never violated)
 *   H1 teacher account is active
 *   H2 teacher is available (availability status + no blocked slot overlapping the exam)
 *   H3 no overlapping / too-close assignment on the same date (min gap is configurable)
 *   H4 not already assigned to the same examination
 *   H5 assigned proctors never exceed the required number
 *   H6 eligibility rules (exam must be Scheduled, daily limit, optional "exclude same department")
 *   H7 teacher's OWN limits (max exams in the period / max per day set by the teacher) and "declined this exam"
 *
 * SOFT constraints / load balancing (used only to RANK eligible teachers)
 *   score = workload  +  department penalty (only if a department preference is configured)
 *   workload = number of non-cancelled assignments inside the configured scheduling period
 *   Ranking: lowest score first -> then teacher who was assigned LEAST RECENTLY (never = first)
 *            -> then teacher number (A-Z) as the consistent final tie-breaker.
 */

class SchedulingException extends RuntimeException
{
    public array $errors;

    public function __construct(array $errors)
    {
        parent::__construct(implode(' ', $errors));
        $this->errors = $errors;
    }
}

class ProctorScheduler
{
    private PDO $pdo;
    private array $settings;

    /** @param array $override temporary settings for one run (e.g. gap minutes / max per day typed on the Auto-assign page) */
    public function __construct(PDO $pdo, array $override = [])
    {
        $this->pdo = $pdo;
        $this->settings = array_merge(get_settings(true), $override);
    }

    public function settings(): array
    {
        return $this->settings;
    }

    /* ================================================================
     *  DATA LOADERS
     * ================================================================ */

    public function getExam(int $id): ?array
    {
        $st = $this->pdo->prepare(
            'SELECT e.*, s.code AS subject_code, s.name AS subject_name, d.code AS dept_code, d.name AS dept_name, r.name AS room_name, r.building AS room_building, r.seat_rows, r.seat_cols, r.capacity AS room_capacity
             FROM examinations e
             JOIN subjects s ON s.id = e.subject_id
             JOIN departments d ON d.id = e.department_id
             JOIN rooms r ON r.id = e.room_id
             WHERE e.id = ?'
        );
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }

    /** Number of non-cancelled proctors on an exam (optionally ignoring one assignment). */
    public function activeCount(int $examId, int $ignoreAssignmentId = 0): int
    {
        $st = $this->pdo->prepare("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id = ? AND status <> 'Cancelled' AND id <> ?");
        $st->execute([$examId, $ignoreAssignmentId]);
        return (int) $st->fetchColumn();
    }

    public function allTeachers(): array
    {
        return $this->pdo->query(
            'SELECT t.id, t.teacher_no, t.department_id, t.specialization, t.availability_status, t.max_assignments, t.max_per_day,
                    u.full_name, u.email, u.status AS account_status, d.code AS dept_code
             FROM teachers t
             JOIN users u ON u.id = t.user_id
             JOIN departments d ON d.id = t.department_id
             ORDER BY t.teacher_no'
        )->fetchAll();
    }

    private function inPeriod(string $date): bool
    {
        $ps = $this->settings['period_start'];
        $pe = $this->settings['period_end'];
        return ($ps === '' || $date >= $ps) && ($pe === '' || $date <= $pe);
    }

    /**
     * LOAD-BALANCING DATA: workload per teacher.
     *  total     = non-cancelled assignments inside the scheduling period  (used for ranking)
     *  all_time  = every non-cancelled assignment
     *  upcoming  = Pending Review / Confirmed assignments from today onward
     *  completed = Completed assignments
     *  last_date = date of the teacher's most recent (latest exam date) assignment
     */
    public function workloadMap(): array
    {
        $map = [];
        $rows = $this->pdo->query(
            "SELECT a.teacher_id, a.status, e.exam_date, e.start_time, e.end_time
             FROM proctor_assignments a JOIN examinations e ON e.id = a.examination_id
             WHERE a.status <> 'Cancelled' AND e.status <> 'Cancelled'"
        )->fetchAll();
        $today = date('Y-m-d');
        foreach ($rows as $r) {
            $tid = (int) $r['teacher_id'];
            $map[$tid] ??= self::emptyWorkload();
            $m = &$map[$tid];
            $m['all_time']++;
            if ($this->inPeriod($r['exam_date'])) { $m['total']++; $m['hours'] += max(0, time_to_min($r['end_time']) - time_to_min($r['start_time'])) / 60; }
            if ($r['status'] === 'Completed') $m['completed']++;
            if ($r['status'] === 'Pending Review') $m['pending']++;
            if (in_array($r['status'], ['Pending Review', 'Confirmed'], true) && $r['exam_date'] >= $today) $m['upcoming']++;
            if ($m['last_date'] === null || $r['exam_date'] > $m['last_date']) $m['last_date'] = $r['exam_date'];
            unset($m);
        }
        return $map;
    }

    public static function emptyWorkload(): array
    {
        return ['total' => 0, 'hours' => 0.0, 'all_time' => 0, 'upcoming' => 0, 'completed' => 0, 'pending' => 0, 'last_date' => null];
    }

    /** Context needed to test hard constraints for one examination. */
    public function buildContext(array $exam, int $ignoreAssignmentId = 0): array
    {
        $ctx = ['sameDay' => [], 'blocks' => [], 'weekly' => [], 'wd' => (int) date('N', strtotime($exam['exam_date'])), 'assigned' => [], 'work' => $this->workloadMap(), 'skip_cap' => false];

        $st = $this->pdo->prepare(
            "SELECT a.teacher_id, e.id AS exam_id, e.exam_code, e.start_time, e.end_time
             FROM proctor_assignments a JOIN examinations e ON e.id = a.examination_id
             WHERE a.status <> 'Cancelled' AND e.status <> 'Cancelled' AND e.exam_date = ? AND e.id <> ?"
        );
        $st->execute([$exam['exam_date'], $exam['id'] ?? 0]);
        foreach ($st->fetchAll() as $r) {
            $ctx['sameDay'][(int) $r['teacher_id']][] = $r;
        }

        $st = $this->pdo->prepare('SELECT teacher_id, start_time, end_time, reason FROM teacher_availability WHERE unavailable_date = ?');
        $st->execute([$exam['exam_date']]);
        foreach ($st->fetchAll() as $r) {
            $ctx['blocks'][(int) $r['teacher_id']][] = $r;
        }

        // weekly availability: the days (Mon-Sat) and hours each teacher said he can proctor
        $st = $this->pdo->prepare('SELECT teacher_id, start_time, end_time FROM teacher_weekly_availability WHERE weekday = ?');
        $st->execute([$ctx['wd']]);
        foreach ($st->fetchAll() as $r) {
            $ctx['weekly'][(int) $r['teacher_id']][] = $r;
        }

        if (!empty($exam['id'])) {
            $st = $this->pdo->prepare("SELECT id, teacher_id FROM proctor_assignments WHERE examination_id = ? AND status <> 'Cancelled' AND id <> ?");
            $st->execute([$exam['id'], $ignoreAssignmentId]);
            foreach ($st->fetchAll() as $r) {
                $ctx['assigned'][(int) $r['teacher_id']] = true;
            }
        }
        return $ctx;
    }

    /** One-line, human readable description used in notifications and e-mails. */
    public function describeExam(array $exam): string
    {
        $st = $this->pdo->prepare('SELECT s.section_name, b.code, s.examinees FROM exam_sections s JOIN subjects b ON b.id = s.subject_id WHERE s.examination_id = ? ORDER BY s.sort_order, s.id');
        $st->execute([$exam['id']]);
        $secs = $st->fetchAll();
        $total = array_sum(array_column($secs, 'examinees'));
        $txt = $exam['exam_code'] . ' ' . $exam['name'] . ' | ' . fmt_date($exam['exam_date']) . ', ' . time_range($exam['start_time'], $exam['end_time'])
             . ' | Room ' . $exam['room_name'] . (!empty($exam['room_building']) ? ' (' . $exam['room_building'] . ')' : '');
        if ($secs) {
            $txt .= ' | ' . $total . ' examinees: ' . implode('; ', array_map(fn($x) => $x['section_name'] . ' ' . $x['code'] . ' x' . $x['examinees'], $secs));
        }
        return $txt;
    }

    /** Notification + optional e-mail to the proctor of an exam. */
    /** @var bool when true, auto-generated assignments are saved as Confirmed (accepted) instead of Pending Review */
    private bool $autoAccept = false;

    public function setAutoAccept(bool $on): self { $this->autoAccept = $on; return $this; }

    private function tell(int $teacherId, string $title, string $lead, array $exam, string $type): void
    {
        if ($uid = teacher_user_id($teacherId)) {
            notify($uid, $title, $lead . ' ' . $this->describeExam($exam), $type, 'teacher/assignments.php');
        }
    }

    /* ================================================================
     *  HARD CONSTRAINTS  (shared by automatic AND manual assignment)
     * ================================================================ */

    /**
     * @return string[] list of violated hard constraints (empty = eligible).
     */
    public function hardViolations(array $t, array $exam, array $ctx): array
    {
        $v = [];
        $tid = (int) $t['id'];
        $s = $this->settings;
        $examStart = time_to_min($exam['start_time']);
        $examEnd = time_to_min($exam['end_time']);

        // H6 (exam level): only Scheduled examinations can receive proctors
        if (($exam['status'] ?? 'Scheduled') !== 'Scheduled') {
            $v[] = 'H6 Eligibility: examination is ' . $exam['status'] . ', proctors can only be assigned to Scheduled examinations.';
        }
        // H1 active account
        if ($t['account_status'] !== 'active') {
            $v[] = 'H1 Inactive: the teacher account is deactivated.';
        }
        // H2 availability
        if ($t['availability_status'] !== 'Available') {
            $v[] = 'H2 Unavailable: teacher availability status is "Unavailable".';
        }
        $dayName = ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][$ctx['wd']];
        $covered = false;
        foreach ($ctx['weekly'][$tid] ?? [] as $w) {
            if (time_to_min($w['start_time']) <= $examStart && $examEnd <= time_to_min($w['end_time'])) $covered = true;
        }
        if (!$covered) {
            $wins = array_map(fn($w) => fmt_time($w['start_time']) . '–' . fmt_time($w['end_time']), $ctx['weekly'][$tid] ?? []);
            $v[] = 'H2 Unavailable: not available on ' . $dayName . ' at this time' . ($wins ? ' (available ' . implode(', ', $wins) . ')' : ' (no availability set for this day)') . '.';
        }
        foreach ($ctx['blocks'][$tid] ?? [] as $b) {
            $bs = time_to_min($b['start_time']);
            $be = time_to_min($b['end_time']);
            if ($examStart < $be && $bs < $examEnd) {
                $v[] = 'H2 Unavailable: blocked ' . fmt_time($b['start_time']) . '–' . fmt_time($b['end_time']) . ' on this date'
                    . (!empty($b['reason']) ? ' (' . $b['reason'] . ')' : '') . '.';
            }
        }
        // H3 overlap / gap
        $gap = max(0, (int) $s['min_gap_minutes']);
        $sameDayRows = $ctx['sameDay'][$tid] ?? [];
        foreach ($sameDayRows as $o) {
            $os = time_to_min($o['start_time']);
            $oe = time_to_min($o['end_time']);
            if ($examStart < $oe && $os < $examEnd) {
                $v[] = 'H3 Schedule conflict: overlaps with ' . $o['exam_code'] . ' (' . fmt_time($o['start_time']) . '–' . fmt_time($o['end_time']) . ').';
            } elseif ($gap > 0 && $examStart < $oe + $gap && $os < $examEnd + $gap) {
                $v[] = 'H3 Rest gap: less than ' . $gap . ' minutes between this exam and ' . $o['exam_code'] . '.';
            }
        }
        // H4 duplicate on the same examination
        if (!empty($ctx['assigned'][$tid])) {
            $v[] = 'H4 Duplicate: already assigned to this examination.';
        }
        // H6 eligibility rules
        $max = (int) $s['max_exams_per_day'];
        if ($t['max_per_day'] !== null && $t['max_per_day'] !== '' && (int) $t['max_per_day'] > 0) {
            $max = $max > 0 ? min($max, (int) $t['max_per_day']) : (int) $t['max_per_day'];   // teacher may only be stricter
        }
        if ($max > 0 && count($sameDayRows) >= $max) {
            $v[] = 'H6 Eligibility: reached the daily limit of ' . $max . ' assignment(s) on this date.';
        }
        // H7 teacher's own maximum number of exams in the scheduling period
        if (empty($ctx['skip_cap']) && $t['max_assignments'] !== null && $t['max_assignments'] !== '') {
            $have = (int) (($ctx['work'][$tid]['total'] ?? 0));
            if ($have >= (int) $t['max_assignments'] && $this->inPeriod($exam['exam_date'])) {
                $v[] = 'H7 Teacher limit: the teacher set a maximum of ' . (int) $t['max_assignments'] . ' exam(s) for the period and already has ' . $have . '.';
            }
        }
        // Proctors from ANY department may supervise any examination (no department rule).
        return $v;
    }

    /** H5: capacity check (assigned proctors must not exceed the required number). */
    public function capacityViolation(array $exam, int $ignoreAssignmentId = 0): ?string
    {
        $count = $this->activeCount((int) $exam['id'], $ignoreAssignmentId);
        if ($count >= (int) $exam['required_proctors']) {
            return 'H5 Capacity: examination already has ' . $count . ' of ' . (int) $exam['required_proctors'] . ' required proctors.';
        }
        return null;
    }

    /** Validate ONE teacher for ONE exam – used by manual assignment, replace and approve. */
    public function validateTeacher(int $teacherId, array $exam, int $ignoreAssignmentId = 0): array
    {
        $teacher = null;
        foreach ($this->allTeachers() as $t) {
            if ((int) $t['id'] === $teacherId) { $teacher = $t; break; }
        }
        if (!$teacher) {
            return ['Teacher not found.'];
        }
        $ctx = $this->buildContext($exam, $ignoreAssignmentId);
        if ($ignoreAssignmentId) {   // the ignored assignment must not count against the teacher's own limit
            $ig = $this->getAssignment($ignoreAssignmentId);
            if ($ig && $ig['status'] !== 'Cancelled') {
                $igExam = $this->getExam((int) $ig['examination_id']);
                if ($igExam && $this->inPeriod($igExam['exam_date']) && isset($ctx['work'][(int) $ig['teacher_id']])) {
                    $ctx['work'][(int) $ig['teacher_id']]['total']--;
                }
            }
        }
        $errors = $this->hardViolations($teacher, $exam, $ctx);
        if ($cap = $this->capacityViolation($exam, $ignoreAssignmentId)) {
            $errors[] = $cap;
        }
        return $errors;
    }

    /* ================================================================
     *  EVALUATION + RANKING  (constraint filtering, then load balancing)
     * ================================================================ */

    public function evaluate(int $examId, array $excludeTeacherIds = []): array
    {
        $exam = $this->getExam($examId);
        if (!$exam) {
            throw new SchedulingException(['Examination not found.']);
        }
        $required = (int) $exam['required_proctors'];
        $existing = $this->activeCount($examId);
        $ctx = $this->buildContext($exam);
        $work = $ctx['work'];
        $s = $this->settings;
        $weight = (float) $s['dept_weight'];

        $declined = [];
        $dq = $this->pdo->prepare("SELECT teacher_id FROM proctor_assignments WHERE examination_id = ? AND declined_at IS NOT NULL AND status = 'Cancelled'");
        $dq->execute([$examId]);
        foreach ($dq->fetchAll(PDO::FETCH_COLUMN) as $d) $declined[(int) $d] = true;

        $eligible = [];
        $excluded = [];
        foreach ($this->allTeachers() as $t) {
            $tid = (int) $t['id'];
            $w = $work[$tid] ?? self::emptyWorkload();
            $row = [
                'teacher_id' => $tid, 'teacher_no' => $t['teacher_no'], 'name' => $t['full_name'],
                'dept_code' => $t['dept_code'], 'workload' => $w['total'], 'all_time' => $w['all_time'],
                'upcoming' => $w['upcoming'], 'completed' => $w['completed'], 'last_date' => $w['last_date'],
            ];
            $viol = $this->hardViolations($t, $exam, $ctx);
            if (isset($declined[$tid])) {
                $viol[] = 'H7 Declined: this teacher declined this examination earlier.';
            }
            if (in_array($tid, $excludeTeacherIds, true)) {
                $viol[] = 'Rejected: proposed in the previous run and rejected by the administrator (regenerate).';
            }
            if ($viol) {
                $row['reasons'] = $viol;
                $excluded[] = $row;
                continue;
            }
            $penalty = 0.0;
            $note = [];
            $row['penalty'] = $penalty;
            $row['penalty_note'] = $note;
            $row['score'] = $w['total'];            // fairness: fewest assigned subjects first ...
            $row['hours'] = round($w['hours'], 2);   // ... then fewest total examination hours
            $eligible[] = $row;
        }

        // FAIR PAIRING RANKING: fewest assigned subjects, then fewest exam hours, least recently assigned, then teacher number.
        usort($eligible, function ($a, $b) {
            return [$a['score'], $a['hours'], $a['last_date'] ?? '', $a['teacher_no']] <=> [$b['score'], $b['hours'], $b['last_date'] ?? '', $b['teacher_no']];
        });
        foreach ($eligible as $i => &$r) {
            $r['rank'] = $i + 1;
        }
        unset($r);

        return [
            'exam' => $exam, 'required' => $required, 'existing' => $existing,
            'needed' => max(0, $required - $existing), 'eligible' => $eligible, 'excluded' => $excluded,
            'settings' => $s,
        ];
    }

    /* ================================================================
     *  AUTOMATIC ASSIGNMENT
     * ================================================================ */

    private function tx(callable $fn)
    {
        $own = !$this->pdo->inTransaction();
        if ($own) $this->pdo->beginTransaction();
        try {
            $r = $fn();
            if ($own) $this->pdo->commit();
            return $r;
        } catch (Throwable $e) {
            if ($own && $this->pdo->inTransaction()) $this->pdo->rollBack();
            throw $e;
        }
    }

    /**
     * Generate proctor assignments for ONE examination. Saves them as "Pending Review".
     * Teachers in $excludeTeacherIds are skipped (used by "Regenerate").
     */
    public function generate(int $examId, int $userId, array $excludeTeacherIds = []): array
    {
        return $this->tx(function () use ($examId, $userId, $excludeTeacherIds) {
            $ev = $this->evaluate($examId, $excludeTeacherIds);
            $exam = $ev['exam'];
            $result = [
                'exam' => $exam, 'needed' => $ev['needed'], 'required' => $ev['required'], 'existing' => $ev['existing'],
                'assigned' => 0, 'warnings' => [], 'messages' => [], 'selected' => [], 'eligible' => $ev['eligible'],
                'excluded' => $ev['excluded'], 'explanations' => [], 'run_id' => null, 'ok' => true,
            ];

            if ($exam['status'] !== 'Scheduled') {
                $result['ok'] = false;
                $result['warnings'][] = 'Examination ' . $exam['exam_code'] . ' is ' . $exam['status'] . '; no proctors can be assigned.';
                return $result;
            }
            if ($ev['needed'] <= 0) {
                $result['messages'][] = $exam['exam_code'] . ' already has all ' . $ev['required'] . ' required proctor(s). Nothing to generate.';
                return $result;
            }

            $take = array_slice($ev['eligible'], 0, $ev['needed']);          // H5: never more than needed
            $cutoff = $take ? end($take)['score'] : null;
            $selectedIds = [];

            foreach ($take as $row) {
                $reason = 'Rank ' . $row['rank'] . ' of ' . count($ev['eligible']) . ' eligible proctors: ' . $row['workload'] . ' subject(s) and '
                    . $row['hours'] . ' exam hour(s) so far; last assigned '
                    . ($row['last_date'] ? fmt_date($row['last_date']) : 'never') . '. All hard constraints passed.';
                $status = $this->autoAccept ? 'Confirmed' : 'Pending Review';
                if ($this->autoAccept) $reason .= ' Accepted automatically (auto-accept was switched on for this run).';
                $id = $this->saveAssignment($examId, $row['teacher_id'], $status, 'Automatic', $row['score'], $row['rank'], $reason, $userId);
                $selectedIds[$row['teacher_id']] = true;
                $row['assignment_id'] = $id;
                $row['explanation'] = $reason;
                $result['selected'][] = $row;
                $this->tell((int) $row['teacher_id'], 'New proctor assignment', $this->autoAccept ? 'You were assigned as proctor (accepted automatically):' : 'You were proposed as proctor (pending admin review):', $exam, 'assignment_new');
            }
            $result['assigned'] = count($take);
            if ($this->autoAccept && $take) $this->paperSync($examId, $userId);   // accepted -> its paper record is created now

            // explanation for every teacher (selected / eligible-not-selected / excluded)
            foreach ($ev['eligible'] as $row) {
                if (isset($selectedIds[$row['teacher_id']])) {
                    $result['explanations'][] = ['teacher_id' => $row['teacher_id'], 'teacher_no' => $row['teacher_no'], 'name' => $row['name'], 'decision' => 'Selected',
                        'rank' => $row['rank'], 'score' => $row['score'], 'text' => 'Selected: passed all hard constraints and has the fewest assigned subjects (' . $row['score'] . ') and exam hours (' . $row['hours'] . ').'];
                } else {
                    $why = $cutoff !== null && $row['score'] > $cutoff
                        ? 'already has more subjects (' . $row['score'] . ') than the selected proctor (' . $cutoff . ')'
                        : 'same number of subjects but more exam hours or a more recent assignment (tie-breakers)';
                    $result['explanations'][] = ['teacher_id' => $row['teacher_id'], 'teacher_no' => $row['teacher_no'], 'name' => $row['name'], 'decision' => 'Eligible – not selected',
                        'rank' => $row['rank'], 'score' => $row['score'], 'text' => 'Eligible but not selected: ' . $why . '.'];
                }
            }
            foreach ($ev['excluded'] as $row) {
                $result['explanations'][] = ['teacher_id' => $row['teacher_id'], 'teacher_no' => $row['teacher_no'], 'name' => $row['name'], 'decision' => 'Excluded',
                    'rank' => null, 'score' => null, 'text' => implode(' ', $row['reasons'])];
            }

            if ($result['assigned'] < $ev['needed']) {
                $result['ok'] = false;
                $result['warnings'][] = 'Insufficient eligible teachers for ' . $exam['exam_code'] . ': ' . $ev['needed'] . ' proctor(s) needed but only '
                    . count($ev['eligible']) . ' teacher(s) passed all hard constraints. ' . $result['assigned']
                    . ' assigned; ' . ($ev['needed'] - $result['assigned']) . ' slot(s) left open. No invalid assignment was forced. '
                    . 'Free up teachers (availability, schedule, settings) or assign manually.';
            }

            $st = $this->pdo->prepare('INSERT INTO assignment_runs (examination_id, run_by, needed, assigned, explanation, created_at) VALUES (?,?,?,?,?,?)');
            $st->execute([$examId, $userId, $ev['needed'], $result['assigned'], json_encode($result['explanations']), now()]);
            $result['run_id'] = (int) $this->pdo->lastInsertId();

            log_activity('assignments_generated', 'examination', $examId, null, 'Pending Review',
                'Auto-generated ' . $result['assigned'] . ' of ' . $ev['needed'] . ' proctor(s) for ' . $exam['exam_code'], $userId);
            return $result;
        });
    }

    /** Generate for every Scheduled exam that still lacks proctors (chronological order). */
    public function generateAll(int $userId, ?string $from = null, ?string $to = null, ?int $dept = null, ?int $semester = null, ?int $year = null): array
    {
        return $this->tx(function () use ($userId, $from, $to, $dept, $semester, $year) {
            $sql = "SELECT e.id FROM examinations e
                 WHERE e.status = 'Scheduled'
                   AND (SELECT COUNT(*) FROM proctor_assignments a WHERE a.examination_id = e.id AND a.status <> 'Cancelled') < e.required_proctors";
            $params = [];
            if ($from) { $sql .= ' AND e.exam_date >= ?'; $params[] = $from; }
            if ($to) { $sql .= ' AND e.exam_date <= ?'; $params[] = $to; }
            if ($dept) { $sql .= ' AND e.department_id = ?'; $params[] = $dept; }
            if ($semester) { $sql .= ' AND e.id IN (SELECT x.examination_id FROM exam_sections x JOIN class_sections c ON c.id = x.section_id WHERE c.semester = ?)'; $params[] = $semester; }
            if ($year) { $sql .= ' AND e.id IN (SELECT x.examination_id FROM exam_sections x JOIN class_sections c ON c.id = x.section_id JOIN year_configs y ON y.id = c.year_config_id WHERE y.year_level = ?)'; $params[] = $year; }
            $st = $this->pdo->prepare($sql . ' ORDER BY e.exam_date, e.start_time, e.id');
            $st->execute($params);
            $ids = $st->fetchAll(PDO::FETCH_COLUMN);
            // FAIR PAIRING: look at ALL proctors for EVERY exam slot first, then fill the most constrained slots (fewest free proctors) before the easy ones,
            // so a proctor who is the only one free at some time is not used up by an easier slot. Every pick still re-checks all hard constraints.
            $slots = [];
            foreach ($ids as $id) {
                $ev = $this->evaluate((int) $id);
                $slots[] = ['id' => (int) $id, 'slack' => count($ev['eligible']) - $ev['needed'], 'd' => $ev['exam']['exam_date'], 't' => $ev['exam']['start_time']];
            }
            usort($slots, fn($a, $b) => [$a['slack'], $a['d'], $a['t'], $a['id']] <=> [$b['slack'], $b['d'], $b['t'], $b['id']]);
            $results = [];
            foreach ($slots as $sl) {
                $results[] = $this->generate($sl['id'], $userId);
            }
            usort($results, fn($a, $b) => [$a['exam']['exam_date'], $a['exam']['start_time'], $a['exam']['id']] <=> [$b['exam']['exam_date'], $b['exam']['start_time'], $b['exam']['id']]);
            return $results;
        });
    }

    /** A teacher declines (rejects) one of HIS OWN assignments. The admin sees it in the Reassignment Center. */
    public function decline(int $assignmentId, int $teacherId, string $reason): array
    {
        $a = $this->getAssignment($assignmentId);
        if (!$a || (int) $a['teacher_id'] !== $teacherId) {
            return ['ok' => false, 'errors' => ['You can only decline your own assignments.']];
        }
        if (!in_array($a['status'], ['Pending Review', 'Confirmed'], true)) {
            return ['ok' => false, 'errors' => ['Only Pending or Confirmed assignments can be declined.']];
        }
        $reason = trim($reason);
        if (mb_strlen($reason) < 3) return ['ok' => false, 'errors' => ['Please give a short reason (at least 3 characters).']];
        $exam = $this->getExam((int) $a['examination_id']);
        if (!$exam || $exam['status'] !== 'Scheduled' || strtotime($exam['exam_date'] . ' ' . $exam['start_time']) <= time()) {
            return ['ok' => false, 'errors' => ['This examination already started or is no longer scheduled; it cannot be declined.']];
        }
        if ($b = $this->paperBlock((int) $a['examination_id'], $teacherId)) {
            return ['ok' => false, 'errors' => [$b]];
        }
        $this->tx(function () use ($a, $exam, $reason, $teacherId) {
            $this->pdo->prepare("UPDATE proctor_assignments SET status='Cancelled', declined_at=?, decline_reason=?, decline_resolved=0, updated_at=? WHERE id=?")
                ->execute([now(), mb_substr($reason, 0, 255), now(), $a['id']]);
            $uid = teacher_user_id($teacherId);
            notify_admins('Proctor declined an assignment', ($_SESSION['user']['name'] ?? 'A teacher') . ' declined ' . $exam['exam_code'] . ' (' . fmt_date($exam['exam_date']) . '): ' . $reason, 'assignment_declined', 'admin/declined.php');
            log_activity('assignment_declined', 'assignment', (int) $a['id'], $a['status'], 'Cancelled', 'Teacher declined ' . $exam['exam_code'] . ': ' . $reason, $uid);
            $this->paperSync((int) $exam['id'], (int) $uid);
        });
        return ['ok' => true, 'errors' => []];
    }

    /** Auto-assign again for an exam that lost a proctor to a decline (decliners are never re-picked). */
    public function reassignDeclined(int $examId, int $userId): array
    {
        return $this->tx(function () use ($examId, $userId) {
            $r = $this->generate($examId, $userId);
            if ($this->activeCount($examId) >= (int) $r['required']) {
                $this->pdo->prepare('UPDATE proctor_assignments SET decline_resolved = 1 WHERE examination_id = ? AND declined_at IS NOT NULL AND decline_resolved = 0')->execute([$examId]);
            }
            return $r;
        });
    }

    /** Removes the proposals nobody answered yet (Pending Review) for upcoming exams. Confirmed ones are never touched. */
    public function clearUnanswered(int $userId, ?string $from = null, ?string $to = null, ?int $dept = null, ?int $semester = null, ?int $year = null): int
    {
        $sql = "SELECT a.id FROM proctor_assignments a JOIN examinations e ON e.id = a.examination_id
                WHERE a.status = 'Pending Review' AND e.status = 'Scheduled' AND e.exam_date >= ?";
        $params = [$from && $from > date('Y-m-d') ? $from : date('Y-m-d')];
        if ($to) { $sql .= ' AND e.exam_date <= ?'; $params[] = $to; }
        if ($dept) { $sql .= ' AND e.department_id = ?'; $params[] = $dept; }
        if ($semester) { $sql .= ' AND e.id IN (SELECT x.examination_id FROM exam_sections x JOIN class_sections c ON c.id = x.section_id WHERE c.semester = ?)'; $params[] = $semester; }
        if ($year) { $sql .= ' AND e.id IN (SELECT x.examination_id FROM exam_sections x JOIN class_sections c ON c.id = x.section_id JOIN year_configs y ON y.id = c.year_config_id WHERE y.year_level = ?)'; $params[] = $year; }
        $st = $this->pdo->prepare($sql); $st->execute($params);
        $ids = $st->fetchAll(PDO::FETCH_COLUMN);
        foreach ($ids as $id) $this->pdo->prepare("UPDATE proctor_assignments SET status='Cancelled', updated_at=? WHERE id=?")->execute([now(), $id]);
        if ($ids) log_activity('unanswered_cleared', 'assignment', null, null, null, count($ids) . ' unanswered proposal(s) removed', $userId);
        return count($ids);
    }

    /** The teacher himself accepts a proposed (Pending Review) assignment. */
    public function acceptByTeacher(int $assignmentId, int $teacherId): array
    {
        $a = $this->getAssignment($assignmentId);
        if (!$a || (int) $a['teacher_id'] !== $teacherId) return ['ok' => false, 'errors' => ['You can only accept your own assignments.']];
        $uid = teacher_user_id($teacherId) ?: 0;
        $r = $this->approve($assignmentId, $uid);
        if ($r['ok']) {
            $exam = $this->getExam((int) $a['examination_id']);
            notify_admins('Proctor accepted', ($_SESSION['user']['name'] ?? 'A teacher') . ' accepted ' . $exam['exam_code'] . ' (' . fmt_date($exam['exam_date']) . ').', 'assignment_accepted', 'admin/assignments.php');
        }
        return $r;
    }

    public static function pendingDeclines(PDO $pdo): int
    {
        try {
            return (int) $pdo->query("SELECT COUNT(*) FROM proctor_assignments WHERE declined_at IS NOT NULL AND decline_resolved = 0")->fetchColumn();
        } catch (Throwable $e) {
            return 0;
        }
    }

    /** Reject the pending proposals of an exam and generate different proctors. */
    public function regenerate(int $examId, int $userId): array
    {
        return $this->tx(function () use ($examId, $userId) {
            $rejected = $this->rejectPending($examId, $userId, true);
            return $this->generate($examId, $userId, $rejected);
        });
    }

    /* ================================================================
     *  MANUAL ASSIGNMENT / REPLACE / APPROVE / REJECT
     * ================================================================ */

    private function saveAssignment(int $examId, int $teacherId, string $status, string $type, ?float $score, ?int $rank, string $reason, int $userId): int
    {
        $st = $this->pdo->prepare('SELECT id, status FROM proctor_assignments WHERE examination_id = ? AND teacher_id = ?');
        $st->execute([$examId, $teacherId]);
        $ex = $st->fetch();
        $confirmedAt = $status === 'Confirmed' ? now() : null;
        if ($ex) {
            if ($ex['status'] !== 'Cancelled') {
                throw new SchedulingException(['H4 Duplicate: already assigned to this examination.']);
            }
            // re-activate the cancelled row (unique key examination_id + teacher_id)
            $this->pdo->prepare('UPDATE proctor_assignments SET status=?, assignment_type=?, workload_score=?, rank_position=?, selection_reason=?, assigned_by=?, confirmed_at=?, updated_at=?, declined_at=NULL, decline_reason=NULL, decline_resolved=0 WHERE id=?')
                ->execute([$status, $type, $score, $rank, $reason, $userId, $confirmedAt, now(), $ex['id']]);
            return (int) $ex['id'];
        }
        $this->pdo->prepare('INSERT INTO proctor_assignments (examination_id, teacher_id, status, assignment_type, workload_score, rank_position, selection_reason, assigned_by, confirmed_at, created_at)
                             VALUES (?,?,?,?,?,?,?,?,?,?)')
            ->execute([$examId, $teacherId, $status, $type, $score, $rank, $reason, $userId, $confirmedAt, now()]);
        return (int) $this->pdo->lastInsertId();
    }

    private function workloadScoreOf(int $teacherId): float
    {
        $w = $this->workloadMap()[$teacherId] ?? self::emptyWorkload();
        return (float) $w['total'];
    }

    /** @return array{ok:bool,errors:string[],id?:int} */
    public function manualAssign(int $examId, int $teacherId, string $status, int $userId): array
    {
        $exam = $this->getExam($examId);
        if (!$exam) return ['ok' => false, 'errors' => ['Examination not found.']];
        if (!in_array($status, ['Pending Review', 'Confirmed'], true)) $status = 'Confirmed';

        $errors = $this->validateTeacher($teacherId, $exam);   // SAME hard constraints as automatic mode
        if ($errors) return ['ok' => false, 'errors' => $errors];

        try {
            $id = $this->tx(function () use ($exam, $examId, $teacherId, $status, $userId) {
                $score = $this->workloadScoreOf($teacherId);
                $id = $this->saveAssignment($examId, $teacherId, $status, 'Manual', $score, null, 'Manually assigned by administrator (hard constraints validated).', $userId);
                $this->tell($teacherId, $status === 'Confirmed' ? 'Assignment confirmed' : 'New proctor assignment', 'You were assigned as proctor:', $exam,
                    $status === 'Confirmed' ? 'assignment_confirmed' : 'assignment_new');
                log_activity('assignment_manual', 'examination', $examId, null, $status, 'Manual assignment of teacher #' . $teacherId . ' to ' . $exam['exam_code'], $userId);
                $this->paperSync($examId, $userId);
                return $id;
            });
        } catch (SchedulingException $e) {
            return ['ok' => false, 'errors' => $e->errors];
        }
        return ['ok' => true, 'errors' => [], 'id' => $id];
    }

    /** keep the automatic paper transaction in step (see PaperTracker::sync) */
    private function paperSync(int $examId, int $userId = 0): void
    {
        if (class_exists('PaperTracker')) PaperTracker::sync($this->pdo, $examId, $userId);
    }

    private function getAssignment(int $id): ?array
    {
        $st = $this->pdo->prepare('SELECT * FROM proctor_assignments WHERE id = ?');
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }

    /** Paper safety: a proctor holding released/received papers must return them first. */
    private function paperBlock(int $examId, int $teacherId): ?string
    {
        $st = $this->pdo->prepare("SELECT status FROM paper_distribution WHERE examination_id = ? AND proctor_teacher_id = ? AND status IN ('Released','Received')");
        $st->execute([$examId, $teacherId]);
        return $st->fetchColumn() ? 'This proctor currently holds released examination papers. Record the paper return first.' : null;
    }

    public function replaceAssignment(int $assignmentId, int $newTeacherId, int $userId): array
    {
        $a = $this->getAssignment($assignmentId);
        if (!$a || !in_array($a['status'], ['Pending Review', 'Confirmed'], true)) {
            return ['ok' => false, 'errors' => ['Only Pending Review or Confirmed assignments can be replaced.']];
        }
        if ((int) $a['teacher_id'] === $newTeacherId) {
            return ['ok' => false, 'errors' => ['Choose a different teacher.']];
        }
        if ($b = $this->paperBlock((int) $a['examination_id'], (int) $a['teacher_id'])) {
            return ['ok' => false, 'errors' => [$b]];
        }
        $exam = $this->getExam((int) $a['examination_id']);
        try {
            $this->tx(function () use ($a, $exam, $newTeacherId, $userId, $assignmentId) {
                $errors = $this->validateTeacher($newTeacherId, $exam, $assignmentId); // old assignment ignored
                if ($errors) throw new SchedulingException($errors);

                $this->pdo->prepare("UPDATE proctor_assignments SET status='Cancelled', updated_at=? WHERE id=?")->execute([now(), $assignmentId]);
                $score = $this->workloadScoreOf($newTeacherId);
                $this->saveAssignment((int) $exam['id'], $newTeacherId, $a['status'], 'Manual', $score, null,
                    'Replacement for assignment #' . $assignmentId . ' (hard constraints validated).', $userId);
                if ($uid = teacher_user_id((int) $a['teacher_id'])) {
                    notify($uid, 'Assignment changed', 'You were replaced as proctor of ' . $exam['exam_code'] . '.', 'schedule_update', 'teacher/assignments.php');
                }
                $this->tell($newTeacherId, 'New proctor assignment', 'You were assigned as proctor:', $exam, 'assignment_new');
                $this->paperSync((int) $exam['id'], $userId);
                log_activity('assignment_replaced', 'examination', (int) $exam['id'], 'teacher #' . $a['teacher_id'], 'teacher #' . $newTeacherId, 'Replaced proctor on ' . $exam['exam_code'], $userId);
            });
        } catch (SchedulingException $e) {
            return ['ok' => false, 'errors' => $e->errors];
        }
        return ['ok' => true, 'errors' => []];
    }

    /** Pending Review -> Confirmed (hard constraints are re-checked at approval time). */
    public function approve(int $assignmentId, int $userId): array
    {
        $a = $this->getAssignment($assignmentId);
        if (!$a || $a['status'] !== 'Pending Review') {
            return ['ok' => false, 'errors' => ['Only Pending Review assignments can be approved.']];
        }
        $exam = $this->getExam((int) $a['examination_id']);
        $errors = $this->validateTeacher((int) $a['teacher_id'], $exam, $assignmentId);
        if ($errors) return ['ok' => false, 'errors' => $errors];

        $this->tx(function () use ($a, $exam, $userId) {
            $this->pdo->prepare("UPDATE proctor_assignments SET status='Confirmed', confirmed_at=?, updated_at=? WHERE id=?")->execute([now(), now(), $a['id']]);
            $this->tell((int) $a['teacher_id'], 'Assignment confirmed', 'Your proctor assignment is confirmed:', $exam, 'assignment_confirmed');
            log_activity('assignment_approved', 'assignment', (int) $a['id'], 'Pending Review', 'Confirmed', 'Approved proctor for ' . $exam['exam_code'], $userId);
            $this->paperSync((int) $exam['id'], $userId);
        });
        return ['ok' => true, 'errors' => []];
    }

    public function approveExam(int $examId, int $userId): array
    {
        $st = $this->pdo->prepare("SELECT id FROM proctor_assignments WHERE examination_id = ? AND status = 'Pending Review' ORDER BY id");
        $st->execute([$examId]);
        $ok = 0;
        $errors = [];
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) {
            $r = $this->approve((int) $id, $userId);
            if ($r['ok']) $ok++; else $errors = array_merge($errors, $r['errors']);
        }
        return ['ok' => $ok > 0 && !$errors, 'approved' => $ok, 'errors' => $errors];
    }

    /** Cancel Pending Review assignments of an exam. Returns the teacher ids that were rejected. */
    public function rejectPending(int $examId, int $userId, bool $silent = false): array
    {
        $st = $this->pdo->prepare("SELECT id, teacher_id FROM proctor_assignments WHERE examination_id = ? AND status = 'Pending Review'");
        $st->execute([$examId]);
        $rows = $st->fetchAll();
        $ids = [];
        foreach ($rows as $r) {
            $this->pdo->prepare("UPDATE proctor_assignments SET status='Cancelled', updated_at=? WHERE id=?")->execute([now(), $r['id']]);
            $ids[] = (int) $r['teacher_id'];
            if (!$silent && ($uid = teacher_user_id((int) $r['teacher_id']))) {
                notify($uid, 'Assignment cancelled', 'A proposed proctor assignment was rejected by the administrator.', 'schedule_update', 'teacher/assignments.php');
            }
        }
        if ($rows) {
            log_activity('assignments_rejected', 'examination', $examId, 'Pending Review', 'Cancelled', count($rows) . ' pending assignment(s) rejected', $userId);
        }
        return $ids;
    }

    /** Cancel a single Pending Review / Confirmed assignment. */
    public function cancelAssignment(int $assignmentId, int $userId): array
    {
        $a = $this->getAssignment($assignmentId);
        if (!$a || !in_array($a['status'], ['Pending Review', 'Confirmed'], true)) {
            return ['ok' => false, 'errors' => ['Only Pending Review or Confirmed assignments can be cancelled.']];
        }
        if ($b = $this->paperBlock((int) $a['examination_id'], (int) $a['teacher_id'])) {
            return ['ok' => false, 'errors' => [$b]];
        }
        $exam = $this->getExam((int) $a['examination_id']);
        $this->tx(function () use ($a, $exam, $userId) {
            $this->pdo->prepare("UPDATE proctor_assignments SET status='Cancelled', updated_at=? WHERE id=?")->execute([now(), $a['id']]);
            if ($uid = teacher_user_id((int) $a['teacher_id'])) {
                notify($uid, 'Assignment cancelled', 'Your proctor assignment for ' . $exam['exam_code'] . ' was cancelled.', 'schedule_update', 'teacher/assignments.php');
            }
            log_activity('assignment_cancelled', 'assignment', (int) $a['id'], $a['status'], 'Cancelled', 'Cancelled proctor for ' . $exam['exam_code'], $userId);
            $this->paperSync((int) $exam['id'], $userId);
        });
        return ['ok' => true, 'errors' => []];
    }

    /* ================================================================
     *  EXAM LIFECYCLE HELPERS
     * ================================================================ */

    public function completeExam(int $examId, int $userId): void
    {
        $this->tx(function () use ($examId, $userId) {
            $exam = $this->getExam($examId);
            $now = now();
            $this->pdo->prepare("UPDATE examinations SET status='Completed' WHERE id=?")->execute([$examId]);
            $this->pdo->prepare("UPDATE proctor_assignments SET status='Completed', updated_at=? WHERE examination_id=? AND status='Confirmed'")->execute([$now, $examId]);
            $this->pdo->prepare("UPDATE proctor_assignments SET status='Cancelled', updated_at=? WHERE examination_id=? AND status='Pending Review'")->execute([$now, $examId]);
            log_activity('exam_completed', 'examination', $examId, $exam['status'], 'Completed', 'Examination ' . $exam['exam_code'] . ' marked completed', $userId);
        });
    }

    public function cancelExam(int $examId, int $userId): void
    {
        $this->tx(function () use ($examId, $userId) {
            $exam = $this->getExam($examId);
            $st = $this->pdo->prepare("SELECT teacher_id FROM proctor_assignments WHERE examination_id = ? AND status IN ('Pending Review','Confirmed')");
            $st->execute([$examId]);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $tid) {
                if ($uid = teacher_user_id((int) $tid)) {
                    notify($uid, 'Examination cancelled', 'Examination ' . $exam['exam_code'] . ' (' . $exam['name'] . ') was cancelled.', 'schedule_update', 'teacher/assignments.php');
                }
            }
            $this->pdo->prepare("UPDATE examinations SET status='Cancelled' WHERE id=?")->execute([$examId]);
            $this->pdo->prepare("UPDATE proctor_assignments SET status='Cancelled', updated_at=? WHERE examination_id=? AND status IN ('Pending Review','Confirmed')")->execute([now(), $examId]);
            log_activity('exam_cancelled', 'examination', $examId, $exam['status'], 'Cancelled', 'Examination ' . $exam['exam_code'] . ' cancelled', $userId);
        });
    }

    /**
     * When an exam is moved, check that every already-assigned teacher still satisfies the hard constraints.
     * @return string[] conflicts (empty = safe to reschedule)
     */
    public function rescheduleConflicts(array $newExam): array
    {
        $out = [];
        $ctx = $this->buildContext($newExam);
        $ctx['assigned'] = [];  // the teachers are already on THIS exam, that is not a duplicate
        $ctx['skip_cap'] = true;
        $st = $this->pdo->prepare("SELECT teacher_id FROM proctor_assignments WHERE examination_id = ? AND status IN ('Pending Review','Confirmed')");
        $st->execute([$newExam['id']]);
        $ids = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
        foreach ($this->allTeachers() as $t) {
            if (!in_array((int) $t['id'], $ids, true)) continue;
            $copy = $newExam;
            $copy['status'] = 'Scheduled';
            foreach ($this->hardViolations($t, $copy, $ctx) as $v) {
                $out[] = $t['full_name'] . ': ' . $v;
            }
        }
        return $out;
    }

    /* ================================================================
     *  REPORT DATA FOR THE LOAD-BALANCING PAGE
     * ================================================================ */

    /** @return array rows ranked by workload (ascending) for every teacher */
    public function workloadRanking(): array
    {
        $work = $this->workloadMap();
        $rows = [];
        foreach ($this->allTeachers() as $t) {
            $w = $work[(int) $t['id']] ?? self::emptyWorkload();
            $rows[] = $t + ['workload' => $w['total'], 'hours' => round($w['hours'], 2), 'all_time' => $w['all_time'], 'upcoming' => $w['upcoming'],
                            'completed' => $w['completed'], 'new_assignments' => $w['pending'], 'last_date' => $w['last_date']];
        }
        usort($rows, fn($a, $b) => [$a['workload'], $a['hours'], $a['last_date'] ?? '', $a['teacher_no']] <=> [$b['workload'], $b['hours'], $b['last_date'] ?? '', $b['teacher_no']]);
        foreach ($rows as $i => &$r) $r['rank'] = $i + 1;
        return $rows;
    }

    /** The window(s) a teacher said he can proctor on the weekday of $date, e.g. "8:00 AM – 5:00 PM". */
    public function availabilityText(int $teacherId, string $date): string
    {
        $st = $this->pdo->prepare('SELECT start_time, end_time FROM teacher_weekly_availability WHERE teacher_id = ? AND weekday = ? ORDER BY start_time');
        $st->execute([$teacherId, (int) date('N', strtotime($date))]);
        $w = array_map(fn($r) => fmt_time($r['start_time']) . ' – ' . fmt_time($r['end_time']), $st->fetchAll());
        return $w ? implode(', ', $w) : 'not set';
    }
}
