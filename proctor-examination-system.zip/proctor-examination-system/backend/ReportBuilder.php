<?php
/**
 * backend/ReportBuilder.php – builds the data of every report (same data for HTML, CSV and PDF).
 */
class ReportBuilder
{
    public const TYPES = [
        'assignments' => 'Proctor assignment report',
        'schedule'    => 'Examination schedule report',
        'workload'    => 'Teacher workload report',
        'papers'      => 'Examination paper distribution report',
        'pending'     => 'Returned and pending examination papers',
        'history'     => 'Assignment history',
    ];

    private PDO $pdo;

    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    /** Common filters on the examinations table (alias e). */
    private function examFilter(array $f, array &$params, bool $withTeacher = false, string $teacherCol = 'a.teacher_id'): string
    {
        $w = '';
        if (!empty($f['from']) && valid_date($f['from'])) { $w .= ' AND e.exam_date >= ?'; $params[] = $f['from']; }
        if (!empty($f['to']) && valid_date($f['to'])) { $w .= ' AND e.exam_date <= ?'; $params[] = $f['to']; }
        if (!empty($f['dept'])) { $w .= ' AND e.department_id = ?'; $params[] = (int) $f['dept']; }
        if (!empty($f['subject'])) { $w .= ' AND e.subject_id = ?'; $params[] = (int) $f['subject']; }
        if (!empty($f['status']) && in_array($f['status'], ['Scheduled', 'Completed', 'Cancelled'], true)) { $w .= ' AND e.status = ?'; $params[] = $f['status']; }
        if ($withTeacher && !empty($f['teacher'])) { $w .= " AND $teacherCol = ?"; $params[] = (int) $f['teacher']; }
        return $w;
    }

    private function q(string $sql, array $p): array
    {
        $st = $this->pdo->prepare($sql);
        $st->execute($p);
        return $st->fetchAll();
    }

    public function build(string $type, array $f): array
    {
        if (!isset(self::TYPES[$type])) $type = 'assignments';
        $title = self::TYPES[$type];
        $p = [];
        switch ($type) {
            case 'schedule':
                $rows = $this->q("SELECT e.*, s.code AS sc, d.code AS dc, r.name AS rn FROM examinations e JOIN subjects s ON s.id = e.subject_id
                    JOIN departments d ON d.id = e.department_id JOIN rooms r ON r.id = e.room_id WHERE 1=1" . $this->examFilter($f, $p) . ' ORDER BY e.exam_date, e.start_time', $p);
                $names = [];
                foreach ($this->q("SELECT a.examination_id, u.full_name FROM proctor_assignments a JOIN teachers t ON t.id = a.teacher_id JOIN users u ON u.id = t.user_id WHERE a.status <> 'Cancelled' ORDER BY u.full_name", []) as $n) {
                    $names[$n['examination_id']][] = $n['full_name'];
                }
                $out = [];
                foreach ($rows as $r) {
                    $assigned = $names[$r['id']] ?? [];
                    $out[] = [$r['exam_code'], $r['name'], $r['sc'], $r['dc'], fmt_date($r['exam_date']), time_range($r['start_time'], $r['end_time']), $r['rn'],
                              count($assigned) . '/' . $r['required_proctors'], implode('; ', $assigned), $r['status']];
                }
                return $this->wrap($title, ['Exam ID', 'Examination', 'Subject', 'Dept', 'Date', 'Time', 'Room', 'Proctors', 'Assigned proctors', 'Status'], $out, $f);

            case 'workload':
                $teachers = $this->q('SELECT t.id, t.teacher_no, t.department_id, u.full_name, d.code AS dc FROM teachers t JOIN users u ON u.id = t.user_id JOIN departments d ON d.id = t.department_id ORDER BY t.teacher_no', []);
                $stat = [];
                $rows = $this->q("SELECT a.teacher_id, a.status FROM proctor_assignments a JOIN examinations e ON e.id = a.examination_id WHERE a.status <> 'Cancelled'" . $this->examFilter($f, $p, true), $p);
                foreach ($rows as $r) {
                    $stat[$r['teacher_id']]['all'] = ($stat[$r['teacher_id']]['all'] ?? 0) + 1;
                    $stat[$r['teacher_id']][$r['status']] = ($stat[$r['teacher_id']][$r['status']] ?? 0) + 1;
                }
                $out = [];
                foreach ($teachers as $t) {
                    if (!empty($f['teacher']) && (int) $f['teacher'] !== (int) $t['id']) continue;
                    if (!empty($f['dept']) && (int) $f['dept'] !== (int) $t['department_id']) continue;
                    $s = $stat[$t['id']] ?? [];
                    $out[] = [$t['teacher_no'], $t['full_name'], $t['dc'], $s['all'] ?? 0, $s['Pending Review'] ?? 0, $s['Confirmed'] ?? 0, $s['Completed'] ?? 0];
                }
                usort($out, fn($a, $b) => $b[3] <=> $a[3]);
                return $this->wrap($title, ['Teacher ID', 'Name', 'Dept', 'Total assignments', 'Pending review', 'Confirmed', 'Completed'], $out, $f);

            case 'papers':
            case 'pending':
                $extra = $type === 'pending' ? " AND p.status <> 'Completed'" : '';
                $rows = $this->q("SELECT p.*, e.exam_code, e.name AS en, e.exam_date, tu.full_name AS pn, t.teacher_no
                    FROM paper_distribution p JOIN examinations e ON e.id = p.examination_id LEFT JOIN teachers t ON t.id = p.proctor_teacher_id LEFT JOIN users tu ON tu.id = t.user_id
                    WHERE 1=1 $extra" . $this->examFilter($f, $p, true, 'p.proctor_teacher_id') . ' ORDER BY e.exam_date, p.id', $p);
                $out = [];
                foreach ($rows as $r) {
                    $pend = in_array($r['status'], ['Pending', 'Preparing', 'Ready for Release'], true) ? 'Pending release' : (in_array($r['status'], ['Released', 'Received'], true) ? 'Pending return' : ($r['status'] === 'Returned' ? 'Pending verification' : 'Done'));
                    $row = [$r['transaction_no'], $r['exam_code'] . ' ' . $r['en'], fmt_date($r['exam_date']), $r['pn'] ? $r['teacher_no'] . ' ' . $r['pn'] : '—', $r['paper_sets'],
                            fmt_dt($r['prepared_at']), fmt_dt($r['released_at']), fmt_dt($r['received_at']), fmt_dt($r['returned_at']), $r['status']];
                    if ($type === 'pending') $row[] = $pend;
                    $out[] = $row;
                }
                $cols = ['Transaction', 'Examination', 'Exam date', 'Proctor', 'Sets', 'Prepared', 'Released', 'Received', 'Returned', 'Status'];
                if ($type === 'pending') $cols[] = 'Pending action';
                return $this->wrap($title, $cols, $out, $f);

            case 'history':
                $rows = $this->q("SELECT a.*, e.exam_code, e.exam_date, e.start_time, e.end_time, u.full_name, t.teacher_no, au.full_name AS by_name
                    FROM proctor_assignments a JOIN examinations e ON e.id = a.examination_id JOIN teachers t ON t.id = a.teacher_id JOIN users u ON u.id = t.user_id
                    LEFT JOIN users au ON au.id = a.assigned_by WHERE 1=1" . $this->examFilter($f, $p, true) . ' ORDER BY a.id DESC', $p);
                $out = [];
                foreach ($rows as $r) $out[] = [$r['exam_code'], fmt_date($r['exam_date']), $r['teacher_no'] . ' ' . $r['full_name'], $r['assignment_type'], $r['status'], $r['by_name'] ?: 'System', fmt_dt($r['created_at']), fmt_dt($r['updated_at'])];
                return $this->wrap($title, ['Exam', 'Exam date', 'Teacher', 'Type', 'Status', 'Assigned by', 'Created', 'Last update'], $out, $f);

            default: // assignments
                $rows = $this->q("SELECT a.*, e.exam_code, e.name AS en, e.exam_date, e.start_time, e.end_time, s.code AS sc, d.code AS dc, r.name AS rn, u.full_name, t.teacher_no
                    FROM proctor_assignments a JOIN examinations e ON e.id = a.examination_id JOIN subjects s ON s.id = e.subject_id JOIN departments d ON d.id = e.department_id
                    JOIN rooms r ON r.id = e.room_id JOIN teachers t ON t.id = a.teacher_id JOIN users u ON u.id = t.user_id
                    WHERE a.status <> 'Cancelled'" . $this->examFilter($f, $p, true) . ' ORDER BY e.exam_date, e.start_time, e.exam_code, u.full_name', $p);
                $out = [];
                foreach ($rows as $r) $out[] = [$r['exam_code'], $r['en'], $r['sc'], $r['dc'], fmt_date($r['exam_date']), time_range($r['start_time'], $r['end_time']), $r['rn'], $r['teacher_no'] . ' ' . $r['full_name'], $r['assignment_type'], $r['status']];
                return $this->wrap($title, ['Exam ID', 'Examination', 'Subject', 'Dept', 'Date', 'Time', 'Room', 'Proctor', 'Type', 'Status'], $out, $f);
        }
    }

    private function wrap(string $title, array $cols, array $rows, array $f): array
    {
        $parts = [];
        if (!empty($f['from'])) $parts[] = 'From ' . $f['from'];
        if (!empty($f['to'])) $parts[] = 'To ' . $f['to'];
        foreach (['dept' => ['departments', 'code', 'Department'], 'subject' => ['subjects', 'code', 'Subject']] as $k => [$tbl, $col, $lbl]) {
            if (!empty($f[$k])) { $st = $this->pdo->prepare("SELECT $col FROM $tbl WHERE id = ?"); $st->execute([(int) $f[$k]]); $parts[] = $lbl . ': ' . $st->fetchColumn(); }
        }
        if (!empty($f['teacher'])) { $st = $this->pdo->prepare('SELECT u.full_name FROM teachers t JOIN users u ON u.id = t.user_id WHERE t.id = ?'); $st->execute([(int) $f['teacher']]); $parts[] = 'Teacher: ' . $st->fetchColumn(); }
        if (!empty($f['status'])) $parts[] = 'Exam status: ' . $f['status'];
        return ['title' => $title, 'columns' => $cols, 'rows' => $rows, 'filters' => $parts ? implode(' | ', $parts) : 'No filters (all records)'];
    }
}
