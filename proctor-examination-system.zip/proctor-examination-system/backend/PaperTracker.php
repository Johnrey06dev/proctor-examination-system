<?php
/**
 * backend/PaperTracker.php
 * Examination paper distribution workflow with a full status history.
 *
 *  Pending -> Preparing -> Ready for Release -> Released -> Received -> Returned -> Completed
 *  (auto)    (admin)       (admin)             (admin)     (PROCTOR)   (admin)     (admin verifies)
 *
 * One record per SUBJECT + SECTION (= one examination). It appears automatically when the proctor of that subject accepts.
 *
 * Every status change runs in a database transaction and writes a row to
 * paper_tracking_history, an activity log and (where relevant) a notification.
 */
class PaperTracker
{
    public const STATUSES = ['Pending', 'Preparing', 'Ready for Release', 'Released', 'Received', 'Returned', 'Completed'];

    /** extra copies printed on top of the number of examinees */
    public const EXTRA_COPIES = 5;

    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    /**
     * Keeps the paper record of ONE subject + section (= one examination) in step with its proctor (called after every assignment change):
     *  - the proctor ACCEPTED (Confirmed)            -> the record is created once, status Pending, copies = students + 5 extra;
     *  - proctor replaced / re-assigned              -> the SAME record is kept (never a second one);
     *  - rejected or removed and nobody is assigned  -> a record still Pending is removed (no accepted assignment any more);
     *  - once the admin started working on it (Preparing and later) it is never deleted by a proctor change;
     *  - while Pending / Preparing the copies follow the number of students of the section.
     */
    public static function sync(PDO $pdo, int $examId, int $userId = 0): void
    {
        $x = $pdo->prepare('SELECT * FROM examinations WHERE id = ?');
        $x->execute([$examId]);
        $exam = $x->fetch();
        if (!$exam) return;
        $conf = (int) $pdo->query("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id = $examId AND status = 'Confirmed'")->fetchColumn();
        $act = (int) $pdo->query("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id = $examId AND status IN ('Pending Review','Confirmed')")->fetchColumn();
        $stu = (int) $pdo->query("SELECT COALESCE(SUM(examinees),0) FROM exam_sections WHERE examination_id = $examId")->fetchColumn();
        $copies = max(1, $stu + self::EXTRA_COPIES);
        $pdo->prepare('UPDATE examinations SET paper_sets = ? WHERE id = ?')->execute([$copies, $examId]);
        $p = $pdo->query("SELECT id, status, paper_sets FROM paper_distribution WHERE examination_id = $examId")->fetch();
        if (!$userId) $userId = (int) ($_SESSION['user']['id'] ?? 0) ?: (int) $pdo->query("SELECT id FROM users WHERE role = 'admin' ORDER BY id LIMIT 1")->fetchColumn();
        if ($exam['status'] === 'Scheduled' && $conf > 0 && !$p && $exam['exam_date'] >= date('Y-m-d')) {
            (new self($pdo))->create($examId, $copies, $userId, 'Created automatically: the proctor accepted. ' . $stu . ' students + ' . self::EXTRA_COPIES . ' extra copies.');
        } elseif ($p && in_array($p['status'], ['Pending', 'Preparing'], true)) {
            if ($p['status'] === 'Pending' && $act === 0 && $exam['status'] === 'Scheduled') {
                $pdo->prepare('DELETE FROM paper_tracking_history WHERE distribution_id = ?')->execute([$p['id']]);
                $pdo->prepare('DELETE FROM paper_distribution WHERE id = ?')->execute([$p['id']]);
            } elseif ((int) $p['paper_sets'] !== $copies) {
                $pdo->prepare('UPDATE paper_distribution SET paper_sets = ? WHERE id = ?')->execute([$copies, $p['id']]);
            }
        }
    }

    public function get(int $id): ?array
    {
        $st = $this->pdo->prepare(
            'SELECT p.*, e.exam_code, e.name AS exam_name, e.exam_date, e.start_time, e.end_time, e.status AS exam_status,
                    r.name AS room_name, s.code AS subject_code,
                    tu.full_name AS proctor_name, t.teacher_no AS proctor_no, ru.full_name AS recorded_by_name
             FROM paper_distribution p
             JOIN examinations e ON e.id = p.examination_id
             JOIN rooms r ON r.id = e.room_id
             JOIN subjects s ON s.id = e.subject_id
             LEFT JOIN teachers t ON t.id = p.proctor_teacher_id
             LEFT JOIN users tu ON tu.id = t.user_id
             LEFT JOIN users ru ON ru.id = p.recorded_by
             WHERE p.id = ?'
        );
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }

    public function history(int $id): array
    {
        $st = $this->pdo->prepare(
            'SELECT h.*, u.full_name AS changed_by_name FROM paper_tracking_history h
             LEFT JOIN users u ON u.id = h.changed_by WHERE h.distribution_id = ? ORDER BY h.id'
        );
        $st->execute([$id]);
        return $st->fetchAll();
    }

    /** STEP 1 – create the record (status Pending: the proctor accepted, papers wait for preparation). */
    public function create(int $examId, int $sets, int $userId, string $remarks = ''): array
    {
        $st = $this->pdo->prepare('SELECT * FROM examinations WHERE id = ?');
        $st->execute([$examId]);
        $exam = $st->fetch();
        if (!$exam) return ['ok' => false, 'errors' => ['Examination not found.']];
        if ($exam['status'] === 'Cancelled') return ['ok' => false, 'errors' => ['A cancelled examination cannot have a paper transaction.']];
        if ($sets < 1) return ['ok' => false, 'errors' => ['Number of paper sets must be at least 1.']];

        $dup = $this->pdo->prepare('SELECT transaction_no FROM paper_distribution WHERE examination_id = ?');
        $dup->execute([$examId]);
        if ($no = $dup->fetchColumn()) {
            return ['ok' => false, 'errors' => ['This examination already has paper transaction ' . $no . '.']];
        }

        $own = !$this->pdo->inTransaction();
        if ($own) $this->pdo->beginTransaction();
        try {
            $this->pdo->prepare('INSERT INTO paper_distribution (transaction_no, examination_id, paper_sets, status, recorded_by, remarks, created_at) VALUES (?,?,?,?,?,?,?)')
                ->execute(['TMP-' . bin2hex(random_bytes(6)), $examId, $sets, 'Pending', $userId, $remarks ?: null, now()]);
            $id = (int) $this->pdo->lastInsertId();
            $no = 'PD-' . date('Ymd') . '-' . str_pad((string) $id, 4, '0', STR_PAD_LEFT);
            $this->pdo->prepare('UPDATE paper_distribution SET transaction_no = ? WHERE id = ?')->execute([$no, $id]);
            $this->addHistory($id, null, 'Pending', $userId, $remarks !== '' ? $remarks : 'Transaction created');
            log_activity('paper_created', 'paper', $id, null, 'Pending', 'Paper transaction ' . $no . ' created for ' . $exam['exam_code'], $userId);
            if ($own) $this->pdo->commit();
        } catch (Throwable $e) {
            if ($own && $this->pdo->inTransaction()) $this->pdo->rollBack();
            throw $e;
        }
        return ['ok' => true, 'id' => $id, 'errors' => []];
    }

    /** A record whose transaction is Completed (returned papers verified) may be deleted by the admin. */
    public function deleteCompleted(int $id, int $userId): array
    {
        $p = $this->get($id);
        if (!$p) return ['ok' => false, 'errors' => ['Record not found.']];
        if ($p['status'] !== 'Completed') return ['ok' => false, 'errors' => ['Only a Completed paper record can be deleted.']];
        $own = !$this->pdo->inTransaction();
        if ($own) $this->pdo->beginTransaction();
        try {
            $this->pdo->prepare('DELETE FROM paper_tracking_history WHERE distribution_id = ?')->execute([$id]);
            $this->pdo->prepare('DELETE FROM paper_distribution WHERE id = ?')->execute([$id]);
            log_activity('paper_deleted', 'paper', $id, 'Completed', null, 'Completed paper record ' . $p['transaction_no'] . ' deleted');
            if ($own) $this->pdo->commit();
        } catch (Throwable $e) { if ($own && $this->pdo->inTransaction()) $this->pdo->rollBack(); return ['ok' => false, 'errors' => ['Could not delete: ' . $e->getMessage()]]; }
        return ['ok' => true, 'errors' => []];
    }

    /** STEP 1a – The admin starts preparing the papers: Pending -> Preparing. */
    public function startPreparing(int $id, int $userId, string $remarks = ''): array
    {
        return $this->move($id, ['Pending'], 'Preparing', [], $userId, $remarks ?: 'Papers are being prepared');
    }

    /** STEP 1b – Papers prepared and counted: Preparing -> Ready for Release. */
    public function markReady(int $id, int $userId, string $remarks): array
    {
        return $this->move($id, ['Pending', 'Preparing'], 'Ready for Release', ['prepared_at' => now()], $userId, $remarks ?: 'Papers prepared and ready for release');
    }

    /** Admin status dropdown: moves to the next allowed step (Released goes to the proctor who accepted). */
    public function advance(int $id, string $to, int $userId): array
    {
        $p = $this->get($id);
        if (!$p) return ['ok' => false, 'errors' => ['Record not found.']];
        if ($to === 'Preparing') return $this->startPreparing($id, $userId);
        if ($to === 'Ready for Release') return $this->markReady($id, $userId, '');
        if ($to === 'Released') {
            $st = $this->pdo->prepare("SELECT teacher_id FROM proctor_assignments WHERE examination_id = ? AND status = 'Confirmed' ORDER BY id LIMIT 1");
            $st->execute([$p['examination_id']]);
            $tid = (int) $st->fetchColumn();
            if (!$tid) return ['ok' => false, 'errors' => ['No proctor has accepted this subject yet, so the papers cannot be released.']];
            return $this->release($id, $tid, $userId, '');
        }
        return ['ok' => false, 'errors' => ['Choose Preparing, Ready or Released.']];
    }

    /** STEP 2 – Release to an assigned (Confirmed) proctor. */
    public function release(int $id, int $teacherId, int $userId, string $remarks): array
    {
        $p = $this->get($id);
        if (!$p) return ['ok' => false, 'errors' => ['Transaction not found.']];
        $st = $this->pdo->prepare("SELECT COUNT(*) FROM proctor_assignments WHERE examination_id = ? AND teacher_id = ? AND status = 'Confirmed'");
        $st->execute([$p['examination_id'], $teacherId]);
        if (!(int) $st->fetchColumn()) {
            return ['ok' => false, 'errors' => ['Papers can only be released to a proctor with a Confirmed assignment for this examination.']];
        }
        $tn = $this->pdo->prepare('SELECT t.teacher_no, u.full_name, u.id AS uid FROM teachers t JOIN users u ON u.id = t.user_id WHERE t.id = ?');
        $tn->execute([$teacherId]);
        $t = $tn->fetch();
        return $this->move($id, ['Ready for Release'], 'Released', ['released_at' => now(), 'proctor_teacher_id' => $teacherId], $userId,
            $remarks ?: 'Released to proctor ' . $t['teacher_no'] . ' (' . $t['full_name'] . ')',
            function () use ($p, $t) {
                notify((int) $t['uid'], 'Examination papers released', 'Papers for ' . $p['exam_code'] . ' (' . $p['paper_sets'] . ' set(s)) were released to you. Please confirm receipt.', 'paper_release', 'teacher/papers.php');
            });
    }

    /** STEP 3 – The assigned proctor confirms receipt (ownership enforced here, in the backend). */
    public function confirmReceipt(int $id, int $teacherId, int $userId = 0): array
    {
        $p = $this->get($id);
        if (!$p) return ['ok' => false, 'errors' => ['Transaction not found.']];
        if ((int) $p['proctor_teacher_id'] !== $teacherId) {
            return ['ok' => false, 'errors' => ['You can only confirm receipt of papers released to you.']];
        }
        $uid = $userId ?: (teacher_user_id($teacherId) ?? 0);
        return $this->move($id, ['Released'], 'Received', ['received_at' => now()], $uid, 'Receipt confirmed by proctor',
            function () use ($p) {
                notify_admins('Paper receipt confirmed', 'Proctor ' . $p['proctor_name'] . ' confirmed receipt of papers for ' . $p['exam_code'] . '.', 'paper_receipt', 'admin/paper_view.php?id=' . $p['id']);
            }, $teacherId);
    }

    /** STEP 4 – Admin records the return of the papers. */
    public function recordReturn(int $id, int $userId, string $remarks): array
    {
        $p = $this->get($id);
        return $this->move($id, ['Received'], 'Returned', ['returned_at' => now()], $userId, $remarks ?: 'Papers returned by proctor',
            function () use ($p) {
                if ($p && $p['proctor_teacher_id'] && ($uid = teacher_user_id((int) $p['proctor_teacher_id']))) {
                    notify($uid, 'Examination papers returned', 'The return of papers for ' . $p['exam_code'] . ' was recorded. Thank you.', 'paper_return', 'teacher/papers.php');
                }
            });
    }

    /** STEP 5 – Admin verifies the return: Returned -> Completed. */
    public function complete(int $id, int $userId, string $remarks): array
    {
        return $this->move($id, ['Returned'], 'Completed', ['completed_at' => now()], $userId, $remarks ?: 'Return verified; transaction completed');
    }

    /* ------------------------------------------------------------- */

    private function addHistory(int $id, ?string $old, string $new, int $userId, string $remarks): void
    {
        $this->pdo->prepare('INSERT INTO paper_tracking_history (distribution_id, old_status, new_status, changed_by, remarks, created_at) VALUES (?,?,?,?,?,?)')
            ->execute([$id, $old, $new, $userId ?: null, mb_substr($remarks, 0, 255), now()]);
    }

    /**
     * Generic, transaction-safe status move. The UPDATE has "WHERE status = old"
     * so two simultaneous clicks cannot move the same transaction twice.
     */
    private function move(int $id, array $from, string $to, array $set, int $userId, string $remarks, ?callable $after = null, ?int $ownerTeacherId = null): array
    {
        $p = $this->get($id);
        if (!$p) return ['ok' => false, 'errors' => ['Transaction not found.']];
        if (!in_array($p['status'], $from, true)) {
            return ['ok' => false, 'errors' => ['Invalid step: transaction ' . $p['transaction_no'] . ' is "' . $p['status'] . '", but this action requires "' . implode('" or "', $from) . '".']];
        }
        if ($p['exam_status'] === 'Cancelled') {
            return ['ok' => false, 'errors' => ['The examination was cancelled.']];
        }

        $own = !$this->pdo->inTransaction();
        if ($own) $this->pdo->beginTransaction();
        try {
            $cols = ['status = ?', 'remarks = ?'];
            $vals = [$to, $remarks !== '' ? mb_substr($remarks, 0, 255) : $p['remarks']];
            foreach ($set as $c => $v) { $cols[] = "$c = ?"; $vals[] = $v; }
            if ($ownerTeacherId === null && $userId) { $cols[] = 'recorded_by = ?'; $vals[] = $userId; }
            $vals[] = $id;
            $vals[] = $p['status'];
            $st = $this->pdo->prepare('UPDATE paper_distribution SET ' . implode(', ', $cols) . ' WHERE id = ? AND status = ?');
            $st->execute($vals);
            if ($st->rowCount() !== 1) {
                throw new RuntimeException('The transaction was changed by someone else. Please refresh.');
            }
            $this->addHistory($id, $p['status'], $to, $userId, $remarks);
            log_activity('paper_' . strtolower(str_replace(' ', '_', $to)), 'paper', $id, $p['status'], $to,
                $p['transaction_no'] . ' (' . $p['exam_code'] . '): ' . $p['status'] . ' → ' . $to, $userId ?: null);
            if ($after) $after();
            if ($own) $this->pdo->commit();
        } catch (Throwable $e) {
            if ($own && $this->pdo->inTransaction()) $this->pdo->rollBack();
            return ['ok' => false, 'errors' => [$e->getMessage()]];
        }
        return ['ok' => true, 'errors' => []];
    }

    /** Timeline structure for the UI. */
    public static function timeline(array $p): array
    {
        $order = array_flip(self::STATUSES);
        $cur = $order[$p['status']] ?? 0;
        $dates = [
            'Pending' => $p['created_at'], 'Preparing' => $p['created_at'], 'Ready for Release' => $p['prepared_at'], 'Released' => $p['released_at'],
            'Received' => $p['received_at'], 'Returned' => $p['returned_at'], 'Completed' => $p['completed_at'],
        ];
        $who = [
            'Pending' => 'Automatic (proctor accepted)', 'Preparing' => 'Admin', 'Ready for Release' => 'Admin', 'Released' => 'Admin → ' . ($p['proctor_name'] ?: 'proctor'),
            'Received' => 'Proctor confirmation', 'Returned' => 'Admin', 'Completed' => 'Admin verification',
        ];
        $out = [];
        foreach (self::STATUSES as $i => $s) {
            $out[] = ['status' => $s, 'state' => $i < $cur ? 'done' : ($i === $cur ? 'current' : 'todo'),
                      'date' => $dates[$s], 'who' => $who[$s]];
        }
        // the last step is "done" once reached
        if ($p['status'] === 'Completed') { $out[count($out) - 1]['state'] = 'done'; }
        return $out;
    }
}
