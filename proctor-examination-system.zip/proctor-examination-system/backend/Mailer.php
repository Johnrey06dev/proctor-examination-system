<?php
/**
 * backend/Mailer.php – tiny dependency-free SMTP client (works on plain XAMPP, needs the openssl extension for Gmail).
 */
class Mailer
{
    /** Sender Gmail + App Password: saved in Security & OTP (database) or, if empty, config/mail.php */
    public static function user(): string { $v = trim((string) (get_settings()['mail_user'] ?? '')); return $v !== '' ? $v : MAIL_USERNAME; }
    public static function pass(): string { $v = (string) (get_settings()['mail_pass'] ?? ''); return $v !== '' ? $v : MAIL_PASSWORD; }

    public static function configured(): bool
    {
        return self::user() !== '' && self::pass() !== '';
    }

    private static function read($fp): array
    {
        $code = 0; $text = '';
        while (($line = fgets($fp, 1024)) !== false) {
            $text .= $line;
            $code = (int) substr($line, 0, 3);
            if (isset($line[3]) && $line[3] === ' ') break;
            if (!isset($line[3])) break;
        }
        return [$code, trim($text)];
    }

    private static function cmd($fp, string $line, array $expect): string
    {
        fwrite($fp, $line . "\r\n");
        [$code, $text] = self::read($fp);
        if (!in_array($code, $expect, true)) {
            throw new RuntimeException('SMTP error (' . $code . '): ' . $text);
        }
        return $text;
    }

    /** Sends one message. Throws RuntimeException with a readable reason on failure. */
    public static function send(string $to, string $subject, string $text, ?string $html = null): void
    {
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('Invalid recipient e-mail address.');
        }
        if (!self::configured()) {
            throw new RuntimeException('E-mail is not configured. Enter the sender Gmail and App Password in Admin > Security & OTP.');
        }
        $enc = MAIL_ENCRYPTION;
        if (($enc === 'tls' || $enc === 'ssl') && !extension_loaded('openssl')) {
            throw new RuntimeException('The PHP "openssl" extension is disabled. In C:\\xampp\\php\\php.ini enable extension=openssl and restart Apache.');
        }
        $remote = ($enc === 'ssl' ? 'ssl://' : 'tcp://') . MAIL_HOST . ':' . MAIL_PORT;
        $fp = @stream_socket_client($remote, $errno, $errstr, 15);
        if (!$fp) {
            throw new RuntimeException('Cannot connect to the mail server ' . MAIL_HOST . ':' . MAIL_PORT . ' (' . $errstr . '). Check your internet connection / firewall.');
        }
        stream_set_timeout($fp, 15);
        try {
            [$c, $t] = self::read($fp);
            if ($c !== 220) throw new RuntimeException('SMTP greeting failed: ' . $t);
            $me = 'localhost';
            self::cmd($fp, 'EHLO ' . $me, [250]);
            if ($enc === 'tls') {
                self::cmd($fp, 'STARTTLS', [220]);
                if (!@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                    throw new RuntimeException('Could not start a secure (TLS) connection with the mail server.');
                }
                self::cmd($fp, 'EHLO ' . $me, [250]);
            }
            self::cmd($fp, 'AUTH LOGIN', [334]);
            self::cmd($fp, base64_encode(self::user()), [334]);
            try {
                self::cmd($fp, base64_encode(self::pass()), [235]);
            } catch (RuntimeException $e) {
                throw new RuntimeException('Login to the mail server failed. For Gmail use an App Password (see config/mail.php). Details: ' . $e->getMessage());
            }
            $from = MAIL_FROM_EMAIL !== '' ? MAIL_FROM_EMAIL : self::user();
            self::cmd($fp, 'MAIL FROM:<' . $from . '>', [250]);
            self::cmd($fp, 'RCPT TO:<' . $to . '>', [250, 251]);
            self::cmd($fp, 'DATA', [354]);

            $boundary = 'b' . bin2hex(random_bytes(8));
            $h = 'From: =?UTF-8?B?' . base64_encode(MAIL_FROM_NAME) . '?= <' . $from . ">\r\n"
               . 'To: <' . $to . ">\r\n"
               . 'Subject: =?UTF-8?B?' . base64_encode($subject) . "?=\r\n"
               . 'Date: ' . date('r') . "\r\n"
               . 'Message-ID: <' . bin2hex(random_bytes(8)) . '@proctorsys.local>' . "\r\n"
               . "MIME-Version: 1.0\r\n";
            if ($html !== null) {
                $h .= "Content-Type: multipart/alternative; boundary=\"$boundary\"\r\n\r\n"
                    . "--$boundary\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($text)) . "\r\n"
                    . "--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($html)) . "\r\n"
                    . "--$boundary--\r\n";
            } else {
                $h .= "Content-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($text)) . "\r\n";
            }
            fwrite($fp, $h . "\r\n.\r\n");
            [$c, $t] = self::read($fp);
            if ($c !== 250) throw new RuntimeException('The mail server rejected the message: ' . $t);
            @fwrite($fp, "QUIT\r\n");
        } finally {
            fclose($fp);
        }
    }

    /** Branded HTML wrapper for a message. */
    public static function html(string $title, string $bodyHtml): string
    {
        return '<div style="font-family:Segoe UI,Arial,sans-serif;background:#f4f6f9;padding:24px"><div style="max-width:520px;margin:auto;background:#fff;border-radius:10px;overflow:hidden;border:1px solid #e1e6ee">'
            . '<div style="background:#0b2545;color:#fff;padding:16px 22px;font-size:18px">&#127891; ProctorSys</div>'
            . '<div style="padding:22px;color:#1c2736"><h2 style="margin:0 0 12px;color:#0b2545;font-size:18px">' . htmlspecialchars($title) . '</h2>' . $bodyHtml . '</div>'
            . '<div style="padding:12px 22px;background:#f4f6f9;color:#6b7a90;font-size:12px">Proctor Assignment &amp; Examination Paper Distribution System</div></div></div>';
    }
}
