<?php
/**
 * backend/SimplePDF.php – minimal dependency-free table PDF writer (A4 landscape, Helvetica).
 * Works on plain XAMPP without Composer. Text only (Latin characters).
 */
class SimplePDF
{
    private const W = 842, H = 595, M = 30;

    private static function enc(string $s): string
    {
        $c = @iconv('UTF-8', 'windows-1252//TRANSLIT//IGNORE', $s);
        $c = $c === false ? $s : $c;
        return str_replace(['\\', '(', ')', "\r", "\n"], ['\\\\', '\\(', '\\)', ' ', ' '], $c);
    }

    private static function fit(string $s, float $width, float $size): string
    {
        $max = max(1, (int) floor($width / ($size * 0.5)));
        return mb_strlen($s) > $max ? mb_substr($s, 0, max(1, $max - 1)) . '.' : $s;
    }

    public static function table(string $title, string $subtitle, array $cols, array $rows): string
    {
        $usableW = self::W - 2 * self::M;
        $weights = [];
        foreach ($cols as $i => $c) {
            $len = mb_strlen($c);
            foreach (array_slice($rows, 0, 40) as $r) $len = max($len, mb_strlen((string) ($r[$i] ?? '')));
            $weights[$i] = max(6, min(36, $len));
        }
        $sum = array_sum($weights);
        $widths = array_map(fn($w) => $usableW * $w / $sum, $weights);

        $rowH = 15; $size = 7.5;
        $top = self::H - 95;                 // table starts below the title band
        $perPage = (int) floor(($top - 40) / $rowH) - 1;
        $chunks = array_chunk($rows ?: [[]], max(1, $perPage));
        $total = count($chunks);
        $pages = [];

        foreach ($chunks as $pi => $chunk) {
            $c = '';
            // title band
            $c .= "0.043 0.145 0.27 rg " . self::M . " " . (self::H - 62) . " $usableW 40 re f\n";
            $c .= "BT /F2 14 Tf 1 1 1 rg " . (self::M + 10) . " " . (self::H - 46) . " Td (" . self::enc($title) . ") Tj ET\n";
            $c .= "BT /F1 8 Tf 0.8 0.85 0.95 rg " . (self::M + 10) . " " . (self::H - 58) . " Td (" . self::enc('Proctor Assignment & Examination Paper Distribution System · Generated ' . date('M d, Y g:i A')) . ") Tj ET\n";
            $c .= "BT /F1 8 Tf 0.3 0.3 0.3 rg " . self::M . " " . (self::H - 78) . " Td (" . self::enc(self::fit($subtitle, $usableW, 8)) . ") Tj ET\n";
            // header row
            $y = $top;
            $c .= "0.91 0.93 0.96 rg " . self::M . " " . ($y - 4) . " $usableW $rowH re f\n";
            $x = self::M;
            foreach ($cols as $i => $h) {
                $c .= "BT /F2 $size Tf 0.043 0.145 0.27 rg " . ($x + 3) . " " . ($y) . " Td (" . self::enc(self::fit($h, $widths[$i] - 4, $size)) . ") Tj ET\n";
                $x += $widths[$i];
            }
            $y -= $rowH;
            foreach ($chunk as $r) {
                if (!$r) break;
                $x = self::M;
                foreach ($cols as $i => $_) {
                    $c .= "BT /F1 $size Tf 0.1 0.1 0.1 rg " . ($x + 3) . " $y Td (" . self::enc(self::fit((string) ($r[$i] ?? ''), $widths[$i] - 4, $size)) . ") Tj ET\n";
                    $x += $widths[$i];
                }
                $c .= "0.88 G 0.4 w " . self::M . " " . ($y - 4) . " m " . (self::M + $usableW) . " " . ($y - 4) . " l S\n";
                $y -= $rowH;
            }
            if (!$rows) $c .= "BT /F1 9 Tf 0.4 0.4 0.4 rg " . self::M . " $y Td (No records match the selected filters.) Tj ET\n";
            $c .= "BT /F1 7.5 Tf 0.4 0.4 0.4 rg " . self::M . " 18 Td (" . self::enc(count($rows) . ' record(s)') . ") Tj ET\n";
            $c .= "BT /F1 7.5 Tf 0.4 0.4 0.4 rg " . (self::W - self::M - 60) . " 18 Td (Page " . ($pi + 1) . " of $total) Tj ET\n";
            $pages[] = $c;
        }

        // assemble PDF objects
        $objs = [];
        $objs[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $kids = [];
        $n = 5;
        $pageObjs = [];
        foreach ($pages as $content) {
            $pageNo = $n; $contentNo = $n + 1; $n += 2;
            $kids[] = "$pageNo 0 R";
            $pageObjs[$pageNo] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " . self::W . " " . self::H . "] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents $contentNo 0 R >>";
            $pageObjs[$contentNo] = "<< /Length " . strlen($content) . " >>\nstream\n" . $content . "endstream";
        }
        $objs[2] = '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . count($kids) . ' >>';
        $objs[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objs[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        foreach ($pageObjs as $k => $v) $objs[$k] = $v;
        ksort($objs);

        $out = "%PDF-1.4\n";
        $offsets = [];
        foreach ($objs as $num => $body) {
            $offsets[$num] = strlen($out);
            $out .= "$num 0 obj\n$body\nendobj\n";
        }
        $xref = strlen($out);
        $out .= "xref\n0 " . (count($objs) + 1) . "\n0000000000 65535 f \n";
        foreach ($offsets as $o) $out .= sprintf("%010d 00000 n \n", $o);
        $out .= "trailer\n<< /Size " . (count($objs) + 1) . " /Root 1 0 R >>\nstartxref\n$xref\n%%EOF";
        return $out;
    }
}
